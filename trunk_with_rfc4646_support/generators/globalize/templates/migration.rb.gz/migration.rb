require 'csv'

class GlobalizeMigration < ActiveRecord::Migration

  def self.up
    create_table :globalize_countries, :force => true do |t|
      t.column :code,               :string, :limit => 2
      t.column :english_name,       :string
      t.column :date_format,        :string
      t.column :currency_format,    :string
      t.column :currency_code,      :string, :limit => 3
      t.column :thousands_sep,      :string, :limit => 2
      t.column :decimal_sep,        :string, :limit => 2
      t.column :currency_decimal_sep,        :string, :limit => 2
      t.column :number_grouping_scheme,      :string
    end
    add_index :globalize_countries, :code

    create_table :globalize_translations, :force => true do |t|
      t.column :type,                :string
      t.column :tr_key,              :string
      t.column :translatable_type,   :string
      t.column :translatable_id,     :integer
      t.column :facet,               :string
      t.column :language_id,         :integer
      t.column :pluralization_index, :integer
      t.column :text,                :text
      t.column :namespace,           :string
    end

    add_index :globalize_translations, [ :tr_key, :language_id ]
    add_index :globalize_translations, [ :translatable_type, :translatable_id, :language_id ], :name => 'globalize_translations_translatable_type_and_id_and_language'

    create_table :globalize_languages, :force => true do |t|
      t.column :tag,            :string
      t.column :primary_subtag, :string
      t.column :english_name,   :string
      t.column :native_name,    :string
      t.column :direction,      :string
      t.column :pluralization,  :string
      t.column :country_id,     :integer
    end

    add_index :globalize_languages, :tag
    add_index :globalize_languages, :country_id

    # add in defaults
    load_from_csv 'globalize_countries',    csv_file( :country_data )
    load_from_csv 'globalize_languages',    csv_file( :language_data )
    load_from_csv 'globalize_translations', csv_file( :translation_data )
  end

  def self.down
    drop_table :globalize_countries
    drop_table :globalize_translations
    drop_table :globalize_languages
  end

  def self.csv_file filename
    path = File.join File.dirname( __FILE__ ), '../../../data', "#{filename}.csv"
    File.open( path ).read
  end

  def self.load_from_csv(table_name, data)
    column_clause = nil
    is_header = false
    cnx = ActiveRecord::Base.connection
    ActiveRecord::Base.silence do
      reader = CSV::Reader.create(data)

      columns = reader.shift.map {|column_name| cnx.quote_column_name(column_name) }
      column_clause = columns.join(', ')

      reader.each do |row|
        next if row.first.nil? # skip blank lines
        raise "No table name defined" if !table_name
        raise "No header defined" if !column_clause
        values_clause = row.map {|v| cnx.quote(v).gsub('\\n', "\n").gsub('\\r', "\r") }.join(', ')
        sql = "INSERT INTO #{table_name} (#{column_clause}) VALUES (#{values_clause})"
        cnx.insert(sql)
      end
    end
  end
end