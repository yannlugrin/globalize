require 'csv'

class GlobalizeMigration < ActiveRecord::Migration

  def self.up
    create_table :globalize_countries, :force => true do |t|
      t.column :code,               :string, :limit => 2
      t.column :english_name,       :string
      t.column :date_format,        :string
      t.column :currency_format,    :string
      t.column :currency_code,      :string, :limit => 3
      t.column :thousands_sep,      :string, :limit => 2
      t.column :decimal_sep,        :string, :limit => 2
      t.column :currency_decimal_sep,        :string, :limit => 2
      t.column :number_grouping_scheme,      :string
    end
    add_index :globalize_countries, :code

    create_table :globalize_translations, :force => true do |t|
      t.column :type,           :string
      t.column :tr_key,         :string
      t.column :table_name,     :string
      t.column :item_id,        :integer
      t.column :facet,          :string
      t.column :language_id,    :integer
      t.column :pluralization_index, :integer
      t.column :text,           :text
    end

    add_index :globalize_translations, [ :tr_key, :language_id ]
    add_index :globalize_translations, [ :table_name, :item_id, :language_id ], , :name => 'globalize_translations_table_name_and_item_and_language'

    create_table :globalize_languages, :force => true do |t|
      t.column :iso_639_1, :string, :limit => 2
      t.column :iso_639_2, :string, :limit => 3
      t.column :iso_639_3, :string, :limit => 3
      t.column :rfc_3066,  :string
      t.column :english_name, :string
      t.column :english_name_locale, :string
      t.column :english_name_modifier, :string
      t.column :native_name, :string
      t.column :native_name_locale, :string
      t.column :native_name_modifier, :string
      t.column :macro_language, :boolean
      t.column :direction, :string
      t.column :pluralization, :string
      t.column :scope, :string, :limit => 1
    end

    add_index :globalize_languages, :iso_639_1
    add_index :globalize_languages, :iso_639_2  
    add_index :globalize_languages, :iso_639_3  
    add_index :globalize_languages, :rfc_3066  

    # add in defaults
    load_from_csv("globalize_countries", country_data)
    load_from_csv("globalize_languages", language_data)
    load_from_csv("globalize_translations", translation_data)
  end

  def self.down
    drop_table :globalize_countries
    drop_table :globalize_translations
    drop_table :globalize_languages    
  end
  
  def self.load_from_csv(table_name, data)
    column_clause = nil
    is_header = false
    cnx = ActiveRecord::Base.connection
    ActiveRecord::Base.silence do
      reader = CSV::Reader.create(data) 
      
      columns = reader.shift.map {|column_name| cnx.quote_column_name(column_name) }
      column_clause = columns.join(', ')

      reader.each do |row|
        next if row.first.nil? # skip blank lines
        raise "No table name defined" if !table_name
        raise "No header defined" if !column_clause
        values_clause = row.map {|v| cnx.quote(v).gsub('\\n', "\n").gsub('\\r', "\r") }.join(', ')
        sql = "INSERT INTO #{table_name} (#{column_clause}) VALUES (#{values_clause})"
        cnx.insert(sql) 
      end
    end
  end

  def self.country_data
    <<'END_OF_DATA'
"id","code","english_name","date_format","currency_format","currency_code","thousands_sep","decimal_sep","currency_decimal_sep","number_grouping_scheme"
1,"AD","Andorra",,,"EUR",,,,"western"
2,"AE","United Arab Emirates",,,"AED",",",".",".","western"
3,"AF","Afghanistan",,,"AFA",,,,"western"
4,"AG","Antigua and Barbuda",,,"XCD",,,,"western"
5,"AI","Anguilla",,,"XCD",,,,"western"
6,"AL","Albania",,,"ALL",".",",",",","western"
7,"AM","Armenia",,,"AMD",,,,"western"
8,"AN","Netherlands Antilles",,,"ANG",,,,"western"
9,"AO","Angola",,,"AON",,,,"western"
10,"AQ","Antarctica",,,"NOK",,,,"western"
11,"AR","Argentina",,,"ARA",".",",",",","western"
12,"AS","American Samoa",,,"USD",,,,"western"
13,"AT","Austria",,"€ %n","EUR",,",",",","western"
14,"AU","Australia",,,"AUD",",",".",".","western"
15,"AW","Aruba",,,"AWG",,,,"western"
16,"AZ","Azerbaijan",,,"AZM",,".",".","western"
17,"BA","Bosnia and Herzegovina",,,"BAM",,",",",","western"
18,"BB","Barbados",,,"BBD",,,,"western"
19,"BD","Bangladesh",,,"BDT",",",".",".","western"
20,"BE","Belgium",,"%n €","EUR",".",",",",","western"
21,"BF","Burkina Faso",,,"XAF",,,,"western"
22,"BG","Bulgaria",,,"BGL"," ",",",",","western"
23,"BH","Bahrain",,,"BHD",",",".",".","western"
24,"BI","Burundi",,,"BIF",,,,"western"
25,"BJ","Benin",,,"XAF",,,,"western"
26,"BM","Bermuda",,,"BMD",,,,"western"
27,"BN","Brunei Darussalam",,,"BND",,,,"western"
28,"BO","Bolivia",,,"BOB",".",",",",","western"
29,"BR","Brazil",,"R$%n","BRR",".",",",",","western"
30,"BS","Bahamas",,,"BSD",,,,"western"
31,"BT","Bhutan",,,"BTN",,,,"western"
32,"BV","Bouvet Island",,,"NOK",,,,"western"
33,"BW","Botswana",,,"BWP",",",".",".","western"
34,"BY","Belarus",,,"BYR",,".",".","western"
35,"BZ","Belize",,,"BZD",,,,"western"
36,"CA","Canada",,,"CAD",",",".",".","western"
37,"CC","Cocos  Islands",,,"AUD",,,,"western"
38,"CD","Congo",,,,,,,"western"
39,"CF","Central African Republic",,,"XAF",,,,"western"
40,"CG","Congo",,,"XAF",,,,"western"
41,"CH","Switzerland",,"SFr. %n","CHF","'",",",".","western"
42,"CI","Cote D'Ivoire",,,"XAF",,,,"western"
43,"CK","Cook Islands",,,"NZD",,,,"western"
44,"CL","Chile",,,"CLF",".",",",",","western"
45,"CM","Cameroon",,,"XAF",,,,"western"
46,"CN","China",,"Y%n","CNY",",",".",".","western"
47,"CO","Colombia",,,"COP",".",",",",","western"
48,"CR","Costa Rica",,,"CRC",",",".",".","western"
49,"CS","Serbia and Montenegro",,,"CSD",,,,"western"
50,"CU","Cuba",,,"CUP",,,,"western"
51,"CV","Cape Verde",,,"CVE",,,,"western"
52,"CX","Christmas Island",,,"AUD",,,,"western"
53,"CY","Cyprus",,,"CYP",,,,"western"
54,"CZ","Czech Republic",,,"CZK"," ",",",",","western"
55,"DE","Germany",,"%n €","EUR",".",",",",","western"
56,"DJ","Djibouti",,,"DJF",,,,"western"
57,"DK","Denmark",,,"DKK",".",",",",","western"
58,"DM","Dominica",,,"XCD",,,,"western"
59,"DO","Dominican Republic",,,"DOP",",",".",".","western"
60,"DZ","Algeria",,,"DZD",",",".",".","western"
61,"EC","Ecuador",,,"USD",".",",",",","western"
62,"EE","Estonia",,,"EEK"," ",",",",","western"
63,"EG","Egypt",,,"EGP",",",".",".","western"
64,"EH","Western Sahara",,,"MAD",,,,"western"
65,"ER","Eritrea",,,"ERN",",",".",".","western"
66,"ES","Spain",,"%n €","EUR",".",",",",","western"
67,"ET","Ethiopia",,,"ETB",",",".",".","western"
68,"FI","Finland",,,"EUR"," ",",",",","western"
69,"FJ","Fiji",,,"FJD",,,,"western"
70,"FK","Falkland Islands",,,"FKP",,,,"western"
71,"FM","Micronesia",,,"USD",,,,"western"
72,"FO","Faeroe Islands",,,"DKK",".",",",",","western"
73,"FR","France",,"%n €","EUR",,",",",","western"
74,"GA","Gabon",,,"XAF",,,,"western"
75,"GB","United Kingdom",,"£%n","GBP",",",".",".","western"
76,"GD","Grenada",,,"XCD",,,,"western"
77,"GE","Georgia",,,"GEL",".",",",",","western"
78,"GF","French Guiana",,,"EUR",,,,"western"
79,"GH","Ghana",,,"GHC",,,,"western"
80,"GI","Gibraltar",,,"GIP",,,,"western"
81,"GL","Greenland",,,"DKK",".",",",",","western"
82,"GM","Gambia",,,"GMD",,,,"western"
83,"GN","Guinea",,,"GNS",,,,"western"
84,"GP","Guadaloupe",,,"EUR",,,,"western"
85,"GQ","Equatorial Guinea",,,"XAF",,,,"western"
86,"GR","Greece",,,"EUR",".",",",",","western"
87,"GS","South Georgia and the South Sandwich Islands",,,"GBP",,,,"western"
88,"GT","Guatemala",,,"GTQ",",",".",".","western"
89,"GU","Guam",,,"USD",,,,"western"
90,"GW","Guinea-Bissau",,,"GWP",,,,"western"
91,"GY","Guyana",,,"GYD",,,,"western"
92,"HK","Hong Kong",,"HK$%n","HKD",",",".",".","western"
93,"HM","Heard and McDonald Islands",,,"AUD",,,,"western"
94,"HN","Honduras",,,"HNL",",",".",".","western"
95,"HR","Hrvatska",,,"HRK",,",",",","western"
96,"HT","Haiti",,,"HTG",,,,"western"
97,"HU","Hungary",,,"HUF",".",",",",","western"
98,"ID","Indonesia",,,"IDR",".",",",",","western"
99,"IE","Ireland",,,"EUR",",",".",".","western"
100,"IL","Israel",,"%n ₪","ILS",",",".",".","western"
101,"IN","India",,"Rs.%n","INR",",",".",".","indian"
102,"IO","British Indian Ocean Territory",,,"GBP",,,,"western"
103,"IQ","Iraq",,,"IQD",",",".",".","western"
104,"IR","Iran",,,"IRR","٬","٫","٫","western"
105,"IS","Iceland",,,"ISK",".",",",",","western"
106,"IT","Italy",,"€ %n","EUR",".",",",",","western"
107,"JM","Jamaica",,,"JMD",,,,"western"
108,"JO","Jordan",,,"JOD",",",".",".","western"
109,"JP","Japan",,"¥%n","JPY",",",".",".","western"
110,"KE","Kenya",,,"KES",,,,"western"
111,"KG","Kyrgyz Republic",,,"KGS",,,,"western"
112,"KH","Cambodia",,,"KHR",,,,"western"
113,"KI","Kiribati",,,"AUD",,,,"western"
114,"KM","Comoros",,,"KMF",,,,"western"
115,"KN","St. Kitts and Nevis",,,"XCD",,,,"western"
116,"KP","Korea",,,"KPW",,,,"western"
117,"KR","Korea",,,"KRW",",",".",".","western"
118,"KW","Kuwait",,,"KWD",",",".",".","western"
119,"KY","Cayman Islands",,,"KYD",,,,"western"
120,"KZ","Kazakhstan",,,"KZT",,,,"western"
121,"LA","Lao People's Democratic Republic",,,"LAK",",",".",".","western"
122,"LB","Lebanon",,,"LBP",",",".",".","western"
123,"LC","St. Lucia",,,"XCD",,,,"western"
124,"LI","Liechtenstein",,,"CHF",,,,"western"
125,"LK","Sri Lanka",,,"LKR",,,,"western"
126,"LR","Liberia",,,"LRD",,,,"western"
127,"LS","Lesotho",,,"LSL",,,,"western"
128,"LT","Lithuania",,,"LTL",".",",",",","western"
129,"LU","Luxembourg",,,"EUR",".",",",",","western"
130,"LV","Latvia",,,"LVL"," ",",",",","western"
131,"LY","Libyan Arab Jamahiriya",,,"LYD",",",".",".","western"
132,"MA","Morocco",,,"MAD",",",".",".","western"
133,"MC","Monaco",,,"EUR",,,,"western"
134,"MD","Moldova",,,"MDL",,,,"western"
135,"MG","Madagascar",,,"MGF",,,,"western"
136,"MH","Marshall Islands",,,"USD",,,,"western"
137,"MK","Macedonia",,,"MKD",,",",",","western"
138,"ML","Mali",,,"XAF",,,,"western"
139,"MM","Myanmar",,,,,,,"western"
140,"MN","Mongolia",,,"MNT",,".",".","western"
141,"MO","Macao",,,"MOP",,,,"western"
142,"MP","Northern Mariana Islands",,,"USD",,,,"western"
143,"MQ","Martinique",,,"EUR",,,,"western"
144,"MR","Mauritania",,,"MRO",,,,"western"
145,"MS","Montserrat",,,"XCD",,,,"western"
146,"MT","Malta",,,"MTL",",",".",".","western"
147,"MU","Mauritius",,,"MUR",,,,"western"
148,"MV","Maldives",,,"MVR",,,,"western"
149,"MW","Malawi",,,"MWK",,,,"western"
150,"MX","Mexico",,,"MXN",",",".",".","western"
151,"MY","Malaysia",,,"MYR",",",".",".","western"
152,"MZ","Mozambique",,,"MZM",,,,"western"
153,"NA","Namibia",,,"NAD",,,,"western"
154,"NC","New Caledonia",,,"XPF",,,,"western"
155,"NE","Niger",,,"XOF",,,,"western"
156,"NF","Norfolk Island",,,"AUD",,,,"western"
157,"NG","Nigeria",,,"NGN",,,,"western"
158,"NI","Nicaragua",,,"NIC",",",".",".","western"
159,"NL","Netherlands",,"€ %n","EUR",,",",",","western"
160,"NO","Norway",,"kr %n","NOK"," ",",",",","western"
161,"NP","Nepal",,,"NPR",",",".",".","western"
162,"NR","Nauru",,,"AUD",,,,"western"
163,"NU","Niue",,,"NZD",,,,"western"
164,"NZ","New Zealand",,,"NZD",",",".",".","western"
165,"OM","Oman",,,"OMR",",",".",".","western"
166,"PA","Panama",,,"PAB",",",".",".","western"
167,"PE","Peru",,,"PEI",",",".",".","western"
168,"PF","French Polynesia",,,"XPF",,,,"western"
169,"PG","Papua New Guinea",,,"PGK",,,,"western"
170,"PH","Philippines",,,"PHP",",",".",".","western"
171,"PK","Pakistan",,,"PKR",",",".",".","western"
172,"PL","Poland",,,"PLN",".",",",",","western"
173,"PM","St. Pierre and Miquelon",,,"EUR",,,,"western"
174,"PN","Pitcairn Island",,,"NZD",,,,"western"
175,"PR","Puerto Rico",,,"USD",",",".",".","western"
176,"PS","Palestinian Territory",,,,,,,"western"
177,"PT","Portugal",,"%n €","EUR",".","$","$","western"
178,"PW","Palau",,,"USD",,,,"western"
179,"PY","Paraguay",,,"PYG",".",",",",","western"
180,"QA","Qatar",,,"QAR",",",".",".","western"
181,"RE","Reunion",,,"EUR",,,,"western"
182,"RO","Romania",,,"ROL",".",",",",","western"
183,"RU","Russian Federation",,,"RUB",,".",".","western"
184,"RW","Rwanda",,,"RWF",,,,"western"
185,"SA","Saudi Arabia",,,"SAR",,".",".","western"
186,"SB","Solomon Islands",,,"SBD",,,,"western"
187,"SC","Seychelles",,,"SCR",,,,"western"
188,"SD","Sudan",,,"SDP",",",".",".","western"
189,"SE","Sweden",,"%n kr","SEK",,",",",","western"
190,"SG","Singapore",,,"SGD",",",".",".","western"
191,"SH","St. Helena",,,"SHP",,,,"western"
192,"SI","Slovenia",,,"SIT",,",",",","western"
193,"SJ","Svalbard & Jan Mayen Islands",,,"NOK",,,,"western"
194,"SK","Slovakia",,,"SKK"," ",",",",","western"
195,"SL","Sierra Leone",,,"SLL",,,,"western"
196,"SM","San Marino",,,"EUR",,,,"western"
197,"SN","Senegal",,,"XOF",,,,"western"
198,"SO","Somalia",,,"SOS",,,,"western"
199,"SR","Suriname",,,"SRG",,,,"western"
200,"ST","Sao Tome and Principe",,,"STD",,,,"western"
201,"SV","El Salvador",,,"SVC",",",".",".","western"
202,"SY","Syrian Arab Republic",,,"SYP",",",".",".","western"
203,"SZ","Swaziland",,,"SZL",,,,"western"
204,"TC","Turks and Caicos Islands",,,"USD",,,,"western"
205,"TD","Chad",,,"XAF",,,,"western"
206,"TF","French Southern Territories",,,"EUR",,,,"western"
207,"TG","Togo",,,"XAF",,,,"western"
208,"TH","Thailand",,,"THB",",",".",".","western"
209,"TJ","Tajikistan",,,"TJR",,".",".","western"
210,"TK","Tokelau",,,"NZD",,,,"western"
211,"TL","Timor-Leste",,,,,,,"western"
212,"TM","Turkmenistan",,,"TMM",,,,"western"
213,"TN","Tunisia",,,"TND",",",".",".","western"
214,"TO","Tonga",,,"TOP",,,,"western"
215,"TR","Turkey",,,"TRL",".",",",",","western"
216,"TT","Trinidad and Tobago",,,"TTD",,,,"western"
217,"TV","Tuvalu",,,"AUD",,,,"western"
218,"TW","Taiwan",,"NT$%n","TWD",",",".",".","western"
219,"TZ","Tanzania",,,"TZS",,,,"western"
220,"UA","Ukraine",,,"UAH",,".",".","western"
221,"UG","Uganda",,,"UGS",",",".",".","western"
222,"UM","United States Minor Outlying Islands",,,"USD",,,,"western"
223,"US","United States of America",,,"USD",",",".",".","western"
224,"UY","Uruguay",,,"UYU",".",",",",","western"
225,"UZ","Uzbekistan",,,"UZS",",",".",".","western"
226,"VA","Holy See",,,"EUR",,,,"western"
227,"VC","St. Vincent and the Grenadines",,,"XCD",,,,"western"
228,"VE","Venezuela",,,"VEB",".",",",",","western"
229,"VG","British Virgin Islands",,,"USD",,,,"western"
230,"VI","US Virgin Islands",,,"USD",,,,"western"
231,"VN","Viet Nam",,,"VND",".",",",",","western"
232,"VU","Vanuatu",,,"VUV",,,,"western"
233,"WF","Wallis and Futuna Islands",,,"XPF",,,,"western"
234,"WS","Samoa",,,"WST",,,,"western"
235,"YE","Yemen",,,,",",".",".","western"
236,"YT","Mayotte",,,"EUR",,,,"western"
237,"ZA","South Africa",,,"ZAR",",",".",".","western"
238,"ZM","Zambia",,,"ZMK",,,,"western"
239,"ZW","Zimbabwe",,,"ZWD",",",".",".","western"
END_OF_DATA
  end

  def self.language_data
    <<'END_OF_DATA'
"id","iso_639_1","iso_639_2","iso_639_3","rfc_3066","english_name","english_name_locale","english_name_modifier","native_name","native_name_locale","native_name_modifier","macro_language","direction","pluralization","scope"
1,,,"aaa",,"Ghotuo",,,,,,0,"ltr",,"L"
2,,,"aab",,"Alumu-Tesu",,,,,,0,"ltr",,"L"
3,,,"aac",,"Ari",,,,,,0,"ltr",,"L"
4,,,"aad",,"Amal",,,,,,0,"ltr",,"L"
5,,,"aae",,"Albanian",,"Arbëreshë",,,,0,"ltr",,"L"
6,,,"aaf",,"Aranadan",,,,,,0,"ltr",,"L"
7,,,"aai",,"Arifama-Miniafia",,,,,,0,"ltr",,"L"
8,,,"aak",,"Ankave",,,,,,0,"ltr",,"L"
9,,,"aal",,"Afade",,,,,,0,"ltr",,"L"
10,,,"aam",,"Aramanik",,,,,,0,"ltr",,"L"
11,,,"aan",,"Anambé",,,,,,0,"ltr",,"L"
12,,,"aao",,"Arabic",,"Algerian Saharan Spoken",,,,0,"rtl",,"L"
13,,,"aap",,"Arára",,"Pará",,,,0,"ltr",,"L"
14,,,"aaq",,"Abnaki",,"Eastern",,,,0,"ltr",,"E"
15,"aa","aar","aar",,"Afar",,,,,,0,"ltr",,"L"
16,,,"aas",,"Aasáx",,,,,,0,"ltr",,"L"
17,,,"aat",,"Albanian",,"Arvanitika",,,,0,"ltr",,"L"
18,,,"aau",,"Abau",,,,,,0,"ltr",,"L"
19,,,"aaw",,"Solong",,,,,,0,"ltr",,"L"
20,,,"aax",,"Mandobo Atas",,,,,,0,"ltr",,"L"
21,,,"aay",,"Aariya",,,,,,0,"ltr",,"L"
22,,,"aaz",,"Amarasi",,,,,,0,"ltr",,"L"
23,,,"aba",,"Abé",,,,,,0,"ltr",,"L"
24,,,"abb",,"Bankon",,,,,,0,"ltr",,"L"
25,,,"abc",,"Ayta",,"Ambala",,,,0,"ltr",,"L"
26,,,"abd",,"Agta",,"Camarines Norte",,,,0,"ltr",,"L"
27,,,"abe",,"Abnaki",,"Western",,,,0,"ltr",,"L"
28,,,"abf",,"Abai Sungai",,,,,,0,"ltr",,"L"
29,,,"abg",,"Abaga",,,,,,0,"ltr",,"L"
30,,,"abh",,"Arabic",,"Tajiki Spoken",,,,0,"rtl",,"L"
31,,,"abi",,"Abidji",,,,,,0,"ltr",,"L"
32,,,"abj",,"Aka-Bea",,,,,,0,"ltr",,"E"
33,"ab","abk","abk",,"Abkhazian",,,"аҧсуа бызшәа",,,0,"ltr",,"L"
34,,,"abl",,"Abung",,,,,,0,"ltr",,"L"
35,,,"abm",,"Abanyom",,,,,,0,"ltr",,"L"
36,,,"abn",,"Abua",,,,,,0,"ltr",,"L"
37,,,"abo",,"Abon",,,,,,0,"ltr",,"L"
38,,,"abp",,"Ayta",,"Abenlen",,,,0,"ltr",,"L"
39,,,"abq",,"Abaza",,,,,,0,"ltr",,"L"
40,,,"abr",,"Abron",,,,,,0,"ltr",,"L"
41,,,"abs",,"Malay",,"Ambonese",,,,0,"ltr",,"L"
42,,,"abt",,"Ambulas",,,,,,0,"ltr",,"L"
43,,,"abu",,"Abure",,,,,,0,"ltr",,"L"
44,,,"abv",,"Arabic",,"Baharna Spoken",,,,0,"rtl",,"L"
45,,,"abw",,"Pal",,,,,,0,"ltr",,"L"
46,,,"abx",,"Inabaknon",,,,,,0,"ltr",,"L"
47,,,"aby",,"Aneme Wake",,,,,,0,"ltr",,"L"
48,,,"abz",,"Abui",,,,,,0,"ltr",,"L"
49,,,"aca",,"Achagua",,,,,,0,"ltr",,"L"
50,,,"acb",,"Áncá",,,,,,0,"ltr",,"L"
51,,,"acc",,"Achí",,"Cubulco",,,,0,"ltr",,"L"
52,,,"acd",,"Gikyode",,,,,,0,"ltr",,"L"
53,,"ace","ace",,"Achinese",,,,,,0,"ltr",,"L"
54,,,"acf",,"Saint Lucian Creole French",,,,,,0,"ltr",,"L"
55,,"ach","ach",,"Acoli",,,,,,0,"ltr",,"L"
56,,,"aci",,"Aka-Cari",,,,,,0,"ltr",,"E"
57,,,"ack",,"Aka-Kora",,,,,,0,"ltr",,"E"
58,,,"acl",,"Akar-Bale",,,,,,0,"ltr",,"E"
59,,,"acm",,"Arabic",,"Mesopotamian Spoken",,,,0,"rtl",,"L"
60,,,"acn",,"Achang",,,,,,0,"ltr",,"L"
61,,,"acp",,"Acipa",,"Eastern",,,,0,"ltr",,"L"
62,,,"acq",,"Arabic",,"Ta'izzi-Adeni Spoken",,,,0,"rtl",,"L"
63,,,"acr",,"Achí",,"Rabinal",,,,0,"ltr",,"L"
64,,,"acs",,"Acroá",,,,,,0,"ltr",,"E"
65,,,"act",,"Achterhoeks",,,,,,0,"ltr",,"L"
66,,,"acu",,"Achuar-Shiwiar",,,,,,0,"ltr",,"L"
67,,,"acv",,"Achumawi",,,,,,0,"ltr",,"L"
68,,,"acw",,"Arabic",,"Hijazi Spoken",,,,0,"rtl",,"L"
69,,,"acx",,"Arabic",,"Omani Spoken",,,,0,"rtl",,"L"
70,,,"acy",,"Arabic",,"Cypriot Spoken",,,,0,"rtl",,"L"
71,,,"acz",,"Acheron",,,,,,0,"ltr",,"L"
72,,"ada","ada",,"Adangme",,,,,,0,"ltr",,"L"
73,,,"adb",,"Adabe",,,,,,0,"ltr",,"L"
74,,,"add",,"Dzodinka",,,,,,0,"ltr",,"L"
75,,,"ade",,"Adele",,,,,,0,"ltr",,"L"
76,,,"adf",,"Arabic",,"Dhofari Spoken",,,,0,"rtl",,"L"
77,,,"adg",,"Andegerebinha",,,,,,0,"ltr",,"L"
78,,,"adh",,"Adhola",,,,,,0,"ltr",,"L"
79,,,"adi",,"Adi",,,,,,0,"ltr",,"L"
80,,,"adj",,"Adioukrou",,,,,,0,"ltr",,"L"
81,,,"adl",,"Adi",,"Galo",,,,0,"ltr",,"L"
82,,,"adn",,"Adang",,,,,,0,"ltr",,"L"
83,,,"ado",,"Abu",,,,,,0,"ltr",,"L"
84,,,"adp",,"Adap",,,,,,0,"ltr",,"L"
85,,,"adq",,"Adangbe",,,,,,0,"ltr",,"L"
86,,,"adr",,"Adonara",,,,,,0,"ltr",,"L"
87,,,"ads",,"Adamorobe Sign Language",,,,,,0,"ltr",,"L"
88,,,"adt",,"Adynyamathanha",,,,,,0,"ltr",,"L"
89,,,"adu",,"Aduge",,,,,,0,"ltr",,"L"
90,,,"adw",,"Amundava",,,,,,0,"ltr",,"L"
91,,,"adx",,"Tibetan",,"Amdo",,,,0,"ltr",,"L"
92,,"ady","ady",,"Adyghe; Adygei",,,,,,0,"ltr",,"L"
93,,,"aea",,"Areba",,,,,,0,"ltr",,"L"
94,,,"aeb",,"Arabic",,"Tunisian Spoken",,,,0,"rtl",,"L"
95,,,"aec",,"Arabic",,"Saidi Spoken",,,,0,"rtl",,"L"
96,,,"aed",,"Argentine Sign Language",,,,,,0,"ltr",,"L"
97,,,"aee",,"Pashayi",,"Northeast",,,,0,"ltr",,"L"
98,,,"aek",,"Haeke",,,,,,0,"ltr",,"L"
99,,,"ael",,"Ambele",,,,,,0,"ltr",,"L"
100,,,"aem",,"Arem",,,,,,0,"ltr",,"L"
101,,,"aen",,"Armenian Sign Language",,,,,,0,"ltr",,"L"
102,,,"aeq",,"Aer",,,,,,0,"ltr",,"L"
103,,,"aer",,"Arrernte",,"Eastern",,,,0,"ltr",,"L"
104,,,"aes",,"Alsea",,,,,,0,"ltr",,"E"
105,,,"aew",,"Ambakich",,,,,,0,"ltr",,"L"
106,,,"aex",,"Amerax",,,,,,0,"ltr",,"L"
107,,,"aey",,"Amele",,,,,,0,"ltr",,"L"
108,,,"afb",,"Arabic",,"Gulf Spoken",,,,0,"rtl",,"L"
109,,,"afe",,"Putukwam",,,,,,0,"ltr",,"L"
110,,"afh","afh",,"Afrihili",,,,,,0,"ltr",,"C"
111,,,"afi",,"Akrukay",,,,,,0,"ltr",,"L"
112,,,"afn",,"Defaka",,,,,,0,"ltr",,"L"
113,,,"afo",,"Eloyi",,,,,,0,"ltr",,"L"
114,"af","afr","afr",,"Afrikaans",,,"Afrikaans",,,0,"ltr",,"L"
115,,,"afs",,"Afro-Seminole Creole",,,,,,0,"ltr",,"L"
116,,,"aft",,"Afitti",,,,,,0,"ltr",,"L"
117,,,"afu",,"Awutu",,,,,,0,"ltr",,"L"
118,,,"afz",,"Obokuitai",,,,,,0,"ltr",,"L"
119,,,"aga",,"Aguano",,,,,,0,"ltr",,"E"
120,,,"agb",,"Legbo",,,,,,0,"ltr",,"L"
121,,,"agc",,"Agatu",,,,,,0,"ltr",,"L"
122,,,"agd",,"Agarabi",,,,,,0,"ltr",,"L"
123,,,"age",,"Angal",,,,,,0,"ltr",,"L"
124,,,"agf",,"Arguni",,,,,,0,"ltr",,"L"
125,,,"agg",,"Angor",,,,,,0,"ltr",,"L"
126,,,"agh",,"Ngelima",,,,,,0,"ltr",,"L"
127,,,"agi",,"Agariya",,,,,,0,"ltr",,"L"
128,,,"agj",,"Argobba",,,,,,0,"ltr",,"L"
129,,,"agk",,"Agta",,"Isarog",,,,0,"ltr",,"L"
130,,,"agl",,"Fembe",,,,,,0,"ltr",,"L"
131,,,"agm",,"Angaatiha",,,,,,0,"ltr",,"L"
132,,,"agn",,"Agutaynen",,,,,,0,"ltr",,"L"
133,,,"ago",,"Tainae",,,,,,0,"ltr",,"L"
134,,,"agp",,"Paranan",,,,,,0,"ltr",,"L"
135,,,"agq",,"Aghem",,,,,,0,"ltr",,"L"
136,,,"agr",,"Aguaruna",,,,,,0,"ltr",,"L"
137,,,"ags",,"Esimbi",,,,,,0,"ltr",,"L"
138,,,"agt",,"Agta",,"Central Cagayan",,,,0,"ltr",,"L"
139,,,"agu",,"Aguacateco",,,,,,0,"ltr",,"L"
140,,,"agv",,"Agta",,"Remontado",,,,0,"ltr",,"L"
141,,,"agw",,"Kahua",,,,,,0,"ltr",,"L"
142,,,"agx",,"Aghul",,,,,,0,"ltr",,"L"
143,,,"agy",,"Alta",,"Southern",,,,0,"ltr",,"L"
144,,,"agz",,"Agta",,"Mt. Iriga",,,,0,"ltr",,"L"
145,,,"aha",,"Ahanta",,,,,,0,"ltr",,"L"
146,,,"ahb",,"Axamb",,,,,,0,"ltr",,"L"
147,,,"ahe",,"Ahe",,,,,,0,"ltr",,"L"
148,,,"ahg",,"Qimant",,,,,,0,"ltr",,"L"
149,,,"ahh",,"Aghu",,,,,,0,"ltr",,"L"
150,,,"ahi",,"Aizi",,"Tiagbamrin",,,,0,"ltr",,"L"
151,,,"ahk",,"Akha",,,,,,0,"ltr",,"L"
152,,,"ahl",,"Igo",,,,,,0,"ltr",,"L"
153,,,"ahm",,"Aizi",,"Mobumrin",,,,0,"ltr",,"L"
154,,,"ahn",,"Àhàn",,,,,,0,"ltr",,"L"
155,,,"aho",,"Ahom",,,,,,0,"ltr",,"E"
156,,,"ahp",,"Aizi",,"Aproumu",,,,0,"ltr",,"L"
157,,,"ahr",,"Ahirani",,,,,,0,"ltr",,"L"
158,,,"ahs",,"Ashe",,,,,,0,"ltr",,"L"
159,,,"aht",,"Ahtena",,,,,,0,"ltr",,"L"
160,,,"aia",,"Arosi",,,,,,0,"ltr",,"L"
161,,,"aib",,"Ainu","China",,,,,0,"ltr",,"L"
162,,,"aic",,"Ainbai",,,,,,0,"ltr",,"L"
163,,,"aid",,"Alngith",,,,,,0,"ltr",,"L"
164,,,"aie",,"Amara",,,,,,0,"ltr",,"L"
165,,,"aif",,"Agi",,,,,,0,"ltr",,"L"
166,,,"aig",,"Antigua and Barbuda Creole English",,,,,,0,"ltr",,"L"
167,,,"aih",,"Ai-Cham",,,,,,0,"ltr",,"L"
168,,,"aii",,"Assyrian Neo-Aramaic",,,,,,0,"ltr",,"L"
169,,,"aij",,"Lishanid Noshan",,,,,,0,"ltr",,"L"
170,,,"aik",,"Ake",,,,,,0,"ltr",,"L"
171,,,"ail",,"Aimele",,,,,,0,"ltr",,"L"
172,,,"aim",,"Aimol",,,,,,0,"ltr",,"L"
173,,"ain","ain",,"Ainu","Japan",,,,,0,"ltr",,"L"
174,,,"aio",,"Aiton",,,,,,0,"ltr",,"L"
175,,,"aip",,"Burumakok",,,,,,0,"ltr",,"L"
176,,,"aiq",,"Aimaq",,,,,,0,"ltr",,"L"
177,,,"air",,"Airoran",,,,,,0,"ltr",,"L"
178,,,"ais",,"Amis",,"Nataoran",,,,0,"ltr",,"L"
179,,,"ait",,"Arikem",,,,,,0,"ltr",,"E"
180,,,"aix",,"Aigon",,,,,,0,"ltr",,"L"
181,,,"aiy",,"Ali",,,,,,0,"ltr",,"L"
182,,,"aiz",,"Aari",,,,,,0,"ltr",,"L"
183,,,"aja",,"Aja","Sudan",,,,,0,"ltr",,"L"
184,,,"ajg",,"Aja","Benin",,,,,0,"ltr",,"L"
185,,,"aji",,"Ajië",,,,,,0,"ltr",,"L"
186,,,"ajp",,"Arabic",,"South Levantine Spoken",,,,0,"rtl",,"L"
187,,,"ajt",,"Arabic",,"Judeo-Tunisian",,,,0,"rtl",,"L"
188,,,"aju",,"Arabic",,"Judeo-Moroccan",,,,0,"rtl",,"L"
189,,,"ajw",,"Ajawa",,,,,,0,"ltr",,"E"
190,,,"ajz",,"Amri",,,,,,0,"ltr",,"L"
191,"ak","aka","aka",,"Akan",,,,,,1,"ltr",,"L"
192,,,"akb",,"Batak Angkola",,,,,,0,"ltr",,"L"
193,,,"akc",,"Mpur",,,,,,0,"ltr",,"L"
194,,,"akd",,"Ukpet-Ehom",,,,,,0,"ltr",,"L"
195,,,"ake",,"Akawaio",,,,,,0,"ltr",,"L"
196,,,"akf",,"Akpa",,,,,,0,"ltr",,"L"
197,,,"akg",,"Anakalangu",,,,,,0,"ltr",,"L"
198,,,"akh",,"Angal Heneng",,,,,,0,"ltr",,"L"
199,,,"aki",,"Aiome",,,,,,0,"ltr",,"L"
200,,,"akj",,"Aka-Jeru",,,,,,0,"ltr",,"E"
201,,"akk","akk",,"Akkadian",,,,,,0,"ltr",,"A"
202,,,"akl",,"Aklanon",,,,,,0,"ltr",,"L"
203,,,"akm",,"Aka-Bo",,,,,,0,"ltr",,"E"
204,,,"akn",,"Amikoana",,,,,,0,"ltr",,"L"
205,,,"ako",,"Akurio",,,,,,0,"ltr",,"L"
206,,,"akp",,"Siwu",,,,,,0,"ltr",,"L"
207,,,"akq",,"Ak",,,,,,0,"ltr",,"L"
208,,,"akr",,"Araki",,,,,,0,"ltr",,"L"
209,,,"aks",,"Akaselem",,,,,,0,"ltr",,"L"
210,,,"akt",,"Akolet",,,,,,0,"ltr",,"L"
211,,,"aku",,"Akum",,,,,,0,"ltr",,"L"
212,,,"akv",,"Akhvakh",,,,,,0,"ltr",,"L"
213,,,"akw",,"Akwa",,,,,,0,"ltr",,"L"
214,,,"akx",,"Aka-Kede",,,,,,0,"ltr",,"E"
215,,,"aky",,"Aka-Kol",,,,,,0,"ltr",,"E"
216,,,"akz",,"Alabama",,,,,,0,"ltr",,"L"
217,,,"ala",,"Alago",,,,,,0,"ltr",,"L"
218,,,"alc",,"Qawasqar",,,,,,0,"ltr",,"L"
219,,,"ald",,"Alladian",,,,,,0,"ltr",,"L"
220,,"ale","ale",,"Aleut",,,,,,0,"ltr",,"L"
221,,,"alf",,"Alege",,,,,,0,"ltr",,"L"
222,,,"alh",,"Alawa",,,,,,0,"ltr",,"L"
223,,,"ali",,"Amaimon",,,,,,0,"ltr",,"L"
224,,,"alj",,"Alangan",,,,,,0,"ltr",,"L"
225,,,"alk",,"Alak",,,,,,0,"ltr",,"L"
226,,,"all",,"Allar",,,,,,0,"ltr",,"L"
227,,,"alm",,"Amblong",,,,,,0,"ltr",,"L"
228,,,"aln",,"Albanian",,"Gheg",,,,0,"ltr",,"L"
229,,,"alo",,"Larike-Wakasihu",,,,,,0,"ltr",,"L"
230,,,"alp",,"Alune",,,,,,0,"ltr",,"L"
231,,,"alq",,"Algonquin",,,,,,0,"ltr",,"L"
232,,,"alr",,"Alutor",,,,,,0,"ltr",,"L"
233,,,"als",,"Albanian",,"Tosk",,,,0,"ltr",,"L"
234,,"alt","alt",,"Altai",,"Southern",,,,0,"ltr",,"L"
235,,,"alu",,"'Are'are",,,,,,0,"ltr",,"L"
236,,,"alw",,"Alaba",,,,,,0,"ltr",,"L"
237,,,"alx",,"Alatil",,,,,,0,"ltr",,"L"
238,,,"aly",,"Alyawarr",,,,,,0,"ltr",,"L"
239,,,"alz",,"Alur",,,,,,0,"ltr",,"L"
240,,,"ama",,"Amanayé",,,,,,0,"ltr",,"L"
241,,,"amb",,"Ambo",,,,,,0,"ltr",,"L"
242,,,"amc",,"Amahuaca",,,,,,0,"ltr",,"L"
243,,,"amd",,"Amapá Creole",,,,,,0,"ltr",,"L"
244,,,"ame",,"Yanesha'",,,,,,0,"ltr",,"L"
245,,,"amf",,"Hamer-Banna",,,,,,0,"ltr",,"L"
246,,,"amg",,"Amarag",,,,,,0,"ltr",,"L"
247,"am","amh","amh",,"Amharic",,,"አማርኛ",,,0,"ltr",,"L"
248,,,"ami",,"Amis",,,,,,0,"ltr",,"L"
249,,,"amj",,"Amdang",,,,,,0,"ltr",,"L"
250,,,"amk",,"Ambai",,,,,,0,"ltr",,"L"
251,,,"aml",,"War",,,,,,0,"ltr",,"L"
252,,,"amm",,"Ama","Papua New Guinea",,,,,0,"ltr",,"L"
253,,,"amn",,"Amanab",,,,,,0,"ltr",,"L"
254,,,"amo",,"Amo",,,,,,0,"ltr",,"L"
255,,,"amp",,"Alamblak",,,,,,0,"ltr",,"L"
256,,,"amq",,"Amahai",,,,,,0,"ltr",,"L"
257,,,"amr",,"Amarakaeri",,,,,,0,"ltr",,"L"
258,,,"ams",,"Amami-Oshima",,"Southern",,,,0,"ltr",,"L"
259,,,"amt",,"Amto",,,,,,0,"ltr",,"L"
260,,,"amu",,"Amuzgo",,"Guerrero",,,,0,"ltr",,"L"
261,,,"amv",,"Ambelau",,,,,,0,"ltr",,"L"
262,,,"amw",,"Western Neo-Aramaic",,,,,,0,"ltr",,"L"
263,,,"amx",,"Anmatyerre",,,,,,0,"ltr",,"L"
264,,,"amy",,"Ami",,,,,,0,"ltr",,"L"
265,,,"amz",,"Atampaya",,,,,,0,"ltr",,"L"
266,,,"ana",,"Andaqui",,,,,,0,"ltr",,"E"
267,,,"anb",,"Andoa",,,,,,0,"ltr",,"E"
268,,,"anc",,"Ngas",,,,,,0,"ltr",,"L"
269,,,"and",,"Ansus",,,,,,0,"ltr",,"L"
270,,,"ane",,"Xârâcùù",,,,,,0,"ltr",,"L"
271,,,"anf",,"Animere",,,,,,0,"ltr",,"L"
272,,"ang","ang",,"English",,"Old (ca.450-1100)",,,,0,"ltr",,"H"
273,,,"anh",,"Nend",,,,,,0,"ltr",,"L"
274,,,"ani",,"Andi",,,,,,0,"ltr",,"L"
275,,,"anj",,"Anor",,,,,,0,"ltr",,"L"
276,,,"ank",,"Goemai",,,,,,0,"ltr",,"L"
277,,,"anl",,"Anu",,,,,,0,"ltr",,"L"
278,,,"anm",,"Anal",,,,,,0,"ltr",,"L"
279,,,"ann",,"Obolo",,,,,,0,"ltr",,"L"
280,,,"ano",,"Andoque",,,,,,0,"ltr",,"L"
281,,,"anp",,"Angika",,,,,,0,"ltr",,"L"
282,,,"anq",,"Jarawa","India",,,,,0,"ltr",,"L"
283,,,"anr",,"Andh",,,,,,0,"ltr",,"L"
284,,,"ans",,"Anserma",,,,,,0,"ltr",,"E"
285,,,"ant",,"Antakarinya",,,,,,0,"ltr",,"L"
286,,,"anu",,"Anuak",,,,,,0,"ltr",,"L"
287,,,"anv",,"Denya",,,,,,0,"ltr",,"L"
288,,,"anw",,"Anaang",,,,,,0,"ltr",,"L"
289,,,"anx",,"Andra-Hus",,,,,,0,"ltr",,"L"
290,,,"any",,"Anyin",,,,,,0,"ltr",,"L"
291,,,"anz",,"Anem",,,,,,0,"ltr",,"L"
292,,,"aoa",,"Angolar",,,,,,0,"ltr",,"L"
293,,,"aob",,"Abom",,,,,,0,"ltr",,"L"
294,,,"aoc",,"Pemon",,,,,,0,"ltr",,"L"
295,,,"aod",,"Andarum",,,,,,0,"ltr",,"L"
296,,,"aoe",,"Angal Enen",,,,,,0,"ltr",,"L"
297,,,"aof",,"Bragat",,,,,,0,"ltr",,"L"
298,,,"aog",,"Angoram",,,,,,0,"ltr",,"L"
299,,,"aoh",,"Arma",,,,,,0,"ltr",,"E"
300,,,"aoi",,"Anindilyakwa",,,,,,0,"ltr",,"L"
301,,,"aoj",,"Mufian",,,,,,0,"ltr",,"L"
302,,,"aok",,"Arhö",,,,,,0,"ltr",,"L"
303,,,"aol",,"Alor",,,,,,0,"ltr",,"L"
304,,,"aom",,"Ömie",,,,,,0,"ltr",,"L"
305,,,"aon",,"Arapesh",,"Bumbita",,,,0,"ltr",,"L"
306,,,"aor",,"Aore",,,,,,0,"ltr",,"L"
307,,,"aos",,"Taikat",,,,,,0,"ltr",,"L"
308,,,"aot",,"A'tong",,,,,,0,"ltr",,"L"
309,,,"aox",,"Atorada",,,,,,0,"ltr",,"L"
310,,,"aoz",,"Uab Meto",,,,,,0,"ltr",,"L"
311,,,"apb",,"Sa'a",,,,,,0,"ltr",,"L"
312,,,"apc",,"Arabic",,"North Levantine Spoken",,,,0,"rtl",,"L"
313,,,"apd",,"Arabic",,"Sudanese Spoken",,,,0,"rtl",,"L"
314,,,"ape",,"Bukiyip",,,,,,0,"ltr",,"L"
315,,,"apg",,"Ampanang",,,,,,0,"ltr",,"L"
316,,,"aph",,"Athpariya",,,,,,0,"ltr",,"L"
317,,,"api",,"Apiacá",,,,,,0,"ltr",,"L"
318,,,"apj",,"Apache",,"Jicarilla",,,,0,"ltr",,"L"
319,,,"apk",,"Apache",,"Kiowa",,,,0,"ltr",,"L"
320,,,"apl",,"Apache",,"Lipan",,,,0,"ltr",,"L"
321,,,"apm",,"Apache",,"Mescalero-Chiricahua",,,,0,"ltr",,"L"
322,,,"apn",,"Apinayé",,,,,,0,"ltr",,"L"
323,,,"apo",,"Apalik",,,,,,0,"ltr",,"L"
324,,,"app",,"Apma",,,,,,0,"ltr",,"L"
325,,,"apq",,"A-Pucikwar",,,,,,0,"ltr",,"L"
326,,,"apr",,"Arop-Lukep",,,,,,0,"ltr",,"L"
327,,,"aps",,"Arop-Sissano",,,,,,0,"ltr",,"L"
328,,,"apt",,"Apatani",,,,,,0,"ltr",,"L"
329,,,"apu",,"Apurinã",,,,,,0,"ltr",,"L"
330,,,"apw",,"Apache",,"Western",,,,0,"ltr",,"L"
331,,,"apx",,"Aputai",,,,,,0,"ltr",,"L"
332,,,"apy",,"Apalaí",,,,,,0,"ltr",,"L"
333,,,"apz",,"Safeyoka",,,,,,0,"ltr",,"L"
334,,,"aqc",,"Archi",,,,,,0,"ltr",,"L"
335,,,"aqg",,"Arigidi",,,,,,0,"ltr",,"L"
336,,,"aqm",,"Atohwaim",,,,,,0,"ltr",,"L"
337,,,"aqn",,"Alta",,"Northern",,,,0,"ltr",,"L"
338,,,"aqp",,"Atakapa",,,,,,0,"ltr",,"E"
339,,,"aqr",,"Arhâ",,,,,,0,"ltr",,"L"
340,"ar","ara","ara",,"Arabic",,,"العربية",,,1,"rtl",,"L"
341,,,"arb",,"Arabic",,"Standard",,,,0,"rtl",,"L"
342,,"arc","arc",,"Aramaic",,,,,,0,"ltr",,"A"
343,,,"ard",,"Arabana",,,,,,0,"ltr",,"L"
344,,,"are",,"Arrarnta",,"Western",,,,0,"ltr",,"L"
345,,,"arf",,"Arafundi",,,,,,0,"ltr",,"L"
346,"an","arg","arg",,"Aragonese",,,,,,0,"ltr",,"L"
347,,,"arh",,"Arhuaco",,,,,,0,"ltr",,"L"
348,,,"ari",,"Arikara",,,,,,0,"ltr",,"L"
349,,,"arj",,"Arapaso",,,,,,0,"ltr",,"L"
350,,,"ark",,"Arikapú",,,,,,0,"ltr",,"L"
351,,,"arl",,"Arabela",,,,,,0,"ltr",,"L"
352,,"arn","arn",,"Araucanian",,,,,,0,"ltr",,"L"
353,,,"aro",,"Araona",,,,,,0,"ltr",,"L"
354,,"arp","arp",,"Arapaho",,,,,,0,"ltr",,"L"
355,,,"arq",,"Arabic",,"Algerian Spoken",,,,0,"rtl",,"L"
356,,,"arr",,"Karo","Brazil",,,,,0,"ltr",,"L"
357,,,"ars",,"Arabic",,"Najdi Spoken",,,,0,"rtl",,"L"
358,,,"aru",,"Arua",,,,,,0,"ltr",,"E"
359,,,"arv",,"Arbore",,,,,,0,"ltr",,"L"
360,,"arw","arw",,"Arawak",,,,,,0,"ltr",,"L"
361,,,"arx",,"Aruá",,,,,,0,"ltr",,"L"
362,,,"ary",,"Arabic",,"Moroccan Spoken",,,,0,"rtl",,"L"
363,,,"arz",,"Arabic",,"Egyptian Spoken",,,,0,"rtl",,"L"
364,,,"asa",,"Asu","Tanzania",,,,,0,"ltr",,"L"
365,,,"asb",,"Assiniboine",,,,,,0,"ltr",,"L"
366,,,"asc",,"Asmat",,"Casuarina Coast",,,,0,"ltr",,"L"
367,,,"asd",,"Asas",,,,,,0,"ltr",,"L"
368,,,"ase",,"American Sign Language",,,,,,0,"ltr",,"L"
369,,,"asf",,"Australian Sign Language",,,,,,0,"ltr",,"L"
370,,,"asg",,"Cishingini",,,,,,0,"ltr",,"L"
371,,,"ash",,"Abishira",,,,,,0,"ltr",,"E"
372,,,"asi",,"Buruwai",,,,,,0,"ltr",,"L"
373,,,"asj",,"Nsari",,,,,,0,"ltr",,"L"
374,,,"ask",,"Ashkun",,,,,,0,"ltr",,"L"
375,,,"asl",,"Asilulu",,,,,,0,"ltr",,"L"
376,"as","asm","asm",,"Assamese",,,,,,0,"ltr",,"L"
377,,,"asn",,"Asuriní",,"Xingú",,,,0,"ltr",,"L"
378,,,"aso",,"Dano",,,,,,0,"ltr",,"L"
379,,,"asp",,"Algerian Sign Language",,,,,,0,"ltr",,"L"
380,,,"asq",,"Austrian Sign Language",,,,,,0,"ltr",,"L"
381,,,"asr",,"Asuri",,,,,,0,"ltr",,"L"
382,,,"ass",,"Ipulo",,,,,,0,"ltr",,"L"
383,,"ast","ast",,"Asturian; Bable",,,,,,0,"ltr",,"L"
384,,,"asu",,"Asuriní",,,,,,0,"ltr",,"L"
385,,,"asv",,"Asoa",,,,,,0,"ltr",,"L"
386,,,"asw",,"Australian Aborigines Sign Language",,,,,,0,"ltr",,"L"
387,,,"asx",,"Muratayak",,,,,,0,"ltr",,"L"
388,,,"asy",,"Asmat",,"Yaosakor",,,,0,"ltr",,"L"
389,,,"asz",,"As",,,,,,0,"ltr",,"L"
390,,,"ata",,"Pele-Ata",,,,,,0,"ltr",,"L"
391,,,"atb",,"Zaiwa",,,,,,0,"ltr",,"L"
392,,,"atc",,"Atsahuaca",,,,,,0,"ltr",,"E"
393,,,"atd",,"Manobo",,"Ata",,,,0,"ltr",,"L"
394,,,"ate",,"Atemble",,,,,,0,"ltr",,"L"
395,,,"atf",,"Atuence",,,,,,0,"ltr",,"L"
396,,,"atg",,"Ivbie North-Okpela-Arhe",,,,,,0,"ltr",,"L"
397,,,"ati",,"Attié",,,,,,0,"ltr",,"L"
398,,,"atj",,"Atikamekw",,,,,,0,"ltr",,"L"
399,,,"atk",,"Ati",,,,,,0,"ltr",,"L"
400,,,"atl",,"Agta",,"Mt. Iraya",,,,0,"ltr",,"L"
401,,,"atm",,"Ata",,,,,,0,"ltr",,"L"
402,,,"atn",,"Ashtiani",,,,,,0,"ltr",,"L"
403,,,"ato",,"Atong",,,,,,0,"ltr",,"L"
404,,,"atp",,"Atta",,"Pudtol",,,,0,"ltr",,"L"
405,,,"atq",,"Aralle-Tabulahan",,,,,,0,"ltr",,"L"
406,,,"atr",,"Atruahí",,,,,,0,"ltr",,"L"
407,,,"ats",,"Gros Ventre",,,,,,0,"ltr",,"L"
408,,,"att",,"Atta",,"Pamplona",,,,0,"ltr",,"L"
409,,,"atu",,"Reel",,,,,,0,"ltr",,"L"
410,,,"atv",,"Altai",,"Northern",,,,0,"ltr",,"L"
411,,,"atw",,"Atsugewi",,,,,,0,"ltr",,"L"
412,,,"atx",,"Arutani",,,,,,0,"ltr",,"L"
413,,,"aty",,"Aneityum",,,,,,0,"ltr",,"L"
414,,,"atz",,"Arta",,,,,,0,"ltr",,"L"
415,,,"aua",,"Asumboa",,,,,,0,"ltr",,"L"
416,,,"auc",,"Waorani",,,,,,0,"ltr",,"L"
417,,,"aud",,"Anuta",,,,,,0,"ltr",,"L"
418,,,"aue",,"=/Kx'au//'ein",,,,,,0,"ltr",,"L"
419,,,"aug",,"Aguna",,,,,,0,"ltr",,"L"
420,,,"auh",,"Aushi",,,,,,0,"ltr",,"L"
421,,,"aui",,"Anuki",,,,,,0,"ltr",,"L"
422,,,"auj",,"Awjilah",,,,,,0,"ltr",,"L"
423,,,"auk",,"Heyo",,,,,,0,"ltr",,"L"
424,,,"aul",,"Aulua",,,,,,0,"ltr",,"L"
425,,,"aum",,"Asu","Nigeria",,,,,0,"ltr",,"L"
426,,,"aun",,"One",,"Molmo",,,,0,"ltr",,"L"
427,,,"auo",,"Auyokawa",,,,,,0,"ltr",,"E"
428,,,"aup",,"Makayam",,,,,,0,"ltr",,"L"
429,,,"auq",,"Anus",,,,,,0,"ltr",,"L"
430,,,"aur",,"Aruek",,,,,,0,"ltr",,"L"
431,,,"aut",,"Austral",,,,,,0,"ltr",,"L"
432,,,"auu",,"Auye",,,,,,0,"ltr",,"L"
433,,,"auv",,"Auvergnat",,,,,,0,"ltr",,"L"
434,,,"auw",,"Awyi",,,,,,0,"ltr",,"L"
435,,,"aux",,"Aurá",,,,,,0,"ltr",,"L"
436,,,"auy",,"Awiyaana",,,,,,0,"ltr",,"L"
437,,,"auz",,"Arabic",,"Uzbeki Spoken",,,,0,"rtl",,"L"
438,"av","ava","ava",,"Avaric",,,,,,0,"ltr",,"L"
439,,,"avb",,"Avau",,,,,,0,"ltr",,"L"
440,,,"avd",,"Alviri-Vidari",,,,,,0,"ltr",,"L"
441,"ae","ave","ave",,"Avestan",,,,,,0,"ltr",,"A"
442,,,"avi",,"Avikam",,,,,,0,"ltr",,"L"
443,,,"avl",,"Arabic",,"Eastern Egyptian Bedawi Spoken",,,,0,"rtl",,"L"
444,,,"avn",,"Avatime",,,,,,0,"ltr",,"L"
445,,,"avo",,"Agavotaguerra",,,,,,0,"ltr",,"L"
446,,,"avs",,"Aushiri",,,,,,0,"ltr",,"E"
447,,,"avt",,"Au",,,,,,0,"ltr",,"L"
448,,,"avu",,"Avokaya",,,,,,0,"ltr",,"L"
449,,,"avv",,"Avá-Canoeiro",,,,,,0,"ltr",,"L"
450,,"awa","awa",,"Awadhi",,,,,,0,"ltr",,"L"
451,,,"awb",,"Awa",,,,,,0,"ltr",,"L"
452,,,"awc",,"Acipa",,"Western",,,,0,"ltr",,"L"
453,,,"awe",,"Awetí",,,,,,0,"ltr",,"L"
454,,,"awh",,"Awbono",,,,,,0,"ltr",,"L"
455,,,"awi",,"Aekyom",,,,,,0,"ltr",,"L"
456,,,"awk",,"Awabakal",,,,,,0,"ltr",,"E"
457,,,"awm",,"Arawum",,,,,,0,"ltr",,"L"
458,,,"awn",,"Awngi",,,,,,0,"ltr",,"L"
459,,,"awo",,"Awak",,,,,,0,"ltr",,"L"
460,,,"awr",,"Awera",,,,,,0,"ltr",,"L"
461,,,"aws",,"Awyu",,"South",,,,0,"ltr",,"L"
462,,,"awt",,"Araweté",,,,,,0,"ltr",,"L"
463,,,"awu",,"Awyu",,"Central",,,,0,"ltr",,"L"
464,,,"awv",,"Awyu",,"Jair",,,,0,"ltr",,"L"
465,,,"aww",,"Awun",,,,,,0,"ltr",,"L"
466,,,"awx",,"Awara",,,,,,0,"ltr",,"L"
467,,,"awy",,"Awyu",,"Edera",,,,0,"ltr",,"L"
468,,,"axb",,"Abipon",,,,,,0,"ltr",,"E"
469,,,"axg",,"Arára",,"Mato Grosso",,,,0,"ltr",,"E"
470,,,"axk",,"Yaka","Central African Republic",,,,,0,"ltr",,"L"
471,,,"axm",,"Armenian",,"Middle",,,,0,"ltr",,"H"
472,,,"axx",,"Xaragure",,,,,,0,"ltr",,"L"
473,,,"aya",,"Awar",,,,,,0,"ltr",,"L"
474,,,"ayb",,"Gbe",,"Ayizo",,,,0,"ltr",,"L"
475,,,"ayc",,"Aymara",,"Southern",,,,0,"ltr",,"L"
476,,,"ayd",,"Ayabadhu",,,,,,0,"ltr",,"L"
477,,,"aye",,"Ayere",,,,,,0,"ltr",,"L"
478,,,"ayg",,"Ginyanga",,,,,,0,"ltr",,"L"
479,,,"ayh",,"Arabic",,"Hadrami Spoken",,,,0,"rtl",,"L"
480,,,"ayi",,"Leyigha",,,,,,0,"ltr",,"L"
481,,,"ayk",,"Akuku",,,,,,0,"ltr",,"L"
482,,,"ayl",,"Arabic",,"Libyan Spoken",,,,0,"rtl",,"L"
483,"ay","aym","aym",,"Aymara",,,,,,1,"ltr",,"L"
484,,,"ayn",,"Arabic",,"Sanaani Spoken",,,,0,"rtl",,"L"
485,,,"ayo",,"Ayoreo",,,,,,0,"ltr",,"L"
486,,,"ayp",,"Arabic",,"North Mesopotamian Spoken",,,,0,"rtl",,"L"
487,,,"ayq",,"Ayi","Papua New Guinea",,,,,0,"ltr",,"L"
488,,,"ayr",,"Aymara",,"Central",,,,0,"ltr",,"L"
489,,,"ays",,"Ayta",,"Sorsogon",,,,0,"ltr",,"L"
490,,,"ayt",,"Ayta",,"Bataan",,,,0,"ltr",,"L"
491,,,"ayu",,"Ayu",,,,,,0,"ltr",,"L"
492,,,"ayx",,"Ayi","China",,,,,0,"ltr",,"L"
493,,,"ayy",,"Ayta",,"Tayabas",,,,0,"ltr",,"E"
494,,,"ayz",,"Mai Brat",,,,,,0,"ltr",,"L"
495,,,"azb",,"Azerbaijani",,"South",,,,0,"ltr",,"L"
496,"az","aze","aze",,"Azerbaijani",,,"azərbaycan",,,1,"ltr",,"L"
497,,,"azg",,"Amuzgo",,"San Pedro Amuzgos",,,,0,"ltr",,"L"
498,,,"azj",,"Azerbaijani",,"North",,,,0,"ltr",,"L"
499,,,"azm",,"Amuzgo",,"Ipalapa",,,,0,"ltr",,"L"
500,,,"azo",,"Awing",,,,,,0,"ltr",,"L"
501,,,"azr",,"Adzera",,,,,,0,"ltr",,"L"
502,,,"azt",,"Atta",,"Faire",,,,0,"ltr",,"L"
503,,,"azz",,"Nahuatl",,"Highland Puebla",,,,0,"ltr",,"L"
504,,,"baa",,"Babatana",,,,,,0,"ltr",,"L"
505,,,"bab",,"Bainouk-Gunyuño",,,,,,0,"ltr",,"L"
506,,,"bac",,"Badui",,,,,,0,"ltr",,"L"
507,,,"bae",,"Baré",,,,,,0,"ltr",,"E"
508,,,"baf",,"Nubaca",,,,,,0,"ltr",,"L"
509,,,"bag",,"Tuki",,,,,,0,"ltr",,"L"
510,,,"bah",,"Bahamas Creole English",,,,,,0,"ltr",,"L"
511,,,"baj",,"Barakai",,,,,,0,"ltr",,"L"
512,"ba","bak","bak",,"Bashkir",,,,,,0,"ltr",,"L"
513,,"bal","bal",,"Baluchi",,,,,,1,"ltr",,"L"
514,"bm","bam","bam",,"Bambara",,,"Bamanankan",,,0,"ltr",,"L"
515,,"ban","ban",,"Balinese",,,,,,0,"ltr",,"L"
516,,,"bao",,"Waimaha",,,,,,0,"ltr",,"L"
517,,,"bap",,"Bantawa",,,,,,0,"ltr",,"L"
518,,,"bar",,"Bavarian",,,,,,0,"ltr",,"L"
519,,"bas","bas",,"Basa","Cameroon",,,,,0,"ltr",,"L"
520,,,"bau",,"Bada","Nigeria",,,,,0,"ltr",,"L"
521,,,"bav",,"Vengo",,,,,,0,"ltr",,"L"
522,,,"baw",,"Bambili-Bambui",,,,,,0,"ltr",,"L"
523,,,"bax",,"Bamun",,,,,,0,"ltr",,"L"
524,,,"bay",,"Batuley",,,,,,0,"ltr",,"L"
525,,,"baz",,"Tunen",,,,,,0,"ltr",,"L"
526,,,"bba",,"Baatonum",,,,,,0,"ltr",,"L"
527,,,"bbb",,"Barai",,,,,,0,"ltr",,"L"
528,,,"bbc",,"Batak Toba",,,,,,0,"ltr",,"L"
529,,,"bbd",,"Bau",,,,,,0,"ltr",,"L"
530,,,"bbe",,"Bangba",,,,,,0,"ltr",,"L"
531,,,"bbf",,"Baibai",,,,,,0,"ltr",,"L"
532,,,"bbg",,"Barama",,,,,,0,"ltr",,"L"
533,,,"bbh",,"Bugan",,,,,,0,"ltr",,"L"
534,,,"bbi",,"Barombi",,,,,,0,"ltr",,"L"
535,,,"bbj",,"Ghomálá'",,,,,,0,"ltr",,"L"
536,,,"bbk",,"Babanki",,,,,,0,"ltr",,"L"
537,,,"bbl",,"Bats",,,,,,0,"ltr",,"L"
538,,,"bbm",,"Babango",,,,,,0,"ltr",,"L"
539,,,"bbn",,"Uneapa",,,,,,0,"ltr",,"L"
540,,,"bbo",,"Bobo Madaré",,"Northern",,,,0,"ltr",,"L"
541,,,"bbp",,"Banda",,"West Central",,,,0,"ltr",,"L"
542,,,"bbq",,"Bamali",,,,,,0,"ltr",,"L"
543,,,"bbr",,"Girawa",,,,,,0,"ltr",,"L"
544,,,"bbs",,"Bakpinka",,,,,,0,"ltr",,"L"
545,,,"bbt",,"Mburku",,,,,,0,"ltr",,"L"
546,,,"bbu",,"Kulung","Nigeria",,,,,0,"ltr",,"L"
547,,,"bbv",,"Karnai",,,,,,0,"ltr",,"L"
548,,,"bbw",,"Baba",,,,,,0,"ltr",,"L"
549,,,"bbx",,"Bubia",,,,,,0,"ltr",,"L"
550,,,"bby",,"Befang",,,,,,0,"ltr",,"L"
551,,,"bbz",,"Arabic",,"Babalia Creole",,,,0,"rtl",,"L"
552,,,"bca",,"Bai",,"Central",,,,0,"ltr",,"L"
553,,,"bcb",,"Bainouk-Samik",,,,,,0,"ltr",,"L"
554,,,"bcc",,"Balochi",,"Southern",,,,0,"ltr",,"L"
555,,,"bcd",,"Babar",,"North",,,,0,"ltr",,"L"
556,,,"bce",,"Bamenyam",,,,,,0,"ltr",,"L"
557,,,"bcf",,"Bamu",,,,,,0,"ltr",,"L"
558,,,"bcg",,"Baga Binari",,,,,,0,"ltr",,"L"
559,,,"bch",,"Bariai",,,,,,0,"ltr",,"L"
560,,,"bci",,"Baoulé",,,,,,0,"ltr",,"L"
561,,,"bcj",,"Bardi",,,,,,0,"ltr",,"L"
562,,,"bck",,"Bunaba",,,,,,0,"ltr",,"L"
563,,,"bcl",,"Bicolano",,"Central",,,,0,"ltr",,"L"
564,,,"bcm",,"Bannoni",,,,,,0,"ltr",,"L"
565,,,"bcn",,"Bali","Nigeria",,,,,0,"ltr",,"L"
566,,,"bco",,"Kaluli",,,,,,0,"ltr",,"L"
567,,,"bcp",,"Bali","Democratic Republic of Congo",,,,,0,"ltr",,"L"
568,,,"bcq",,"Bench",,,,,,0,"ltr",,"L"
569,,,"bcr",,"Babine",,,,,,0,"ltr",,"L"
570,,,"bcs",,"Kohumono",,,,,,0,"ltr",,"L"
571,,,"bct",,"Bendi",,,,,,0,"ltr",,"L"
572,,,"bcu",,"Awad Bing",,,,,,0,"ltr",,"L"
573,,,"bcv",,"Shoo-Minda-Nye",,,,,,0,"ltr",,"L"
574,,,"bcw",,"Bana",,,,,,0,"ltr",,"L"
575,,,"bcx",,"Pamona",,,,,,0,"ltr",,"L"
576,,,"bcy",,"Bacama",,,,,,0,"ltr",,"L"
577,,,"bcz",,"Bainouk-Gunyaamolo",,,,,,0,"ltr",,"L"
578,,,"bda",,"Bayot",,,,,,0,"ltr",,"L"
579,,,"bdb",,"Basap",,,,,,0,"ltr",,"L"
580,,,"bdc",,"Emberá-Baudó",,,,,,0,"ltr",,"L"
581,,,"bdd",,"Bunama",,,,,,0,"ltr",,"L"
582,,,"bde",,"Bade",,,,,,0,"ltr",,"L"
583,,,"bdg",,"Bonggi",,,,,,0,"ltr",,"L"
584,,,"bdh",,"Baka","Sudan",,,,,0,"ltr",,"L"
585,,,"bdi",,"Burun",,,,,,0,"ltr",,"L"
586,,,"bdj",,"Bai",,,,,,0,"ltr",,"L"
587,,,"bdk",,"Budukh",,,,,,0,"ltr",,"L"
588,,,"bdl",,"Bajau",,"Indonesian",,,,0,"ltr",,"L"
589,,,"bdm",,"Buduma",,,,,,0,"ltr",,"L"
590,,,"bdn",,"Baldemu",,,,,,0,"ltr",,"L"
591,,,"bdo",,"Bernde",,,,,,0,"ltr",,"L"
592,,,"bdp",,"Bende",,,,,,0,"ltr",,"L"
593,,,"bdq",,"Bahnar",,,,,,0,"ltr",,"L"
594,,,"bdr",,"Bajau",,"West Coast",,,,0,"ltr",,"L"
595,,,"bds",,"Burunge",,,,,,0,"ltr",,"L"
596,,,"bdt",,"Bokoto",,,,,,0,"ltr",,"L"
597,,,"bdu",,"Oroko",,,,,,0,"ltr",,"L"
598,,,"bdv",,"Bodo Parja",,,,,,0,"ltr",,"L"
599,,,"bdw",,"Baham",,,,,,0,"ltr",,"L"
600,,,"bdx",,"Budong-Budong",,,,,,0,"ltr",,"L"
601,,,"bdy",,"Bandjalang",,,,,,0,"ltr",,"L"
602,,,"bdz",,"Badeshi",,,,,,0,"ltr",,"L"
603,,,"bea",,"Beaver",,,,,,0,"ltr",,"L"
604,,,"beb",,"Bebele",,,,,,0,"ltr",,"L"
605,,,"bec",,"Iceve-Maci",,,,,,0,"ltr",,"L"
606,,,"bed",,"Bedoanas",,,,,,0,"ltr",,"L"
607,,,"bee",,"Byangsi",,,,,,0,"ltr",,"L"
608,,,"bef",,"Benabena",,,,,,0,"ltr",,"L"
609,,,"beg",,"Belait",,,,,,0,"ltr",,"L"
610,,,"beh",,"Biali",,,,,,0,"ltr",,"L"
611,,,"bei",,"Bekati'",,,,,,0,"ltr",,"L"
612,,"bej","bej",,"Beja",,,,,,0,"ltr",,"L"
613,,,"bek",,"Bebeli",,,,,,0,"ltr",,"L"
614,"be","bel","bel",,"Belarusian",,,"Беларуская",,,0,"ltr",,"L"
615,,"bem","bem",,"Bemba","Zambia",,,,,0,"ltr",,"L"
616,"bn","ben","ben",,"Bengali",,,,,,0,"ltr",,"L"
617,,,"beo",,"Beami",,,,,,0,"ltr",,"L"
618,,,"bep",,"Besoa",,,,,,0,"ltr",,"L"
619,,,"beq",,"Beembe",,,,,,0,"ltr",,"L"
620,,,"bes",,"Besme",,,,,,0,"ltr",,"L"
621,,,"bet",,"Béte",,"Guiberoua",,,,0,"ltr",,"L"
622,,,"beu",,"Blagar",,,,,,0,"ltr",,"L"
623,,,"bev",,"Bété",,"Daloa",,,,0,"ltr",,"L"
624,,,"bew",,"Betawi",,,,,,0,"ltr",,"L"
625,,,"bex",,"Jur Modo",,,,,,0,"ltr",,"L"
626,,,"bey",,"Beli","Papua New Guinea",,,,,0,"ltr",,"L"
627,,,"bez",,"Bena","Tanzania",,,,,0,"ltr",,"L"
628,,,"bfa",,"Bari",,,,,,0,"ltr",,"L"
629,,,"bfb",,"Bareli",,"Pauri",,,,0,"ltr",,"L"
630,,,"bfc",,"Bai",,"Northern",,,,0,"ltr",,"L"
631,,,"bfd",,"Bafut",,,,,,0,"ltr",,"L"
632,,,"bfe",,"Betaf",,,,,,0,"ltr",,"L"
633,,,"bff",,"Bofi",,,,,,0,"ltr",,"L"
634,,,"bfg",,"Kayan",,"Busang",,,,0,"ltr",,"L"
635,,,"bfh",,"Blafe",,,,,,0,"ltr",,"L"
636,,,"bfi",,"British Sign Language",,,,,,0,"ltr",,"L"
637,,,"bfj",,"Bafanji",,,,,,0,"ltr",,"L"
638,,,"bfk",,"Ban Khor Sign Language",,,,,,0,"ltr",,"L"
639,,,"bfl",,"Banda-Ndélé",,,,,,0,"ltr",,"L"
640,,,"bfm",,"Mmen",,,,,,0,"ltr",,"L"
641,,,"bfn",,"Bunak",,,,,,0,"ltr",,"L"
642,,,"bfo",,"Birifor",,"Malba",,,,0,"ltr",,"L"
643,,,"bfp",,"Beba",,,,,,0,"ltr",,"L"
644,,,"bfq",,"Badaga",,,,,,0,"ltr",,"L"
645,,,"bfr",,"Bazigar",,,,,,0,"ltr",,"L"
646,,,"bfs",,"Bai",,"Southern",,,,0,"ltr",,"L"
647,,,"bft",,"Balti",,,,,,0,"ltr",,"L"
648,,,"bfu",,"Gahri",,,,,,0,"ltr",,"L"
649,,,"bfw",,"Bondo",,,,,,0,"ltr",,"L"
650,,,"bfy",,"Bagheli",,,,,,0,"ltr",,"L"
651,,,"bfz",,"Pahari",,"Mahasu",,,,0,"ltr",,"L"
652,,,"bga",,"Gwamhi-Wuri",,,,,,0,"ltr",,"L"
653,,,"bgb",,"Bobongko",,,,,,0,"ltr",,"L"
654,,,"bgc",,"Haryanvi",,,,,,0,"ltr",,"L"
655,,,"bgd",,"Bareli",,"Rathwi",,,,0,"ltr",,"L"
656,,,"bge",,"Bauria",,,,,,0,"ltr",,"L"
657,,,"bgf",,"Bangandu",,,,,,0,"ltr",,"L"
658,,,"bgg",,"Bugun",,,,,,0,"ltr",,"L"
659,,,"bgh",,"Bogan",,,,,,0,"ltr",,"L"
660,,,"bgi",,"Giangan",,,,,,0,"ltr",,"L"
661,,,"bgj",,"Bangolan",,,,,,0,"ltr",,"L"
662,,,"bgk",,"Bit",,,,,,0,"ltr",,"L"
663,,,"bgl",,"Bo","Laos",,,,,0,"ltr",,"L"
664,,,"bgm",,"Baga Mboteni",,,,,,0,"ltr",,"L"
665,,,"bgn",,"Balochi",,"Western",,,,0,"ltr",,"L"
666,,,"bgo",,"Baga Koga",,,,,,0,"ltr",,"L"
667,,,"bgp",,"Balochi",,"Eastern",,,,0,"ltr",,"L"
668,,,"bgq",,"Bagri",,,,,,0,"ltr",,"L"
669,,,"bgr",,"Chin",,"Bawm",,,,0,"ltr",,"L"
670,,,"bgs",,"Tagabawa",,,,,,0,"ltr",,"L"
671,,,"bgt",,"Bughotu",,,,,,0,"ltr",,"L"
672,,,"bgu",,"Mbongno",,,,,,0,"ltr",,"L"
673,,,"bgv",,"Warkay-Bipim",,,,,,0,"ltr",,"L"
674,,,"bgw",,"Bhatri",,,,,,0,"ltr",,"L"
675,,,"bgx",,"Balkan Gagauz Turkish",,,,,,0,"ltr",,"L"
676,,,"bgy",,"Benggoi",,,,,,0,"ltr",,"L"
677,,,"bgz",,"Banggai",,,,,,0,"ltr",,"L"
678,,,"bha",,"Bharia",,,,,,0,"ltr",,"L"
679,,,"bhb",,"Bhili",,,,,,0,"ltr",,"L"
680,,,"bhc",,"Biga",,,,,,0,"ltr",,"L"
681,,,"bhd",,"Bhadrawahi",,,,,,0,"ltr",,"L"
682,,,"bhe",,"Bhaya",,,,,,0,"ltr",,"L"
683,,,"bhf",,"Odiai",,,,,,0,"ltr",,"L"
684,,,"bhg",,"Binandere",,,,,,0,"ltr",,"L"
685,,,"bhh",,"Bukharic",,,,,,0,"ltr",,"L"
686,,,"bhi",,"Bhilali",,,,,,0,"ltr",,"L"
687,,,"bhj",,"Bahing",,,,,,0,"ltr",,"L"
688,,,"bhk",,"Bicolano",,"Albay",,,,0,"ltr",,"L"
689,,,"bhl",,"Bimin",,,,,,0,"ltr",,"L"
690,,,"bhm",,"Bathari",,,,,,0,"ltr",,"L"
691,,,"bhn",,"Bohtan Neo-Aramaic",,,,,,0,"ltr",,"L"
692,,"bho","bho",,"Bhojpuri",,,,,,0,"ltr",,"L"
693,,,"bhp",,"Bima",,,,,,0,"ltr",,"L"
694,,,"bhq",,"Tukang Besi South",,,,,,0,"ltr",,"L"
695,,,"bhr",,"Malagasy",,"Bara",,,,0,"ltr",,"L"
696,,,"bhs",,"Buwal",,,,,,0,"ltr",,"L"
697,,,"bht",,"Bhattiyali",,,,,,0,"ltr",,"L"
698,,,"bhu",,"Bhunjia",,,,,,0,"ltr",,"L"
699,,,"bhv",,"Bahau",,,,,,0,"ltr",,"L"
700,,,"bhw",,"Biak",,,,,,0,"ltr",,"L"
701,,,"bhx",,"Bhalay",,,,,,0,"ltr",,"L"
702,,,"bhy",,"Bhele",,,,,,0,"ltr",,"L"
703,,,"bhz",,"Bada","Indonesia",,,,,0,"ltr",,"L"
704,,,"bia",,"Badimaya",,,,,,0,"ltr",,"L"
705,,,"bib",,"Bissa",,,,,,0,"ltr",,"L"
706,,,"bic",,"Bikaru",,,,,,0,"ltr",,"L"
707,,,"bid",,"Bidiyo",,,,,,0,"ltr",,"L"
708,,,"bie",,"Bepour",,,,,,0,"ltr",,"L"
709,,,"bif",,"Biafada",,,,,,0,"ltr",,"L"
710,,,"big",,"Biangai",,,,,,0,"ltr",,"L"
711,,,"bii",,"Bisu",,,,,,0,"ltr",,"L"
712,,,"bij",,"Vaghat-Ya-Bijim-Legeri",,,,,,0,"ltr",,"L"
713,,"bik","bik",,"Bikol",,,,,,1,"ltr",,"L"
714,,,"bil",,"Bile",,,,,,0,"ltr",,"L"
715,,,"bim",,"Bimoba",,,,,,0,"ltr",,"L"
716,,"bin","bin",,"Bini",,,,,,0,"ltr",,"L"
717,,,"bio",,"Nai",,,,,,0,"ltr",,"L"
718,,,"bip",,"Bila",,,,,,0,"ltr",,"L"
719,,,"biq",,"Bipi",,,,,,0,"ltr",,"L"
720,,,"bir",,"Bisorio",,,,,,0,"ltr",,"L"
721,"bi","bis","bis",,"Bislama",,,,,,0,"ltr",,"L"
722,,,"bit",,"Berinomo",,,,,,0,"ltr",,"L"
723,,,"biu",,"Biete",,,,,,0,"ltr",,"L"
724,,,"biv",,"Birifor",,"Southern",,,,0,"ltr",,"L"
725,,,"biw",,"Kol","Cameroon",,,,,0,"ltr",,"L"
726,,,"bix",,"Bijori",,,,,,0,"ltr",,"L"
727,,,"biy",,"Birhor",,,,,,0,"ltr",,"L"
728,,,"biz",,"Baloi",,,,,,0,"ltr",,"L"
729,,,"bja",,"Budza",,,,,,0,"ltr",,"L"
730,,,"bjb",,"Banggarla",,,,,,0,"ltr",,"E"
731,,,"bjc",,"Bariji",,,,,,0,"ltr",,"L"
732,,,"bjd",,"Bandjigali",,,,,,0,"ltr",,"L"
733,,,"bje",,"Biao-Jiao Mien",,,,,,0,"ltr",,"L"
734,,,"bjf",,"Barzani Jewish Neo-Aramaic",,,,,,0,"ltr",,"L"
735,,,"bjg",,"Bidyogo",,,,,,0,"ltr",,"L"
736,,,"bjh",,"Bahinemo",,,,,,0,"ltr",,"L"
737,,,"bji",,"Burji",,,,,,0,"ltr",,"L"
738,,,"bjj",,"Kanauji",,,,,,0,"ltr",,"L"
739,,,"bjk",,"Barok",,,,,,0,"ltr",,"L"
740,,,"bjl",,"Bulu","Papua New Guinea",,,,,0,"ltr",,"L"
741,,,"bjm",,"Bajelani",,,,,,0,"ltr",,"L"
742,,,"bjn",,"Banjar",,,,,,0,"ltr",,"L"
743,,,"bjo",,"Banda",,"Mid-Southern",,,,0,"ltr",,"L"
744,,,"bjq",,"Malagasy",,"Southern Betsimisaraka",,,,0,"ltr",,"L"
745,,,"bjr",,"Binumarien",,,,,,0,"ltr",,"L"
746,,,"bjs",,"Bajan",,,,,,0,"ltr",,"L"
747,,,"bjt",,"Balanta-Ganja",,,,,,0,"ltr",,"L"
748,,,"bju",,"Busuu",,,,,,0,"ltr",,"L"
749,,,"bjv",,"Bedjond",,,,,,0,"ltr",,"L"
750,,,"bjw",,"Bakwé",,,,,,0,"ltr",,"L"
751,,,"bjx",,"Itneg",,"Banao",,,,0,"ltr",,"L"
752,,,"bjy",,"Bayali",,,,,,0,"ltr",,"E"
753,,,"bjz",,"Baruga",,,,,,0,"ltr",,"L"
754,,,"bka",,"Kyak",,,,,,0,"ltr",,"L"
755,,,"bkb",,"Finallig",,,,,,0,"ltr",,"L"
756,,,"bkc",,"Baka","Cameroon",,,,,0,"ltr",,"L"
757,,,"bkd",,"Binukid",,,,,,0,"ltr",,"L"
758,,,"bke",,"Bengkulu",,,,,,0,"ltr",,"L"
759,,,"bkf",,"Beeke",,,,,,0,"ltr",,"L"
760,,,"bkg",,"Buraka",,,,,,0,"ltr",,"L"
761,,,"bkh",,"Bakoko",,,,,,0,"ltr",,"L"
762,,,"bki",,"Baki",,,,,,0,"ltr",,"L"
763,,,"bkj",,"Pande",,,,,,0,"ltr",,"L"
764,,,"bkk",,"Brokskat",,,,,,0,"ltr",,"L"
765,,,"bkl",,"Berik",,,,,,0,"ltr",,"L"
766,,,"bkm",,"Kom","Cameroon",,,,,0,"ltr",,"L"
767,,,"bkn",,"Bukitan",,,,,,0,"ltr",,"L"
768,,,"bko",,"Kwa'",,,,,,0,"ltr",,"L"
769,,,"bkp",,"Boko","Democratic Republic of Congo",,,,,0,"ltr",,"L"
770,,,"bkq",,"Bakairí",,,,,,0,"ltr",,"L"
771,,,"bkr",,"Bakumpai",,,,,,0,"ltr",,"L"
772,,,"bks",,"Sorsogon",,"Masbate",,,,0,"ltr",,"L"
773,,,"bkt",,"Boloki",,,,,,0,"ltr",,"L"
774,,,"bku",,"Buhid",,,,,,0,"ltr",,"L"
775,,,"bkv",,"Bekwarra",,,,,,0,"ltr",,"L"
776,,,"bkw",,"Bekwil",,,,,,0,"ltr",,"L"
777,,,"bkx",,"Baikeno",,,,,,0,"ltr",,"L"
778,,,"bky",,"Bokyi",,,,,,0,"ltr",,"L"
779,,,"bkz",,"Bungku",,,,,,0,"ltr",,"L"
780,,"bla","bla",,"Siksika",,,,,,0,"ltr",,"L"
781,,,"blb",,"Bilua",,,,,,0,"ltr",,"L"
782,,,"blc",,"Bella Coola",,,,,,0,"ltr",,"L"
783,,,"bld",,"Bolango",,,,,,0,"ltr",,"L"
784,,,"ble",,"Balanta-Kentohe",,,,,,0,"ltr",,"L"
785,,,"blf",,"Buol",,,,,,0,"ltr",,"L"
786,,,"blg",,"Balau",,,,,,0,"ltr",,"L"
787,,,"blh",,"Kuwaa",,,,,,0,"ltr",,"L"
788,,,"bli",,"Bolia",,,,,,0,"ltr",,"L"
789,,,"blj",,"Bolongan",,,,,,0,"ltr",,"L"
790,,,"blk",,"Karen",,"Pa'o",,,,0,"ltr",,"L"
791,,,"bll",,"Biloxi",,,,,,0,"ltr",,"E"
792,,,"blm",,"Beli","Sudan",,,,,0,"ltr",,"L"
793,,,"bln",,"Bicolano",,"Southern Catanduanes",,,,0,"ltr",,"L"
794,,,"blo",,"Anii",,,,,,0,"ltr",,"L"
795,,,"blp",,"Blablanga",,,,,,0,"ltr",,"L"
796,,,"blq",,"Baluan-Pam",,,,,,0,"ltr",,"L"
797,,,"blr",,"Blang",,,,,,0,"ltr",,"L"
798,,,"bls",,"Balaesang",,,,,,0,"ltr",,"L"
799,,,"blt",,"Tai Dam",,,,,,0,"ltr",,"L"
800,,,"blu",,"Hmong Njua",,,,,,0,"ltr",,"L"
801,,,"blv",,"Bolo",,,,,,0,"ltr",,"L"
802,,,"blw",,"Balangao",,,,,,0,"ltr",,"L"
803,,,"blx",,"Ayta",,"Mag-Indi",,,,0,"ltr",,"L"
804,,,"bly",,"Notre",,,,,,0,"ltr",,"L"
805,,,"blz",,"Balantak",,,,,,0,"ltr",,"L"
806,,,"bma",,"Lame",,,,,,0,"ltr",,"L"
807,,,"bmb",,"Bembe",,,,,,0,"ltr",,"L"
808,,,"bmc",,"Biem",,,,,,0,"ltr",,"L"
809,,,"bmd",,"Baga Manduri",,,,,,0,"ltr",,"L"
810,,,"bme",,"Limassa",,,,,,0,"ltr",,"L"
811,,,"bmf",,"Bom",,,,,,0,"ltr",,"L"
812,,,"bmg",,"Bamwe",,,,,,0,"ltr",,"L"
813,,,"bmh",,"Kein",,,,,,0,"ltr",,"L"
814,,,"bmi",,"Bagirmi",,,,,,0,"ltr",,"L"
815,,,"bmj",,"Bote-Majhi",,,,,,0,"ltr",,"L"
816,,,"bmk",,"Ghayavi",,,,,,0,"ltr",,"L"
817,,,"bml",,"Bomboli",,,,,,0,"ltr",,"L"
818,,,"bmm",,"Malagasy",,"Northern Betsimisaraka",,,,0,"ltr",,"L"
819,,,"bmn",,"Bina","Papua New Guinea",,,,,0,"ltr",,"E"
820,,,"bmo",,"Bambalang",,,,,,0,"ltr",,"L"
821,,,"bmp",,"Bulgebi",,,,,,0,"ltr",,"L"
822,,,"bmq",,"Bomu",,,,,,0,"ltr",,"L"
823,,,"bmr",,"Muinane",,,,,,0,"ltr",,"L"
824,,,"bms",,"Kanuri",,"Bilma",,,,0,"ltr",,"L"
825,,,"bmt",,"Biao Mon",,,,,,0,"ltr",,"L"
826,,,"bmu",,"Burum-Mindik",,,,,,0,"ltr",,"L"
827,,,"bmv",,"Bum",,,,,,0,"ltr",,"L"
828,,,"bmw",,"Bomwali",,,,,,0,"ltr",,"L"
829,,,"bmx",,"Baimak",,,,,,0,"ltr",,"L"
830,,,"bmy",,"Bemba","Democratic Republic of Congo",,,,,0,"ltr",,"L"
831,,,"bmz",,"Baramu",,,,,,0,"ltr",,"L"
832,,,"bna",,"Bonerate",,,,,,0,"ltr",,"L"
833,,,"bnb",,"Bookan",,,,,,0,"ltr",,"L"
834,,,"bnc",,"Bontoc",,"Central",,,,0,"ltr",,"L"
835,,,"bnd",,"Banda","Indonesia",,,,,0,"ltr",,"L"
836,,,"bne",,"Bintauna",,,,,,0,"ltr",,"L"
837,,,"bnf",,"Masiwang",,,,,,0,"ltr",,"L"
838,,,"bng",,"Benga",,,,,,0,"ltr",,"L"
839,,,"bnh",,"Banawá",,,,,,0,"ltr",,"L"
840,,,"bni",,"Bangi",,,,,,0,"ltr",,"L"
841,,,"bnj",,"Tawbuid",,"Eastern",,,,0,"ltr",,"L"
842,,,"bnk",,"Bierebo",,,,,,0,"ltr",,"L"
843,,,"bnl",,"Boon",,,,,,0,"ltr",,"L"
844,,,"bnm",,"Batanga",,,,,,0,"ltr",,"L"
845,,,"bnn",,"Bunun",,,,,,0,"ltr",,"L"
846,,,"bno",,"Bantoanon",,,,,,0,"ltr",,"L"
847,,,"bnp",,"Bola",,,,,,0,"ltr",,"L"
848,,,"bnq",,"Bantik",,,,,,0,"ltr",,"L"
849,,,"bnr",,"Butmas-Tur",,,,,,0,"ltr",,"L"
850,,,"bns",,"Bundeli",,,,,,0,"ltr",,"L"
851,,,"bnu",,"Bentong",,,,,,0,"ltr",,"L"
852,,,"bnv",,"Bonerif",,,,,,0,"ltr",,"L"
853,,,"bnw",,"Bisis",,,,,,0,"ltr",,"L"
854,,,"bnx",,"Bangubangu",,,,,,0,"ltr",,"L"
855,,,"bny",,"Bintulu",,,,,,0,"ltr",,"L"
856,,,"bnz",,"Beezen",,,,,,0,"ltr",,"L"
857,,,"boa",,"Bora",,,,,,0,"ltr",,"L"
858,,,"bob",,"Boni",,,,,,0,"ltr",,"L"
859,,,"boc",,"Kenyah",,"Bakung",,,,0,"ltr",,"L"
860,"bo","bod","bod",,"Tibetan",,,,,,0,"ltr",,"L"
861,,,"boe",,"Mundabli",,,,,,0,"ltr",,"L"
862,,,"bof",,"Bolon",,,,,,0,"ltr",,"L"
863,,,"bog",,"Bamako Sign Language",,,,,,0,"ltr",,"L"
864,,,"boh",,"Boma",,,,,,0,"ltr",,"L"
865,,,"boi",,"Barbareño",,,,,,0,"ltr",,"E"
866,,,"boj",,"Anjam",,,,,,0,"ltr",,"L"
867,,,"bok",,"Bonjo",,,,,,0,"ltr",,"L"
868,,,"bol",,"Bole",,,,,,0,"ltr",,"L"
869,,,"bom",,"Berom",,,,,,0,"ltr",,"L"
870,,,"bon",,"Bine",,,,,,0,"ltr",,"L"
871,,,"boo",,"Bozo",,"Tièma Cièwè",,,,0,"ltr",,"L"
872,,,"bop",,"Bonkiman",,,,,,0,"ltr",,"L"
873,,,"boq",,"Bogaya",,,,,,0,"ltr",,"L"
874,,,"bor",,"Borôro",,,,,,0,"ltr",,"L"
875,"bs","bos","bos",,"Bosnian",,,,,,0,"ltr",,"L"
876,,,"bot",,"Bongo",,,,,,0,"ltr",,"L"
877,,,"bou",,"Bondei",,,,,,0,"ltr",,"L"
878,,,"bov",,"Tuwuli",,,,,,0,"ltr",,"L"
879,,,"bow",,"Rema",,,,,,0,"ltr",,"E"
880,,,"box",,"Buamu",,,,,,0,"ltr",,"L"
881,,,"boy",,"Bodo","Central African Republic",,,,,0,"ltr",,"L"
882,,,"boz",,"Bozo",,"Tiéyaxo",,,,0,"ltr",,"L"
883,,,"bpa",,"Dakaka",,,,,,0,"ltr",,"L"
884,,,"bpb",,"Barbacoas",,,,,,0,"ltr",,"E"
885,,,"bpd",,"Banda-Banda",,,,,,0,"ltr",,"L"
886,,,"bpg",,"Bonggo",,,,,,0,"ltr",,"L"
887,,,"bph",,"Botlikh",,,,,,0,"ltr",,"L"
888,,,"bpi",,"Bagupi",,,,,,0,"ltr",,"L"
889,,,"bpj",,"Binji",,,,,,0,"ltr",,"L"
890,,,"bpk",,"Orowe",,,,,,0,"ltr",,"L"
891,,,"bpl",,"Broome Pearling Lugger Pidgin",,,,,,0,"ltr",,"L"
892,,,"bpm",,"Biyom",,,,,,0,"ltr",,"L"
893,,,"bpn",,"Dzao Min",,,,,,0,"ltr",,"L"
894,,,"bpo",,"Anasi",,,,,,0,"ltr",,"L"
895,,,"bpp",,"Kaure",,,,,,0,"ltr",,"L"
896,,,"bpq",,"Malay",,"Banda",,,,0,"ltr",,"L"
897,,,"bpr",,"Blaan",,"Koronadal",,,,0,"ltr",,"L"
898,,,"bps",,"Blaan",,"Sarangani",,,,0,"ltr",,"L"
899,,,"bpt",,"Barrow Point",,,,,,0,"ltr",,"L"
900,,,"bpu",,"Bongu",,,,,,0,"ltr",,"L"
901,,,"bpv",,"Marind",,"Bian",,,,0,"ltr",,"L"
902,,,"bpw",,"Bo","Papua New Guinea",,,,,0,"ltr",,"L"
903,,,"bpx",,"Bareli",,"Palya",,,,0,"ltr",,"L"
904,,,"bpy",,"Bishnupriya",,,,,,0,"ltr",,"L"
905,,,"bpz",,"Bilba",,,,,,0,"ltr",,"L"
906,,,"bqa",,"Tchumbuli",,,,,,0,"ltr",,"L"
907,,,"bqb",,"Bagusa",,,,,,0,"ltr",,"L"
908,,,"bqc",,"Boko","Benin",,,,,0,"ltr",,"L"
909,,,"bqd",,"Bung",,,,,,0,"ltr",,"L"
910,,,"bqe",,"Basque",,"Navarro-Labourdin",,,,0,"ltr",,"L"
911,,,"bqf",,"Baga Kaloum",,,,,,0,"ltr",,"E"
912,,,"bqg",,"Bago-Kusuntu",,,,,,0,"ltr",,"L"
913,,,"bqh",,"Baima",,,,,,0,"ltr",,"L"
914,,,"bqi",,"Bakhtiari",,,,,,0,"ltr",,"L"
915,,,"bqj",,"Bandial",,,,,,0,"ltr",,"L"
916,,,"bqk",,"Banda-Mbrès",,,,,,0,"ltr",,"L"
917,,,"bql",,"Bilakura",,,,,,0,"ltr",,"L"
918,,,"bqm",,"Wumboko",,,,,,0,"ltr",,"L"
919,,,"bqn",,"Bulgarian Sign Language",,,,,,0,"ltr",,"L"
920,,,"bqo",,"Balo",,,,,,0,"ltr",,"L"
921,,,"bqp",,"Busa",,,,,,0,"ltr",,"L"
922,,,"bqq",,"Biritai",,,,,,0,"ltr",,"L"
923,,,"bqr",,"Burusu",,,,,,0,"ltr",,"L"
924,,,"bqs",,"Bosngun",,,,,,0,"ltr",,"L"
925,,,"bqt",,"Bamukumbit",,,,,,0,"ltr",,"L"
926,,,"bqu",,"Boguru",,,,,,0,"ltr",,"L"
927,,,"bqv",,"Begbere-Ejar",,,,,,0,"ltr",,"L"
928,,,"bqw",,"Buru","Nigeria",,,,,0,"ltr",,"L"
929,,,"bqx",,"Baangi",,,,,,0,"ltr",,"L"
930,,,"bqy",,"Bali Sign Language",,,,,,0,"ltr",,"L"
931,,,"bqz",,"Bakaka",,,,,,0,"ltr",,"L"
932,,"bra","bra",,"Braj",,,,,,0,"ltr",,"L"
933,,,"brb",,"Lave",,,,,,0,"ltr",,"L"
934,,,"brc",,"Berbice Creole Dutch",,,,,,0,"ltr",,"L"
935,,,"brd",,"Baraamu",,,,,,0,"ltr",,"L"
936,"br","bre","bre",,"Breton",,,,,,0,"ltr",,"L"
937,,,"brf",,"Bera",,,,,,0,"ltr",,"L"
938,,,"brg",,"Baure",,,,,,0,"ltr",,"L"
939,,,"brh",,"Brahui",,,,,,0,"ltr",,"L"
940,,,"bri",,"Mokpwe",,,,,,0,"ltr",,"L"
941,,,"brj",,"Bieria",,,,,,0,"ltr",,"L"
942,,,"brk",,"Birked",,,,,,0,"ltr",,"E"
943,,,"brl",,"Birwa",,,,,,0,"ltr",,"L"
944,,,"brm",,"Barambu",,,,,,0,"ltr",,"L"
945,,,"brn",,"Boruca",,,,,,0,"ltr",,"L"
946,,,"bro",,"Brokkat",,,,,,0,"ltr",,"L"
947,,,"brp",,"Barapasi",,,,,,0,"ltr",,"L"
948,,,"brq",,"Breri",,,,,,0,"ltr",,"L"
949,,,"brr",,"Birao",,,,,,0,"ltr",,"L"
950,,,"brs",,"Baras",,,,,,0,"ltr",,"L"
951,,,"brt",,"Bitare",,,,,,0,"ltr",,"L"
952,,,"bru",,"Bru",,"Eastern",,,,0,"ltr",,"L"
953,,,"brv",,"Bru",,"Western",,,,0,"ltr",,"L"
954,,,"brw",,"Bellari",,,,,,0,"ltr",,"L"
955,,,"brx",,"Bodo","India",,,,,0,"ltr",,"L"
956,,,"bry",,"Burui",,,,,,0,"ltr",,"L"
957,,,"brz",,"Bilbil",,,,,,0,"ltr",,"L"
958,,,"bsa",,"Abinomn",,,,,,0,"ltr",,"L"
959,,,"bsb",,"Bisaya",,"Brunei",,,,0,"ltr",,"L"
960,,,"bsc",,"Bassari",,,,,,0,"ltr",,"L"
961,,,"bsd",,"Bisaya",,"Sarawak",,,,0,"ltr",,"L"
962,,,"bse",,"Wushi",,,,,,0,"ltr",,"L"
963,,,"bsf",,"Bauchi",,,,,,0,"ltr",,"L"
964,,,"bsg",,"Bashkardi",,,,,,0,"ltr",,"L"
965,,,"bsh",,"Kati",,,,,,0,"ltr",,"L"
966,,,"bsi",,"Bassossi",,,,,,0,"ltr",,"L"
967,,,"bsj",,"Bangwinji",,,,,,0,"ltr",,"L"
968,,,"bsk",,"Burushaski",,,,,,0,"ltr",,"L"
969,,,"bsl",,"Basa-Gumna",,,,,,0,"ltr",,"E"
970,,,"bsm",,"Busami",,,,,,0,"ltr",,"L"
971,,,"bsn",,"Barasana",,,,,,0,"ltr",,"L"
972,,,"bso",,"Buso",,,,,,0,"ltr",,"L"
973,,,"bsp",,"Baga Sitemu",,,,,,0,"ltr",,"L"
974,,,"bsq",,"Bassa",,,,,,0,"ltr",,"L"
975,,,"bsr",,"Bassa-Kontagora",,,,,,0,"ltr",,"L"
976,,,"bss",,"Akoose",,,,,,0,"ltr",,"L"
977,,,"bst",,"Basketo",,,,,,0,"ltr",,"L"
978,,,"bsu",,"Bahonsuai",,,,,,0,"ltr",,"L"
979,,,"bsv",,"Baga Sobané",,,,,,0,"ltr",,"E"
980,,,"bsw",,"Baiso",,,,,,0,"ltr",,"L"
981,,,"bsx",,"Yangkam",,,,,,0,"ltr",,"L"
982,,,"bsy",,"Bisaya",,"Sabah",,,,0,"ltr",,"L"
983,,,"bsz",,"Basque",,"Souletin",,,,0,"ltr",,"L"
984,,,"bta",,"Bata",,,,,,0,"ltr",,"L"
985,,,"btb",,"Beti","Cameroon",,,,,0,"ltr",,"L"
986,,,"btc",,"Bati","Cameroon",,,,,0,"ltr",,"L"
987,,,"btd",,"Batak Dairi",,,,,,0,"ltr",,"L"
988,,,"bte",,"Gamo-Ningi",,,,,,0,"ltr",,"E"
989,,,"btf",,"Birgit",,,,,,0,"ltr",,"L"
990,,,"btg",,"Bété",,"Gagnoa",,,,0,"ltr",,"L"
991,,,"bth",,"Biatah",,,,,,0,"ltr",,"L"
992,,,"bti",,"Burate",,,,,,0,"ltr",,"L"
993,,,"btj",,"Malay",,"Bacanese",,,,0,"ltr",,"L"
994,,,"btl",,"Bhatola",,,,,,0,"ltr",,"L"
995,,,"btm",,"Batak Mandailing",,,,,,0,"ltr",,"L"
996,,,"btn",,"Ratagnon",,,,,,0,"ltr",,"L"
997,,,"bto",,"Bicolano",,"Iriga",,,,0,"ltr",,"L"
998,,,"btp",,"Budibud",,,,,,0,"ltr",,"L"
999,,,"btq",,"Batek",,,,,,0,"ltr",,"L"
1000,,,"btr",,"Baetora",,,,,,0,"ltr",,"L"
1001,,,"bts",,"Batak Simalungun",,,,,,0,"ltr",,"L"
1002,,,"btt",,"Bete-Bendi",,,,,,0,"ltr",,"L"
1003,,,"btu",,"Batu",,,,,,0,"ltr",,"L"
1004,,,"btv",,"Bateri",,,,,,0,"ltr",,"L"
1005,,,"btw",,"Butuanon",,,,,,0,"ltr",,"L"
1006,,,"btx",,"Batak Karo",,,,,,0,"ltr",,"L"
1007,,,"bty",,"Bobot",,,,,,0,"ltr",,"L"
1008,,,"btz",,"Batak Alas-Kluet",,,,,,0,"ltr",,"L"
1009,,"bua","bua",,"Buriat",,,,,,1,"ltr",,"L"
1010,,,"bub",,"Bua",,,,,,0,"ltr",,"L"
1011,,,"buc",,"Bushi",,,,,,0,"ltr",,"L"
1012,,,"bud",,"Ntcham",,,,,,0,"ltr",,"L"
1013,,,"bue",,"Beothuk",,,,,,0,"ltr",,"E"
1014,,,"buf",,"Bushoong",,,,,,0,"ltr",,"L"
1015,,"bug","bug",,"Buginese",,,,,,0,"ltr",,"L"
1016,,,"buh",,"Bunu",,"Younuo",,,,0,"ltr",,"L"
1017,,,"bui",,"Bongili",,,,,,0,"ltr",,"L"
1018,,,"buj",,"Basa-Gurmana",,,,,,0,"ltr",,"L"
1019,,,"buk",,"Bugawac",,,,,,0,"ltr",,"L"
1020,"bg","bul","bul",,"Bulgarian",,,"Български",,,0,"ltr",,"L"
1021,,,"bum",,"Bulu","Cameroon",,,,,0,"ltr",,"L"
1022,,,"bun",,"Sherbro",,,,,,0,"ltr",,"L"
1023,,,"buo",,"Terei",,,,,,0,"ltr",,"L"
1024,,,"bup",,"Busoa",,,,,,0,"ltr",,"L"
1025,,,"buq",,"Brem",,,,,,0,"ltr",,"L"
1026,,,"bus",,"Bokobaru",,,,,,0,"ltr",,"L"
1027,,,"but",,"Bungain",,,,,,0,"ltr",,"L"
1028,,,"buu",,"Budu",,,,,,0,"ltr",,"L"
1029,,,"buv",,"Bun",,,,,,0,"ltr",,"L"
1030,,,"buw",,"Bubi",,,,,,0,"ltr",,"L"
1031,,,"bux",,"Boghom",,,,,,0,"ltr",,"L"
1032,,,"buy",,"Bullom So",,,,,,0,"ltr",,"L"
1033,,,"buz",,"Bukwen",,,,,,0,"ltr",,"L"
1034,,,"bva",,"Barein",,,,,,0,"ltr",,"L"
1035,,,"bvb",,"Bube",,,,,,0,"ltr",,"L"
1036,,,"bvc",,"Baelelea",,,,,,0,"ltr",,"L"
1037,,,"bvd",,"Baeggu",,,,,,0,"ltr",,"L"
1038,,,"bve",,"Malay",,"Berau",,,,0,"ltr",,"L"
1039,,,"bvf",,"Boor",,,,,,0,"ltr",,"L"
1040,,,"bvg",,"Bonkeng",,,,,,0,"ltr",,"L"
1041,,,"bvh",,"Bure",,,,,,0,"ltr",,"L"
1042,,,"bvi",,"Belanda Viri",,,,,,0,"ltr",,"L"
1043,,,"bvj",,"Baan",,,,,,0,"ltr",,"L"
1044,,,"bvk",,"Bukat",,,,,,0,"ltr",,"L"
1045,,,"bvl",,"Bolivian Sign Language",,,,,,0,"ltr",,"L"
1046,,,"bvm",,"Bamunka",,,,,,0,"ltr",,"L"
1047,,,"bvn",,"Buna",,,,,,0,"ltr",,"L"
1048,,,"bvo",,"Bolgo",,,,,,0,"ltr",,"L"
1049,,,"bvq",,"Birri",,,,,,0,"ltr",,"L"
1050,,,"bvr",,"Burarra",,,,,,0,"ltr",,"L"
1051,,,"bvs",,"Belgian Sign Language",,,,,,0,"ltr",,"L"
1052,,,"bvt",,"Bati","Indonesia",,,,,0,"ltr",,"L"
1053,,,"bvu",,"Malay",,"Bukit",,,,0,"ltr",,"L"
1054,,,"bvv",,"Baniva",,,,,,0,"ltr",,"E"
1055,,,"bvw",,"Boga",,,,,,0,"ltr",,"L"
1056,,,"bvx",,"Dibole",,,,,,0,"ltr",,"L"
1057,,,"bvz",,"Bauzi",,,,,,0,"ltr",,"L"
1058,,,"bwa",,"Bwatoo",,,,,,0,"ltr",,"L"
1059,,,"bwb",,"Namosi-Naitasiri-Serua",,,,,,0,"ltr",,"L"
1060,,,"bwc",,"Bwile",,,,,,0,"ltr",,"L"
1061,,,"bwd",,"Bwaidoka",,,,,,0,"ltr",,"L"
1062,,,"bwe",,"Karen",,"Bwe",,,,0,"ltr",,"L"
1063,,,"bwf",,"Boselewa",,,,,,0,"ltr",,"L"
1064,,,"bwg",,"Barwe",,,,,,0,"ltr",,"L"
1065,,,"bwh",,"Bishuo",,,,,,0,"ltr",,"L"
1066,,,"bwi",,"Baniwa",,,,,,0,"ltr",,"L"
1067,,,"bwj",,"Bwamu",,"Láá Láá",,,,0,"ltr",,"L"
1068,,,"bwk",,"Bauwaki",,,,,,0,"ltr",,"L"
1069,,,"bwl",,"Bwela",,,,,,0,"ltr",,"L"
1070,,,"bwm",,"Biwat",,,,,,0,"ltr",,"L"
1071,,,"bwn",,"Bunu",,"Wunai",,,,0,"ltr",,"L"
1072,,,"bwo",,"Boro",,,,,,0,"ltr",,"L"
1073,,,"bwp",,"Mandobo Bawah",,,,,,0,"ltr",,"L"
1074,,,"bwq",,"Bobo Madaré",,"Southern",,,,0,"ltr",,"L"
1075,,,"bwr",,"Bura-Pabir",,,,,,0,"ltr",,"L"
1076,,,"bws",,"Bomboma",,,,,,0,"ltr",,"L"
1077,,,"bwt",,"Bafaw-Balong",,,,,,0,"ltr",,"L"
1078,,,"bwu",,"Buli","Ghana",,,,,0,"ltr",,"L"
1079,,,"bwv",,"Kenyah",,"Bahau River",,,,0,"ltr",,"L"
1080,,,"bww",,"Bwa",,,,,,0,"ltr",,"L"
1081,,,"bwx",,"Bunu",,"Bu-Nao",,,,0,"ltr",,"L"
1082,,,"bwy",,"Bwamu",,"Cwi",,,,0,"ltr",,"L"
1083,,,"bwz",,"Bwisi",,,,,,0,"ltr",,"L"
1084,,,"bxa",,"Bauro",,,,,,0,"ltr",,"L"
1085,,,"bxb",,"Belanda Bor",,,,,,0,"ltr",,"L"
1086,,,"bxc",,"Molengue",,,,,,0,"ltr",,"L"
1087,,,"bxd",,"Pela",,,,,,0,"ltr",,"L"
1088,,,"bxe",,"Birale",,,,,,0,"ltr",,"L"
1089,,,"bxf",,"Bilur",,,,,,0,"ltr",,"L"
1090,,,"bxg",,"Bangala",,,,,,0,"ltr",,"L"
1091,,,"bxh",,"Buhutu",,,,,,0,"ltr",,"L"
1092,,,"bxi",,"Pirlatapa",,,,,,0,"ltr",,"E"
1093,,,"bxj",,"Bayungu",,,,,,0,"ltr",,"L"
1094,,,"bxk",,"Bukusu",,,,,,0,"ltr",,"L"
1095,,,"bxl",,"Jalkunan",,,,,,0,"ltr",,"L"
1096,,,"bxm",,"Buriat",,"Mongolia",,,,0,"ltr",,"L"
1097,,,"bxn",,"Burduna",,,,,,0,"ltr",,"L"
1098,,,"bxo",,"Barikanchi",,,,,,0,"ltr",,"L"
1099,,,"bxp",,"Bebil",,,,,,0,"ltr",,"L"
1100,,,"bxq",,"Beele",,,,,,0,"ltr",,"L"
1101,,,"bxr",,"Buriat",,"Russia",,,,0,"ltr",,"L"
1102,,,"bxs",,"Busam",,,,,,0,"ltr",,"L"
1103,,,"bxt",,"Buxinhua",,,,,,0,"ltr",,"L"
1104,,,"bxu",,"Buriat",,"China",,,,0,"ltr",,"L"
1105,,,"bxv",,"Berakou",,,,,,0,"ltr",,"L"
1106,,,"bxw",,"Bankagooma",,,,,,0,"ltr",,"L"
1107,,,"bxx",,"Borna",,,,,,0,"ltr",,"L"
1108,,,"bxz",,"Binahari",,,,,,0,"ltr",,"L"
1109,,,"bya",,"Batak",,,,,,0,"ltr",,"L"
1110,,,"byb",,"Bikya",,,,,,0,"ltr",,"L"
1111,,,"byc",,"Ubaghara",,,,,,0,"ltr",,"L"
1112,,,"byd",,"Benyadu'",,,,,,0,"ltr",,"L"
1113,,,"bye",,"Pouye",,,,,,0,"ltr",,"L"
1114,,,"byf",,"Bete",,,,,,0,"ltr",,"L"
1115,,,"byg",,"Baygo",,,,,,0,"ltr",,"E"
1116,,,"byh",,"Bujhyal",,,,,,0,"ltr",,"L"
1117,,,"byi",,"Buyu",,,,,,0,"ltr",,"L"
1118,,,"byj",,"Bina","Nigeria",,,,,0,"ltr",,"L"
1119,,,"byk",,"Biao",,,,,,0,"ltr",,"L"
1120,,,"byl",,"Bayono",,,,,,0,"ltr",,"L"
1121,,,"bym",,"Bidyara",,,,,,0,"ltr",,"L"
1122,,"byn","byn",,"Blin; Bilin",,,,,,0,"ltr",,"L"
1123,,,"byo",,"Biyo",,,,,,0,"ltr",,"L"
1124,,,"byp",,"Bumaji",,,,,,0,"ltr",,"L"
1125,,,"byq",,"Basay",,,,,,0,"ltr",,"E"
1126,,,"byr",,"Baruya",,,,,,0,"ltr",,"L"
1127,,,"bys",,"Burak",,,,,,0,"ltr",,"L"
1128,,,"byt",,"Berti",,,,,,0,"ltr",,"E"
1129,,,"byu",,"Buyang",,,,,,0,"ltr",,"L"
1130,,,"byv",,"Medumba",,,,,,0,"ltr",,"L"
1131,,,"byw",,"Belhariya",,,,,,0,"ltr",,"L"
1132,,,"byx",,"Qaqet",,,,,,0,"ltr",,"L"
1133,,,"byy",,"Buya",,,,,,0,"ltr",,"L"
1134,,,"byz",,"Banaro",,,,,,0,"ltr",,"L"
1135,,,"bza",,"Bandi",,,,,,0,"ltr",,"L"
1136,,,"bzb",,"Andio",,,,,,0,"ltr",,"L"
1137,,,"bzd",,"Bribri",,,,,,0,"ltr",,"L"
1138,,,"bze",,"Bozo",,"Jenaama",,,,0,"ltr",,"L"
1139,,,"bzf",,"Boikin",,,,,,0,"ltr",,"L"
1140,,,"bzg",,"Babuza",,,,,,0,"ltr",,"L"
1141,,,"bzh",,"Buang",,"Mapos",,,,0,"ltr",,"L"
1142,,,"bzj",,"Belize Kriol English",,,,,,0,"ltr",,"L"
1143,,,"bzk",,"Nicaragua Creole English",,,,,,0,"ltr",,"L"
1144,,,"bzl",,"Boano","Sulawesi",,,,,0,"ltr",,"L"
1145,,,"bzm",,"Bolondo",,,,,,0,"ltr",,"L"
1146,,,"bzn",,"Boano","Maluku",,,,,0,"ltr",,"L"
1147,,,"bzo",,"Bozaba",,,,,,0,"ltr",,"L"
1148,,,"bzp",,"Kemberano",,,,,,0,"ltr",,"L"
1149,,,"bzq",,"Buli","Indonesia",,,,,0,"ltr",,"L"
1150,,,"bzr",,"Biri",,,,,,0,"ltr",,"E"
1151,,,"bzs",,"Brazilian Sign Language",,,,,,0,"ltr",,"L"
1152,,,"bzt",,"Brithenig",,,,,,0,"ltr",,"C"
1153,,,"bzu",,"Burmeso",,,,,,0,"ltr",,"L"
1154,,,"bzv",,"Bebe",,,,,,0,"ltr",,"L"
1155,,,"bzw",,"Basa","Nigeria",,,,,0,"ltr",,"L"
1156,,,"bzx",,"Bozo",,"Hainyaxo",,,,0,"ltr",,"L"
1157,,,"bzy",,"Obanliku",,,,,,0,"ltr",,"L"
1158,,,"bzz",,"Evant",,,,,,0,"ltr",,"L"
1159,,,"caa",,"Chortí",,,,,,0,"ltr",,"L"
1160,,,"cab",,"Garifuna",,,,,,0,"ltr",,"L"
1161,,,"cac",,"Chuj",,"San Sebastián Coatán",,,,0,"ltr",,"L"
1162,,"cad","cad",,"Caddo",,,,,,0,"ltr",,"L"
1163,,,"cae",,"Lehar",,,,,,0,"ltr",,"L"
1164,,,"caf",,"Carrier",,"Southern",,,,0,"ltr",,"L"
1165,,,"cag",,"Nivaclé",,,,,,0,"ltr",,"L"
1166,,,"cah",,"Cahuarano",,,,,,0,"ltr",,"L"
1167,,,"caj",,"Chané",,,,,,0,"ltr",,"E"
1168,,,"cak",,"Cakchiquel",,"Central",,,,0,"ltr",,"L"
1169,,,"cal",,"Carolinian",,,,,,0,"ltr",,"L"
1170,,,"cam",,"Cemuhî",,,,,,0,"ltr",,"L"
1171,,,"can",,"Chambri",,,,,,0,"ltr",,"L"
1172,,,"cao",,"Chácobo",,,,,,0,"ltr",,"L"
1173,,,"cap",,"Chipaya",,,,,,0,"ltr",,"L"
1174,,,"caq",,"Nicobarese",,"Car",,,,0,"ltr",,"L"
1175,,"car","car",,"Carib",,,,,,0,"ltr",,"L"
1176,,,"cas",,"Tsimané",,,,,,0,"ltr",,"L"
1177,"ca","cat","cat",,"Catalan",,,"Català",,,0,"ltr",,"L"
1178,,,"cav",,"Cavineña",,,,,,0,"ltr",,"L"
1179,,,"caw",,"Callawalla",,,,,,0,"ltr",,"L"
1180,,,"cax",,"Chiquitano",,,,,,0,"ltr",,"L"
1181,,,"cay",,"Cayuga",,,,,,0,"ltr",,"L"
1182,,,"caz",,"Canichana",,,,,,0,"ltr",,"E"
1183,,,"cbb",,"Cabiyarí",,,,,,0,"ltr",,"L"
1184,,,"cbc",,"Carapana",,,,,,0,"ltr",,"L"
1185,,,"cbd",,"Carijona",,,,,,0,"ltr",,"L"
1186,,,"cbe",,"Chipiajes",,,,,,0,"ltr",,"E"
1187,,,"cbg",,"Chimila",,,,,,0,"ltr",,"L"
1188,,,"cbh",,"Cagua",,,,,,0,"ltr",,"E"
1189,,,"cbi",,"Chachi",,,,,,0,"ltr",,"L"
1190,,,"cbj",,"Ede Cabe",,,,,,0,"ltr",,"L"
1191,,,"cbk",,"Chavacano",,,,,,0,"ltr",,"L"
1192,,,"cbl",,"Chin",,"Bualkhaw",,,,0,"ltr",,"L"
1193,,,"cbm",,"Cakchiquel",,"Yepocapa Southwestern",,,,0,"ltr",,"L"
1194,,,"cbn",,"Nyahkur",,,,,,0,"ltr",,"L"
1195,,,"cbo",,"Izora",,,,,,0,"ltr",,"L"
1196,,,"cbr",,"Cashibo-Cacataibo",,,,,,0,"ltr",,"L"
1197,,,"cbs",,"Cashinahua",,,,,,0,"ltr",,"L"
1198,,,"cbt",,"Chayahuita",,,,,,0,"ltr",,"L"
1199,,,"cbu",,"Candoshi-Shapra",,,,,,0,"ltr",,"L"
1200,,,"cbv",,"Cacua",,,,,,0,"ltr",,"L"
1201,,,"cby",,"Carabayo",,,,,,0,"ltr",,"L"
1202,,,"cca",,"Cauca",,,,,,0,"ltr",,"E"
1203,,,"ccc",,"Chamicuro",,,,,,0,"ltr",,"L"
1204,,,"ccd",,"Cafundo Creole",,,,,,0,"ltr",,"L"
1205,,,"cce",,"Chopi",,,,,,0,"ltr",,"L"
1206,,,"ccg",,"Samba Daka",,,,,,0,"ltr",,"L"
1207,,,"cch",,"Atsam",,,,,,0,"ltr",,"L"
1208,,,"ccj",,"Kasanga",,,,,,0,"ltr",,"L"
1209,,,"ccl",,"Cutchi-Swahili",,,,,,0,"ltr",,"L"
1210,,,"ccm",,"Malaccan Creole Malay",,,,,,0,"ltr",,"L"
1211,,,"cco",,"Chinantec",,"Comaltepec",,,,0,"ltr",,"L"
1212,,,"ccp",,"Chakma",,,,,,0,"ltr",,"L"
1213,,,"ccq",,"Chaungtha",,,,,,0,"ltr",,"L"
1214,,,"ccr",,"Cacaopera",,,,,,0,"ltr",,"E"
1215,,,"ccx",,"Zhuang",,"Northern",,,,0,"ltr",,"L"
1216,,,"ccy",,"Zhuang",,"Southern",,,,0,"ltr",,"L"
1217,,,"cda",,"Choni",,,,,,0,"ltr",,"L"
1218,,,"cde",,"Chenchu",,,,,,0,"ltr",,"L"
1219,,,"cdf",,"Chiru",,,,,,0,"ltr",,"L"
1220,,,"cdg",,"Chamari",,,,,,0,"ltr",,"L"
1221,,,"cdh",,"Chambeali",,,,,,0,"ltr",,"L"
1222,,,"cdi",,"Chodri",,,,,,0,"ltr",,"L"
1223,,,"cdj",,"Churahi",,,,,,0,"ltr",,"L"
1224,,,"cdm",,"Chepang",,,,,,0,"ltr",,"L"
1225,,,"cdn",,"Chaudangsi",,,,,,0,"ltr",,"L"
1226,,,"cdo",,"Chinese",,"Min Dong",,,,0,"ltr",,"L"
1227,,,"cdr",,"Cinda-Regi-Tiyal",,,,,,0,"ltr",,"L"
1228,,,"cds",,"Chadian Sign Language",,,,,,0,"ltr",,"L"
1229,,,"cdz",,"Koda",,,,,,0,"ltr",,"L"
1230,,,"cea",,"Chehalis",,"Lower",,,,0,"ltr",,"E"
1231,,"ceb","ceb",,"Cebuano",,,,,,0,"ltr",,"L"
1232,,,"ceg",,"Chamacoco",,,,,,0,"ltr",,"L"
1233,"cs","ces","ces",,"Czech",,,"čeština",,,0,"ltr","c%10==1 && c%100!=11 ? 1 : c%10>=2 && c%10<=4 && (c%100<10 || c%100>=20) ? 2 : 3","L"
1234,,,"cet",,"Centúúm",,,,,,0,"ltr",,"L"
1235,,,"cfa",,"Dijim-Bwilim",,,,,,0,"ltr",,"L"
1236,,,"cfd",,"Cara",,,,,,0,"ltr",,"L"
1237,,,"cfg",,"Como Karim",,,,,,0,"ltr",,"L"
1238,,,"cga",,"Changriwa",,,,,,0,"ltr",,"L"
1239,,,"cgc",,"Kagayanen",,,,,,0,"ltr",,"L"
1240,,,"cgg",,"Chiga",,,,,,0,"ltr",,"L"
1241,,,"cgk",,"Chocangacakha",,,,,,0,"ltr",,"L"
1242,"ch","cha","cha",,"Chamorro",,,,,,0,"ltr",,"L"
1243,,"chb","chb",,"Chibcha",,,,,,0,"ltr",,"E"
1244,,,"chc",,"Catawba",,,,,,0,"ltr",,"E"
1245,,,"chd",,"Chontal",,"Highland Oaxaca",,,,0,"ltr",,"L"
1246,"ce","che","che",,"Chechen",,,,,,0,"ltr",,"L"
1247,,,"chf",,"Chontal",,"Tabasco",,,,0,"ltr",,"L"
1248,,"chg","chg",,"Chagatai",,,,,,0,"ltr",,"E"
1249,,,"chh",,"Chinook",,,,,,0,"ltr",,"L"
1250,,,"chj",,"Chinantec",,"Ojitlán",,,,0,"ltr",,"L"
1251,,"chk","chk",,"Chuukese",,,,,,0,"ltr",,"L"
1252,,,"chl",,"Cahuilla",,,,,,0,"ltr",,"L"
1253,,"chm","chm",,"Mari","Russia",,,,,1,"ltr",,"L"
1254,,"chn","chn",,"Chinook jargon",,,,,,0,"ltr",,"L"
1255,,"cho","cho",,"Choctaw",,,,,,0,"ltr",,"L"
1256,,"chp","chp",,"Chipewyan",,,,,,0,"ltr",,"L"
1257,,,"chq",,"Chinantec",,"Quiotepec",,,,0,"ltr",,"L"
1258,,"chr","chr",,"Cherokee",,,,,,0,"ltr",,"L"
1259,,,"chs",,"Chumash",,,,,,0,"ltr",,"E"
1260,,,"cht",,"Cholón",,,,,,0,"ltr",,"E"
1261,"cu","chu","chu",,"Slavic",,"Church",,,,0,"ltr",,"A"
1262,"cv","chv","chv",,"Chuvash",,,,,,0,"ltr",,"L"
1263,,,"chw",,"Chuwabu",,,,,,0,"ltr",,"L"
1264,,,"chx",,"Chantyal",,,,,,0,"ltr",,"L"
1265,,"chy","chy",,"Cheyenne",,,,,,0,"ltr",,"L"
1266,,,"chz",,"Chinantec",,"Ozumacín",,,,0,"ltr",,"L"
1267,,,"cia",,"Cia-Cia",,,,,,0,"ltr",,"L"
1268,,,"cib",,"Gbe",,"Ci",,,,0,"ltr",,"L"
1269,,,"cic",,"Chickasaw",,,,,,0,"ltr",,"L"
1270,,,"cid",,"Chimariko",,,,,,0,"ltr",,"E"
1271,,,"cie",,"Cineni",,,,,,0,"ltr",,"L"
1272,,,"cih",,"Chinali",,,,,,0,"ltr",,"L"
1273,,,"cik",,"Kinnauri",,"Chitkuli",,,,0,"ltr",,"L"
1274,,,"cim",,"Cimbrian",,,,,,0,"ltr",,"L"
1275,,,"cin",,"Cinta Larga",,,,,,0,"ltr",,"L"
1276,,,"cip",,"Chiapanec",,,,,,0,"ltr",,"L"
1277,,,"cir",,"Tiri",,,,,,0,"ltr",,"L"
1278,,,"cit",,"Chittagonian",,,,,,0,"ltr",,"L"
1279,,,"ciw",,"Chippewa",,,,,,0,"ltr",,"L"
1280,,,"ciy",,"Chaima",,,,,,0,"ltr",,"L"
1281,,,"cja",,"Cham",,"Western",,,,0,"ltr",,"L"
1282,,,"cje",,"Chru",,,,,,0,"ltr",,"L"
1283,,,"cjh",,"Chehalis",,"Upper",,,,0,"ltr",,"E"
1284,,,"cji",,"Chamalal",,,,,,0,"ltr",,"L"
1285,,,"cjk",,"Chokwe",,,,,,0,"ltr",,"L"
1286,,,"cjm",,"Cham",,"Eastern",,,,0,"ltr",,"L"
1287,,,"cjn",,"Chenapian",,,,,,0,"ltr",,"L"
1288,,,"cjo",,"Ashéninka Pajonal",,,,,,0,"ltr",,"L"
1289,,,"cjp",,"Cabécar",,,,,,0,"ltr",,"L"
1290,,,"cjr",,"Chorotega",,,,,,0,"ltr",,"E"
1291,,,"cjs",,"Shor",,,,,,0,"ltr",,"L"
1292,,,"cjv",,"Chuave",,,,,,0,"ltr",,"L"
1293,,,"cjy",,"Chinese",,"Jinyu",,,,0,"ltr",,"L"
1294,,,"cka",,"Chin",,"Khumi Awa",,,,0,"ltr",,"L"
1295,,,"ckb",,"Kurdish",,"Central",,,,0,"ltr",,"L"
1296,,,"ckc",,"Cakchiquel",,"Northern",,,,0,"ltr",,"L"
1297,,,"ckd",,"Cakchiquel",,"South Central",,,,0,"ltr",,"L"
1298,,,"cke",,"Cakchiquel",,"Eastern",,,,0,"ltr",,"L"
1299,,,"ckf",,"Cakchiquel",,"Southern",,,,0,"ltr",,"L"
1300,,,"ckh",,"Chak",,,,,,0,"ltr",,"L"
1301,,,"cki",,"Cakchiquel",,"Santa María De Jesús",,,,0,"ltr",,"L"
1302,,,"ckj",,"Cakchiquel",,"Santo Domingo Xenacoj",,,,0,"ltr",,"L"
1303,,,"ckk",,"Cakchiquel",,"Acatenango Southwestern",,,,0,"ltr",,"L"
1304,,,"ckl",,"Cibak",,,,,,0,"ltr",,"L"
1305,,,"cko",,"Anufo",,,,,,0,"ltr",,"L"
1306,,,"ckq",,"Kajakse",,,,,,0,"ltr",,"L"
1307,,,"ckr",,"Kairak",,,,,,0,"ltr",,"L"
1308,,,"cks",,"Tayo",,,,,,0,"ltr",,"L"
1309,,,"ckt",,"Chukot",,,,,,0,"ltr",,"L"
1310,,,"cku",,"Koasati",,,,,,0,"ltr",,"L"
1311,,,"ckv",,"Kavalan",,,,,,0,"ltr",,"L"
1312,,,"ckw",,"Cakchiquel",,"Western",,,,0,"ltr",,"L"
1313,,,"ckx",,"Caka",,,,,,0,"ltr",,"L"
1314,,,"cky",,"Cakfem-Mushere",,,,,,0,"ltr",,"L"
1315,,,"ckz",,"Cakchiquel-Quiché Mixed Language",,,,,,0,"ltr",,"L"
1316,,,"cla",,"Ron",,,,,,0,"ltr",,"L"
1317,,,"clc",,"Chilcotin",,,,,,0,"ltr",,"L"
1318,,,"cld",,"Chaldean Neo-Aramaic",,,,,,0,"ltr",,"L"
1319,,,"cle",,"Chinantec",,"Lealao",,,,0,"ltr",,"L"
1320,,,"clh",,"Chilisso",,,,,,0,"ltr",,"L"
1321,,,"cli",,"Chakali",,,,,,0,"ltr",,"L"
1322,,,"clk",,"Idu-Mishmi",,,,,,0,"ltr",,"L"
1323,,,"cll",,"Chala",,,,,,0,"ltr",,"L"
1324,,,"clm",,"Clallam",,,,,,0,"ltr",,"L"
1325,,,"clo",,"Chontal",,"Lowland Oaxaca",,,,0,"ltr",,"L"
1326,,,"clu",,"Caluyanun",,,,,,0,"ltr",,"L"
1327,,,"clw",,"Chulym",,,,,,0,"ltr",,"L"
1328,,,"cly",,"Chatino",,"Eastern Highland",,,,0,"ltr",,"L"
1329,,,"cma",,"Maa",,,,,,0,"ltr",,"L"
1330,,,"cme",,"Cerma",,,,,,0,"ltr",,"L"
1331,,,"cmg",,"Mongolian",,"Classical",,,,0,"ltr",,"H"
1332,,,"cmi",,"Emberá-Chamí",,,,,,0,"ltr",,"L"
1333,,,"cmk",,"Chimakum",,,,,,0,"ltr",,"E"
1334,,,"cml",,"Campalagian",,,,,,0,"ltr",,"L"
1335,,,"cmm",,"Michigamea",,,,,,0,"ltr",,"E"
1336,,,"cmn",,"Chinese",,"Mandarin",,,,0,"ltr",,"L"
1337,,,"cmo",,"Mnong",,"Central",,,,0,"ltr",,"L"
1338,,,"cmr",,"Chin",,"Mro",,,,0,"ltr",,"L"
1339,,,"cms",,"Messapic",,,,,,0,"ltr",,"A"
1340,,,"cmt",,"Camtho",,,,,,0,"ltr",,"L"
1341,,,"cna",,"Changthang",,,,,,0,"ltr",,"L"
1342,,,"cnb",,"Chin",,"Chinbon",,,,0,"ltr",,"L"
1343,,,"cnc",,"Côông",,,,,,0,"ltr",,"L"
1344,,,"cng",,"Qiang",,"Northern",,,,0,"ltr",,"L"
1345,,,"cnh",,"Chin",,"Haka",,,,0,"ltr",,"L"
1346,,,"cni",,"Asháninka",,,,,,0,"ltr",,"L"
1347,,,"cnk",,"Chin",,"Khumi",,,,0,"ltr",,"L"
1348,,,"cnl",,"Chinantec",,"Lalana",,,,0,"ltr",,"L"
1349,,,"cnm",,"Chuj",,"Ixtatán",,,,0,"ltr",,"L"
1350,,,"cno",,"Con",,,,,,0,"ltr",,"L"
1351,,,"cns",,"Asmat",,"Central",,,,0,"ltr",,"L"
1352,,,"cnt",,"Chinantec",,"Tepetotutla",,,,0,"ltr",,"L"
1353,,,"cnu",,"Chenoua",,,,,,0,"ltr",,"L"
1354,,,"cnw",,"Chin",,"Ngawn",,,,0,"ltr",,"L"
1355,,,"cnx",,"Cornish",,"Middle",,,,0,"ltr",,"H"
1356,,,"coa",,"Malay",,"Cocos Islands",,,,0,"ltr",,"L"
1357,,,"cob",,"Chicomuceltec",,,,,,0,"ltr",,"E"
1358,,,"coc",,"Cocopa",,,,,,0,"ltr",,"L"
1359,,,"cod",,"Cocama-Cocamilla",,,,,,0,"ltr",,"L"
1360,,,"coe",,"Koreguaje",,,,,,0,"ltr",,"L"
1361,,,"cof",,"Colorado",,,,,,0,"ltr",,"L"
1362,,,"cog",,"Chong",,,,,,0,"ltr",,"L"
1363,,,"coh",,"Chonyi",,,,,,0,"ltr",,"L"
1364,,,"coj",,"Cochimi",,,,,,0,"ltr",,"E"
1365,,,"cok",,"Cora",,"Santa Teresa",,,,0,"ltr",,"L"
1366,,,"col",,"Columbia-Wenatchi",,,,,,0,"ltr",,"L"
1367,,,"com",,"Comanche",,,,,,0,"ltr",,"L"
1368,,,"con",,"Cofán",,,,,,0,"ltr",,"L"
1369,,,"coo",,"Comox",,,,,,0,"ltr",,"L"
1370,,"cop","cop",,"Coptic",,,,,,0,"ltr",,"E"
1371,,,"coq",,"Coquille",,,,,,0,"ltr",,"E"
1372,"kw","cor","cor",,"Cornish",,,,,,0,"ltr",,"L"
1373,"co","cos","cos",,"Corsican",,,,,,0,"ltr",,"L"
1374,,,"cot",,"Caquinte",,,,,,0,"ltr",,"L"
1375,,,"cou",,"Wamey",,,,,,0,"ltr",,"L"
1376,,,"cov",,"Cao Miao",,,,,,0,"ltr",,"L"
1377,,,"cow",,"Cowlitz",,,,,,0,"ltr",,"E"
1378,,,"cox",,"Nanti",,,,,,0,"ltr",,"L"
1379,,,"coy",,"Coyaima",,,,,,0,"ltr",,"E"
1380,,,"coz",,"Chochotec",,,,,,0,"ltr",,"L"
1381,,,"cpa",,"Chinantec",,"Palantla",,,,0,"ltr",,"L"
1382,,,"cpb",,"Ashéninka",,"Ucayali-Yurúa",,,,0,"ltr",,"L"
1383,,,"cpc",,"Ajyíninka Apurucayali",,,,,,0,"ltr",,"L"
1384,,,"cpg",,"Greek",,"Cappadocian",,,,0,"ltr",,"E"
1385,,,"cpi",,"Chinese Pidgin English",,,,,,0,"ltr",,"L"
1386,,,"cpn",,"Cherepon",,,,,,0,"ltr",,"L"
1387,,,"cps",,"Capiznon",,,,,,0,"ltr",,"L"
1388,,,"cpu",,"Ashéninka",,"Pichis",,,,0,"ltr",,"L"
1389,,,"cpx",,"Chinese",,"Pu-Xian",,,,0,"ltr",,"L"
1390,,,"cpy",,"Ashéninka",,"South Ucayali",,,,0,"ltr",,"L"
1391,,,"cql",,"Ceqli",,,,,,0,"ltr",,"C"
1392,,,"cqu",,"Quechua",,"Chilean",,,,0,"ltr",,"L"
1393,,,"cra",,"Chara",,,,,,0,"ltr",,"L"
1394,,,"crb",,"Carib",,"Island",,,,0,"ltr",,"E"
1395,,,"crc",,"Lonwolwol",,,,,,0,"ltr",,"L"
1396,,,"crd",,"Coeur d'Alene",,,,,,0,"ltr",,"L"
1397,"cr","cre","cre",,"Cree",,,,,,1,"ltr",,"L"
1398,,,"crf",,"Caramanta",,,,,,0,"ltr",,"E"
1399,,,"crg",,"Michif",,,,,,0,"ltr",,"L"
1400,,"crh","crh",,"Crimean Turkish; Crimean Tatar",,,,,,0,"ltr",,"L"
1401,,,"cri",,"Sãotomense",,,,,,0,"ltr",,"L"
1402,,,"crj",,"East Cree",,"Southern",,,,0,"ltr",,"L"
1403,,,"crk",,"Cree",,"Plains",,,,0,"ltr",,"L"
1404,,,"crl",,"East Cree",,"Northern",,,,0,"ltr",,"L"
1405,,,"crm",,"Cree",,"Moose",,,,0,"ltr",,"L"
1406,,,"crn",,"Cora",,"El Nayar",,,,0,"ltr",,"L"
1407,,,"cro",,"Crow",,,,,,0,"ltr",,"L"
1408,,,"crq",,"Chorote",,"Iyo'wujwa",,,,0,"ltr",,"L"
1409,,,"crr",,"Carolina Algonquian",,,,,,0,"ltr",,"E"
1410,,,"crs",,"Seselwa Creole French",,,,,,0,"ltr",,"L"
1411,,,"crt",,"Chorote",,"Iyojwa'ja",,,,0,"ltr",,"L"
1412,,,"cru",,"Carútana",,,,,,0,"ltr",,"L"
1413,,,"crv",,"Chaura",,,,,,0,"ltr",,"L"
1414,,,"crw",,"Chrau",,,,,,0,"ltr",,"L"
1415,,,"crx",,"Carrier",,,,,,0,"ltr",,"L"
1416,,,"cry",,"Cori",,,,,,0,"ltr",,"L"
1417,,,"crz",,"Cruzeño",,,,,,0,"ltr",,"E"
1418,,,"csa",,"Chinantec",,"Chiltepec",,,,0,"ltr",,"L"
1419,,"csb","csb",,"Kashubian",,,,,,0,"ltr",,"L"
1420,,,"csc",,"Catalonian Sign Language",,,,,,0,"ltr",,"L"
1421,,,"csd",,"Chiangmai Sign Language",,,,,,0,"ltr",,"L"
1422,,,"cse",,"Czech Sign Language",,,,,,0,"ltr",,"L"
1423,,,"csf",,"Cuba Sign Language",,,,,,0,"ltr",,"L"
1424,,,"csg",,"Chilean Sign Language",,,,,,0,"ltr",,"L"
1425,,,"csh",,"Chin",,"Asho",,,,0,"ltr",,"L"
1426,,,"csi",,"Miwok",,"Coast",,,,0,"ltr",,"E"
1427,,,"csk",,"Jola-Kasa",,,,,,0,"ltr",,"L"
1428,,,"csl",,"Chinese Sign Language",,,,,,0,"ltr",,"L"
1429,,,"csm",,"Miwok",,"Central Sierra",,,,0,"ltr",,"L"
1430,,,"csn",,"Colombian Sign Language",,,,,,0,"ltr",,"L"
1431,,,"cso",,"Chinantec",,"Sochiapan",,,,0,"ltr",,"L"
1432,,,"csq",,"Croatia Sign Language",,,,,,0,"ltr",,"L"
1433,,,"csr",,"Costa Rican Sign Language",,,,,,0,"ltr",,"L"
1434,,,"css",,"Ohlone",,"Southern",,,,0,"ltr",,"E"
1435,,,"cst",,"Ohlone",,"Northern",,,,0,"ltr",,"E"
1436,,,"csw",,"Cree",,"Swampy",,,,0,"ltr",,"L"
1437,,,"csy",,"Chin",,"Siyin",,,,0,"ltr",,"L"
1438,,,"csz",,"Coos",,,,,,0,"ltr",,"L"
1439,,,"cta",,"Chatino",,"Tataltepec",,,,0,"ltr",,"L"
1440,,,"ctc",,"Chetco",,,,,,0,"ltr",,"L"
1441,,,"ctd",,"Chin",,"Tedim",,,,0,"ltr",,"L"
1442,,,"cte",,"Chinantec",,"Tepinapa",,,,0,"ltr",,"L"
1443,,,"cti",,"Chol",,"Tila",,,,0,"ltr",,"L"
1444,,,"ctl",,"Chinantec",,"Tlacoatzintepec",,,,0,"ltr",,"L"
1445,,,"ctm",,"Chitimacha",,,,,,0,"ltr",,"E"
1446,,,"ctn",,"Chhintange",,,,,,0,"ltr",,"L"
1447,,,"cto",,"Emberá-Catío",,,,,,0,"ltr",,"L"
1448,,,"ctp",,"Chatino",,"Western Highland",,,,0,"ltr",,"L"
1449,,,"cts",,"Bicolano",,"Northern Catanduanes",,,,0,"ltr",,"L"
1450,,,"ctu",,"Chol",,"Tumbalá",,,,0,"ltr",,"L"
1451,,,"ctz",,"Chatino",,"Zacatepec",,,,0,"ltr",,"L"
1452,,,"cua",,"Cua",,,,,,0,"ltr",,"L"
1453,,,"cub",,"Cubeo",,,,,,0,"ltr",,"L"
1454,,,"cuc",,"Chinantec",,"Usila",,,,0,"ltr",,"L"
1455,,,"cug",,"Cung",,,,,,0,"ltr",,"L"
1456,,,"cuh",,"Chuka",,,,,,0,"ltr",,"L"
1457,,,"cui",,"Cuiba",,,,,,0,"ltr",,"L"
1458,,,"cuj",,"Mashco Piro",,,,,,0,"ltr",,"L"
1459,,,"cuk",,"Kuna",,"San Blas",,,,0,"ltr",,"L"
1460,,,"cul",,"Culina",,,,,,0,"ltr",,"L"
1461,,,"cum",,"Cumeral",,,,,,0,"ltr",,"E"
1462,,,"cun",,"Quiché",,"Cunén",,,,0,"ltr",,"L"
1463,,,"cuo",,"Cumanagoto",,,,,,0,"ltr",,"E"
1464,,,"cup",,"Cupeño",,,,,,0,"ltr",,"E"
1465,,,"cuq",,"Cun",,,,,,0,"ltr",,"L"
1466,,,"cur",,"Chhulung",,,,,,0,"ltr",,"L"
1467,,,"cut",,"Cuicatec",,"Teutila",,,,0,"ltr",,"L"
1468,,,"cuu",,"Tai Ya",,,,,,0,"ltr",,"L"
1469,,,"cuv",,"Cuvok",,,,,,0,"ltr",,"L"
1470,,,"cuw",,"Chukwa",,,,,,0,"ltr",,"L"
1471,,,"cux",,"Cuicatec",,"Tepeuxila",,,,0,"ltr",,"L"
1472,,,"cvn",,"Chinantec",,"Valle Nacional",,,,0,"ltr",,"L"
1473,,,"cwa",,"Kabwa",,,,,,0,"ltr",,"L"
1474,,,"cwb",,"Maindo",,,,,,0,"ltr",,"L"
1475,,,"cwd",,"Cree",,"Woods",,,,0,"ltr",,"L"
1476,,,"cwe",,"Kwere",,,,,,0,"ltr",,"L"
1477,,,"cwg",,"Chewong",,,,,,0,"ltr",,"L"
1478,,,"cwt",,"Kuwaataay",,,,,,0,"ltr",,"L"
1479,,,"cya",,"Chatino",,"Nopala",,,,0,"ltr",,"L"
1480,,,"cyb",,"Cayubaba",,,,,,0,"ltr",,"E"
1481,"cy","cym","cym",,"Welsh",,,"Cymraeg",,,0,"ltr",,"L"
1482,,,"cyo",,"Cuyonon",,,,,,0,"ltr",,"L"
1483,,,"czh",,"Chinese",,"Huizhou",,,,0,"ltr",,"L"
1484,,,"czk",,"Knaanic",,,,,,0,"ltr",,"E"
1485,,,"czn",,"Chatino",,"Zenzontepec",,,,0,"ltr",,"L"
1486,,,"czo",,"Chinese",,"Min Zhong",,,,0,"ltr",,"L"
1487,,,"czt",,"Chin",,"Zotung",,,,0,"ltr",,"L"
1488,,,"daa",,"Dangaléat",,,,,,0,"ltr",,"L"
1489,,,"dac",,"Dambi",,,,,,0,"ltr",,"L"
1490,,,"dad",,"Marik",,,,,,0,"ltr",,"L"
1491,,,"dae",,"Duupa",,,,,,0,"ltr",,"L"
1492,,,"daf",,"Dan",,,,,,0,"ltr",,"L"
1493,,,"dag",,"Dagbani",,,,,,0,"ltr",,"L"
1494,,,"dah",,"Gwahatike",,,,,,0,"ltr",,"L"
1495,,,"dai",,"Day",,,,,,0,"ltr",,"L"
1496,,,"daj",,"Daju",,"Dar Fur",,,,0,"ltr",,"L"
1497,,"dak","dak",,"Dakota",,,,,,0,"ltr",,"L"
1498,,,"dal",,"Dahalo",,,,,,0,"ltr",,"L"
1499,"da","dan","dan",,"Danish",,,"Dansk",,,0,"ltr","c == 1 ? 1 : 2","L"
1500,,,"dao",,"Chin",,"Daai",,,,0,"ltr",,"L"
1501,,,"dap",,"Nisi",,,,,,0,"ltr",,"L"
1502,,,"daq",,"Maria",,"Dandami",,,,0,"ltr",,"L"
1503,,"dar","dar",,"Dargwa",,,,,,0,"ltr",,"L"
1504,,,"das",,"Daho-Doo",,,,,,0,"ltr",,"L"
1505,,,"dat",,"Darang Deng",,,,,,0,"ltr",,"L"
1506,,,"dau",,"Daju",,"Dar Sila",,,,0,"ltr",,"L"
1507,,,"dav",,"Taita",,,,,,0,"ltr",,"L"
1508,,,"daw",,"Davawenyo",,,,,,0,"ltr",,"L"
1509,,,"dax",,"Dayi",,,,,,0,"ltr",,"L"
1510,,,"daz",,"Dao",,,,,,0,"ltr",,"L"
1511,,,"dba",,"Dogon",,"Bangeri Me",,,,0,"ltr",,"L"
1512,,,"dbb",,"Deno",,,,,,0,"ltr",,"L"
1513,,,"dbd",,"Dadiya",,,,,,0,"ltr",,"L"
1514,,,"dbe",,"Dabe",,,,,,0,"ltr",,"L"
1515,,,"dbf",,"Edopi",,,,,,0,"ltr",,"L"
1516,,,"dbg",,"Dogon",,"Dogul Dom",,,,0,"ltr",,"L"
1517,,,"dbi",,"Doka",,,,,,0,"ltr",,"L"
1518,,,"dbj",,"Ida'an",,,,,,0,"ltr",,"L"
1519,,,"dbl",,"Dyirbal",,,,,,0,"ltr",,"L"
1520,,,"dbm",,"Duguri",,,,,,0,"ltr",,"L"
1521,,,"dbn",,"Duriankere",,,,,,0,"ltr",,"L"
1522,,,"dbo",,"Dulbu",,,,,,0,"ltr",,"L"
1523,,,"dbp",,"Duwai",,,,,,0,"ltr",,"L"
1524,,,"dbq",,"Daba",,,,,,0,"ltr",,"L"
1525,,,"dbr",,"Dabarre",,,,,,0,"ltr",,"L"
1526,,,"dbu",,"Dogon",,"Bondum Dom",,,,0,"ltr",,"L"
1527,,,"dbv",,"Dungu",,,,,,0,"ltr",,"L"
1528,,,"dby",,"Dibiyaso",,,,,,0,"ltr",,"L"
1529,,,"dcc",,"Deccan",,,,,,0,"ltr",,"L"
1530,,,"dcr",,"Negerhollands",,,,,,0,"ltr",,"E"
1531,,,"ddd",,"Dongotono",,,,,,0,"ltr",,"L"
1532,,,"dde",,"Doondo",,,,,,0,"ltr",,"L"
1533,,,"ddg",,"Fataluku",,,,,,0,"ltr",,"L"
1534,,,"ddi",,"Diodio",,,,,,0,"ltr",,"L"
1535,,,"ddj",,"Jaru",,,,,,0,"ltr",,"L"
1536,,,"ddn",,"Dendi","Benin",,,,,0,"ltr",,"L"
1537,,,"ddo",,"Dido",,,,,,0,"ltr",,"L"
1538,,,"dds",,"Dogon",,"Donno So",,,,0,"ltr",,"L"
1539,,,"ddw",,"Dawera-Daweloor",,,,,,0,"ltr",,"L"
1540,,,"dea",,"Delason",,,,,,0,"ltr",,"C"
1541,,,"dec",,"Dagik",,,,,,0,"ltr",,"L"
1542,,,"ded",,"Dedua",,,,,,0,"ltr",,"L"
1543,,,"dee",,"Dewoin",,,,,,0,"ltr",,"L"
1544,,,"def",,"Dezfuli",,,,,,0,"ltr",,"L"
1545,,,"deg",,"Degema",,,,,,0,"ltr",,"L"
1546,,,"deh",,"Dehwari",,,,,,0,"ltr",,"L"
1547,,,"dei",,"Demisa",,,,,,0,"ltr",,"L"
1548,,,"dek",,"Dek",,,,,,0,"ltr",,"L"
1549,,"del","del",,"Delaware",,,,,,1,"ltr",,"L"
1550,,,"dem",,"Dem",,,,,,0,"ltr",,"L"
1551,,"den","den",,"Slave","Athapascan",,,,,1,"ltr",,"L"
1552,,,"dep",,"Delaware",,"Pidgin",,,,0,"ltr",,"E"
1553,,,"deq",,"Dendi","Central African Republic",,,,,0,"ltr",,"L"
1554,,,"der",,"Deori",,,,,,0,"ltr",,"L"
1555,,,"des",,"Desano",,,,,,0,"ltr",,"L"
1556,"de","deu","deu",,"German",,,"Deutsch",,,0,"ltr","c == 1 ? 1 : 2","L"
1557,,,"dev",,"Domung",,,,,,0,"ltr",,"L"
1558,,,"dez",,"Dengese",,,,,,0,"ltr",,"L"
1559,,,"dga",,"Dagaare",,"Southern",,,,0,"ltr",,"L"
1560,,,"dgc",,"Agta",,"Casiguran Dumagat",,,,0,"ltr",,"L"
1561,,,"dgd",,"Dagaari Dioula",,,,,,0,"ltr",,"L"
1562,,,"dge",,"Degenan",,,,,,0,"ltr",,"L"
1563,,,"dgg",,"Doga",,,,,,0,"ltr",,"L"
1564,,,"dgh",,"Dghwede",,,,,,0,"ltr",,"L"
1565,,,"dgi",,"Dagara",,"Northern",,,,0,"ltr",,"L"
1566,,,"dgk",,"Dagba",,,,,,0,"ltr",,"L"
1567,,,"dgn",,"Dagoman",,,,,,0,"ltr",,"E"
1568,,,"dgo",,"Dogri","specific",,,,,0,"ltr",,"L"
1569,,"dgr","dgr",,"Dogrib",,,,,,0,"ltr",,"L"
1570,,,"dgs",,"Dogoso",,,,,,0,"ltr",,"L"
1571,,,"dgu",,"Degaru",,,,,,0,"ltr",,"L"
1572,,,"dgx",,"Doghoro",,,,,,0,"ltr",,"L"
1573,,,"dgz",,"Daga",,,,,,0,"ltr",,"L"
1574,,,"dha",,"Dhanwar","India",,,,,0,"ltr",,"L"
1575,,,"dhd",,"Dhundari",,,,,,0,"ltr",,"L"
1576,,,"dhg",,"Dhangu",,,,,,0,"ltr",,"L"
1577,,,"dhi",,"Dhimal",,,,,,0,"ltr",,"L"
1578,,,"dhl",,"Dhalandji",,,,,,0,"ltr",,"L"
1579,,,"dhm",,"Zemba",,,,,,0,"ltr",,"L"
1580,,,"dhn",,"Dhanki",,,,,,0,"ltr",,"L"
1581,,,"dho",,"Dhodia",,,,,,0,"ltr",,"L"
1582,,,"dhr",,"Dhargari",,,,,,0,"ltr",,"L"
1583,,,"dhs",,"Dhaiso",,,,,,0,"ltr",,"L"
1584,,,"dhu",,"Dhurga",,,,,,0,"ltr",,"E"
1585,,,"dhv",,"Dehu",,,,,,0,"ltr",,"L"
1586,,,"dhw",,"Dhanwar","Nepal",,,,,0,"ltr",,"L"
1587,,,"dia",,"Dia",,,,,,0,"ltr",,"L"
1588,,,"dib",,"Dinka",,"South Central",,,,0,"ltr",,"L"
1589,,,"dic",,"Dida",,"Lakota",,,,0,"ltr",,"L"
1590,,,"did",,"Didinga",,,,,,0,"ltr",,"L"
1591,,,"dif",,"Dieri",,,,,,0,"ltr",,"E"
1592,,,"dig",,"Digo",,,,,,0,"ltr",,"L"
1593,,,"dih",,"Kumiai",,,,,,0,"ltr",,"L"
1594,,,"dii",,"Dimbong",,,,,,0,"ltr",,"L"
1595,,,"dij",,"Dai",,,,,,0,"ltr",,"L"
1596,,,"dik",,"Dinka",,"Southwestern",,,,0,"ltr",,"L"
1597,,,"dil",,"Dilling",,,,,,0,"ltr",,"L"
1598,,,"dim",,"Dime",,,,,,0,"ltr",,"L"
1599,,"din","din",,"Dinka",,,,,,1,"ltr",,"L"
1600,,,"dio",,"Dibo",,,,,,0,"ltr",,"L"
1601,,,"dip",,"Dinka",,"Northeastern",,,,0,"ltr",,"L"
1602,,,"diq",,"Dimli",,,,,,0,"ltr",,"L"
1603,,,"dir",,"Dirim",,,,,,0,"ltr",,"L"
1604,,,"dis",,"Dimasa",,,,,,0,"ltr",,"L"
1605,,,"dit",,"Dirari",,,,,,0,"ltr",,"L"
1606,,,"diu",,"Diriku",,,,,,0,"ltr",,"L"
1607,"dv","div","div",,"Divehi",,,,,,0,"ltr",,"L"
1608,,,"diw",,"Dinka",,"Northwestern",,,,0,"ltr",,"L"
1609,,,"dix",,"Dixon Reef",,,,,,0,"ltr",,"L"
1610,,,"diy",,"Diuwe",,,,,,0,"ltr",,"L"
1611,,,"diz",,"Ding",,,,,,0,"ltr",,"L"
1612,,,"djb",,"Djinba",,,,,,0,"ltr",,"L"
1613,,,"djc",,"Daju",,"Dar Daju",,,,0,"ltr",,"L"
1614,,,"djd",,"Djamindjung",,,,,,0,"ltr",,"L"
1615,,,"dje",,"Zarma",,,,,,0,"ltr",,"L"
1616,,,"djf",,"Djangun",,,,,,0,"ltr",,"L"
1617,,,"dji",,"Djinang",,,,,,0,"ltr",,"L"
1618,,,"djj",,"Djeebbana",,,,,,0,"ltr",,"L"
1619,,,"djk",,"Aukan",,,,,,0,"ltr",,"L"
1620,,,"djl",,"Djiwarli",,,,,,0,"ltr",,"L"
1621,,,"djm",,"Dogon",,"Jamsay",,,,0,"ltr",,"L"
1622,,,"djn",,"Djauan",,,,,,0,"ltr",,"L"
1623,,,"djo",,"Djongkang",,,,,,0,"ltr",,"L"
1624,,,"djr",,"Djambarrpuyngu",,,,,,0,"ltr",,"L"
1625,,,"dju",,"Kapriman",,,,,,0,"ltr",,"L"
1626,,,"djw",,"Djawi",,,,,,0,"ltr",,"L"
1627,,,"dka",,"Dakpakha",,,,,,0,"ltr",,"L"
1628,,,"dkk",,"Dakka",,,,,,0,"ltr",,"L"
1629,,,"dkl",,"Dogon",,"Kolum So",,,,0,"ltr",,"L"
1630,,,"dkr",,"Kuijau",,,,,,0,"ltr",,"L"
1631,,,"dks",,"Dinka",,"Southeastern",,,,0,"ltr",,"L"
1632,,,"dkx",,"Mazagway",,,,,,0,"ltr",,"L"
1633,,,"dlg",,"Dolgan",,,,,,0,"ltr",,"L"
1634,,,"dlm",,"Dalmatian",,,,,,0,"ltr",,"E"
1635,,,"dln",,"Darlong",,,,,,0,"ltr",,"L"
1636,,,"dma",,"Duma",,,,,,0,"ltr",,"L"
1637,,,"dmc",,"Dimir",,,,,,0,"ltr",,"L"
1638,,,"dme",,"Dugwor",,,,,,0,"ltr",,"L"
1639,,,"dmg",,"Kinabatangan",,"Upper",,,,0,"ltr",,"L"
1640,,,"dmk",,"Domaaki",,,,,,0,"ltr",,"L"
1641,,,"dml",,"Dameli",,,,,,0,"ltr",,"L"
1642,,,"dmm",,"Dama",,,,,,0,"ltr",,"L"
1643,,,"dmo",,"Kemezung",,,,,,0,"ltr",,"L"
1644,,,"dmr",,"Damar",,"East",,,,0,"ltr",,"L"
1645,,,"dms",,"Dampelas",,,,,,0,"ltr",,"L"
1646,,,"dmu",,"Dubu",,,,,,0,"ltr",,"L"
1647,,,"dmv",,"Dumpas",,,,,,0,"ltr",,"L"
1648,,,"dmx",,"Dema",,,,,,0,"ltr",,"L"
1649,,,"dmy",,"Demta",,,,,,0,"ltr",,"L"
1650,,,"dna",,"Dani",,"Upper Grand Valley",,,,0,"ltr",,"L"
1651,,,"dnd",,"Daonda",,,,,,0,"ltr",,"L"
1652,,,"dne",,"Ndendeule",,,,,,0,"ltr",,"L"
1653,,,"dng",,"Dungan",,,,,,0,"ltr",,"L"
1654,,,"dni",,"Dani",,"Lower Grand Valley",,,,0,"ltr",,"L"
1655,,,"dnk",,"Dengka",,,,,,0,"ltr",,"L"
1656,,,"dnn",,"Dzùùngoo",,,,,,0,"ltr",,"L"
1657,,,"dnr",,"Danaru",,,,,,0,"ltr",,"L"
1658,,,"dnt",,"Dani",,"Mid Grand Valley",,,,0,"ltr",,"L"
1659,,,"dnu",,"Danau",,,,,,0,"ltr",,"L"
1660,,,"dnw",,"Dani",,"Western",,,,0,"ltr",,"L"
1661,,,"dny",,"Dení",,,,,,0,"ltr",,"L"
1662,,,"doa",,"Dom",,,,,,0,"ltr",,"L"
1663,,,"dob",,"Dobu",,,,,,0,"ltr",,"L"
1664,,,"doc",,"Dong",,"Northern",,,,0,"ltr",,"L"
1665,,,"doe",,"Doe",,,,,,0,"ltr",,"L"
1666,,,"dof",,"Domu",,,,,,0,"ltr",,"L"
1667,,,"doh",,"Dong",,,,,,0,"ltr",,"L"
1668,,"doi","doi",,"Dogri","generic",,,,,1,"ltr",,"L"
1669,,,"dok",,"Dondo",,,,,,0,"ltr",,"L"
1670,,,"dol",,"Doso",,,,,,0,"ltr",,"L"
1671,,,"don",,"Toura","Papua New Guinea",,,,,0,"ltr",,"L"
1672,,,"doo",,"Dongo",,,,,,0,"ltr",,"L"
1673,,,"dop",,"Lukpa",,,,,,0,"ltr",,"L"
1674,,,"doq",,"Dominican Sign Language",,,,,,0,"ltr",,"L"
1675,,,"dor",,"Dori'o",,,,,,0,"ltr",,"L"
1676,,,"dos",,"Dogosé",,,,,,0,"ltr",,"L"
1677,,,"dot",,"Dass",,,,,,0,"ltr",,"L"
1678,,,"dov",,"Dombe",,,,,,0,"ltr",,"L"
1679,,,"dow",,"Doyayo",,,,,,0,"ltr",,"L"
1680,,,"dox",,"Bussa",,,,,,0,"ltr",,"L"
1681,,,"doy",,"Dompo",,,,,,0,"ltr",,"L"
1682,,,"doz",,"Dorze",,,,,,0,"ltr",,"L"
1683,,,"dpp",,"Papar",,,,,,0,"ltr",,"L"
1684,,,"drb",,"Dair",,,,,,0,"ltr",,"L"
1685,,,"drd",,"Darmiya",,,,,,0,"ltr",,"L"
1686,,,"dre",,"Dolpo",,,,,,0,"ltr",,"L"
1687,,,"drg",,"Rungus",,,,,,0,"ltr",,"L"
1688,,,"drh",,"Darkhat",,,,,,0,"ltr",,"L"
1689,,,"dri",,"C'lela",,,,,,0,"ltr",,"L"
1690,,,"drl",,"Darling",,,,,,0,"ltr",,"L"
1691,,,"drn",,"Damar",,"West",,,,0,"ltr",,"L"
1692,,,"dro",,"Daro-Matu",,,,,,0,"ltr",,"L"
1693,,,"drq",,"Dura",,,,,,0,"ltr",,"E"
1694,,,"drr",,"Dororo",,,,,,0,"ltr",,"E"
1695,,,"drs",,"Gedeo",,,,,,0,"ltr",,"L"
1696,,,"drt",,"Drents",,,,,,0,"ltr",,"L"
1697,,,"dru",,"Rukai",,,,,,0,"ltr",,"L"
1698,,,"drw",,"Darwazi",,,,,,0,"ltr",,"L"
1699,,,"dry",,"Darai",,,,,,0,"ltr",,"L"
1700,,"dsb","dsb",,"Sorbian",,"Lower",,,,0,"ltr",,"L"
1701,,,"dse",,"Dutch Sign Language",,,,,,0,"ltr",,"L"
1702,,,"dsh",,"Daasanach",,,,,,0,"ltr",,"L"
1703,,,"dsi",,"Disa",,,,,,0,"ltr",,"L"
1704,,,"dsl",,"Danish Sign Language",,,,,,0,"ltr",,"L"
1705,,,"dsn",,"Dusner",,,,,,0,"ltr",,"L"
1706,,,"dso",,"Oriya",,"Desiya",,,,0,"ltr",,"L"
1707,,,"dsq",,"Tadaksahak",,,,,,0,"ltr",,"L"
1708,,,"dta",,"Daur",,,,,,0,"ltr",,"L"
1709,,,"dtb",,"Kadazan",,"Labuk-Kinabatangan",,,,0,"ltr",,"L"
1710,,,"dtk",,"Dogon",,"Tene Kan",,,,0,"ltr",,"L"
1711,,,"dtm",,"Dogon",,"Tomo Kan",,,,0,"ltr",,"L"
1712,,,"dtp",,"Dusun",,"Central",,,,0,"ltr",,"L"
1713,,,"dtr",,"Lotud",,,,,,0,"ltr",,"L"
1714,,,"dts",,"Dogon",,"Toro So",,,,0,"ltr",,"L"
1715,,,"dtt",,"Dogon",,"Toro Tegu",,,,0,"ltr",,"L"
1716,,"dua","dua",,"Duala",,,,,,0,"ltr",,"L"
1717,,,"dub",,"Dubli",,,,,,0,"ltr",,"L"
1718,,,"duc",,"Duna",,,,,,0,"ltr",,"L"
1719,,,"dud",,"Hun-Saare",,,,,,0,"ltr",,"L"
1720,,,"due",,"Agta",,"Umiray Dumaget",,,,0,"ltr",,"L"
1721,,,"duf",,"Dumbea",,,,,,0,"ltr",,"L"
1722,,,"dug",,"Duruma",,,,,,0,"ltr",,"L"
1723,,,"duh",,"Dungra Bhil",,,,,,0,"ltr",,"L"
1724,,,"dui",,"Dumun",,,,,,0,"ltr",,"L"
1725,,,"duj",,"Dhuwal",,,,,,0,"ltr",,"L"
1726,,,"duk",,"Duduela",,,,,,0,"ltr",,"L"
1727,,,"dul",,"Agta",,"Alabat Island",,,,0,"ltr",,"L"
1728,,"dum","dum",,"Dutch",,"Middle (ca.1050-1350)",,,,0,"ltr",,"H"
1729,,,"dun",,"Dusun Deyah",,,,,,0,"ltr",,"L"
1730,,,"duo",,"Agta",,"Dupaninan",,,,0,"ltr",,"L"
1731,,,"dup",,"Duano'",,,,,,0,"ltr",,"L"
1732,,,"duq",,"Dusun Malang",,,,,,0,"ltr",,"L"
1733,,,"dur",,"Dii",,,,,,0,"ltr",,"L"
1734,,,"dus",,"Dumi",,,,,,0,"ltr",,"L"
1735,,,"duu",,"Drung",,,,,,0,"ltr",,"L"
1736,,,"duv",,"Duvle",,,,,,0,"ltr",,"L"
1737,,,"duw",,"Dusun Witu",,,,,,0,"ltr",,"L"
1738,,,"dux",,"Duungooma",,,,,,0,"ltr",,"L"
1739,,,"duy",,"Agta",,"Dicamay",,,,0,"ltr",,"E"
1740,,,"duz",,"Duli",,,,,,0,"ltr",,"E"
1741,,,"dva",,"Duau",,,,,,0,"ltr",,"L"
1742,,,"dwa",,"Diri",,,,,,0,"ltr",,"L"
1743,,,"dws",,"Dutton World Speedwords",,,,,,0,"ltr",,"C"
1744,,,"dww",,"Dawawa",,,,,,0,"ltr",,"L"
1745,,,"dya",,"Dyan",,,,,,0,"ltr",,"L"
1746,,,"dyb",,"Dyaberdyaber",,,,,,0,"ltr",,"L"
1747,,,"dyd",,"Dyugun",,,,,,0,"ltr",,"L"
1748,,,"dyg",,"Agta",,"Villa Viciosa",,,,0,"ltr",,"E"
1749,,,"dyi",,"Senoufo",,"Djimini",,,,0,"ltr",,"L"
1750,,,"dyk",,"Dayak",,"Land",,,,0,"ltr",,"L"
1751,,,"dyn",,"Dyangadi",,,,,,0,"ltr",,"L"
1752,,,"dyo",,"Jola-Fonyi",,,,,,0,"ltr",,"L"
1753,,"dyu","dyu",,"Dyula",,,,,,0,"ltr",,"L"
1754,,,"dyy",,"Dyaabugay",,,,,,0,"ltr",,"L"
1755,,,"dza",,"Duguza",,,,,,0,"ltr",,"L"
1756,,,"dzd",,"Daza",,,,,,0,"ltr",,"L"
1757,,,"dzg",,"Dazaga",,,,,,0,"ltr",,"L"
1758,,,"dzl",,"Dzalakha",,,,,,0,"ltr",,"L"
1759,,,"dzn",,"Dzando",,,,,,0,"ltr",,"L"
1760,"dz","dzo","dzo",,"Dzongkha",,,,,,0,"ltr",,"L"
1761,,,"ebg",,"Ebughu",,,,,,0,"ltr",,"L"
1762,,,"ebo",,"Teke-Ebo",,,,,,0,"ltr",,"L"
1763,,,"ebr",,"Ebrié",,,,,,0,"ltr",,"L"
1764,,,"ebu",,"Embu",,,,,,0,"ltr",,"L"
1765,,,"ecr",,"Eteocretan",,,,,,0,"ltr",,"A"
1766,,,"ecs",,"Ecuadorian Sign Language",,,,,,0,"ltr",,"L"
1767,,,"ecy",,"Eteocypriot",,,,,,0,"ltr",,"A"
1768,,,"eee",,"E",,,,,,0,"ltr",,"L"
1769,,,"efa",,"Efai",,,,,,0,"ltr",,"L"
1770,,,"efe",,"Efe",,,,,,0,"ltr",,"L"
1771,,"efi","efi",,"Efik",,,,,,0,"ltr",,"L"
1772,,,"ega",,"Ega",,,,,,0,"ltr",,"L"
1773,,,"ego",,"Eggon",,,,,,0,"ltr",,"L"
1774,,"egy","egy",,"Egyptian","Ancient",,,,,0,"ltr",,"A"
1775,,,"ehu",,"Ehueun",,,,,,0,"ltr",,"L"
1776,,,"eip",,"Eipomek",,,,,,0,"ltr",,"L"
1777,,,"eit",,"Eitiep",,,,,,0,"ltr",,"L"
1778,,,"eiv",,"Askopan",,,,,,0,"ltr",,"L"
1779,,,"eja",,"Ejamat",,,,,,0,"ltr",,"L"
1780,,"eka","eka",,"Ekajuk",,,,,,0,"ltr",,"L"
1781,,,"eke",,"Ekit",,,,,,0,"ltr",,"L"
1782,,,"ekg",,"Ekari",,,,,,0,"ltr",,"L"
1783,,,"eki",,"Eki",,,,,,0,"ltr",,"L"
1784,,,"ekm",,"Elip",,,,,,0,"ltr",,"L"
1785,,,"eko",,"Koti",,,,,,0,"ltr",,"L"
1786,,,"ekp",,"Ekpeye",,,,,,0,"ltr",,"L"
1787,,,"ekr",,"Yace",,,,,,0,"ltr",,"L"
1788,,,"eky",,"Kayah",,"Eastern",,,,0,"ltr",,"L"
1789,,,"ele",,"Elepi",,,,,,0,"ltr",,"L"
1790,,,"elh",,"El Hugeirat",,,,,,0,"ltr",,"L"
1791,,,"eli",,"Nding",,,,,,0,"ltr",,"L"
1792,,,"elk",,"Elkei",,,,,,0,"ltr",,"L"
1793,"el","ell","ell",,"Greek",,"Modern (1453-)","Ελληνικά",,,0,"ltr","c == 1 ? 1 : 2","L"
1794,,,"elm",,"Eleme",,,,,,0,"ltr",,"L"
1795,,,"elo",,"El Molo",,,,,,0,"ltr",,"L"
1796,,,"elp",,"Elpaputih",,,,,,0,"ltr",,"L"
1797,,,"elu",,"Elu",,,,,,0,"ltr",,"L"
1798,,"elx","elx",,"Elamite",,,,,,0,"ltr",,"A"
1799,,,"ema",,"Emai-Iuleha-Ora",,,,,,0,"ltr",,"L"
1800,,,"emb",,"Embaloh",,,,,,0,"ltr",,"L"
1801,,,"eme",,"Emerillon",,,,,,0,"ltr",,"L"
1802,,,"emg",,"Meohang",,"Eastern",,,,0,"ltr",,"L"
1803,,,"emi",,"Mussau-Emira",,,,,,0,"ltr",,"L"
1804,,,"emk",,"Maninkakan",,"Eastern",,,,0,"ltr",,"L"
1805,,,"eml",,"Emiliano-Romagnolo",,,,,,0,"ltr",,"L"
1806,,,"emm",,"Mamulique",,,,,,0,"ltr",,"E"
1807,,,"emn",,"Eman",,,,,,0,"ltr",,"L"
1808,,,"emo",,"Emok",,,,,,0,"ltr",,"E"
1809,,,"emp",,"Emberá",,"Northern",,,,0,"ltr",,"L"
1810,,,"ems",,"Yupik",,"Pacific Gulf",,,,0,"ltr",,"L"
1811,,,"emu",,"Muria",,"Eastern",,,,0,"ltr",,"L"
1812,,,"emw",,"Emplawas",,,,,,0,"ltr",,"L"
1813,,,"emy",,"Mayan",,"Epigraphic",,,,0,"ltr",,"E"
1814,,,"ena",,"Apali",,,,,,0,"ltr",,"L"
1815,,,"enb",,"Endo",,,,,,0,"ltr",,"L"
1816,,,"enc",,"En",,,,,,0,"ltr",,"L"
1817,,,"end",,"Ende",,,,,,0,"ltr",,"L"
1818,,,"enf",,"Enets",,"Forest",,,,0,"ltr",,"L"
1819,"en","eng","eng",,"English",,,,,,0,"ltr","c == 1 ? 1 : 2","L"
1820,,,"enh",,"Enets",,"Tundra",,,,0,"ltr",,"L"
1821,,,"eni",,"Enim",,,,,,0,"ltr",,"L"
1822,,"enm","enm",,"English",,"Middle (1100-1500)",,,,0,"ltr",,"H"
1823,,,"enn",,"Engenni",,,,,,0,"ltr",,"L"
1824,,,"eno",,"Enggano",,,,,,0,"ltr",,"L"
1825,,,"enq",,"Enga",,,,,,0,"ltr",,"L"
1826,,,"enr",,"Emumu",,,,,,0,"ltr",,"L"
1827,,,"env",,"Enwan","Edu State",,,,,0,"ltr",,"L"
1828,,,"enw",,"Enwan","Akwa Ibom State",,,,,0,"ltr",,"L"
1829,,,"eot",,"Beti","Côte d'Ivoire",,,,,0,"ltr",,"L"
1830,,,"epi",,"Epie",,,,,,0,"ltr",,"L"
1831,"eo","epo","epo",,"Esperanto",,,,,,0,"ltr","c == 1 ? 1 : 2","C"
1832,,,"erg",,"Sie",,,,,,0,"ltr",,"L"
1833,,,"erh",,"Eruwa",,,,,,0,"ltr",,"L"
1834,,,"eri",,"Ogea",,,,,,0,"ltr",,"L"
1835,,,"erk",,"Efate",,"South",,,,0,"ltr",,"L"
1836,,,"ero",,"Horpa",,,,,,0,"ltr",,"L"
1837,,,"err",,"Erre",,,,,,0,"ltr",,"L"
1838,,,"ers",,"Ersu",,,,,,0,"ltr",,"L"
1839,,,"ert",,"Eritai",,,,,,0,"ltr",,"L"
1840,,,"erw",,"Erokwanas",,,,,,0,"ltr",,"L"
1841,,,"ese",,"Ese Ejja",,,,,,0,"ltr",,"L"
1842,,,"esh",,"Eshtehardi",,,,,,0,"ltr",,"L"
1843,,,"esi",,"Inupiatun",,"North Alaskan",,,,0,"ltr",,"L"
1844,,,"esk",,"Inupiatun",,"Northwest Alaska",,,,0,"ltr",,"L"
1845,,,"esl",,"Egypt Sign Language",,,,,,0,"ltr",,"L"
1846,,,"esm",,"Esuma",,,,,,0,"ltr",,"E"
1847,,,"esn",,"Salvadoran Sign Language",,,,,,0,"ltr",,"L"
1848,,,"eso",,"Estonian Sign Language",,,,,,0,"ltr",,"L"
1849,,,"esq",,"Esselen",,,,,,0,"ltr",,"E"
1850,,,"ess",,"Yupik",,"Central Siberian",,,,0,"ltr",,"L"
1851,"et","est","est",,"Estonian",,,"Eesti",,,0,"ltr","c == 1 ? 1 : 2","L"
1852,,,"esu",,"Yupik",,"Central",,,,0,"ltr",,"L"
1853,,,"etb",,"Etebi",,,,,,0,"ltr",,"L"
1854,,,"etc",,"Etchemin",,,,,,0,"ltr",,"E"
1855,,,"eth",,"Ethiopian Sign Language",,,,,,0,"ltr",,"L"
1856,,,"etn",,"Eton","Vanuatu",,,,,0,"ltr",,"L"
1857,,,"eto",,"Eton","Cameroon",,,,,0,"ltr",,"L"
1858,,,"etr",,"Edolo",,,,,,0,"ltr",,"L"
1859,,,"ets",,"Yekhee",,,,,,0,"ltr",,"L"
1860,,,"ett",,"Etruscan",,,,,,0,"ltr",,"A"
1861,,,"etu",,"Ejagham",,,,,,0,"ltr",,"L"
1862,,,"etx",,"Eten",,,,,,0,"ltr",,"L"
1863,,,"etz",,"Semimi",,,,,,0,"ltr",,"L"
1864,,,"eur",,"Europanto",,,,,,0,"ltr",,"L"
1865,"eu","eus","eus",,"Basque",,,"euskera",,,0,"ltr",,"L"
1866,,,"eve",,"Even",,,,,,0,"ltr",,"L"
1867,,,"evh",,"Uvbie",,,,,,0,"ltr",,"L"
1868,,,"evn",,"Evenki",,,,,,0,"ltr",,"L"
1869,"ee","ewe","ewe",,"Ewe",,,"Ɛʋɛ",,,0,"ltr",,"L"
1870,,"ewo","ewo",,"Ewondo",,,,,,0,"ltr",,"L"
1871,,,"ext",,"Extremaduran",,,,,,0,"ltr",,"L"
1872,,,"eya",,"Eyak",,,,,,0,"ltr",,"L"
1873,,,"eze",,"Uzekwe",,,,,,0,"ltr",,"L"
1874,,,"faa",,"Fasu",,,,,,0,"ltr",,"L"
1875,,,"fab",,"Fa D'ambu",,,,,,0,"ltr",,"L"
1876,,,"fad",,"Wagi",,,,,,0,"ltr",,"L"
1877,,,"faf",,"Fagani",,,,,,0,"ltr",,"L"
1878,,,"fag",,"Finongan",,,,,,0,"ltr",,"L"
1879,,,"fah",,"Fali Of Baissa",,,,,,0,"ltr",,"L"
1880,,,"fai",,"Faiwol",,,,,,0,"ltr",,"L"
1881,,,"faj",,"Faita",,,,,,0,"ltr",,"L"
1882,,,"fak",,"Fang","Cameroon",,,,,0,"ltr",,"L"
1883,,,"fal",,"Fali",,"South",,,,0,"ltr",,"L"
1884,,,"fam",,"Fam",,,,,,0,"ltr",,"L"
1885,,"fan","fan",,"Fang","Equatorial Guinea",,,,,0,"ltr",,"L"
1886,"fo","fao","fao",,"Faroese",,,,,,0,"ltr",,"L"
1887,,,"fap",,"Palor",,,,,,0,"ltr",,"L"
1888,,,"far",,"Fataleka",,,,,,0,"ltr",,"L"
1889,"fa","fas","fas",,"Persian",,,"فارسی",,,1,"ltr",,"L"
1890,,"fat","fat",,"Fanti",,,,,,0,"ltr",,"L"
1891,,,"fau",,"Fayu",,,,,,0,"ltr",,"L"
1892,,,"fax",,"Fala",,,,,,0,"ltr",,"L"
1893,,,"fay",,"Fars",,"Southwestern",,,,0,"ltr",,"L"
1894,,,"faz",,"Fars",,"Northwestern",,,,0,"ltr",,"L"
1895,,,"fcs",,"Quebec Sign Language",,,,,,0,"ltr",,"L"
1896,,,"fer",,"Feroge",,,,,,0,"ltr",,"L"
1897,,,"ffm",,"Fulfulde",,"Maasina",,,,0,"ltr",,"L"
1898,,,"fgr",,"Fongoro",,,,,,0,"ltr",,"L"
1899,,,"fia",,"Nobiin",,,,,,0,"ltr",,"L"
1900,,,"fie",,"Fyer",,,,,,0,"ltr",,"L"
1901,"fj","fij","fij",,"Fijian",,,,,,0,"ltr",,"L"
1902,,"fil","fil",,"Filipino; Pilipino",,,,,,0,"ltr",,"L"
1903,"fi","fin","fin",,"Finnish",,,"suomi",,,0,"ltr","c == 1 ? 1 : 2","L"
1904,,,"fip",,"Fipa",,,,,,0,"ltr",,"L"
1905,,,"fir",,"Firan",,,,,,0,"ltr",,"L"
1906,,,"fit",,"Finnish",,"Tornedalen",,,,0,"ltr",,"L"
1907,,,"fiw",,"Fiwaga",,,,,,0,"ltr",,"L"
1908,,,"fiz",,"Izere",,,,,,0,"ltr",,"L"
1909,,,"fkv",,"Finnish",,"Kven",,,,0,"ltr",,"L"
1910,,,"fla",,"Kalispel-Pend d'Oreille",,,,,,0,"ltr",,"L"
1911,,,"flh",,"Foau",,,,,,0,"ltr",,"L"
1912,,,"fli",,"Fali",,,,,,0,"ltr",,"L"
1913,,,"fll",,"Fali",,"North",,,,0,"ltr",,"L"
1914,,,"flm",,"Chin",,"Falam",,,,0,"ltr",,"L"
1915,,,"fln",,"Flinders Island",,,,,,0,"ltr",,"L"
1916,,,"flr",,"Fuliiru",,,,,,0,"ltr",,"L"
1917,,,"fly",,"Tsotsitaal",,,,,,0,"ltr",,"L"
1918,,,"fmp",,"Fe'fe'",,,,,,0,"ltr",,"L"
1919,,,"fmu",,"Muria",,"Far Western",,,,0,"ltr",,"L"
1920,,,"fng",,"Fanagalo",,,,,,0,"ltr",,"L"
1921,,,"fni",,"Fania",,,,,,0,"ltr",,"L"
1922,,,"fod",,"Foodo",,,,,,0,"ltr",,"L"
1923,,,"foi",,"Foi",,,,,,0,"ltr",,"L"
1924,,,"fom",,"Foma",,,,,,0,"ltr",,"L"
1925,,"fon","fon",,"Fon",,,,,,0,"ltr",,"L"
1926,,,"for",,"Fore",,,,,,0,"ltr",,"L"
1927,,,"fos",,"Siraya",,,,,,0,"ltr",,"E"
1928,,,"fpe",,"Fernando Po Creole English",,,,,,0,"ltr",,"L"
1929,,,"fqs",,"Fas",,,,,,0,"ltr",,"L"
1930,"fr","fra","fra",,"French",,,"français",,,0,"ltr","c == 1 ? 1 : 2","L"
1931,,,"frc",,"French",,"Cajun",,,,0,"ltr",,"L"
1932,,,"frd",,"Fordata",,,,,,0,"ltr",,"L"
1933,,,"fri",,"Frisian",,"Western",,,,0,"ltr",,"L"
1934,,,"frk",,"Frankish",,,,,,0,"ltr",,"E"
1935,,"frm","frm",,"French",,"Middle (ca.1400-1600)",,,,0,"ltr",,"H"
1936,,"fro","fro",,"French",,"Old (842-Ca.1400)",,,,0,"ltr",,"H"
1937,,,"frp",,"Franco-Provençal",,,,,,0,"ltr",,"L"
1938,,,"frq",,"Forak",,,,,,0,"ltr",,"L"
1939,,,"frr",,"Frisian",,"Northern",,,,0,"ltr",,"L"
1940,,,"frs",,"Frisian",,"Eastern",,,,0,"ltr",,"L"
1941,,,"frt",,"Fortsenal",,,,,,0,"ltr",,"L"
1942,"fy","fry","fry",,"Frisian",,,,,,1,"ltr",,"L"
1943,,,"fse",,"Finnish Sign Language",,,,,,0,"ltr",,"L"
1944,,,"fsl",,"French Sign Language",,,,,,0,"ltr",,"L"
1945,,,"fss",,"Finnish-Swedish Sign Language",,,,,,0,"ltr",,"L"
1946,,,"fub",,"Fulfulde",,"Adamawa",,,,0,"ltr",,"L"
1947,,,"fuc",,"Pulaar",,,,,,0,"ltr",,"L"
1948,,,"fud",,"Futuna",,"East",,,,0,"ltr",,"L"
1949,,,"fue",,"Fulfulde",,"Borgu",,,,0,"ltr",,"L"
1950,,,"fuf",,"Pular",,,,,,0,"ltr",,"L"
1951,,,"fuh",,"Fulfulde",,"Western Niger",,,,0,"ltr",,"L"
1952,,,"fui",,"Fulfulde",,"Bagirmi",,,,0,"ltr",,"L"
1953,,,"fuj",,"Ko",,,,,,0,"ltr",,"L"
1954,"ff","ful","ful",,"Fulah",,,"Fulfulde, Pulaar, Pular",,,1,"ltr",,"L"
1955,,,"fum",,"Fum",,,,,,0,"ltr",,"L"
1956,,,"fun",,"Fulniô",,,,,,0,"ltr",,"L"
1957,,,"fuq",,"Fulfulde",,"Central-Eastern Niger",,,,0,"ltr",,"L"
1958,,"fur","fur",,"Friulian",,,,,,0,"ltr",,"L"
1959,,,"fut",,"Futuna-Aniwa",,,,,,0,"ltr",,"L"
1960,,,"fuu",,"Furu",,,,,,0,"ltr",,"L"
1961,,,"fuv",,"Fulfulde",,"Nigerian",,,,0,"ltr",,"L"
1962,,,"fuy",,"Fuyug",,,,,,0,"ltr",,"L"
1963,,,"fvr",,"Fur",,,,,,0,"ltr",,"L"
1964,,,"fwa",,"Fwâi",,,,,,0,"ltr",,"L"
1965,,,"fwe",,"Fwe",,,,,,0,"ltr",,"L"
1966,,"gaa","gaa",,"Ga",,,,,,0,"ltr",,"L"
1967,,,"gab",,"Gabri",,,,,,0,"ltr",,"L"
1968,,,"gad",,"Gaddang",,,,,,0,"ltr",,"L"
1969,,,"gae",,"Guarequena",,,,,,0,"ltr",,"L"
1970,,,"gaf",,"Gende",,,,,,0,"ltr",,"L"
1971,,,"gag",,"Gagauz",,,,,,0,"ltr",,"L"
1972,,,"gah",,"Alekano",,,,,,0,"ltr",,"L"
1973,,,"gai",,"Borei",,,,,,0,"ltr",,"L"
1974,,,"gaj",,"Gadsup",,,,,,0,"ltr",,"L"
1975,,,"gak",,"Gamkonora",,,,,,0,"ltr",,"L"
1976,,,"gal",,"Galoli",,,,,,0,"ltr",,"L"
1977,,,"gam",,"Kandawo",,,,,,0,"ltr",,"L"
1978,,,"gan",,"Chinese",,"Gan",,,,0,"ltr",,"L"
1979,,,"gao",,"Gants",,,,,,0,"ltr",,"L"
1980,,,"gap",,"Gal",,,,,,0,"ltr",,"L"
1981,,,"gaq",,"Gata'",,,,,,0,"ltr",,"L"
1982,,,"gar",,"Galeya",,,,,,0,"ltr",,"L"
1983,,,"gas",,"Garasia",,"Adiwasi",,,,0,"ltr",,"L"
1984,,,"gat",,"Kenati",,,,,,0,"ltr",,"L"
1985,,,"gau",,"Gadaba",,"Mudhili",,,,0,"ltr",,"L"
1986,,,"gav",,"Gabutamon",,,,,,0,"ltr",,"L"
1987,,,"gaw",,"Nobonob",,,,,,0,"ltr",,"L"
1988,,,"gax",,"Oromo",,"Borana-Arsi-Guji",,,,0,"ltr",,"L"
1989,,"gay","gay",,"Gayo",,,,,,0,"ltr",,"L"
1990,,,"gaz",,"Oromo",,"West Central",,,,0,"ltr",,"L"
1991,,"gba","gba",,"Gbaya","Central African Republic",,,,,1,"ltr",,"L"
1992,,,"gbb",,"Kaytetye",,,,,,0,"ltr",,"L"
1993,,,"gbc",,"Garawa",,,,,,0,"ltr",,"L"
1994,,,"gbd",,"Karadjeri",,,,,,0,"ltr",,"L"
1995,,,"gbe",,"Niksek",,,,,,0,"ltr",,"L"
1996,,,"gbf",,"Gaikundi",,,,,,0,"ltr",,"L"
1997,,,"gbg",,"Gbanziri",,,,,,0,"ltr",,"L"
1998,,,"gbh",,"Gbe",,"Defi",,,,0,"ltr",,"L"
1999,,,"gbi",,"Galela",,,,,,0,"ltr",,"L"
2000,,,"gbj",,"Gadaba",,"Bodo",,,,0,"ltr",,"L"
2001,,,"gbk",,"Gaddi",,,,,,0,"ltr",,"L"
2002,,,"gbl",,"Gamit",,,,,,0,"ltr",,"L"
2003,,,"gbm",,"Garhwali",,,,,,0,"ltr",,"L"
2004,,,"gbn",,"Mo'da",,,,,,0,"ltr",,"L"
2005,,,"gbo",,"Grebo",,"Northern",,,,0,"ltr",,"L"
2006,,,"gbp",,"Gbaya-Bossangoa",,,,,,0,"ltr",,"L"
2007,,,"gbq",,"Gbaya-Bozoum",,,,,,0,"ltr",,"L"
2008,,,"gbr",,"Gbagyi",,,,,,0,"ltr",,"L"
2009,,,"gbs",,"Gbe",,"Gbesi",,,,0,"ltr",,"L"
2010,,,"gbu",,"Gagadu",,,,,,0,"ltr",,"L"
2011,,,"gbv",,"Gbanu",,,,,,0,"ltr",,"L"
2012,,,"gbx",,"Gbe",,"Eastern Xwla",,,,0,"ltr",,"L"
2013,,,"gby",,"Gbari",,,,,,0,"ltr",,"L"
2014,,,"gbz",,"Dari",,"Zoroastrian",,,,0,"ltr",,"L"
2015,,,"gcc",,"Mali",,,,,,0,"ltr",,"L"
2016,,,"gcd",,"Ganggalida",,,,,,0,"ltr",,"L"
2017,,,"gce",,"Galice",,,,,,0,"ltr",,"E"
2018,,,"gcf",,"Guadeloupean Creole French",,,,,,0,"ltr",,"L"
2019,,,"gcl",,"Grenadian Creole English",,,,,,0,"ltr",,"L"
2020,,,"gcn",,"Gaina",,,,,,0,"ltr",,"L"
2021,,,"gcr",,"Guianese Creole French",,,,,,0,"ltr",,"L"
2022,,,"gct",,"German",,"Colonia Tovar",,,,0,"ltr",,"L"
2023,,,"gda",,"Lohar",,"Gade",,,,0,"ltr",,"L"
2024,,,"gdb",,"Gadaba",,"Pottangi Ollar",,,,0,"ltr",,"L"
2025,,,"gdc",,"Gugu Badhun",,,,,,0,"ltr",,"L"
2026,,,"gdd",,"Gedaged",,,,,,0,"ltr",,"L"
2027,,,"gde",,"Gude",,,,,,0,"ltr",,"L"
2028,,,"gdf",,"Guduf-Gava",,,,,,0,"ltr",,"L"
2029,,,"gdg",,"Ga'dang",,,,,,0,"ltr",,"L"
2030,,,"gdh",,"Gadjerawang",,,,,,0,"ltr",,"L"
2031,,,"gdi",,"Gundi",,,,,,0,"ltr",,"L"
2032,,,"gdj",,"Gurdjar",,,,,,0,"ltr",,"L"
2033,,,"gdk",,"Gadang",,,,,,0,"ltr",,"L"
2034,,,"gdl",,"Dirasha",,,,,,0,"ltr",,"L"
2035,,,"gdm",,"Laal",,,,,,0,"ltr",,"L"
2036,,,"gdn",,"Umanakaina",,,,,,0,"ltr",,"L"
2037,,,"gdo",,"Ghodoberi",,,,,,0,"ltr",,"L"
2038,,,"gdq",,"Mehri",,,,,,0,"ltr",,"L"
2039,,,"gdr",,"Wipi",,,,,,0,"ltr",,"L"
2040,,,"gdu",,"Gudu",,,,,,0,"ltr",,"L"
2041,,,"gdx",,"Godwari",,,,,,0,"ltr",,"L"
2042,,,"gea",,"Geruma",,,,,,0,"ltr",,"L"
2043,,,"geb",,"Kire",,,,,,0,"ltr",,"L"
2044,,,"gec",,"Grebo",,"Gboloo",,,,0,"ltr",,"L"
2045,,,"ged",,"Gade",,,,,,0,"ltr",,"L"
2046,,,"geg",,"Gengle",,,,,,0,"ltr",,"L"
2047,,,"geh",,"German",,"Hutterite",,,,0,"ltr",,"L"
2048,,,"gei",,"Gebe",,,,,,0,"ltr",,"L"
2049,,,"gej",,"Gen",,,,,,0,"ltr",,"L"
2050,,,"gek",,"Yiwom",,,,,,0,"ltr",,"L"
2051,,,"gel",,"Kag-Fer-Jiir-Koor-Ror-Us-Zuksun",,,,,,0,"ltr",,"L"
2052,,,"gen",,"Geman Deng",,,,,,0,"ltr",,"L"
2053,,,"geq",,"Geme",,,,,,0,"ltr",,"L"
2054,,,"ges",,"Geser-Gorom",,,,,,0,"ltr",,"L"
2055,,,"gew",,"Gera",,,,,,0,"ltr",,"L"
2056,,,"gex",,"Garre",,,,,,0,"ltr",,"L"
2057,,,"gey",,"Enya",,,,,,0,"ltr",,"L"
2058,,"gez","gez",,"Geez",,,,,,0,"ltr",,"A"
2059,,,"gfk",,"Patpatar",,,,,,0,"ltr",,"L"
2060,,,"gft",,"Gafat",,,,,,0,"ltr",,"E"
2061,,,"gga",,"Gao",,,,,,0,"ltr",,"L"
2062,,,"ggb",,"Gbii",,,,,,0,"ltr",,"L"
2063,,,"ggd",,"Gugadj",,,,,,0,"ltr",,"L"
2064,,,"gge",,"Guragone",,,,,,0,"ltr",,"L"
2065,,,"ggg",,"Gurgula",,,,,,0,"ltr",,"L"
2066,,,"ggh",,"Garreh-Ajuran",,,,,,0,"ltr",,"L"
2067,,,"ggk",,"Kungarakany",,,,,,0,"ltr",,"E"
2068,,,"ggl",,"Ganglau",,,,,,0,"ltr",,"L"
2069,,,"ggn",,"Gurung",,"Eastern",,,,0,"ltr",,"L"
2070,,,"ggo",,"Gondi",,"Southern",,,,0,"ltr",,"L"
2071,,,"ggr",,"Aghu Tharnggalu",,,,,,0,"ltr",,"E"
2072,,,"ggt",,"Gitua",,,,,,0,"ltr",,"L"
2073,,,"ggu",,"Gagu",,,,,,0,"ltr",,"L"
2074,,,"ggw",,"Gogodala",,,,,,0,"ltr",,"L"
2075,,,"gha",,"Ghadamès",,,,,,0,"ltr",,"L"
2076,,,"ghc",,"Gaelic",,"Hiberno-Scottish",,,,0,"ltr",,"E"
2077,,,"ghe",,"Ghale",,"Southern",,,,0,"ltr",,"L"
2078,,,"ghh",,"Ghale",,"Northern",,,,0,"ltr",,"L"
2079,,,"ghk",,"Karen",,"Geko",,,,0,"ltr",,"L"
2080,,,"ghl",,"Ghulfan",,,,,,0,"ltr",,"L"
2081,,,"ghn",,"Ghanongga",,,,,,0,"ltr",,"L"
2082,,,"gho",,"Ghomara",,,,,,0,"ltr",,"E"
2083,,,"ghr",,"Ghera",,,,,,0,"ltr",,"L"
2084,,,"ghs",,"Guhu-Samane",,,,,,0,"ltr",,"L"
2085,,,"ght",,"Ghale",,"Kutang",,,,0,"ltr",,"L"
2086,,,"gia",,"Kitja",,,,,,0,"ltr",,"L"
2087,,,"gib",,"Gibanawa",,,,,,0,"ltr",,"L"
2088,,,"gic",,"Gail",,,,,,0,"ltr",,"L"
2089,,,"gid",,"Gidar",,,,,,0,"ltr",,"L"
2090,,,"gig",,"Goaria",,,,,,0,"ltr",,"L"
2091,,"gil","gil",,"Gilbertese",,,,,,0,"ltr",,"L"
2092,,,"gim",,"Gimi","Eastern Highlands",,,,,0,"ltr",,"L"
2093,,,"gin",,"Hinukh",,,,,,0,"ltr",,"L"
2094,,,"gio",,"Gelao",,,,,,0,"ltr",,"L"
2095,,,"gip",,"Gimi","West New Britain",,,,,0,"ltr",,"L"
2096,,,"giq",,"Gelao",,"Green",,,,0,"ltr",,"L"
2097,,,"gir",,"Gelao",,"Red",,,,0,"ltr",,"L"
2098,,,"gis",,"Giziga",,"North",,,,0,"ltr",,"L"
2099,,,"git",,"Gitxsan",,,,,,0,"ltr",,"L"
2100,,,"giw",,"Gelao",,"White",,,,0,"ltr",,"L"
2101,,,"gix",,"Gilima",,,,,,0,"ltr",,"L"
2102,,,"giy",,"Giyug",,,,,,0,"ltr",,"L"
2103,,,"giz",,"Giziga",,"South",,,,0,"ltr",,"L"
2104,,,"gji",,"Geji",,,,,,0,"ltr",,"L"
2105,,,"gjk",,"Koli",,"Kachi",,,,0,"ltr",,"L"
2106,,,"gjn",,"Gonja",,,,,,0,"ltr",,"L"
2107,,,"gju",,"Gujari",,,,,,0,"ltr",,"L"
2108,,,"gka",,"Guya",,,,,,0,"ltr",,"L"
2109,,,"gke",,"Ndai",,,,,,0,"ltr",,"L"
2110,,,"gkn",,"Gokana",,,,,,0,"ltr",,"L"
2111,,,"gkp",,"Kpelle",,"Guinea",,,,0,"ltr",,"L"
2112,"gd","gla","gla",,"Gaelic","Scots",,,,,0,"ltr","c==1 ? 1 : c==2 ? 2 : 3","L"
2113,,,"glc",,"Bon Gula",,,,,,0,"ltr",,"L"
2114,,,"gld",,"Nanai",,,,,,0,"ltr",,"L"
2115,"ga","gle","gle",,"Irish",,,"Gaeilge",,,0,"ltr","c==1 ? 1 : c==2 ? 2 : 3","L"
2116,"gl","glg","glg",,"Gallegan",,,"Galego",,,0,"ltr",,"L"
2117,,,"glh",,"Pashayi",,"Northwest",,,,0,"ltr",,"L"
2118,,,"gli",,"Guliguli",,,,,,0,"ltr",,"E"
2119,,,"glj",,"Gula Iro",,,,,,0,"ltr",,"L"
2120,,,"glk",,"Gilaki",,,,,,0,"ltr",,"L"
2121,,,"glo",,"Galambu",,,,,,0,"ltr",,"L"
2122,,,"glr",,"Glaro-Twabo",,,,,,0,"ltr",,"L"
2123,,,"gls",,"Glosa",,,,,,0,"ltr",,"C"
2124,,,"glu",,"Gula","Chad",,,,,0,"ltr",,"L"
2125,"gv","glv","glv",,"Manx",,,,,,0,"ltr",,"E"
2126,,,"glw",,"Glavda",,,,,,0,"ltr",,"L"
2127,,,"gly",,"Gule",,,,,,0,"ltr",,"E"
2128,,,"gma",,"Gambera",,,,,,0,"ltr",,"L"
2129,,,"gmb",,"Gula'alaa",,,,,,0,"ltr",,"L"
2130,,,"gmd",,"Mághdì",,,,,,0,"ltr",,"L"
2131,,"gmh","gmh",,"German",,"Middle High (ca.1050-1500)",,,,0,"ltr",,"H"
2132,,,"gmn",,"Gimnime",,,,,,0,"ltr",,"L"
2133,,,"gmo",,"Gamo-Gofa-Dawro",,,,,,0,"ltr",,"L"
2134,,,"gmu",,"Gumalu",,,,,,0,"ltr",,"L"
2135,,,"gmx",,"Magoma",,,,,,0,"ltr",,"L"
2136,,,"gmy",,"Greek",,"Mycenaean",,,,0,"ltr",,"A"
2137,,,"gna",,"Kaansa",,,,,,0,"ltr",,"L"
2138,,,"gnb",,"Gangte",,,,,,0,"ltr",,"L"
2139,,,"gnc",,"Guanche",,,,,,0,"ltr",,"E"
2140,,,"gnd",,"Zulgo-Gemzek",,,,,,0,"ltr",,"L"
2141,,,"gng",,"Ngangam",,,,,,0,"ltr",,"L"
2142,,,"gnh",,"Lere",,,,,,0,"ltr",,"L"
2143,,,"gni",,"Gooniyandi",,,,,,0,"ltr",,"L"
2144,,,"gnk",,"//Gana",,,,,,0,"ltr",,"L"
2145,,,"gnl",,"Gangulu",,,,,,0,"ltr",,"E"
2146,,,"gnm",,"Ginuman",,,,,,0,"ltr",,"L"
2147,,,"gnn",,"Gumatj",,,,,,0,"ltr",,"L"
2148,,,"gno",,"Gondi",,"Northern",,,,0,"ltr",,"L"
2149,,,"gnq",,"Gana",,,,,,0,"ltr",,"L"
2150,,,"gnr",,"Gureng Gureng",,,,,,0,"ltr",,"E"
2151,,,"gnt",,"Guntai",,,,,,0,"ltr",,"L"
2152,,,"gnu",,"Gnau",,,,,,0,"ltr",,"L"
2153,,,"gnw",,"Guaraní",,"Western Bolivian",,,,0,"ltr",,"L"
2154,,,"gnz",,"Ganzi",,,,,,0,"ltr",,"L"
2155,,,"goa",,"Guro",,,,,,0,"ltr",,"L"
2156,,,"gob",,"Playero",,,,,,0,"ltr",,"L"
2157,,,"goc",,"Gorakor",,,,,,0,"ltr",,"L"
2158,,,"god",,"Godié",,,,,,0,"ltr",,"L"
2159,,,"goe",,"Gongduk",,,,,,0,"ltr",,"L"
2160,,,"gog",,"Gogo",,,,,,0,"ltr",,"L"
2161,,"goh","goh",,"German",,"Old High (ca.750-1050)",,,,0,"ltr",,"H"
2162,,,"goi",,"Gobasi",,,,,,0,"ltr",,"L"
2163,,,"goj",,"Gowlan",,,,,,0,"ltr",,"L"
2164,,,"gok",,"Gowli",,,,,,0,"ltr",,"L"
2165,,,"gol",,"Gola",,,,,,0,"ltr",,"L"
2166,,,"gom",,"Konkani",,"Goanese",,,,0,"ltr",,"L"
2167,,"gon","gon",,"Gondi",,,,,,1,"ltr",,"L"
2168,,,"goo",,"Gone Dau",,,,,,0,"ltr",,"L"
2169,,,"gop",,"Yeretuar",,,,,,0,"ltr",,"L"
2170,,,"goq",,"Gorap",,,,,,0,"ltr",,"L"
2171,,"gor","gor",,"Gorontalo",,,,,,0,"ltr",,"L"
2172,,,"gos",,"Gronings",,,,,,0,"ltr",,"L"
2173,,"got","got",,"Gothic",,,,,,0,"ltr",,"A"
2174,,,"gou",,"Gavar",,,,,,0,"ltr",,"L"
2175,,,"gow",,"Gorowa",,,,,,0,"ltr",,"L"
2176,,,"gox",,"Gobu",,,,,,0,"ltr",,"L"
2177,,,"goy",,"Goundo",,,,,,0,"ltr",,"L"
2178,,,"goz",,"Gozarkhani",,,,,,0,"ltr",,"L"
2179,,,"gpa",,"Gupa-Abawa",,,,,,0,"ltr",,"L"
2180,,,"gpn",,"Taiap",,,,,,0,"ltr",,"L"
2181,,,"gqa",,"Ga'anda",,,,,,0,"ltr",,"L"
2182,,,"gqi",,"Guiqiong",,,,,,0,"ltr",,"L"
2183,,,"gqn",,"Guana","Brazil",,,,,0,"ltr",,"E"
2184,,,"gqr",,"Gor",,,,,,0,"ltr",,"L"
2185,,,"gra",,"Garasia",,"Rajput",,,,0,"ltr",,"L"
2186,,"grb","grb",,"Grebo",,,,,,1,"ltr",,"L"
2187,,"grc","grc",,"Greek",,"Ancient (to 1453)",,,,0,"ltr",,"H"
2188,,,"grd",,"Guruntum-Mbaaru",,,,,,0,"ltr",,"L"
2189,,,"grg",,"Madi",,,,,,0,"ltr",,"L"
2190,,,"grh",,"Gbiri-Niragu",,,,,,0,"ltr",,"L"
2191,,,"gri",,"Ghari",,,,,,0,"ltr",,"L"
2192,,,"grj",,"Grebo",,"Southern",,,,0,"ltr",,"L"
2193,,,"grm",,"Kota Marudu Talantang",,,,,,0,"ltr",,"L"
2194,"gn","grn","grn",,"Guarani",,,,,,1,"ltr",,"L"
2195,,,"gro",,"Groma",,,,,,0,"ltr",,"L"
2196,,,"grq",,"Gorovu",,,,,,0,"ltr",,"L"
2197,,,"grr",,"Taznatit",,,,,,0,"ltr",,"L"
2198,,,"grs",,"Gresi",,,,,,0,"ltr",,"L"
2199,,,"grt",,"Garo",,,,,,0,"ltr",,"L"
2200,,,"gru",,"Kistane",,,,,,0,"ltr",,"L"
2201,,,"grv",,"Grebo",,"Central",,,,0,"ltr",,"L"
2202,,,"grw",,"Gweda",,,,,,0,"ltr",,"L"
2203,,,"grx",,"Guriaso",,,,,,0,"ltr",,"L"
2204,,,"gry",,"Grebo",,"Barclayville",,,,0,"ltr",,"L"
2205,,,"grz",,"Guramalum",,,,,,0,"ltr",,"L"
2206,,,"gsc",,"Gascon",,,,,,0,"ltr",,"L"
2207,,,"gse",,"Ghanaian Sign Language",,,,,,0,"ltr",,"L"
2208,,,"gsg",,"German Sign Language",,,,,,0,"ltr",,"L"
2209,,,"gsl",,"Gusilay",,,,,,0,"ltr",,"L"
2210,,,"gsm",,"Guatemalan Sign Language",,,,,,0,"ltr",,"L"
2211,,,"gsn",,"Gusan",,,,,,0,"ltr",,"L"
2212,,,"gsp",,"Wasembo",,,,,,0,"ltr",,"L"
2213,,,"gss",,"Greek Sign Language",,,,,,0,"ltr",,"L"
2214,,,"gsw",,"Schwyzerdütsch",,,,,,0,"ltr",,"L"
2215,,,"gta",,"Guató",,,,,,0,"ltr",,"L"
2216,,,"gti",,"Gbati-ri",,,,,,0,"ltr",,"L"
2217,,,"gua",,"Shiki",,,,,,0,"ltr",,"L"
2218,,,"gub",,"Guajajára",,,,,,0,"ltr",,"L"
2219,,,"guc",,"Wayuu",,,,,,0,"ltr",,"L"
2220,,,"gud",,"Dida",,"Yocoboué",,,,0,"ltr",,"L"
2221,,,"gue",,"Gurinji",,,,,,0,"ltr",,"L"
2222,,,"guf",,"Gupapuyngu",,,,,,0,"ltr",,"L"
2223,,,"gug",,"Guaraní",,"Paraguayan",,,,0,"ltr",,"L"
2224,,,"guh",,"Guahibo",,,,,,0,"ltr",,"L"
2225,,,"gui",,"Guaraní",,"Eastern Bolivian",,,,0,"ltr",,"L"
2226,"gu","guj","guj",,"Gujarati",,,,,,0,"ltr",,"L"
2227,,,"guk",,"Gumuz",,,,,,0,"ltr",,"L"
2228,,,"gul",,"Sea Island Creole English",,,,,,0,"ltr",,"L"
2229,,,"gum",,"Guambiano",,,,,,0,"ltr",,"L"
2230,,,"gun",,"Guaraní",,"Mbyá",,,,0,"ltr",,"L"
2231,,,"guo",,"Guayabero",,,,,,0,"ltr",,"L"
2232,,,"gup",,"Gunwinggu",,,,,,0,"ltr",,"L"
2233,,,"guq",,"Aché",,,,,,0,"ltr",,"L"
2234,,,"gur",,"Farefare",,,,,,0,"ltr",,"L"
2235,,,"gus",,"Guinean Sign Language",,,,,,0,"ltr",,"L"
2236,,,"gut",,"Maléku Jaíka",,,,,,0,"ltr",,"L"
2237,,,"guu",,"Yanomamö",,,,,,0,"ltr",,"L"
2238,,,"guv",,"Gey",,,,,,0,"ltr",,"E"
2239,,,"guw",,"Gun",,,,,,0,"ltr",,"L"
2240,,,"gux",,"Gourmanchéma",,,,,,0,"ltr",,"L"
2241,,,"guz",,"Gusii",,,,,,0,"ltr",,"L"
2242,,,"gva",,"Guana","Paraguay",,,,,0,"ltr",,"L"
2243,,,"gvc",,"Guanano",,,,,,0,"ltr",,"L"
2244,,,"gve",,"Duwet",,,,,,0,"ltr",,"L"
2245,,,"gvf",,"Golin",,,,,,0,"ltr",,"L"
2246,,,"gvj",,"Guajá",,,,,,0,"ltr",,"L"
2247,,,"gvl",,"Gulay",,,,,,0,"ltr",,"L"
2248,,,"gvm",,"Gurmana",,,,,,0,"ltr",,"L"
2249,,,"gvn",,"Kuku-Yalanji",,,,,,0,"ltr",,"L"
2250,,,"gvo",,"Gavião Do Jiparaná",,,,,,0,"ltr",,"L"
2251,,,"gvp",,"Gavião",,"Pará",,,,0,"ltr",,"L"
2252,,,"gvr",,"Gurung",,"Western",,,,0,"ltr",,"L"
2253,,,"gvs",,"Gumawana",,,,,,0,"ltr",,"L"
2254,,,"gvy",,"Guyani",,,,,,0,"ltr",,"E"
2255,,,"gwa",,"Mbato",,,,,,0,"ltr",,"L"
2256,,,"gwb",,"Gwa",,,,,,0,"ltr",,"L"
2257,,,"gwc",,"Kalami",,,,,,0,"ltr",,"L"
2258,,,"gwd",,"Gawwada",,,,,,0,"ltr",,"L"
2259,,,"gwe",,"Gweno",,,,,,0,"ltr",,"L"
2260,,,"gwf",,"Gowro",,,,,,0,"ltr",,"L"
2261,,,"gwg",,"Moo",,,,,,0,"ltr",,"L"
2262,,"gwi","gwi",,"Gwich´in",,,,,,0,"ltr",,"L"
2263,,,"gwj",,"/Gwi",,,,,,0,"ltr",,"L"
2264,,,"gwn",,"Gwandara",,,,,,0,"ltr",,"L"
2265,,,"gwr",,"Gwere",,,,,,0,"ltr",,"L"
2266,,,"gwt",,"Gawar-Bati",,,,,,0,"ltr",,"L"
2267,,,"gwu",,"Guwamu",,,,,,0,"ltr",,"L"
2268,,,"gww",,"Kwini",,,,,,0,"ltr",,"L"
2269,,,"gwx",,"Gua",,,,,,0,"ltr",,"L"
2270,,,"gxx",,"Wè Southern",,,,,,0,"ltr",,"L"
2271,,,"gya",,"Gbaya",,"Northwest",,,,0,"ltr",,"L"
2272,,,"gyb",,"Garus",,,,,,0,"ltr",,"L"
2273,,,"gyd",,"Kayardild",,,,,,0,"ltr",,"L"
2274,,,"gye",,"Gyem",,,,,,0,"ltr",,"L"
2275,,,"gyf",,"Gungabula",,,,,,0,"ltr",,"L"
2276,,,"gyg",,"Gbayi",,,,,,0,"ltr",,"L"
2277,,,"gyi",,"Gyele",,,,,,0,"ltr",,"L"
2278,,,"gym",,"Ngäbere",,,,,,0,"ltr",,"L"
2279,,,"gyn",,"Guyanese Creole English",,,,,,0,"ltr",,"L"
2280,,,"gyr",,"Guarayu",,,,,,0,"ltr",,"L"
2281,,,"gyy",,"Gunya",,,,,,0,"ltr",,"L"
2282,,,"gza",,"Ganza",,,,,,0,"ltr",,"L"
2283,,,"gzi",,"Gazi",,,,,,0,"ltr",,"L"
2284,,,"gzn",,"Gane",,,,,,0,"ltr",,"L"
2285,,,"haa",,"Han",,,,,,0,"ltr",,"L"
2286,,,"hab",,"Hanoi Sign Language",,,,,,0,"ltr",,"L"
2287,,,"hac",,"Gurani",,,,,,0,"ltr",,"L"
2288,,,"had",,"Hatam",,,,,,0,"ltr",,"L"
2289,,,"hae",,"Oromo",,"Eastern",,,,0,"ltr",,"L"
2290,,,"haf",,"Haiphong Sign Language",,,,,,0,"ltr",,"L"
2291,,,"hag",,"Hanga",,,,,,0,"ltr",,"L"
2292,,,"hah",,"Hahon",,,,,,0,"ltr",,"L"
2293,,"hai","hai",,"Haida",,,,,,1,"ltr",,"L"
2294,,,"haj",,"Hajong",,,,,,0,"ltr",,"L"
2295,,,"hak",,"Chinese",,"Hakka",,,,0,"ltr",,"L"
2296,,,"hal",,"Halang",,,,,,0,"ltr",,"L"
2297,,,"ham",,"Hewa",,,,,,0,"ltr",,"L"
2298,,,"han",,"Hangaza",,,,,,0,"ltr",,"L"
2299,,,"hao",,"Hakö",,,,,,0,"ltr",,"L"
2300,,,"hap",,"Hupla",,,,,,0,"ltr",,"L"
2301,,,"haq",,"Ha",,,,,,0,"ltr",,"L"
2302,,,"har",,"Harari",,,,,,0,"ltr",,"L"
2303,,,"has",,"Haisla",,,,,,0,"ltr",,"L"
2304,"ht","hat","hat",,"Haitian; Haitian Creole",,,,,,0,"ltr",,"L"
2305,"ha","hau","hau",,"Hausa",,,"Hausa",,,0,"ltr",,"L"
2306,,,"hav",,"Havu",,,,,,0,"ltr",,"L"
2307,,"haw","haw",,"Hawaiian",,,,,,0,"ltr",,"L"
2308,,,"hax",,"Haida",,"Southern",,,,0,"ltr",,"L"
2309,,,"hay",,"Haya",,,,,,0,"ltr",,"L"
2310,,,"haz",,"Hazaragi",,,,,,0,"ltr",,"L"
2311,,,"hba",,"Hamba",,,,,,0,"ltr",,"L"
2312,,,"hbb",,"Huba",,,,,,0,"ltr",,"L"
2313,,,"hbn",,"Heiban",,,,,,0,"ltr",,"L"
2314,,,"hbo",,"Hebrew",,"Ancient","עברית מקראית",,,0,"rtl",,"H"
2315,"sh",,"hbs",,"Serbo-Croatian",,,,,,1,"ltr",,"L"
2316,,,"hbu",,"Habu",,,,,,0,"ltr",,"L"
2317,,,"hca",,"Andaman Creole Hindi",,,,,,0,"ltr",,"L"
2318,,,"hch",,"Huichol",,,,,,0,"ltr",,"L"
2319,,,"hdn",,"Haida",,"Northern",,,,0,"ltr",,"L"
2320,,,"hds",,"Honduras Sign Language",,,,,,0,"ltr",,"L"
2321,,,"hdy",,"Hadiyya",,,,,,0,"ltr",,"L"
2322,,,"hea",,"Hmong",,"Northern Qiandong",,,,0,"ltr",,"L"
2323,"he","heb","heb",,"Hebrew",,,"עברית",,,0,"rtl","c == 1 ? 1 : 2","L"
2324,,,"hed",,"Herdé",,,,,,0,"ltr",,"L"
2325,,,"heg",,"Helong",,,,,,0,"ltr",,"L"
2326,,,"heh",,"Hehe",,,,,,0,"ltr",,"L"
2327,,,"hei",,"Heiltsuk",,,,,,0,"ltr",,"L"
2328,,,"hem",,"Hemba",,,,,,0,"ltr",,"L"
2329,"hz","her","her",,"Herero",,,,,,0,"ltr",,"L"
2330,,,"hgm",,"Hai//om",,,,,,0,"ltr",,"L"
2331,,,"hgw",,"Haigwai",,,,,,0,"ltr",,"L"
2332,,,"hhr",,"Kerak",,,,,,0,"ltr",,"L"
2333,,,"hia",,"Lamang",,,,,,0,"ltr",,"L"
2334,,,"hib",,"Hibito",,,,,,0,"ltr",,"E"
2335,,,"hid",,"Hidatsa",,,,,,0,"ltr",,"L"
2336,,,"hif",,"Hindustani",,"Fijian",,,,0,"ltr",,"L"
2337,,,"hig",,"Kamwe",,,,,,0,"ltr",,"L"
2338,,,"hih",,"Pamosu",,,,,,0,"ltr",,"L"
2339,,,"hii",,"Hinduri",,,,,,0,"ltr",,"L"
2340,,,"hij",,"Hijuk",,,,,,0,"ltr",,"L"
2341,,,"hik",,"Seit-Kaitetu",,,,,,0,"ltr",,"L"
2342,,"hil","hil",,"Hiligaynon",,,,,,0,"ltr",,"L"
2343,"hi","hin","hin",,"Hindi",,,"हिंदी",,,0,"ltr",,"L"
2344,,,"hio",,"Tsoa",,,,,,0,"ltr",,"L"
2345,,,"hir",,"Himarimã",,,,,,0,"ltr",,"L"
2346,,"hit","hit",,"Hittite",,,,,,0,"ltr",,"A"
2347,,,"hiw",,"Hiw",,,,,,0,"ltr",,"L"
2348,,,"hix",,"Hixkaryána",,,,,,0,"ltr",,"L"
2349,,,"hka",,"Kahe",,,,,,0,"ltr",,"L"
2350,,,"hke",,"Hunde",,,,,,0,"ltr",,"L"
2351,,,"hla",,"Halia",,,,,,0,"ltr",,"L"
2352,,,"hlb",,"Halbi",,,,,,0,"ltr",,"L"
2353,,,"hld",,"Halang Doan",,,,,,0,"ltr",,"L"
2354,,,"hlt",,"Nga La",,,,,,0,"ltr",,"L"
2355,,,"hlu",,"Luwian",,"Hieroglyphic",,,,0,"ltr",,"A"
2356,,,"hma",,"Hmong",,"Southern Mashan",,,,0,"ltr",,"L"
2357,,,"hmb",,"Songhay",,"Humburi Senni",,,,0,"ltr",,"L"
2358,,,"hmc",,"Hmong",,"Central Huishui",,,,0,"ltr",,"L"
2359,,,"hmd",,"Hmong",,"Northeastern Dian",,,,0,"ltr",,"L"
2360,,,"hme",,"Hmong",,"Eastern Huishui",,,,0,"ltr",,"L"
2361,,,"hmf",,"Hmong Don",,,,,,0,"ltr",,"L"
2362,,,"hmg",,"Hmong",,"Southwestern Guiyang",,,,0,"ltr",,"L"
2363,,,"hmh",,"Hmong",,"Southwestern Huishui",,,,0,"ltr",,"L"
2364,,,"hmi",,"Hmong",,"Northern Huishui",,,,0,"ltr",,"L"
2365,,,"hmj",,"Hmong",,"Chonganjiang",,,,0,"ltr",,"L"
2366,,,"hmk",,"Maek",,,,,,0,"ltr",,"E"
2367,,,"hml",,"Hmong",,"Luopohe",,,,0,"ltr",,"L"
2368,,,"hmm",,"Hmong",,"Central Mashan",,,,0,"ltr",,"L"
2369,,"hmn","hmn",,"Hmong",,,,,,1,"ltr",,"L"
2370,"ho","hmo","hmo",,"Hiri Motu",,,,,,0,"ltr",,"L"
2371,,,"hmp",,"Hmong",,"Northern Mashan",,,,0,"ltr",,"L"
2372,,,"hmq",,"Hmong",,"Eastern Qiandong",,,,0,"ltr",,"L"
2373,,,"hmr",,"Hmar",,,,,,0,"ltr",,"L"
2374,,,"hms",,"Hmong",,"Southern Qiandong",,,,0,"ltr",,"L"
2375,,,"hmt",,"Hamtai",,,,,,0,"ltr",,"L"
2376,,,"hmu",,"Hamap",,,,,,0,"ltr",,"L"
2377,,,"hmv",,"Hmong Dô",,,,,,0,"ltr",,"L"
2378,,,"hmw",,"Hmong",,"Western Mashan",,,,0,"ltr",,"L"
2379,,,"hmy",,"Hmong",,"Southern Guiyang",,,,0,"ltr",,"L"
2380,,,"hmz",,"Hmong Shua",,,,,,0,"ltr",,"L"
2381,,,"hna",,"Mina","Cameroon",,,,,0,"ltr",,"L"
2382,,,"hnd",,"Hindko",,"Southern",,,,0,"ltr",,"L"
2383,,,"hne",,"Chhattisgarhi",,,,,,0,"ltr",,"L"
2384,,,"hnh",,"//Ani",,,,,,0,"ltr",,"L"
2385,,,"hni",,"Hani",,,,,,0,"ltr",,"L"
2386,,,"hnn",,"Hanunoo",,,,,,0,"ltr",,"L"
2387,,,"hno",,"Hindko",,"Northern",,,,0,"ltr",,"L"
2388,,,"hns",,"Hindustani",,"Caribbean",,,,0,"ltr",,"L"
2389,,,"hnu",,"Hung",,,,,,0,"ltr",,"L"
2390,,,"hoa",,"Hoava",,,,,,0,"ltr",,"L"
2391,,,"hob",,"Mari","Madang Province",,,,,0,"ltr",,"L"
2392,,,"hoc",,"Ho",,,,,,0,"ltr",,"L"
2393,,,"hod",,"Holma",,,,,,0,"ltr",,"E"
2394,,,"hoe",,"Horom",,,,,,0,"ltr",,"L"
2395,,,"hoh",,"Hobyót",,,,,,0,"ltr",,"L"
2396,,,"hoi",,"Holikachuk",,,,,,0,"ltr",,"L"
2397,,,"hoj",,"Harauti",,,,,,0,"ltr",,"L"
2398,,,"hol",,"Holu",,,,,,0,"ltr",,"L"
2399,,,"hom",,"Homa",,,,,,0,"ltr",,"E"
2400,,,"hoo",,"Holoholo",,,,,,0,"ltr",,"L"
2401,,,"hop",,"Hopi",,,,,,0,"ltr",,"L"
2402,,,"hor",,"Horo",,,,,,0,"ltr",,"E"
2403,,,"hos",,"Ho Chi Minh City Sign Language",,,,,,0,"ltr",,"L"
2404,,,"hot",,"Hote",,,,,,0,"ltr",,"L"
2405,,,"hov",,"Hovongan",,,,,,0,"ltr",,"L"
2406,,,"how",,"Honi",,,,,,0,"ltr",,"L"
2407,,,"hoy",,"Holiya",,,,,,0,"ltr",,"L"
2408,,,"hoz",,"Hozo",,,,,,0,"ltr",,"L"
2409,,,"hpo",,"Hpon",,,,,,0,"ltr",,"L"
2410,,,"hps",,"Hawai'i Pidgin Sign Language",,,,,,0,"ltr",,"L"
2411,,,"hra",,"Hrangkhol",,,,,,0,"ltr",,"L"
2412,,,"hre",,"Hre",,,,,,0,"ltr",,"L"
2413,,,"hrk",,"Haruku",,,,,,0,"ltr",,"L"
2414,,,"hro",,"Haroi",,,,,,0,"ltr",,"L"
2415,,,"hrr",,"Horuru",,,,,,0,"ltr",,"L"
2416,,,"hrt",,"Hértevin",,,,,,0,"ltr",,"L"
2417,,,"hru",,"Hruso",,,,,,0,"ltr",,"L"
2418,"hr","hrv","hrv",,"Croatian",,,"Hrvatski",,,0,"ltr","c%10==1 && c%100!=11 ? 1 : c%10>=2 && c%10<=4 && (c%100<10 || c%100>=20) ? 2 : 3","L"
2419,,,"hrz",,"Harzani",,,,,,0,"ltr",,"L"
2420,,"hsb","hsb",,"Sorbian",,"Upper",,,,0,"ltr",,"L"
2421,,,"hsf",,"Huastec",,"Southeastern",,,,0,"ltr",,"L"
2422,,,"hsh",,"Hungarian Sign Language",,,,,,0,"ltr",,"L"
2423,,,"hsl",,"Hausa Sign Language",,,,,,0,"ltr",,"L"
2424,,,"hsn",,"Chinese",,"Xiang",,,,0,"ltr",,"L"
2425,,,"hss",,"Harsusi",,,,,,0,"ltr",,"L"
2426,,,"hti",,"Hoti",,,,,,0,"ltr",,"L"
2427,,,"hto",,"Huitoto",,"Minica",,,,0,"ltr",,"L"
2428,,,"hts",,"Hadza",,,,,,0,"ltr",,"L"
2429,,,"htu",,"Hitu",,,,,,0,"ltr",,"L"
2430,,,"htx",,"Hittite",,"Middle",,,,0,"ltr",,"A"
2431,,,"hub",,"Huambisa",,,,,,0,"ltr",,"L"
2432,,,"huc",,"=/Hua",,,,,,0,"ltr",,"L"
2433,,,"hud",,"Huaulu",,,,,,0,"ltr",,"L"
2434,,,"hue",,"Huave",,"San Francisco Del Mar",,,,0,"ltr",,"L"
2435,,,"huf",,"Humene",,,,,,0,"ltr",,"L"
2436,,,"hug",,"Huachipaeri",,,,,,0,"ltr",,"L"
2437,,,"huh",,"Huilliche",,,,,,0,"ltr",,"L"
2438,,,"hui",,"Huli",,,,,,0,"ltr",,"L"
2439,,,"huj",,"Hmong",,"Northern Guiyang",,,,0,"ltr",,"L"
2440,,,"huk",,"Hulung",,,,,,0,"ltr",,"L"
2441,,,"hul",,"Hula",,,,,,0,"ltr",,"L"
2442,,,"hum",,"Hungana",,,,,,0,"ltr",,"L"
2443,"hu","hun","hun",,"Hungarian",,,"Magyar",,,0,"ltr","c = 1","L"
2444,,,"huo",,"Hu",,,,,,0,"ltr",,"L"
2445,,"hup","hup",,"Hupa",,,,,,0,"ltr",,"L"
2446,,,"huq",,"Tsat",,,,,,0,"ltr",,"L"
2447,,,"hur",,"Halkomelem",,,,,,0,"ltr",,"L"
2448,,,"hus",,"Huastec",,"Veracruz",,,,0,"ltr",,"L"
2449,,,"hut",,"Humla",,,,,,0,"ltr",,"L"
2450,,,"huu",,"Huitoto",,"Murui",,,,0,"ltr",,"L"
2451,,,"huv",,"Huave",,"San Mateo Del Mar",,,,0,"ltr",,"L"
2452,,,"huw",,"Hukumina",,,,,,0,"ltr",,"L"
2453,,,"hux",,"Huitoto",,"Nüpode",,,,0,"ltr",,"L"
2454,,,"huy",,"Hulaulá",,,,,,0,"ltr",,"L"
2455,,,"huz",,"Hunzib",,,,,,0,"ltr",,"L"
2456,,,"hva",,"Huastec",,"San Luís Potosí",,,,0,"ltr",,"L"
2457,,,"hvc",,"Haitian Vodoun Culture Language",,,,,,0,"ltr",,"L"
2458,,,"hve",,"Huave",,"San Dionisio Del Mar",,,,0,"ltr",,"L"
2459,,,"hvk",,"Haveke",,,,,,0,"ltr",,"L"
2460,,,"hvn",,"Sabu",,,,,,0,"ltr",,"L"
2461,,,"hvv",,"Huave",,"Santa María Del Mar",,,,0,"ltr",,"L"
2462,,,"hwa",,"Wané",,,,,,0,"ltr",,"L"
2463,,,"hwc",,"Hawai'i Creole English",,,,,,0,"ltr",,"L"
2464,,,"hwo",,"Hwana",,,,,,0,"ltr",,"L"
2465,,,"hya",,"Hya",,,,,,0,"ltr",,"L"
2466,"hy","hye","hye",,"Armenian",,,"Հայերեն",,,0,"ltr",,"L"
2467,,,"iai",,"Iaai",,,,,,0,"ltr",,"L"
2468,,,"ian",,"Iatmul",,,,,,0,"ltr",,"L"
2469,,,"iap",,"Iapama",,,,,,0,"ltr",,"L"
2470,,,"iar",,"Purari",,,,,,0,"ltr",,"L"
2471,,"iba","iba",,"Iban",,,,,,0,"ltr",,"L"
2472,,,"ibb",,"Ibibio",,,,,,0,"ltr",,"L"
2473,,,"ibd",,"Iwaidja",,,,,,0,"ltr",,"L"
2474,,,"ibe",,"Akpes",,,,,,0,"ltr",,"L"
2475,,,"ibg",,"Ibanag",,,,,,0,"ltr",,"L"
2476,,,"ibi",,"Ibilo",,,,,,0,"ltr",,"L"
2477,,,"ibl",,"Ibaloi",,,,,,0,"ltr",,"L"
2478,,,"ibm",,"Agoi",,,,,,0,"ltr",,"L"
2479,,,"ibn",,"Ibino",,,,,,0,"ltr",,"L"
2480,"ig","ibo","ibo",,"Igbo",,,,,,0,"ltr",,"L"
2481,,,"ibr",,"Ibuoro",,,,,,0,"ltr",,"L"
2482,,,"ibu",,"Ibu",,,,,,0,"ltr",,"L"
2483,,,"iby",,"Ibani",,,,,,0,"ltr",,"L"
2484,,,"ica",,"Ede Ica",,,,,,0,"ltr",,"L"
2485,,,"ich",,"Etkywan",,,,,,0,"ltr",,"L"
2486,,,"icl",,"Icelandic Sign Language",,,,,,0,"ltr",,"L"
2487,,,"icr",,"Islander Creole English",,,,,,0,"ltr",,"L"
2488,,,"ida",,"Idakho-Isukha-Tiriki",,,,,,0,"ltr",,"L"
2489,,,"idb",,"Indo-Portuguese",,,,,,0,"ltr",,"L"
2490,,,"idc",,"Idon",,,,,,0,"ltr",,"L"
2491,,,"idd",,"Ede Idaca",,,,,,0,"ltr",,"L"
2492,,,"ide",,"Idere",,,,,,0,"ltr",,"L"
2493,,,"idi",,"Idi",,,,,,0,"ltr",,"L"
2494,"io","ido","ido",,"Ido",,,,,,0,"ltr",,"C"
2495,,,"idr",,"Indri",,,,,,0,"ltr",,"L"
2496,,,"ids",,"Idesa",,,,,,0,"ltr",,"L"
2497,,,"idt",,"Idaté",,,,,,0,"ltr",,"L"
2498,,,"idu",,"Idoma",,,,,,0,"ltr",,"L"
2499,,,"ifa",,"Ifugao",,"Amganad",,,,0,"ltr",,"L"
2500,,,"ifb",,"Ifugao",,"Batad",,,,0,"ltr",,"L"
2501,,,"ife",,"Ifè",,,,,,0,"ltr",,"L"
2502,,,"iff",,"Ifo",,,,,,0,"ltr",,"E"
2503,,,"ifk",,"Ifugao",,"Tuwali",,,,0,"ltr",,"L"
2504,,,"ifm",,"Teke-Fuumu",,,,,,0,"ltr",,"L"
2505,,,"ifu",,"Ifugao",,"Mayoyao",,,,0,"ltr",,"L"
2506,,,"ify",,"Kallahan",,"Keley-I",,,,0,"ltr",,"L"
2507,,,"igb",,"Ebira",,,,,,0,"ltr",,"L"
2508,,,"ige",,"Igede",,,,,,0,"ltr",,"L"
2509,,,"igg",,"Igana",,,,,,0,"ltr",,"L"
2510,,,"igl",,"Igala",,,,,,0,"ltr",,"L"
2511,,,"igm",,"Kanggape",,,,,,0,"ltr",,"L"
2512,,,"ign",,"Ignaciano",,,,,,0,"ltr",,"L"
2513,,,"igo",,"Isebe",,,,,,0,"ltr",,"L"
2514,,,"igs",,"Interglossa",,,,,,0,"ltr",,"C"
2515,,,"igw",,"Igwe",,,,,,0,"ltr",,"L"
2516,,,"ihb",,"Iha Based Pidgin",,,,,,0,"ltr",,"L"
2517,,,"ihi",,"Ihievbe",,,,,,0,"ltr",,"L"
2518,,,"ihp",,"Iha",,,,,,0,"ltr",,"L"
2519,"ii","iii","iii",,"Yi",,"Sichuan",,,,0,"ltr",,"L"
2520,,,"ijc",,"Izon",,,,,,0,"ltr",,"L"
2521,,,"ije",,"Biseni",,,,,,0,"ltr",,"L"
2522,,,"ijj",,"Ede Ije",,,,,,0,"ltr",,"L"
2523,,,"ijn",,"Kalabari",,,,,,0,"ltr",,"L"
2524,,,"ijs",,"Ijo",,"Southeast",,,,0,"ltr",,"L"
2525,,,"ike",,"Inuktitut",,"Eastern Canadian",,,,0,"ltr",,"L"
2526,,,"iki",,"Iko",,,,,,0,"ltr",,"L"
2527,,,"ikk",,"Ika",,,,,,0,"ltr",,"L"
2528,,,"ikl",,"Ikulu",,,,,,0,"ltr",,"L"
2529,,,"iko",,"Olulumo-Ikom",,,,,,0,"ltr",,"L"
2530,,,"ikp",,"Ikpeshi",,,,,,0,"ltr",,"L"
2531,,,"ikt",,"Inuktitut",,"Western Canadian",,,,0,"ltr",,"L"
2532,"iu","iku","iku",,"Inuktitut",,,,,,1,"ltr",,"L"
2533,,,"ikv",,"Iku-Gora-Ankwa",,,,,,0,"ltr",,"L"
2534,,,"ikw",,"Ikwere",,,,,,0,"ltr",,"L"
2535,,,"ikx",,"Ik",,,,,,0,"ltr",,"L"
2536,,,"ikz",,"Ikizu",,,,,,0,"ltr",,"L"
2537,,,"ila",,"Ile Ape",,,,,,0,"ltr",,"L"
2538,,,"ilb",,"Ila",,,,,,0,"ltr",,"L"
2539,"ie","ile","ile",,"Interlingue",,,,,,0,"ltr",,"C"
2540,,,"ilg",,"Garig-Ilgar",,,,,,0,"ltr",,"L"
2541,,,"ili",,"Ili Turki",,,,,,0,"ltr",,"L"
2542,,,"ilk",,"Ilongot",,,,,,0,"ltr",,"L"
2543,,,"ill",,"Iranun",,,,,,0,"ltr",,"L"
2544,,"ilo","ilo",,"Iloko",,,,,,0,"ltr",,"L"
2545,,,"ilu",,"Ili'uun",,,,,,0,"ltr",,"L"
2546,,,"ilv",,"Ilue",,,,,,0,"ltr",,"L"
2547,,,"ilw",,"Talur",,,,,,0,"ltr",,"L"
2548,,,"ime",,"Imeraguen",,,,,,0,"ltr",,"L"
2549,,,"imi",,"Anamgura",,,,,,0,"ltr",,"L"
2550,,,"iml",,"Miluk",,,,,,0,"ltr",,"E"
2551,,,"imn",,"Imonda",,,,,,0,"ltr",,"L"
2552,,,"imo",,"Imbongu",,,,,,0,"ltr",,"L"
2553,,,"imr",,"Imroing",,,,,,0,"ltr",,"L"
2554,,,"ims",,"Marsian",,,,,,0,"ltr",,"A"
2555,,,"imy",,"Milyan",,,,,,0,"ltr",,"A"
2556,"ia","ina","ina",,"Interlingua","International Auxiliary Language Association",,,,,0,"ltr",,"C"
2557,,,"inb",,"Inga",,,,,,0,"ltr",,"L"
2558,"id","ind","ind",,"Indonesian",,,"Bahasa indonesia",,,0,"ltr",,"L"
2559,,,"ing",,"Degexit'an",,,,,,0,"ltr",,"L"
2560,,"inh","inh",,"Ingush",,,,,,0,"ltr",,"L"
2561,,,"inj",,"Inga",,"Jungle",,,,0,"ltr",,"L"
2562,,,"inl",,"Indonesian Sign Language",,,,,,0,"ltr",,"L"
2563,,,"inm",,"Minaean",,,,,,0,"ltr",,"A"
2564,,,"inn",,"Isinai",,,,,,0,"ltr",,"L"
2565,,,"ino",,"Inoke-Yate",,,,,,0,"ltr",,"L"
2566,,,"inp",,"Iñapari",,,,,,0,"ltr",,"L"
2567,,,"ins",,"Indian Sign Language",,,,,,0,"ltr",,"L"
2568,,,"int",,"Intha",,,,,,0,"ltr",,"L"
2569,,,"inz",,"Ineseño",,,,,,0,"ltr",,"E"
2570,,,"ior",,"Inor",,,,,,0,"ltr",,"L"
2571,,,"iou",,"Tuma-Irumu",,,,,,0,"ltr",,"L"
2572,,,"iow",,"Iowa-Oto",,,,,,0,"ltr",,"E"
2573,,,"ipi",,"Ipili",,,,,,0,"ltr",,"L"
2574,"ik","ipk","ipk",,"Inupiaq",,,,,,1,"ltr",,"L"
2575,,,"ipo",,"Ipiko",,,,,,0,"ltr",,"L"
2576,,,"iqu",,"Iquito",,,,,,0,"ltr",,"L"
2577,,,"ire",,"Iresim",,,,,,0,"ltr",,"L"
2578,,,"irh",,"Irarutu",,,,,,0,"ltr",,"L"
2579,,,"iri",,"Irigwe",,,,,,0,"ltr",,"L"
2580,,,"irk",,"Iraqw",,,,,,0,"ltr",,"L"
2581,,,"irn",,"Irántxe",,,,,,0,"ltr",,"L"
2582,,,"irr",,"Ir",,,,,,0,"ltr",,"L"
2583,,,"iru",,"Irula",,,,,,0,"ltr",,"L"
2584,,,"irx",,"Kamberau",,,,,,0,"ltr",,"L"
2585,,,"iry",,"Iraya",,,,,,0,"ltr",,"L"
2586,,,"isa",,"Isabi",,,,,,0,"ltr",,"L"
2587,,,"isc",,"Isconahua",,,,,,0,"ltr",,"L"
2588,,,"isd",,"Isnag",,,,,,0,"ltr",,"L"
2589,,,"ise",,"Italian Sign Language",,,,,,0,"ltr",,"L"
2590,,,"isg",,"Irish Sign Language",,,,,,0,"ltr",,"L"
2591,,,"ish",,"Esan",,,,,,0,"ltr",,"L"
2592,,,"isi",,"Nkem-Nkum",,,,,,0,"ltr",,"L"
2593,"is","isl","isl",,"Icelandic",,,"Íslenska",,,0,"ltr",,"L"
2594,,,"ism",,"Masimasi",,,,,,0,"ltr",,"L"
2595,,,"isn",,"Isanzu",,,,,,0,"ltr",,"L"
2596,,,"iso",,"Isoko",,,,,,0,"ltr",,"L"
2597,,,"isr",,"Israeli Sign Language",,,,,,0,"ltr",,"L"
2598,,,"ist",,"Istriot",,,,,,0,"ltr",,"L"
2599,,,"isu",,"Isu","Menchum Division",,,,,0,"ltr",,"L"
2600,"it","ita","ita",,"Italian",,,"italiano",,,0,"ltr","c == 1 ? 1 : 2","L"
2601,,,"itb",,"Itneg",,"Binongan",,,,0,"ltr",,"L"
2602,,,"ite",,"Itene",,,,,,0,"ltr",,"E"
2603,,,"iti",,"Itneg",,"Inlaod",,,,0,"ltr",,"L"
2604,,,"itk",,"Judeo-Italian",,,,,,0,"ltr",,"L"
2605,,,"itl",,"Itelmen",,,,,,0,"ltr",,"L"
2606,,,"itm",,"Itu Mbon Uzo",,,,,,0,"ltr",,"L"
2607,,,"ito",,"Itonama",,,,,,0,"ltr",,"L"
2608,,,"itr",,"Iteri",,,,,,0,"ltr",,"L"
2609,,,"its",,"Isekiri",,,,,,0,"ltr",,"L"
2610,,,"itt",,"Itneg",,"Maeng",,,,0,"ltr",,"L"
2611,,,"itu",,"Itutang",,,,,,0,"ltr",,"L"
2612,,,"itv",,"Itawit",,,,,,0,"ltr",,"L"
2613,,,"itw",,"Ito",,,,,,0,"ltr",,"L"
2614,,,"itx",,"Itik",,,,,,0,"ltr",,"L"
2615,,,"ity",,"Itneg",,"Moyadan",,,,0,"ltr",,"L"
2616,,,"itz",,"Itzá",,,,,,0,"ltr",,"L"
2617,,,"ium",,"Iu Mien",,,,,,0,"ltr",,"L"
2618,,,"ivb",,"Ibatan",,,,,,0,"ltr",,"L"
2619,,,"ivv",,"Ivatan",,,,,,0,"ltr",,"L"
2620,,,"iwk",,"I-Wak",,,,,,0,"ltr",,"L"
2621,,,"iwm",,"Iwam",,,,,,0,"ltr",,"L"
2622,,,"iwo",,"Iwur",,,,,,0,"ltr",,"L"
2623,,,"iws",,"Iwam",,"Sepik",,,,0,"ltr",,"L"
2624,,,"ixc",,"Ixcatec",,,,,,0,"ltr",,"L"
2625,,,"ixi",,"Ixil",,"Nebaj",,,,0,"ltr",,"L"
2626,,,"ixj",,"Ixil",,"Chajul",,,,0,"ltr",,"L"
2627,,,"ixl",,"Ixil",,"San Juan Cotzal",,,,0,"ltr",,"L"
2628,,,"iya",,"Iyayu",,,,,,0,"ltr",,"L"
2629,,,"iyo",,"Mesaka",,,,,,0,"ltr",,"L"
2630,,,"iyx",,"Yaka","Congo",,,,,0,"ltr",,"L"
2631,,,"izh",,"Ingrian",,,,,,0,"ltr",,"L"
2632,,,"izi",,"Izi-Ezaa-Ikwo-Mgbo",,,,,,0,"ltr",,"L"
2633,,,"jaa",,"Jamamadí",,,,,,0,"ltr",,"L"
2634,,,"jab",,"Hyam",,,,,,0,"ltr",,"L"
2635,,,"jac",,"Jacalteco",,"Eastern",,,,0,"ltr",,"L"
2636,,,"jad",,"Jahanka",,,,,,0,"ltr",,"L"
2637,,,"jae",,"Yabem",,,,,,0,"ltr",,"L"
2638,,,"jaf",,"Jara",,,,,,0,"ltr",,"L"
2639,,,"jah",,"Jah Hut",,,,,,0,"ltr",,"L"
2640,,,"jai",,"Jacalteco",,"Western",,,,0,"ltr",,"L"
2641,,,"jaj",,"Zazao",,,,,,0,"ltr",,"L"
2642,,,"jak",,"Jakun",,,,,,0,"ltr",,"L"
2643,,,"jal",,"Yalahatan",,,,,,0,"ltr",,"L"
2644,,,"jam",,"Jamaican Creole English",,,,,,0,"ltr",,"L"
2645,,,"jao",,"Yanyuwa",,,,,,0,"ltr",,"L"
2646,,,"jap",,"Jaruára",,,,,,0,"ltr",,"L"
2647,,,"jaq",,"Yaqay",,,,,,0,"ltr",,"L"
2648,,,"jar",,"Jarawa","Nigeria",,,,,0,"ltr",,"L"
2649,,,"jas",,"Javanese",,"New Caledonian",,,,0,"ltr",,"L"
2650,,,"jat",,"Jakati",,,,,,0,"ltr",,"L"
2651,,,"jau",,"Yaur",,,,,,0,"ltr",,"L"
2652,"jv","jav","jav",,"Javanese",,,,,,0,"ltr",,"L"
2653,,,"jax",,"Malay",,"Jambi",,,,0,"ltr",,"L"
2654,,,"jay",,"Jarnango",,,,,,0,"ltr",,"L"
2655,,,"jaz",,"Jawe",,,,,,0,"ltr",,"L"
2656,,,"jbe",,"Judeo-Berber",,,,,,0,"ltr",,"L"
2657,,,"jbj",,"Arandai",,,,,,0,"ltr",,"L"
2658,,,"jbn",,"Nafusi",,,,,,0,"ltr",,"L"
2659,,"jbo","jbo",,"Lojban",,,,,,0,"ltr",,"C"
2660,,,"jbt",,"Jabutí",,,,,,0,"ltr",,"L"
2661,,,"jbu",,"Jukun Takum",,,,,,0,"ltr",,"L"
2662,,,"jcs",,"Jamaican Country Sign Language",,,,,,0,"ltr",,"L"
2663,,,"jct",,"Judeo-Crimean Tatar",,,,,,0,"ltr",,"L"
2664,,,"jda",,"Jad",,,,,,0,"ltr",,"L"
2665,,,"jdg",,"Jadgali",,,,,,0,"ltr",,"L"
2666,,,"jdt",,"Judeo-Tat",,,,,,0,"ltr",,"L"
2667,,,"jeb",,"Jebero",,,,,,0,"ltr",,"L"
2668,,,"jee",,"Jerung",,,,,,0,"ltr",,"L"
2669,,,"jeg",,"Jeng",,,,,,0,"ltr",,"L"
2670,,,"jeh",,"Jeh",,,,,,0,"ltr",,"L"
2671,,,"jei",,"Yei",,,,,,0,"ltr",,"L"
2672,,,"jek",,"Jeri Kuo",,,,,,0,"ltr",,"L"
2673,,,"jel",,"Yelmek",,,,,,0,"ltr",,"L"
2674,,,"jen",,"Dza",,,,,,0,"ltr",,"L"
2675,,,"jer",,"Jere",,,,,,0,"ltr",,"L"
2676,,,"jet",,"Manem",,,,,,0,"ltr",,"L"
2677,,,"jeu",,"Jonkor Bourmataguil",,,,,,0,"ltr",,"L"
2678,,,"jgb",,"Ngbee",,,,,,0,"ltr",,"E"
2679,,,"jge",,"Judeo-Georgian",,,,,,0,"ltr",,"L"
2680,,,"jgo",,"Ngomba",,,,,,0,"ltr",,"L"
2681,,,"jhi",,"Jehai",,,,,,0,"ltr",,"L"
2682,,,"jia",,"Jina",,,,,,0,"ltr",,"L"
2683,,,"jib",,"Jibu",,,,,,0,"ltr",,"L"
2684,,,"jic",,"Tol",,,,,,0,"ltr",,"L"
2685,,,"jid",,"Bu",,,,,,0,"ltr",,"L"
2686,,,"jie",,"Jilbe",,,,,,0,"ltr",,"L"
2687,,,"jig",,"Djingili",,,,,,0,"ltr",,"L"
2688,,,"jih",,"Shangzhai",,,,,,0,"ltr",,"L"
2689,,,"jii",,"Jiiddu",,,,,,0,"ltr",,"L"
2690,,,"jil",,"Jilim",,,,,,0,"ltr",,"L"
2691,,,"jim",,"Jimi","Cameroon",,,,,0,"ltr",,"L"
2692,,,"jio",,"Jiamao",,,,,,0,"ltr",,"L"
2693,,,"jiq",,"Guanyinqiao",,,,,,0,"ltr",,"L"
2694,,,"jit",,"Jita",,,,,,0,"ltr",,"L"
2695,,,"jiu",,"Jinuo",,"Youle",,,,0,"ltr",,"L"
2696,,,"jiv",,"Shuar",,,,,,0,"ltr",,"L"
2697,,,"jiy",,"Jinuo",,"Buyuan",,,,0,"ltr",,"L"
2698,,,"jkl",,"Jakelimotu",,,,,,0,"ltr",,"C"
2699,,,"jko",,"Kubo",,,,,,0,"ltr",,"L"
2700,,,"jku",,"Labir",,,,,,0,"ltr",,"L"
2701,,,"jle",,"Ngile",,,,,,0,"ltr",,"L"
2702,,,"jma",,"Dima",,,,,,0,"ltr",,"L"
2703,,,"jmb",,"Zumbun",,,,,,0,"ltr",,"L"
2704,,,"jmc",,"Machame",,,,,,0,"ltr",,"L"
2705,,,"jmd",,"Yamdena",,,,,,0,"ltr",,"L"
2706,,,"jmi",,"Jimi","Nigeria",,,,,0,"ltr",,"L"
2707,,,"jml",,"Jumli",,,,,,0,"ltr",,"L"
2708,,,"jmr",,"Kamara",,,,,,0,"ltr",,"L"
2709,,,"jms",,"Mashi","Nigeria",,,,,0,"ltr",,"L"
2710,,,"jmx",,"Mixtec",,"Western Juxtlahuaca",,,,0,"ltr",,"L"
2711,,,"jna",,"Jangshung",,,,,,0,"ltr",,"L"
2712,,,"jnd",,"Jandavra",,,,,,0,"ltr",,"L"
2713,,,"jng",,"Yangman",,,,,,0,"ltr",,"E"
2714,,,"jni",,"Janji",,,,,,0,"ltr",,"L"
2715,,,"jnj",,"Yemsa",,,,,,0,"ltr",,"L"
2716,,,"jnl",,"Rawat",,,,,,0,"ltr",,"L"
2717,,,"jns",,"Jaunsari",,,,,,0,"ltr",,"L"
2718,,,"job",,"Joba",,,,,,0,"ltr",,"L"
2719,,,"jod",,"Wojenaka",,,,,,0,"ltr",,"L"
2720,,,"jor",,"Jorá",,,,,,0,"ltr",,"E"
2721,,,"jos",,"Jordanian Sign Language",,,,,,0,"ltr",,"L"
2722,,,"jow",,"Jowulu",,,,,,0,"ltr",,"L"
2723,"ja","jpn","jpn",,"Japanese",,,"日本語",,,0,"ltr","c = 1","L"
2724,,"jpr","jpr",,"Judeo-Persian",,,,,,0,"ltr",,"L"
2725,,,"jqr",,"Jaqaru",,,,,,0,"ltr",,"L"
2726,,,"jra",,"Jarai",,,,,,0,"ltr",,"L"
2727,,"jrb","jrb",,"Judeo-Arabic",,,,,,1,"rtl",,"L"
2728,,,"jrr",,"Jiru",,,,,,0,"ltr",,"L"
2729,,,"jrt",,"Jorto",,,,,,0,"ltr",,"L"
2730,,,"jru",,"Japrería",,,,,,0,"ltr",,"L"
2731,,,"jsl",,"Japanese Sign Language",,,,,,0,"ltr",,"L"
2732,,,"jua",,"Júma",,,,,,0,"ltr",,"L"
2733,,,"jub",,"Wannu",,,,,,0,"ltr",,"L"
2734,,,"juc",,"Jurchen",,,,,,0,"ltr",,"E"
2735,,,"jud",,"Worodougou",,,,,,0,"ltr",,"L"
2736,,,"juh",,"Hõne",,,,,,0,"ltr",,"L"
2737,,,"juk",,"Wapan",,,,,,0,"ltr",,"L"
2738,,,"jul",,"Jirel",,,,,,0,"ltr",,"L"
2739,,,"jum",,"Jumjum",,,,,,0,"ltr",,"L"
2740,,,"jun",,"Juang",,,,,,0,"ltr",,"L"
2741,,,"juo",,"Jiba",,,,,,0,"ltr",,"L"
2742,,,"jup",,"Hupdë",,,,,,0,"ltr",,"L"
2743,,,"jur",,"Jurúna",,,,,,0,"ltr",,"L"
2744,,,"jut",,"Jutish",,,,,,0,"ltr",,"L"
2745,,,"juu",,"Ju",,,,,,0,"ltr",,"L"
2746,,,"juw",,"Wãpha",,,,,,0,"ltr",,"L"
2747,,,"juy",,"Juray",,,,,,0,"ltr",,"L"
2748,,,"jvn",,"Javanese",,"Caribbean",,,,0,"ltr",,"L"
2749,,,"jwi",,"Jwira-Pepesa",,,,,,0,"ltr",,"L"
2750,,,"jya",,"Jiarong",,,,,,0,"ltr",,"L"
2751,,,"jye",,"Arabic",,"Judeo-Yemeni",,,,0,"rtl",,"L"
2752,,,"jyy",,"Jaya",,,,,,0,"ltr",,"L"
2753,,"kaa","kaa",,"Kara-Kalpak",,,,,,0,"ltr",,"L"
2754,,"kab","kab",,"Kabyle",,,,,,0,"ltr",,"L"
2755,,"kac","kac",,"Kachin",,,,,,0,"ltr",,"L"
2756,,,"kad",,"Kadara",,,,,,0,"ltr",,"L"
2757,,,"kae",,"Ketangalan",,,,,,0,"ltr",,"E"
2758,,,"kag",,"Kajaman",,,,,,0,"ltr",,"L"
2759,,,"kah",,"Kara","Central African Republic",,,,,0,"ltr",,"L"
2760,,,"kai",,"Karekare",,,,,,0,"ltr",,"L"
2761,,,"kaj",,"Jju",,,,,,0,"ltr",,"L"
2762,,,"kak",,"Kallahan",,"Kayapa",,,,0,"ltr",,"L"
2763,"kl","kal","kal",,"Kalaallisut",,,,,,0,"ltr",,"L"
2764,,"kam","kam",,"Kamba","Kenya",,,,,0,"ltr",,"L"
2765,"kn","kan","kan",,"Kannada",,,"ಕನ್ನಡ",,,0,"ltr",,"L"
2766,,,"kao",,"Xaasongaxango",,,,,,0,"ltr",,"L"
2767,,,"kap",,"Bezhta",,,,,,0,"ltr",,"L"
2768,,,"kaq",,"Capanahua",,,,,,0,"ltr",,"L"
2769,"ks","kas","kas",,"Kashmiri",,,,,,0,"ltr",,"L"
2770,"ka","kat","kat",,"Georgian",,,,,,0,"ltr",,"L"
2771,"kr","kau","kau",,"Kanuri",,,,,,1,"ltr",,"L"
2772,,,"kav",,"Katukína",,,,,,0,"ltr",,"L"
2773,,"kaw","kaw",,"Kawi",,,,,,0,"ltr",,"A"
2774,,,"kax",,"Kao",,,,,,0,"ltr",,"L"
2775,,,"kay",,"Kamayurá",,,,,,0,"ltr",,"L"
2776,"kk","kaz","kaz",,"Kazakh",,,"Қазақ",,,0,"ltr",,"L"
2777,,,"kba",,"Kalarko",,,,,,0,"ltr",,"E"
2778,,,"kbb",,"Kaxuiâna",,,,,,0,"ltr",,"L"
2779,,,"kbc",,"Kadiwéu",,,,,,0,"ltr",,"L"
2780,,"kbd","kbd",,"Kabardian",,,,,,0,"ltr",,"L"
2781,,,"kbe",,"Kanju",,,,,,0,"ltr",,"L"
2782,,,"kbf",,"Kakauhua",,,,,,0,"ltr",,"E"
2783,,,"kbg",,"Khamba",,,,,,0,"ltr",,"L"
2784,,,"kbh",,"Camsá",,,,,,0,"ltr",,"L"
2785,,,"kbj",,"Kari",,,,,,0,"ltr",,"L"
2786,,,"kbk",,"Koiari",,"Grass",,,,0,"ltr",,"L"
2787,,,"kbl",,"Kanembu",,,,,,0,"ltr",,"L"
2788,,,"kbm",,"Iwal",,,,,,0,"ltr",,"L"
2789,,,"kbn",,"Kare","Central African Republic",,,,,0,"ltr",,"L"
2790,,,"kbo",,"Keliko",,,,,,0,"ltr",,"L"
2791,,,"kbp",,"Kabiyé",,,,,,0,"ltr",,"L"
2792,,,"kbq",,"Kamano",,,,,,0,"ltr",,"L"
2793,,,"kbr",,"Kafa",,,,,,0,"ltr",,"L"
2794,,,"kbs",,"Kande",,,,,,0,"ltr",,"L"
2795,,,"kbt",,"Abadi",,,,,,0,"ltr",,"L"
2796,,,"kbu",,"Kabutra",,,,,,0,"ltr",,"L"
2797,,,"kbv",,"Dera","Indonesia",,,,,0,"ltr",,"L"
2798,,,"kbw",,"Kaiep",,,,,,0,"ltr",,"L"
2799,,,"kbx",,"Ap Ma",,,,,,0,"ltr",,"L"
2800,,,"kby",,"Kanuri",,"Manga",,,,0,"ltr",,"L"
2801,,,"kbz",,"Duhwa",,,,,,0,"ltr",,"L"
2802,,,"kca",,"Khanty",,,,,,0,"ltr",,"L"
2803,,,"kcb",,"Kawacha",,,,,,0,"ltr",,"L"
2804,,,"kcc",,"Lubila",,,,,,0,"ltr",,"L"
2805,,,"kcd",,"Kanum",,"Ngkâlmpw",,,,0,"ltr",,"L"
2806,,,"kce",,"Kaivi",,,,,,0,"ltr",,"L"
2807,,,"kcf",,"Ukaan",,,,,,0,"ltr",,"L"
2808,,,"kcg",,"Tyap",,,,,,0,"ltr",,"L"
2809,,,"kch",,"Vono",,,,,,0,"ltr",,"L"
2810,,,"kci",,"Kamantan",,,,,,0,"ltr",,"L"
2811,,,"kcj",,"Kobiana",,,,,,0,"ltr",,"L"
2812,,,"kck",,"Kalanga",,,,,,0,"ltr",,"L"
2813,,,"kcl",,"Kela","Papua New Guinea",,,,,0,"ltr",,"L"
2814,,,"kcm",,"Gula","Central African Republic",,,,,0,"ltr",,"L"
2815,,,"kcn",,"Nubi",,,,,,0,"ltr",,"L"
2816,,,"kco",,"Kinalakna",,,,,,0,"ltr",,"L"
2817,,,"kcp",,"Kanga",,,,,,0,"ltr",,"L"
2818,,,"kcq",,"Kamo",,,,,,0,"ltr",,"L"
2819,,,"kcr",,"Katla",,,,,,0,"ltr",,"L"
2820,,,"kcs",,"Koenoem",,,,,,0,"ltr",,"L"
2821,,,"kct",,"Kaian",,,,,,0,"ltr",,"L"
2822,,,"kcu",,"Kami","Tanzania",,,,,0,"ltr",,"L"
2823,,,"kcv",,"Kete",,,,,,0,"ltr",,"L"
2824,,,"kcw",,"Kabwari",,,,,,0,"ltr",,"L"
2825,,,"kcx",,"Kachama-Ganjule",,,,,,0,"ltr",,"L"
2826,,,"kcy",,"Korandje",,,,,,0,"ltr",,"L"
2827,,,"kcz",,"Konongo",,,,,,0,"ltr",,"L"
2828,,,"kda",,"Worimi",,,,,,0,"ltr",,"E"
2829,,,"kdc",,"Kutu",,,,,,0,"ltr",,"L"
2830,,,"kdd",,"Yankunytjatjara",,,,,,0,"ltr",,"L"
2831,,,"kde",,"Makonde",,,,,,0,"ltr",,"L"
2832,,,"kdf",,"Mamusi",,,,,,0,"ltr",,"L"
2833,,,"kdg",,"Seba",,,,,,0,"ltr",,"L"
2834,,,"kdh",,"Tem",,,,,,0,"ltr",,"L"
2835,,,"kdi",,"Kumam",,,,,,0,"ltr",,"L"
2836,,,"kdj",,"Karamojong",,,,,,0,"ltr",,"L"
2837,,,"kdk",,"Numee",,,,,,0,"ltr",,"L"
2838,,,"kdl",,"Tsikimba",,,,,,0,"ltr",,"L"
2839,,,"kdm",,"Kagoma",,,,,,0,"ltr",,"L"
2840,,,"kdn",,"Kunda",,,,,,0,"ltr",,"L"
2841,,,"kdp",,"Kaningdon-Nindem",,,,,,0,"ltr",,"L"
2842,,,"kdq",,"Koch",,,,,,0,"ltr",,"L"
2843,,,"kdr",,"Karaim",,,,,,0,"ltr",,"L"
2844,,,"kds",,"Lahu Shi",,,,,,0,"ltr",,"L"
2845,,,"kdt",,"Kuy",,,,,,0,"ltr",,"L"
2846,,,"kdu",,"Kadaru",,,,,,0,"ltr",,"L"
2847,,,"kdv",,"Kado",,,,,,0,"ltr",,"L"
2848,,,"kdw",,"Koneraw",,,,,,0,"ltr",,"L"
2849,,,"kdx",,"Kam",,,,,,0,"ltr",,"L"
2850,,,"kdy",,"Keder",,,,,,0,"ltr",,"L"
2851,,,"kdz",,"Kwaja",,,,,,0,"ltr",,"L"
2852,,,"kea",,"Kabuverdianu",,,,,,0,"ltr",,"L"
2853,,,"keb",,"Kélé",,,,,,0,"ltr",,"L"
2854,,,"kec",,"Keiga",,,,,,0,"ltr",,"L"
2855,,,"ked",,"Kerewe",,,,,,0,"ltr",,"L"
2856,,,"kee",,"Keres",,"Eastern",,,,0,"ltr",,"L"
2857,,,"kef",,"Kpessi",,,,,,0,"ltr",,"L"
2858,,,"keg",,"Tese",,,,,,0,"ltr",,"L"
2859,,,"kei",,"Kei",,,,,,0,"ltr",,"L"
2860,,,"kej",,"Kadar",,,,,,0,"ltr",,"L"
2861,,,"kek",,"Kekchí",,,,,,0,"ltr",,"L"
2862,,,"kel",,"Kela","Democratic Republic of Congo",,,,,0,"ltr",,"L"
2863,,,"kem",,"Kemak",,,,,,0,"ltr",,"L"
2864,,,"ken",,"Kenyang",,,,,,0,"ltr",,"L"
2865,,,"keo",,"Kakwa",,,,,,0,"ltr",,"L"
2866,,,"kep",,"Kaikadi",,,,,,0,"ltr",,"L"
2867,,,"keq",,"Kamar",,,,,,0,"ltr",,"L"
2868,,,"ker",,"Kera",,,,,,0,"ltr",,"L"
2869,,,"kes",,"Kugbo",,,,,,0,"ltr",,"L"
2870,,,"ket",,"Ket",,,,,,0,"ltr",,"L"
2871,,,"keu",,"Akebu",,,,,,0,"ltr",,"L"
2872,,,"kev",,"Kanikkaran",,,,,,0,"ltr",,"L"
2873,,,"kew",,"Kewa",,"West",,,,0,"ltr",,"L"
2874,,,"kex",,"Kukna",,,,,,0,"ltr",,"L"
2875,,,"key",,"Kupia",,,,,,0,"ltr",,"L"
2876,,,"kez",,"Kukele",,,,,,0,"ltr",,"L"
2877,,,"kfa",,"Kodagu",,,,,,0,"ltr",,"L"
2878,,,"kfb",,"Kolami",,"Northwestern",,,,0,"ltr",,"L"
2879,,,"kfc",,"Konda-Dora",,,,,,0,"ltr",,"L"
2880,,,"kfd",,"Koraga",,"Korra",,,,0,"ltr",,"L"
2881,,,"kfe",,"Kota","India",,,,,0,"ltr",,"L"
2882,,,"kff",,"Koya",,,,,,0,"ltr",,"L"
2883,,,"kfg",,"Kudiya",,,,,,0,"ltr",,"L"
2884,,,"kfh",,"Kurichiya",,,,,,0,"ltr",,"L"
2885,,,"kfi",,"Kurumba",,,,,,0,"ltr",,"L"
2886,,,"kfj",,"Kemiehua",,,,,,0,"ltr",,"L"
2887,,,"kfk",,"Kinnauri",,,,,,0,"ltr",,"L"
2888,,,"kfl",,"Kung",,,,,,0,"ltr",,"L"
2889,,,"kfm",,"Khunsari",,,,,,0,"ltr",,"L"
2890,,,"kfn",,"Kuk",,,,,,0,"ltr",,"L"
2891,,,"kfo",,"Koro","Côte d'Ivoire",,,,,0,"ltr",,"L"
2892,,,"kfp",,"Korwa",,,,,,0,"ltr",,"L"
2893,,,"kfq",,"Korku",,,,,,0,"ltr",,"L"
2894,,,"kfr",,"Kachchi",,,,,,0,"ltr",,"L"
2895,,,"kfs",,"Bilaspuri",,,,,,0,"ltr",,"L"
2896,,,"kft",,"Kanjari",,,,,,0,"ltr",,"L"
2897,,,"kfu",,"Katkari",,,,,,0,"ltr",,"L"
2898,,,"kfv",,"Kurmukar",,,,,,0,"ltr",,"L"
2899,,,"kfw",,"Naga",,"Kharam",,,,0,"ltr",,"L"
2900,,,"kfx",,"Pahari",,"Kullu",,,,0,"ltr",,"L"
2901,,,"kfy",,"Kumauni",,,,,,0,"ltr",,"L"
2902,,,"kfz",,"Koromfé",,,,,,0,"ltr",,"L"
2903,,,"kga",,"Koyaga",,,,,,0,"ltr",,"L"
2904,,,"kgb",,"Kawe",,,,,,0,"ltr",,"L"
2905,,,"kgc",,"Kasseng",,,,,,0,"ltr",,"L"
2906,,,"kgd",,"Kataang",,,,,,0,"ltr",,"L"
2907,,,"kge",,"Komering",,,,,,0,"ltr",,"L"
2908,,,"kgf",,"Kube",,,,,,0,"ltr",,"L"
2909,,,"kgg",,"Kusunda",,,,,,0,"ltr",,"E"
2910,,,"kgh",,"Kalinga",,"Upper Tanudan",,,,0,"ltr",,"L"
2911,,,"kgi",,"Selangor Sign Language",,,,,,0,"ltr",,"L"
2912,,,"kgj",,"Kham",,"Gamale",,,,0,"ltr",,"L"
2913,,,"kgk",,"Kaiwá",,,,,,0,"ltr",,"L"
2914,,,"kgl",,"Kunggari",,,,,,0,"ltr",,"L"
2915,,,"kgm",,"Karipúna",,,,,,0,"ltr",,"E"
2916,,,"kgn",,"Karingani",,,,,,0,"ltr",,"L"
2917,,,"kgo",,"Krongo",,,,,,0,"ltr",,"L"
2918,,,"kgp",,"Kaingáng",,,,,,0,"ltr",,"L"
2919,,,"kgq",,"Kamoro",,,,,,0,"ltr",,"L"
2920,,,"kgr",,"Abun",,,,,,0,"ltr",,"L"
2921,,,"kgs",,"Kumbainggar",,,,,,0,"ltr",,"L"
2922,,,"kgt",,"Somyev",,,,,,0,"ltr",,"L"
2923,,,"kgu",,"Kobol",,,,,,0,"ltr",,"L"
2924,,,"kgv",,"Karas",,,,,,0,"ltr",,"L"
2925,,,"kgw",,"Karon Dori",,,,,,0,"ltr",,"L"
2926,,,"kgx",,"Kamaru",,,,,,0,"ltr",,"L"
2927,,,"kgy",,"Kyerung",,,,,,0,"ltr",,"L"
2928,,"kha","kha",,"Khasi",,,,,,0,"ltr",,"L"
2929,,,"khb",,"Lü",,,,,,0,"ltr",,"L"
2930,,,"khc",,"Tukang Besi North",,,,,,0,"ltr",,"L"
2931,,,"khd",,"Kanum",,"Bädi",,,,0,"ltr",,"L"
2932,,,"khe",,"Korowai",,,,,,0,"ltr",,"L"
2933,,,"khf",,"Khuen",,,,,,0,"ltr",,"L"
2934,,,"khg",,"Tibetan",,"Khams",,,,0,"ltr",,"L"
2935,,,"khh",,"Kehu",,,,,,0,"ltr",,"L"
2936,,,"khj",,"Kuturmi",,,,,,0,"ltr",,"L"
2937,,,"khk",,"Mongolian",,"Halh",,,,0,"ltr",,"L"
2938,,,"khl",,"Lusi",,,,,,0,"ltr",,"L"
2939,"km","khm","khm",,"Khmer",,,,,,0,"ltr",,"L"
2940,,,"khn",,"Khandesi",,,,,,0,"ltr",,"L"
2941,,"kho","kho",,"Khotanese",,,,,,0,"ltr",,"A"
2942,,,"khp",,"Kapori",,,,,,0,"ltr",,"L"
2943,,,"khq",,"Songhay",,"Koyra Chiini",,,,0,"ltr",,"L"
2944,,,"khr",,"Kharia",,,,,,0,"ltr",,"L"
2945,,,"khs",,"Kasua",,,,,,0,"ltr",,"L"
2946,,,"kht",,"Khamti",,,,,,0,"ltr",,"L"
2947,,,"khu",,"Nkhumbi",,,,,,0,"ltr",,"L"
2948,,,"khv",,"Khvarshi",,,,,,0,"ltr",,"L"
2949,,,"khw",,"Khowar",,,,,,0,"ltr",,"L"
2950,,,"khx",,"Kanu",,,,,,0,"ltr",,"L"
2951,,,"khy",,"Kele","Democratic Republic of Congo",,,,,0,"ltr",,"L"
2952,,,"khz",,"Keapara",,,,,,0,"ltr",,"L"
2953,,,"kia",,"Kim",,,,,,0,"ltr",,"L"
2954,,,"kib",,"Koalib",,,,,,0,"ltr",,"L"
2955,,,"kic",,"Kickapoo",,,,,,0,"ltr",,"L"
2956,,,"kid",,"Koshin",,,,,,0,"ltr",,"L"
2957,,,"kie",,"Kibet",,,,,,0,"ltr",,"L"
2958,,,"kif",,"Parbate",,"Eastern",,,,0,"ltr",,"L"
2959,,,"kig",,"Kimaama",,,,,,0,"ltr",,"L"
2960,,,"kih",,"Kilmeri",,,,,,0,"ltr",,"L"
2961,,,"kii",,"Kitsai",,,,,,0,"ltr",,"E"
2962,,,"kij",,"Kilivila",,,,,,0,"ltr",,"L"
2963,"ki","kik","kik",,"Kikuyu",,,,,,0,"ltr",,"L"
2964,,,"kil",,"Kariya",,,,,,0,"ltr",,"L"
2965,,,"kim",,"Karagas",,,,,,0,"ltr",,"L"
2966,"rw","kin","kin",,"Kinyarwanda",,,"Kinyarwanda",,,0,"ltr",,"L"
2967,,,"kio",,"Kiowa",,,,,,0,"ltr",,"L"
2968,,,"kip",,"Kham",,"Sheshi",,,,0,"ltr",,"L"
2969,,,"kiq",,"Kosadle",,,,,,0,"ltr",,"L"
2970,"ky","kir","kir",,"Kirghiz",,,"Кыргыз",,,0,"ltr",,"L"
2971,,,"kis",,"Kis",,,,,,0,"ltr",,"L"
2972,,,"kit",,"Agob",,,,,,0,"ltr",,"L"
2973,,,"kiu",,"Kirmanjki",,,,,,0,"ltr",,"L"
2974,,,"kiv",,"Kimbu",,,,,,0,"ltr",,"L"
2975,,,"kiw",,"Kiwai",,"Northeast",,,,0,"ltr",,"L"
2976,,,"kiy",,"Kirikiri",,,,,,0,"ltr",,"L"
2977,,,"kiz",,"Kisi",,,,,,0,"ltr",,"L"
2978,,,"kja",,"Mlap",,,,,,0,"ltr",,"L"
2979,,,"kjb",,"Kanjobal",,"Eastern",,,,0,"ltr",,"L"
2980,,,"kjc",,"Konjo",,"Coastal",,,,0,"ltr",,"L"
2981,,,"kjd",,"Kiwai",,"Southern",,,,0,"ltr",,"L"
2982,,,"kje",,"Kisar",,,,,,0,"ltr",,"L"
2983,,,"kjf",,"Khalaj",,,,,,0,"ltr",,"L"
2984,,,"kjg",,"Khmu",,,,,,0,"ltr",,"L"
2985,,,"kjh",,"Khakas",,,,,,0,"ltr",,"L"
2986,,,"kji",,"Zabana",,,,,,0,"ltr",,"L"
2987,,,"kjj",,"Khinalugh",,,,,,0,"ltr",,"L"
2988,,,"kjk",,"Konjo",,"Highland",,,,0,"ltr",,"L"
2989,,,"kjl",,"Parbate",,"Western",,,,0,"ltr",,"L"
2990,,,"kjm",,"Kháng",,,,,,0,"ltr",,"L"
2991,,,"kjn",,"Kunjen",,,,,,0,"ltr",,"L"
2992,,,"kjo",,"Kinnauri",,"Harijan",,,,0,"ltr",,"L"
2993,,,"kjp",,"Karen",,"Pwo Eastern",,,,0,"ltr",,"L"
2994,,,"kjq",,"Keres",,"Western",,,,0,"ltr",,"L"
2995,,,"kjr",,"Kurudu",,,,,,0,"ltr",,"L"
2996,,,"kjs",,"Kewa",,"East",,,,0,"ltr",,"L"
2997,,,"kjt",,"Karen",,"Phrae Pwo",,,,0,"ltr",,"L"
2998,,,"kju",,"Kashaya",,,,,,0,"ltr",,"L"
2999,,,"kjx",,"Ramopa",,,,,,0,"ltr",,"L"
3000,,,"kjy",,"Erave",,,,,,0,"ltr",,"L"
3001,,,"kjz",,"Bumthangkha",,,,,,0,"ltr",,"L"
3002,,,"kka",,"Kakanda",,,,,,0,"ltr",,"L"
3003,,,"kkb",,"Kwerisa",,,,,,0,"ltr",,"L"
3004,,,"kkc",,"Odoodee",,,,,,0,"ltr",,"L"
3005,,,"kkd",,"Kinuku",,,,,,0,"ltr",,"L"
3006,,,"kke",,"Kakabe",,,,,,0,"ltr",,"L"
3007,,,"kkg",,"Kalinga",,"Mabaka Valley",,,,0,"ltr",,"L"
3008,,,"kkh",,"Khün",,,,,,0,"ltr",,"L"
3009,,,"kki",,"Kagulu",,,,,,0,"ltr",,"L"
3010,,,"kkj",,"Kako",,,,,,0,"ltr",,"L"
3011,,,"kkk",,"Kokota",,,,,,0,"ltr",,"L"
3012,,,"kkl",,"Yale",,"Kosarek",,,,0,"ltr",,"L"
3013,,,"kkm",,"Kiong",,,,,,0,"ltr",,"L"
3014,,,"kkn",,"Kon Keu",,,,,,0,"ltr",,"L"
3015,,,"kko",,"Karko",,,,,,0,"ltr",,"L"
3016,,,"kkp",,"Gugubera",,,,,,0,"ltr",,"L"
3017,,,"kkq",,"Kaiku",,,,,,0,"ltr",,"L"
3018,,,"kkr",,"Kir-Balar",,,,,,0,"ltr",,"L"
3019,,,"kks",,"Giiwo",,,,,,0,"ltr",,"L"
3020,,,"kkt",,"Koi",,,,,,0,"ltr",,"L"
3021,,,"kku",,"Tumi",,,,,,0,"ltr",,"L"
3022,,,"kkv",,"Kangean",,,,,,0,"ltr",,"L"
3023,,,"kkw",,"Teke-Kukuya",,,,,,0,"ltr",,"L"
3024,,,"kkx",,"Kohin",,,,,,0,"ltr",,"L"
3025,,,"kky",,"Guguyimidjir",,,,,,0,"ltr",,"L"
3026,,,"kkz",,"Kaska",,,,,,0,"ltr",,"L"
3027,,,"kla",,"Klamath-Modoc",,,,,,0,"ltr",,"L"
3028,,,"klb",,"Kiliwa",,,,,,0,"ltr",,"L"
3029,,,"klc",,"Kolbila",,,,,,0,"ltr",,"L"
3030,,,"kld",,"Gamilaraay",,,,,,0,"ltr",,"L"
3031,,,"kle",,"Kulung","Nepal",,,,,0,"ltr",,"L"
3032,,,"klf",,"Kendeje",,,,,,0,"ltr",,"L"
3033,,,"klg",,"Kalagan",,"Tagakaulu",,,,0,"ltr",,"L"
3034,,,"klh",,"Weliki",,,,,,0,"ltr",,"L"
3035,,,"kli",,"Kalumpang",,,,,,0,"ltr",,"L"
3036,,,"klj",,"Khalaj",,"Turkic",,,,0,"ltr",,"L"
3037,,,"klk",,"Kono","Nigeria",,,,,0,"ltr",,"L"
3038,,,"kll",,"Kalagan",,"Kagan",,,,0,"ltr",,"L"
3039,,,"klm",,"Kolom",,,,,,0,"ltr",,"L"
3040,,,"kln",,"Kalenjin",,,,,,0,"ltr",,"L"
3041,,,"klo",,"Kapya",,,,,,0,"ltr",,"L"
3042,,,"klp",,"Kamasa",,,,,,0,"ltr",,"L"
3043,,,"klq",,"Rumu",,,,,,0,"ltr",,"L"
3044,,,"klr",,"Khaling",,,,,,0,"ltr",,"L"
3045,,,"kls",,"Kalasha",,,,,,0,"ltr",,"L"
3046,,,"klt",,"Nukna",,,,,,0,"ltr",,"L"
3047,,,"klu",,"Klao",,,,,,0,"ltr",,"L"
3048,,,"klv",,"Maskelynes",,,,,,0,"ltr",,"L"
3049,,,"klw",,"Lindu",,,,,,0,"ltr",,"L"
3050,,,"klx",,"Koluwawa",,,,,,0,"ltr",,"L"
3051,,,"kly",,"Kalao",,,,,,0,"ltr",,"L"
3052,,,"klz",,"Kabola",,,,,,0,"ltr",,"L"
3053,,,"kma",,"Konni",,,,,,0,"ltr",,"L"
3054,,"kmb","kmb",,"Kimbundu",,,,,,0,"ltr",,"L"
3055,,,"kmc",,"Dong",,"Southern",,,,0,"ltr",,"L"
3056,,,"kmd",,"Kalinga",,"Madukayang",,,,0,"ltr",,"L"
3057,,,"kme",,"Bakole",,,,,,0,"ltr",,"L"
3058,,,"kmf",,"Kare","Papua New Guinea",,,,,0,"ltr",,"L"
3059,,,"kmg",,"Kâte",,,,,,0,"ltr",,"L"
3060,,,"kmh",,"Kalam",,,,,,0,"ltr",,"L"
3061,,,"kmi",,"Kami","Nigeria",,,,,0,"ltr",,"L"
3062,,,"kmj",,"Kumarbhag Paharia",,,,,,0,"ltr",,"L"
3063,,,"kmk",,"Kalinga",,"Limos",,,,0,"ltr",,"L"
3064,,,"kml",,"Kalinga",,"Lower Tanudan",,,,0,"ltr",,"L"
3065,,,"kmm",,"Kom","India",,,,,0,"ltr",,"L"
3066,,,"kmn",,"Awtuw",,,,,,0,"ltr",,"L"
3067,,,"kmo",,"Kwoma",,,,,,0,"ltr",,"L"
3068,,,"kmp",,"Gimme",,,,,,0,"ltr",,"L"
3069,,,"kmq",,"Kwama",,,,,,0,"ltr",,"L"
3070,,,"kmr",,"Kurdish",,"Northern",,,,0,"ltr",,"L"
3071,,,"kms",,"Kamasau",,,,,,0,"ltr",,"L"
3072,,,"kmt",,"Kemtuik",,,,,,0,"ltr",,"L"
3073,,,"kmu",,"Kanite",,,,,,0,"ltr",,"L"
3074,,,"kmv",,"Karipúna Creole French",,,,,,0,"ltr",,"L"
3075,,,"kmw",,"Komo","Democratic Republic of Congo",,,,,0,"ltr",,"L"
3076,,,"kmx",,"Waboda",,,,,,0,"ltr",,"L"
3077,,,"kmy",,"Koma",,,,,,0,"ltr",,"L"
3078,,,"kmz",,"Khorasani Turkish",,,,,,0,"ltr",,"L"
3079,,,"kna",,"Dera","Nigeria",,,,,0,"ltr",,"L"
3080,,,"knb",,"Kalinga",,"Lubuagan",,,,0,"ltr",,"L"
3081,,,"knc",,"Kanuri",,"Central",,,,0,"ltr",,"L"
3082,,,"knd",,"Konda",,,,,,0,"ltr",,"L"
3083,,,"kne",,"Kankanaey",,,,,,0,"ltr",,"L"
3084,,,"knf",,"Mankanya",,,,,,0,"ltr",,"L"
3085,,,"kng",,"Koongo",,,,,,0,"ltr",,"L"
3086,,,"knh",,"Kenyah",,"Kayan River",,,,0,"ltr",,"L"
3087,,,"kni",,"Kanufi",,,,,,0,"ltr",,"L"
3088,,,"knj",,"Kanjobal",,"Western",,,,0,"ltr",,"L"
3089,,,"knk",,"Kuranko",,,,,,0,"ltr",,"L"
3090,,,"knl",,"Keninjal",,,,,,0,"ltr",,"L"
3091,,,"knm",,"Kanamarí",,,,,,0,"ltr",,"L"
3092,,,"knn",,"Konkani","specific",,,,,0,"ltr",,"L"
3093,,,"kno",,"Kono","Sierra Leone",,,,,0,"ltr",,"L"
3094,,,"knp",,"Kwanja",,,,,,0,"ltr",,"L"
3095,,,"knq",,"Kintaq",,,,,,0,"ltr",,"L"
3096,,,"knr",,"Kaningra",,,,,,0,"ltr",,"L"
3097,,,"kns",,"Kensiu",,,,,,0,"ltr",,"L"
3098,,,"knt",,"Katukína",,"Panoan",,,,0,"ltr",,"L"
3099,,,"knu",,"Kono","Guinea",,,,,0,"ltr",,"L"
3100,,,"knv",,"Tabo",,,,,,0,"ltr",,"L"
3101,,,"knw",,"Kung-Ekoka",,,,,,0,"ltr",,"L"
3102,,,"knx",,"Kendayan",,,,,,0,"ltr",,"L"
3103,,,"kny",,"Kanyok",,,,,,0,"ltr",,"L"
3104,,,"knz",,"Kalamsé",,,,,,0,"ltr",,"L"
3105,,,"koa",,"Konomala",,,,,,0,"ltr",,"L"
3106,,,"kob",,"Kohoroxitari",,,,,,0,"ltr",,"L"
3107,,,"koc",,"Kpati",,,,,,0,"ltr",,"E"
3108,,,"kod",,"Kodi",,,,,,0,"ltr",,"L"
3109,,,"koe",,"Kacipo-Balesi",,,,,,0,"ltr",,"L"
3110,,,"kof",,"Kubi",,,,,,0,"ltr",,"E"
3111,,,"kog",,"Cogui",,,,,,0,"ltr",,"L"
3112,,,"koh",,"Koyo",,,,,,0,"ltr",,"L"
3113,,,"koi",,"Komi-Permyak",,,,,,0,"ltr",,"L"
3114,,,"koj",,"Sara Dunjo",,,,,,0,"ltr",,"L"
3115,,"kok","kok",,"Konkani","generic",,,,,1,"ltr",,"L"
3116,,,"kol",,"Kol","Papua New Guinea",,,,,0,"ltr",,"L"
3117,"kv","kom","kom",,"Komi",,,,,,1,"ltr",,"L"
3118,"kg","kon","kon",,"Kongo",,,,,,1,"ltr",,"L"
3119,,,"koo",,"Konjo",,,,,,0,"ltr",,"L"
3120,,,"kop",,"Kwato",,,,,,0,"ltr",,"L"
3121,,,"koq",,"Kota","Gabon",,,,,0,"ltr",,"L"
3122,"ko","kor","kor",,"Korean",,,"한국어",,,0,"ltr","c = 1","L"
3123,,"kos","kos",,"Kosraean",,,,,,0,"ltr",,"L"
3124,,,"kot",,"Lagwan",,,,,,0,"ltr",,"L"
3125,,,"kou",,"Koke",,,,,,0,"ltr",,"L"
3126,,,"kov",,"Kudu-Camo",,,,,,0,"ltr",,"L"
3127,,,"kow",,"Kugama",,,,,,0,"ltr",,"L"
3128,,,"kox",,"Coxima",,,,,,0,"ltr",,"E"
3129,,,"koy",,"Koyukon",,,,,,0,"ltr",,"L"
3130,,,"koz",,"Korak",,,,,,0,"ltr",,"L"
3131,,,"kpa",,"Kutto",,,,,,0,"ltr",,"L"
3132,,,"kpb",,"Kurumba",,"Mullu",,,,0,"ltr",,"L"
3133,,,"kpc",,"Curripaco",,,,,,0,"ltr",,"L"
3134,,,"kpd",,"Koba",,,,,,0,"ltr",,"L"
3135,,"kpe","kpe",,"Kpelle",,,,,,1,"ltr",,"L"
3136,,,"kpf",,"Komba",,,,,,0,"ltr",,"L"
3137,,,"kpg",,"Kapingamarangi",,,,,,0,"ltr",,"L"
3138,,,"kph",,"Kplang",,,,,,0,"ltr",,"L"
3139,,,"kpi",,"Kofei",,,,,,0,"ltr",,"L"
3140,,,"kpj",,"Karajá",,,,,,0,"ltr",,"L"
3141,,,"kpk",,"Kpan",,,,,,0,"ltr",,"L"
3142,,,"kpl",,"Kpala",,,,,,0,"ltr",,"L"
3143,,,"kpm",,"Koho",,,,,,0,"ltr",,"L"
3144,,,"kpn",,"Kepkiriwát",,,,,,0,"ltr",,"E"
3145,,,"kpo",,"Ikposo",,,,,,0,"ltr",,"L"
3146,,,"kpp",,"Karen",,"Paku",,,,0,"ltr",,"L"
3147,,,"kpq",,"Korupun-Sela",,,,,,0,"ltr",,"L"
3148,,,"kpr",,"Korafe",,,,,,0,"ltr",,"L"
3149,,,"kps",,"Tehit",,,,,,0,"ltr",,"L"
3150,,,"kpt",,"Karata",,,,,,0,"ltr",,"L"
3151,,,"kpu",,"Kafoa",,,,,,0,"ltr",,"L"
3152,,,"kpv",,"Komi-Zyrian",,,,,,0,"ltr",,"L"
3153,,,"kpw",,"Kobon",,,,,,0,"ltr",,"L"
3154,,,"kpx",,"Koiali",,"Mountain",,,,0,"ltr",,"L"
3155,,,"kpy",,"Koryak",,,,,,0,"ltr",,"L"
3156,,,"kpz",,"Kupsabiny",,,,,,0,"ltr",,"L"
3157,,,"kqa",,"Mum",,,,,,0,"ltr",,"L"
3158,,,"kqb",,"Kovai",,,,,,0,"ltr",,"L"
3159,,,"kqc",,"Doromu",,,,,,0,"ltr",,"L"
3160,,,"kqd",,"Koy Sanjaq Surat",,,,,,0,"ltr",,"L"
3161,,,"kqe",,"Kalagan",,,,,,0,"ltr",,"L"
3162,,,"kqf",,"Kakabai",,,,,,0,"ltr",,"L"
3163,,,"kqg",,"Khe",,,,,,0,"ltr",,"L"
3164,,,"kqh",,"Kisankasa",,,,,,0,"ltr",,"L"
3165,,,"kqi",,"Koitabu",,,,,,0,"ltr",,"L"
3166,,,"kqj",,"Koromira",,,,,,0,"ltr",,"L"
3167,,,"kqk",,"Gbe",,"Kotafon",,,,0,"ltr",,"L"
3168,,,"kql",,"Kyenele",,,,,,0,"ltr",,"L"
3169,,,"kqm",,"Khisa",,,,,,0,"ltr",,"L"
3170,,,"kqn",,"Kaonde",,,,,,0,"ltr",,"L"
3171,,,"kqo",,"Krahn",,"Eastern",,,,0,"ltr",,"L"
3172,,,"kqp",,"Kimré",,,,,,0,"ltr",,"L"
3173,,,"kqq",,"Krenak",,,,,,0,"ltr",,"L"
3174,,,"kqr",,"Kimaragang",,,,,,0,"ltr",,"L"
3175,,,"kqs",,"Kissi",,"Northern",,,,0,"ltr",,"L"
3176,,,"kqt",,"Kadazan",,"Klias River",,,,0,"ltr",,"L"
3177,,,"kqu",,"Seroa",,,,,,0,"ltr",,"E"
3178,,,"kqv",,"Okolod",,,,,,0,"ltr",,"L"
3179,,,"kqw",,"Kandas",,,,,,0,"ltr",,"L"
3180,,,"kqx",,"Mser",,,,,,0,"ltr",,"L"
3181,,,"kqy",,"Koorete",,,,,,0,"ltr",,"L"
3182,,,"kqz",,"Korana",,,,,,0,"ltr",,"E"
3183,,,"kra",,"Kumhali",,,,,,0,"ltr",,"L"
3184,,,"krb",,"Karkin",,,,,,0,"ltr",,"E"
3185,,"krc","krc",,"Karachay-Balkar",,,,,,0,"ltr",,"L"
3186,,,"krd",,"Kairui-Midiki",,,,,,0,"ltr",,"L"
3187,,,"kre",,"Kreen-Akarore",,,,,,0,"ltr",,"L"
3188,,,"krf",,"Koro","Vanuatu",,,,,0,"ltr",,"L"
3189,,,"krg",,"Korowai",,"North",,,,0,"ltr",,"L"
3190,,,"krh",,"Kurama",,,,,,0,"ltr",,"L"
3191,,,"kri",,"Krio",,,,,,0,"ltr",,"L"
3192,,,"krj",,"Kinaray-A",,,,,,0,"ltr",,"L"
3193,,,"krk",,"Kerek",,,,,,0,"ltr",,"L"
3194,,,"krl",,"Karelian",,,,,,0,"ltr",,"L"
3195,,,"krm",,"Krim",,,,,,0,"ltr",,"L"
3196,,,"krn",,"Sapo",,,,,,0,"ltr",,"L"
3197,,,"krp",,"Korop",,,,,,0,"ltr",,"L"
3198,,,"krq",,"Krui",,,,,,0,"ltr",,"L"
3199,,,"krr",,"Kru'ng 2",,,,,,0,"ltr",,"L"
3200,,,"krs",,"Gbaya","Sudan",,,,,0,"ltr",,"L"
3201,,,"krt",,"Kanuri",,"Tumari",,,,0,"ltr",,"L"
3202,,"kru","kru",,"Kurukh",,,,,,0,"ltr",,"L"
3203,,,"krv",,"Kravet",,,,,,0,"ltr",,"L"
3204,,,"krw",,"Krahn",,"Western",,,,0,"ltr",,"L"
3205,,,"krx",,"Karon",,,,,,0,"ltr",,"L"
3206,,,"kry",,"Kryts",,,,,,0,"ltr",,"L"
3207,,,"krz",,"Kanum",,"Sota",,,,0,"ltr",,"L"
3208,,,"ksa",,"Shuwa-Zamani",,,,,,0,"ltr",,"L"
3209,,,"ksb",,"Shambala",,,,,,0,"ltr",,"L"
3210,,,"ksc",,"Kalinga",,"Southern",,,,0,"ltr",,"L"
3211,,,"ksd",,"Kuanua",,,,,,0,"ltr",,"L"
3212,,,"kse",,"Kuni",,,,,,0,"ltr",,"L"
3213,,,"ksf",,"Bafia",,,,,,0,"ltr",,"L"
3214,,,"ksg",,"Kusaghe",,,,,,0,"ltr",,"L"
3215,,,"ksh",,"Kölsch",,,,,,0,"ltr",,"L"
3216,,,"ksi",,"Krisa",,,,,,0,"ltr",,"L"
3217,,,"ksj",,"Uare",,,,,,0,"ltr",,"L"
3218,,,"ksk",,"Kansa",,,,,,0,"ltr",,"L"
3219,,,"ksl",,"Kumalu",,,,,,0,"ltr",,"L"
3220,,,"ksm",,"Kumba",,,,,,0,"ltr",,"L"
3221,,,"ksn",,"Kasiguranin",,,,,,0,"ltr",,"L"
3222,,,"kso",,"Kofa",,,,,,0,"ltr",,"L"
3223,,,"ksp",,"Kaba",,,,,,0,"ltr",,"L"
3224,,,"ksq",,"Kwaami",,,,,,0,"ltr",,"L"
3225,,,"ksr",,"Borong",,,,,,0,"ltr",,"L"
3226,,,"kss",,"Kisi",,"Southern",,,,0,"ltr",,"L"
3227,,,"kst",,"Winyé",,,,,,0,"ltr",,"L"
3228,,,"ksu",,"Khamyang",,,,,,0,"ltr",,"L"
3229,,,"ksv",,"Kusu",,,,,,0,"ltr",,"L"
3230,,,"ksw",,"Karen",,"S'gaw",,,,0,"ltr",,"L"
3231,,,"ksx",,"Kedang",,,,,,0,"ltr",,"L"
3232,,,"ksy",,"Kharia Thar",,,,,,0,"ltr",,"L"
3233,,,"ksz",,"Koraku",,,,,,0,"ltr",,"L"
3234,,,"kta",,"Katua",,,,,,0,"ltr",,"L"
3235,,,"ktb",,"Kambaata",,,,,,0,"ltr",,"L"
3236,,,"ktc",,"Kholok",,,,,,0,"ltr",,"L"
3237,,,"ktd",,"Kokata",,,,,,0,"ltr",,"L"
3238,,,"kte",,"Nubri",,,,,,0,"ltr",,"L"
3239,,,"ktf",,"Kwami",,,,,,0,"ltr",,"L"
3240,,,"ktg",,"Kalkutung",,,,,,0,"ltr",,"E"
3241,,,"kth",,"Karanga",,,,,,0,"ltr",,"L"
3242,,,"kti",,"Muyu",,"North",,,,0,"ltr",,"L"
3243,,,"ktj",,"Krumen",,"Plapo",,,,0,"ltr",,"L"
3244,,,"ktk",,"Kaniet",,,,,,0,"ltr",,"E"
3245,,,"ktl",,"Koroshi",,,,,,0,"ltr",,"L"
3246,,,"ktm",,"Kurti",,,,,,0,"ltr",,"L"
3247,,,"ktn",,"Karitiâna",,,,,,0,"ltr",,"L"
3248,,,"kto",,"Kuot",,,,,,0,"ltr",,"L"
3249,,,"ktp",,"Kaduo",,,,,,0,"ltr",,"L"
3250,,,"ktq",,"Katabaga",,,,,,0,"ltr",,"E"
3251,,,"ktr",,"Kota Marudu Tinagas",,,,,,0,"ltr",,"L"
3252,,,"kts",,"Muyu",,"South",,,,0,"ltr",,"L"
3253,,,"ktt",,"Ketum",,,,,,0,"ltr",,"L"
3254,,,"ktu",,"Kituba","Democratic Republic of Congo",,,,,0,"ltr",,"L"
3255,,,"ktv",,"Katu",,"Eastern",,,,0,"ltr",,"L"
3256,,,"ktw",,"Kato",,,,,,0,"ltr",,"E"
3257,,,"ktx",,"Kaxararí",,,,,,0,"ltr",,"L"
3258,,,"kty",,"Kango","Bas-Uélé District",,,,,0,"ltr",,"L"
3259,,,"ktz",,"Ju/'hoan",,,,,,0,"ltr",,"L"
3260,"kj","kua","kua",,"Kuanyama",,,,,,0,"ltr",,"L"
3261,,,"kub",,"Kutep",,,,,,0,"ltr",,"L"
3262,,,"kud",,"'Auhelawa",,,,,,0,"ltr",,"L"
3263,,,"kue",,"Kuman",,,,,,0,"ltr",,"L"
3264,,,"kuf",,"Katu",,"Western",,,,0,"ltr",,"L"
3265,,,"kug",,"Kupa",,,,,,0,"ltr",,"L"
3266,,,"kuh",,"Kushi",,,,,,0,"ltr",,"L"
3267,,,"kui",,"Kuikúro-Kalapálo",,,,,,0,"ltr",,"L"
3268,,,"kuj",,"Kuria",,,,,,0,"ltr",,"L"
3269,,,"kuk",,"Kepo'",,,,,,0,"ltr",,"L"
3270,,,"kul",,"Kulere",,,,,,0,"ltr",,"L"
3271,,"kum","kum",,"Kumyk",,,,,,0,"ltr",,"L"
3272,,,"kun",,"Kunama",,,,,,0,"ltr",,"L"
3273,,,"kuo",,"Kumukio",,,,,,0,"ltr",,"L"
3274,,,"kup",,"Kunimaipa",,,,,,0,"ltr",,"L"
3275,,,"kuq",,"Karipuná",,,,,,0,"ltr",,"L"
3276,"ku","kur","kur",,"Kurdish",,,,,,1,"ltr",,"L"
3277,,,"kus",,"Kusaal",,,,,,0,"ltr",,"L"
3278,,"kut","kut",,"Kutenai",,,,,,0,"ltr",,"L"
3279,,,"kuu",,"Kuskokwim",,"Upper",,,,0,"ltr",,"L"
3280,,,"kuv",,"Kur",,,,,,0,"ltr",,"L"
3281,,,"kuw",,"Kpagua",,,,,,0,"ltr",,"L"
3282,,,"kux",,"Kukatja",,,,,,0,"ltr",,"L"
3283,,,"kuy",,"Kuuku-Ya'u",,,,,,0,"ltr",,"L"
3284,,,"kuz",,"Kunza",,,,,,0,"ltr",,"E"
3285,,,"kva",,"Bagvalal",,,,,,0,"ltr",,"L"
3286,,,"kvb",,"Kubu",,,,,,0,"ltr",,"L"
3287,,,"kvc",,"Kove",,,,,,0,"ltr",,"L"
3288,,,"kvd",,"Kui","Indonesia",,,,,0,"ltr",,"L"
3289,,,"kve",,"Kalabakan",,,,,,0,"ltr",,"L"
3290,,,"kvf",,"Kabalai",,,,,,0,"ltr",,"L"
3291,,,"kvg",,"Kuni-Boazi",,,,,,0,"ltr",,"L"
3292,,,"kvh",,"Komodo",,,,,,0,"ltr",,"L"
3293,,,"kvi",,"Kwang",,,,,,0,"ltr",,"L"
3294,,,"kvj",,"Psikye",,,,,,0,"ltr",,"L"
3295,,,"kvk",,"Korean Sign Language",,,,,,0,"ltr",,"L"
3296,,,"kvl",,"Karen",,"Brek",,,,0,"ltr",,"L"
3297,,,"kvm",,"Kendem",,,,,,0,"ltr",,"L"
3298,,,"kvn",,"Kuna",,"Border",,,,0,"ltr",,"L"
3299,,,"kvo",,"Dobel",,,,,,0,"ltr",,"L"
3300,,,"kvp",,"Kompane",,,,,,0,"ltr",,"L"
3301,,,"kvq",,"Karen",,"Geba",,,,0,"ltr",,"L"
3302,,,"kvr",,"Kerinci",,,,,,0,"ltr",,"L"
3303,,,"kvs",,"Kunggara",,,,,,0,"ltr",,"L"
3304,,,"kvt",,"Karen",,"Lahta",,,,0,"ltr",,"L"
3305,,,"kvu",,"Karen",,"Yinbaw",,,,0,"ltr",,"L"
3306,,,"kvv",,"Kola",,,,,,0,"ltr",,"L"
3307,,,"kvw",,"Wersing",,,,,,0,"ltr",,"L"
3308,,,"kvx",,"Koli",,"Parkari",,,,0,"ltr",,"L"
3309,,,"kvy",,"Karen",,"Yintale",,,,0,"ltr",,"L"
3310,,,"kvz",,"Tsakwambo",,,,,,0,"ltr",,"L"
3311,,,"kwa",,"Dâw",,,,,,0,"ltr",,"L"
3312,,,"kwb",,"Kwa",,,,,,0,"ltr",,"L"
3313,,,"kwc",,"Likwala",,,,,,0,"ltr",,"L"
3314,,,"kwd",,"Kwaio",,,,,,0,"ltr",,"L"
3315,,,"kwe",,"Kwerba",,,,,,0,"ltr",,"L"
3316,,,"kwf",,"Kwara'ae",,,,,,0,"ltr",,"L"
3317,,,"kwg",,"Kaba Deme",,,,,,0,"ltr",,"L"
3318,,,"kwh",,"Kowiai",,,,,,0,"ltr",,"L"
3319,,,"kwi",,"Awa-Cuaiquer",,,,,,0,"ltr",,"L"
3320,,,"kwj",,"Kwanga",,,,,,0,"ltr",,"L"
3321,,,"kwk",,"Kwakiutl",,,,,,0,"ltr",,"L"
3322,,,"kwl",,"Kofyar",,,,,,0,"ltr",,"L"
3323,,,"kwm",,"Kwambi",,,,,,0,"ltr",,"L"
3324,,,"kwn",,"Kwangali",,,,,,0,"ltr",,"L"
3325,,,"kwo",,"Kwomtari",,,,,,0,"ltr",,"L"
3326,,,"kwp",,"Kodia",,,,,,0,"ltr",,"L"
3327,,,"kwq",,"Kwak",,,,,,0,"ltr",,"L"
3328,,,"kwr",,"Kwer",,,,,,0,"ltr",,"L"
3329,,,"kws",,"Kwese",,,,,,0,"ltr",,"L"
3330,,,"kwt",,"Kwesten",,,,,,0,"ltr",,"L"
3331,,,"kwu",,"Kwakum",,,,,,0,"ltr",,"L"
3332,,,"kwv",,"Kaba Na",,,,,,0,"ltr",,"L"
3333,,,"kww",,"Kwinti",,,,,,0,"ltr",,"L"
3334,,,"kwx",,"Khirwar",,,,,,0,"ltr",,"L"
3335,,,"kwy",,"Kongo",,"San Salvador",,,,0,"ltr",,"L"
3336,,,"kwz",,"Kwadi",,,,,,0,"ltr",,"E"
3337,,,"kxa",,"Kairiru",,,,,,0,"ltr",,"L"
3338,,,"kxb",,"Krobu",,,,,,0,"ltr",,"L"
3339,,,"kxc",,"Komso",,,,,,0,"ltr",,"L"
3340,,,"kxd",,"Brunei",,,,,,0,"ltr",,"L"
3341,,,"kxe",,"Kakihum",,,,,,0,"ltr",,"L"
3342,,,"kxf",,"Karen",,"Manumanaw",,,,0,"ltr",,"L"
3343,,,"kxg",,"Katingan",,,,,,0,"ltr",,"L"
3344,,,"kxh",,"Karo","Ethiopia",,,,,0,"ltr",,"L"
3345,,,"kxi",,"Keningau Murut",,,,,,0,"ltr",,"L"
3346,,,"kxj",,"Kulfa",,,,,,0,"ltr",,"L"
3347,,,"kxk",,"Karen",,"Zayein",,,,0,"ltr",,"L"
3348,,,"kxl",,"Kurux",,"Nepali",,,,0,"ltr",,"L"
3349,,,"kxm",,"Khmer",,"Northern",,,,0,"ltr",,"L"
3350,,,"kxn",,"Kanowit",,,,,,0,"ltr",,"L"
3351,,,"kxo",,"Kanoé",,,,,,0,"ltr",,"E"
3352,,,"kxp",,"Koli",,"Wadiyara",,,,0,"ltr",,"L"
3353,,,"kxq",,"Kanum",,"Smärky",,,,0,"ltr",,"L"
3354,,,"kxr",,"Koro","Papua New Guinea",,,,,0,"ltr",,"L"
3355,,,"kxs",,"Kangjia",,,,,,0,"ltr",,"L"
3356,,,"kxt",,"Koiwat",,,,,,0,"ltr",,"L"
3357,,,"kxu",,"Kui","India",,,,,0,"ltr",,"L"
3358,,,"kxv",,"Kuvi",,,,,,0,"ltr",,"L"
3359,,,"kxw",,"Konai",,,,,,0,"ltr",,"L"
3360,,,"kxx",,"Likuba",,,,,,0,"ltr",,"L"
3361,,,"kxy",,"Kayong",,,,,,0,"ltr",,"L"
3362,,,"kxz",,"Kerewo",,,,,,0,"ltr",,"L"
3363,,,"kya",,"Kwaya",,,,,,0,"ltr",,"L"
3364,,,"kyb",,"Kalinga",,"Butbut",,,,0,"ltr",,"L"
3365,,,"kyc",,"Kyaka",,,,,,0,"ltr",,"L"
3366,,,"kyd",,"Karey",,,,,,0,"ltr",,"L"
3367,,,"kye",,"Krache",,,,,,0,"ltr",,"L"
3368,,,"kyf",,"Kouya",,,,,,0,"ltr",,"L"
3369,,,"kyg",,"Keyagana",,,,,,0,"ltr",,"L"
3370,,,"kyh",,"Karok",,,,,,0,"ltr",,"L"
3371,,,"kyi",,"Kiput",,,,,,0,"ltr",,"L"
3372,,,"kyj",,"Karao",,,,,,0,"ltr",,"L"
3373,,,"kyk",,"Kamayo",,,,,,0,"ltr",,"L"
3374,,,"kyl",,"Kalapuya",,,,,,0,"ltr",,"L"
3375,,,"kym",,"Kpatili",,,,,,0,"ltr",,"L"
3376,,,"kyn",,"Karolanos",,,,,,0,"ltr",,"L"
3377,,,"kyo",,"Kelon",,,,,,0,"ltr",,"L"
3378,,,"kyp",,"Kang",,,,,,0,"ltr",,"L"
3379,,,"kyq",,"Kenga",,,,,,0,"ltr",,"L"
3380,,,"kyr",,"Kuruáya",,,,,,0,"ltr",,"L"
3381,,,"kys",,"Kayan",,"Baram",,,,0,"ltr",,"L"
3382,,,"kyt",,"Kayagar",,,,,,0,"ltr",,"L"
3383,,,"kyu",,"Kayah",,"Western",,,,0,"ltr",,"L"
3384,,,"kyv",,"Kayort",,,,,,0,"ltr",,"L"
3385,,,"kyw",,"Kudmali",,,,,,0,"ltr",,"L"
3386,,,"kyx",,"Rapoisi",,,,,,0,"ltr",,"L"
3387,,,"kyy",,"Kambaira",,,,,,0,"ltr",,"L"
3388,,,"kyz",,"Kayabí",,,,,,0,"ltr",,"L"
3389,,,"kza",,"Karaboro",,"Western",,,,0,"ltr",,"L"
3390,,,"kzb",,"Kaibobo",,,,,,0,"ltr",,"L"
3391,,,"kzc",,"Kulango",,"Bondoukou",,,,0,"ltr",,"L"
3392,,,"kzd",,"Kadai",,,,,,0,"ltr",,"L"
3393,,,"kze",,"Kosena",,,,,,0,"ltr",,"L"
3394,,,"kzf",,"Kaili",,"Da'a",,,,0,"ltr",,"L"
3395,,,"kzg",,"Kikai",,,,,,0,"ltr",,"L"
3396,,,"kzh",,"Kenuzi-Dongola",,,,,,0,"ltr",,"L"
3397,,,"kzi",,"Kelabit",,,,,,0,"ltr",,"L"
3398,,,"kzj",,"Kadazan",,"Coastal",,,,0,"ltr",,"L"
3399,,,"kzk",,"Kazukuru",,,,,,0,"ltr",,"E"
3400,,,"kzl",,"Kayeli",,,,,,0,"ltr",,"L"
3401,,,"kzm",,"Kais",,,,,,0,"ltr",,"L"
3402,,,"kzn",,"Kokola",,,,,,0,"ltr",,"L"
3403,,,"kzo",,"Kaningi",,,,,,0,"ltr",,"L"
3404,,,"kzp",,"Kaidipang",,,,,,0,"ltr",,"L"
3405,,,"kzq",,"Kaike",,,,,,0,"ltr",,"L"
3406,,,"kzr",,"Karang",,,,,,0,"ltr",,"L"
3407,,,"kzs",,"Dusun",,"Sugut",,,,0,"ltr",,"L"
3408,,,"kzt",,"Dusun",,"Tambunan",,,,0,"ltr",,"L"
3409,,,"kzu",,"Kayupulau",,,,,,0,"ltr",,"L"
3410,,,"kzv",,"Komyandaret",,,,,,0,"ltr",,"L"
3411,,,"kzw",,"Karirí-Xocó",,,,,,0,"ltr",,"E"
3412,,,"kzx",,"Kamarian",,,,,,0,"ltr",,"L"
3413,,,"kzy",,"Kango","Tshopo District",,,,,0,"ltr",,"L"
3414,,,"kzz",,"Kalabra",,,,,,0,"ltr",,"L"
3415,,,"laa",,"Subanun",,"Lapuyan",,,,0,"ltr",,"L"
3416,,,"lac",,"Lacandon",,,,,,0,"ltr",,"L"
3417,,"lad","lad",,"Ladino",,,,,,0,"ltr",,"L"
3418,,,"lae",,"Pattani",,,,,,0,"ltr",,"L"
3419,,,"laf",,"Lafofa",,,,,,0,"ltr",,"L"
3420,,,"lag",,"Langi",,,,,,0,"ltr",,"L"
3421,,"lah","lah",,"Lahnda",,,,,,1,"ltr",,"L"
3422,,,"lai",,"Lambya",,,,,,0,"ltr",,"L"
3423,,,"laj",,"Lango","Uganda",,,,,0,"ltr",,"L"
3424,,,"lak",,"Laka","Nigeria",,,,,0,"ltr",,"L"
3425,,,"lal",,"Lalia",,,,,,0,"ltr",,"L"
3426,,"lam","lam",,"Lamba",,,,,,0,"ltr",,"L"
3427,,,"lan",,"Laru",,,,,,0,"ltr",,"L"
3428,"lo","lao","lao",,"Lao",,,,,,0,"ltr",,"L"
3429,,,"lap",,"Laka","Chad",,,,,0,"ltr",,"L"
3430,,,"laq",,"Qabiao",,,,,,0,"ltr",,"L"
3431,,,"lar",,"Larteh",,,,,,0,"ltr",,"L"
3432,,,"las",,"Lama","Togo",,,,,0,"ltr",,"L"
3433,"la","lat","lat",,"Latin",,,,,,0,"ltr",,"A"
3434,,,"lau",,"Laba",,,,,,0,"ltr",,"L"
3435,"lv","lav","lav",,"Latvian",,,"Latviešu",,,0,"ltr","c%10==1 && c%100!=11 ? 1 : c != 0 ? 2 : 3","L"
3436,,,"law",,"Lauje",,,,,,0,"ltr",,"L"
3437,,,"lax",,"Tiwa",,,,,,0,"ltr",,"L"
3438,,,"lay",,"Lama","Myanmar",,,,,0,"ltr",,"L"
3439,,,"laz",,"Aribwatsa",,,,,,0,"ltr",,"E"
3440,,,"lba",,"Lui",,,,,,0,"ltr",,"L"
3441,,,"lbb",,"Label",,,,,,0,"ltr",,"L"
3442,,,"lbc",,"Lakkia",,,,,,0,"ltr",,"L"
3443,,,"lbe",,"Lak",,,,,,0,"ltr",,"L"
3444,,,"lbf",,"Tinani",,,,,,0,"ltr",,"L"
3445,,,"lbg",,"Laopang",,,,,,0,"ltr",,"L"
3446,,,"lbi",,"La'bi",,,,,,0,"ltr",,"L"
3447,,,"lbj",,"Ladakhi",,,,,,0,"ltr",,"L"
3448,,,"lbm",,"Lodhi",,,,,,0,"ltr",,"L"
3449,,,"lbn",,"Lamet",,,,,,0,"ltr",,"L"
3450,,,"lbo",,"Laven",,,,,,0,"ltr",,"L"
3451,,,"lbq",,"Wampar",,,,,,0,"ltr",,"L"
3452,,,"lbr",,"Lorung",,"Northern",,,,0,"ltr",,"L"
3453,,,"lbs",,"Libyan Sign Language",,,,,,0,"ltr",,"L"
3454,,,"lbt",,"Lachi",,,,,,0,"ltr",,"L"
3455,,,"lbu",,"Labu",,,,,,0,"ltr",,"L"
3456,,,"lbv",,"Lavatbura-Lamusong",,,,,,0,"ltr",,"L"
3457,,,"lbw",,"Tolaki",,,,,,0,"ltr",,"L"
3458,,,"lbx",,"Lawangan",,,,,,0,"ltr",,"L"
3459,,,"lby",,"Lamu-Lamu",,,,,,0,"ltr",,"L"
3460,,,"lbz",,"Lardil",,,,,,0,"ltr",,"L"
3461,,,"lcc",,"Legenyem",,,,,,0,"ltr",,"L"
3462,,,"lcd",,"Lola",,,,,,0,"ltr",,"L"
3463,,,"lce",,"Loncong",,,,,,0,"ltr",,"L"
3464,,,"lcf",,"Lubu",,,,,,0,"ltr",,"L"
3465,,,"lch",,"Luchazi",,,,,,0,"ltr",,"L"
3466,,,"lcl",,"Lisela",,,,,,0,"ltr",,"L"
3467,,,"lcm",,"Tungag",,,,,,0,"ltr",,"L"
3468,,,"lcp",,"Lawa",,"Western",,,,0,"ltr",,"L"
3469,,,"lcq",,"Luhu",,,,,,0,"ltr",,"L"
3470,,,"lcs",,"Lisabata-Nuniali",,,,,,0,"ltr",,"L"
3471,,,"ldb",,"Idun",,,,,,0,"ltr",,"L"
3472,,,"ldd",,"Luri",,,,,,0,"ltr",,"L"
3473,,,"ldg",,"Lenyima",,,,,,0,"ltr",,"L"
3474,,,"ldh",,"Lamja-Dengsa-Tola",,,,,,0,"ltr",,"L"
3475,,,"ldi",,"Laari",,,,,,0,"ltr",,"L"
3476,,,"ldj",,"Lemoro",,,,,,0,"ltr",,"L"
3477,,,"ldk",,"Leelau",,,,,,0,"ltr",,"L"
3478,,,"ldl",,"Kaan",,,,,,0,"ltr",,"L"
3479,,,"ldm",,"Landoma",,,,,,0,"ltr",,"L"
3480,,,"ldn",,"Láadan",,,,,,0,"ltr",,"C"
3481,,,"ldo",,"Loo",,,,,,0,"ltr",,"L"
3482,,,"ldp",,"Tso",,,,,,0,"ltr",,"L"
3483,,,"ldq",,"Lufu",,,,,,0,"ltr",,"L"
3484,,,"lea",,"Lega-Shabunda",,,,,,0,"ltr",,"L"
3485,,,"leb",,"Lala-Bisa",,,,,,0,"ltr",,"L"
3486,,,"lec",,"Leco",,,,,,0,"ltr",,"L"
3487,,,"led",,"Lendu",,,,,,0,"ltr",,"L"
3488,,,"lee",,"Lyélé",,,,,,0,"ltr",,"L"
3489,,,"lef",,"Lelemi",,,,,,0,"ltr",,"L"
3490,,,"leg",,"Lengua",,,,,,0,"ltr",,"L"
3491,,,"leh",,"Lenje",,,,,,0,"ltr",,"L"
3492,,,"lei",,"Lemio",,,,,,0,"ltr",,"L"
3493,,,"lej",,"Lengola",,,,,,0,"ltr",,"L"
3494,,,"lek",,"Leipon",,,,,,0,"ltr",,"L"
3495,,,"lel",,"Lele","Democratic Republic of Congo",,,,,0,"ltr",,"L"
3496,,,"lem",,"Nomaande",,,,,,0,"ltr",,"L"
3497,,,"len",,"Lenca",,,,,,0,"ltr",,"L"
3498,,,"leo",,"Leti","Cameroon",,,,,0,"ltr",,"L"
3499,,,"lep",,"Lepcha",,,,,,0,"ltr",,"L"
3500,,,"leq",,"Lembena",,,,,,0,"ltr",,"L"
3501,,,"ler",,"Lenkau",,,,,,0,"ltr",,"L"
3502,,,"les",,"Lese",,,,,,0,"ltr",,"L"
3503,,,"let",,"Lesing-Gelimi",,,,,,0,"ltr",,"L"
3504,,,"leu",,"Kara","Papua New Guinea",,,,,0,"ltr",,"L"
3505,,,"lev",,"Lamma",,,,,,0,"ltr",,"L"
3506,,,"lew",,"Kaili",,"Ledo",,,,0,"ltr",,"L"
3507,,,"lex",,"Luang",,,,,,0,"ltr",,"L"
3508,,,"ley",,"Lemolang",,,,,,0,"ltr",,"L"
3509,,"lez","lez",,"Lezghian",,,,,,0,"ltr",,"L"
3510,,,"lfa",,"Lefa",,,,,,0,"ltr",,"L"
3511,,,"lga",,"Lungga",,,,,,0,"ltr",,"L"
3512,,,"lgb",,"Laghu",,,,,,0,"ltr",,"L"
3513,,,"lgg",,"Lugbara",,,,,,0,"ltr",,"L"
3514,,,"lgh",,"Laghuu",,,,,,0,"ltr",,"L"
3515,,,"lgi",,"Lengilu",,,,,,0,"ltr",,"L"
3516,,,"lgk",,"Lingarak",,,,,,0,"ltr",,"L"
3517,,,"lgl",,"Wala",,,,,,0,"ltr",,"L"
3518,,,"lgm",,"Lega-Mwenga",,,,,,0,"ltr",,"L"
3519,,,"lgn",,"Opuuo",,,,,,0,"ltr",,"L"
3520,,,"lgq",,"Logba",,,,,,0,"ltr",,"L"
3521,,,"lgr",,"Lengo",,,,,,0,"ltr",,"L"
3522,,,"lgt",,"Pahi",,,,,,0,"ltr",,"L"
3523,,,"lgu",,"Longgu",,,,,,0,"ltr",,"L"
3524,,,"lgz",,"Ligenza",,,,,,0,"ltr",,"L"
3525,,,"lha",,"Laha","Viet Nam",,,,,0,"ltr",,"L"
3526,,,"lhh",,"Laha","Indonesia",,,,,0,"ltr",,"L"
3527,,,"lhl",,"Lohar",,"Lahul",,,,0,"ltr",,"L"
3528,,,"lhm",,"Lhomi",,,,,,0,"ltr",,"L"
3529,,,"lhn",,"Lahanan",,,,,,0,"ltr",,"L"
3530,,,"lhp",,"Lhokpu",,,,,,0,"ltr",,"L"
3531,,,"lhs",,"Mlahsö",,,,,,0,"ltr",,"E"
3532,,,"lht",,"Toga",,,,,,0,"ltr",,"L"
3533,,,"lhu",,"Lahu",,,,,,0,"ltr",,"L"
3534,,,"lia",,"Limba",,"West-Central",,,,0,"ltr",,"L"
3535,,,"lib",,"Likum",,,,,,0,"ltr",,"L"
3536,,,"lic",,"Hlai",,,,,,0,"ltr",,"L"
3537,,,"lid",,"Nyindrou",,,,,,0,"ltr",,"L"
3538,,,"lie",,"Likila",,,,,,0,"ltr",,"L"
3539,,,"lif",,"Limbu",,,,,,0,"ltr",,"L"
3540,,,"lig",,"Ligbi",,,,,,0,"ltr",,"L"
3541,,,"lih",,"Lihir",,,,,,0,"ltr",,"L"
3542,,,"lii",,"Lingkhim",,,,,,0,"ltr",,"L"
3543,,,"lij",,"Ligurian",,,,,,0,"ltr",,"L"
3544,,,"lik",,"Lika",,,,,,0,"ltr",,"L"
3545,,,"lil",,"Lillooet",,,,,,0,"ltr",,"L"
3546,"li","lim","lim",,"Limburgish",,"Limburger",,,,0,"ltr",,"L"
3547,"ln","lin","lin",,"Lingala",,,,,,0,"ltr",,"L"
3548,,,"lio",,"Liki",,,,,,0,"ltr",,"L"
3549,,,"lip",,"Sekpele",,,,,,0,"ltr",,"L"
3550,,,"liq",,"Libido",,,,,,0,"ltr",,"L"
3551,,,"lir",,"Liberian English",,,,,,0,"ltr",,"L"
3552,,,"lis",,"Lisu",,,,,,0,"ltr",,"L"
3553,"lt","lit","lit",,"Lithuanian",,,"Lietuviškai",,,0,"ltr","c%10==1 && c%100!=11 ? 1 : c%10>=2 && (c%100<10 || c%100>=20) ? 2 : 3","L"
3554,,,"liu",,"Logorik",,,,,,0,"ltr",,"L"
3555,,,"liv",,"Liv",,,,,,0,"ltr",,"L"
3556,,,"liw",,"Lembak",,,,,,0,"ltr",,"L"
3557,,,"lix",,"Liabuku",,,,,,0,"ltr",,"L"
3558,,,"liy",,"Banda-Bambari",,,,,,0,"ltr",,"L"
3559,,,"liz",,"Libinza",,,,,,0,"ltr",,"L"
3560,,,"lje",,"Rampi",,,,,,0,"ltr",,"L"
3561,,,"lji",,"Laiyolo",,,,,,0,"ltr",,"L"
3562,,,"ljl",,"Li'o",,,,,,0,"ltr",,"L"
3563,,,"ljp",,"Lampung",,,,,,0,"ltr",,"L"
3564,,,"lka",,"Lakalei",,,,,,0,"ltr",,"L"
3565,,,"lke",,"Kenyi",,,,,,0,"ltr",,"L"
3566,,,"lkh",,"Lakha",,,,,,0,"ltr",,"L"
3567,,,"lki",,"Laki",,,,,,0,"ltr",,"L"
3568,,,"lkj",,"Remun",,,,,,0,"ltr",,"L"
3569,,,"lkl",,"Laeko-Libuat",,,,,,0,"ltr",,"L"
3570,,,"lkn",,"Lakona",,,,,,0,"ltr",,"L"
3571,,,"lkr",,"Päri",,,,,,0,"ltr",,"L"
3572,,,"lkt",,"Lakota",,,,,,0,"ltr",,"L"
3573,,,"lky",,"Lokoya",,,,,,0,"ltr",,"L"
3574,,,"lla",,"Lala-Roba",,,,,,0,"ltr",,"L"
3575,,,"llb",,"Lolo",,,,,,0,"ltr",,"L"
3576,,,"llc",,"Lele","Guinea",,,,,0,"ltr",,"L"
3577,,,"lld",,"Ladin",,,,,,0,"ltr",,"L"
3578,,,"lle",,"Lele","Papua New Guinea",,,,,0,"ltr",,"L"
3579,,,"llf",,"Hermit",,,,,,0,"ltr",,"E"
3580,,,"llg",,"Lole",,,,,,0,"ltr",,"L"
3581,,,"lli",,"Teke-Laali",,,,,,0,"ltr",,"L"
3582,,,"llk",,"Lelak",,,,,,0,"ltr",,"L"
3583,,,"lll",,"Lilau",,,,,,0,"ltr",,"L"
3584,,,"llm",,"Lasalimu",,,,,,0,"ltr",,"L"
3585,,,"lln",,"Lele","Chad",,,,,0,"ltr",,"L"
3586,,,"llo",,"Khlor",,,,,,0,"ltr",,"L"
3587,,,"llp",,"Efate",,"North",,,,0,"ltr",,"L"
3588,,,"llq",,"Lolak",,,,,,0,"ltr",,"L"
3589,,,"lls",,"Lithuanian Sign Language",,,,,,0,"ltr",,"L"
3590,,,"llu",,"Lau",,,,,,0,"ltr",,"L"
3591,,,"llx",,"Lauan",,,,,,0,"ltr",,"L"
3592,,,"lma",,"Limba",,"East",,,,0,"ltr",,"L"
3593,,,"lmb",,"Merei",,,,,,0,"ltr",,"L"
3594,,,"lmc",,"Limilngan",,,,,,0,"ltr",,"L"
3595,,,"lmd",,"Lumun",,,,,,0,"ltr",,"L"
3596,,,"lme",,"Pévé",,,,,,0,"ltr",,"L"
3597,,,"lmf",,"Lembata",,"South",,,,0,"ltr",,"L"
3598,,,"lmg",,"Lamogai",,,,,,0,"ltr",,"L"
3599,,,"lmh",,"Lambichhong",,,,,,0,"ltr",,"L"
3600,,,"lmi",,"Lombi",,,,,,0,"ltr",,"L"
3601,,,"lmj",,"Lembata",,"West",,,,0,"ltr",,"L"
3602,,,"lmk",,"Lamkang",,,,,,0,"ltr",,"L"
3603,,,"lml",,"Hano",,,,,,0,"ltr",,"L"
3604,,,"lmm",,"Lamam",,,,,,0,"ltr",,"L"
3605,,,"lmn",,"Lambadi",,,,,,0,"ltr",,"L"
3606,,,"lmo",,"Lombard",,,,,,0,"ltr",,"L"
3607,,,"lmp",,"Limbum",,,,,,0,"ltr",,"L"
3608,,,"lmq",,"Lamatuka",,,,,,0,"ltr",,"L"
3609,,,"lmr",,"Lamalera",,,,,,0,"ltr",,"L"
3610,,,"lms",,"Limousin",,,,,,0,"ltr",,"L"
3611,,,"lmt",,"Lematang",,,,,,0,"ltr",,"L"
3612,,,"lmu",,"Lamenu",,,,,,0,"ltr",,"L"
3613,,,"lmv",,"Lomaiviti",,,,,,0,"ltr",,"L"
3614,,,"lmw",,"Miwok",,"Lake",,,,0,"ltr",,"L"
3615,,,"lmx",,"Laimbue",,,,,,0,"ltr",,"L"
3616,,,"lmy",,"Lamboya",,,,,,0,"ltr",,"L"
3617,,,"lmz",,"Lumbee",,,,,,0,"ltr",,"E"
3618,,,"lna",,"Langbashe",,,,,,0,"ltr",,"L"
3619,,,"lnb",,"Mbalanhu",,,,,,0,"ltr",,"L"
3620,,,"lnc",,"Languedocien",,,,,,0,"ltr",,"L"
3621,,,"lnd",,"Lundayeh",,,,,,0,"ltr",,"L"
3622,,,"lng",,"Langobardic",,,,,,0,"ltr",,"A"
3623,,,"lnh",,"Lanoh",,,,,,0,"ltr",,"L"
3624,,,"lni",,"Lantanai",,,,,,0,"ltr",,"L"
3625,,,"lnj",,"Leningitij",,,,,,0,"ltr",,"E"
3626,,,"lnl",,"Banda",,"South Central",,,,0,"ltr",,"L"
3627,,,"lnm",,"Langam",,,,,,0,"ltr",,"L"
3628,,,"lnn",,"Lorediakarkar",,,,,,0,"ltr",,"L"
3629,,,"lno",,"Lango","Sudan",,,,,0,"ltr",,"L"
3630,,,"lnq",,"Linga",,,,,,0,"ltr",,"C"
3631,,,"lns",,"Lamnso'",,,,,,0,"ltr",,"L"
3632,,,"lnt",,"Lintang",,,,,,0,"ltr",,"L"
3633,,,"lnu",,"Longuda",,,,,,0,"ltr",,"L"
3634,,,"lnz",,"Lonzo",,,,,,0,"ltr",,"L"
3635,,,"loa",,"Loloda",,,,,,0,"ltr",,"L"
3636,,,"lob",,"Lobi",,,,,,0,"ltr",,"L"
3637,,,"loc",,"Inonhan",,,,,,0,"ltr",,"L"
3638,,,"lod",,"Berawan",,,,,,0,"ltr",,"L"
3639,,,"loe",,"Saluan",,"Coastal",,,,0,"ltr",,"L"
3640,,,"lof",,"Logol",,,,,,0,"ltr",,"L"
3641,,,"log",,"Logo",,,,,,0,"ltr",,"L"
3642,,,"loh",,"Narim",,,,,,0,"ltr",,"L"
3643,,,"loi",,"Loma","Côte d'Ivoire",,,,,0,"ltr",,"L"
3644,,,"loj",,"Lou",,,,,,0,"ltr",,"L"
3645,,,"lok",,"Loko",,,,,,0,"ltr",,"L"
3646,,"lol","lol",,"Mongo",,,,,,0,"ltr",,"L"
3647,,,"lom",,"Loma","Liberia",,,,,0,"ltr",,"L"
3648,,,"lon",,"Lomwe",,"Malawi",,,,0,"ltr",,"L"
3649,,,"loo",,"Lombo",,,,,,0,"ltr",,"L"
3650,,,"lop",,"Lopa",,,,,,0,"ltr",,"L"
3651,,,"loq",,"Lobala",,,,,,0,"ltr",,"L"
3652,,,"lor",,"Téén",,,,,,0,"ltr",,"L"
3653,,,"los",,"Loniu",,,,,,0,"ltr",,"L"
3654,,,"lot",,"Otuho",,,,,,0,"ltr",,"L"
3655,,,"lou",,"Louisiana Creole French",,,,,,0,"ltr",,"L"
3656,,,"lov",,"Lopi",,,,,,0,"ltr",,"L"
3657,,,"low",,"Lobu",,"Tampias",,,,0,"ltr",,"L"
3658,,,"lox",,"Loun",,,,,,0,"ltr",,"L"
3659,,,"loy",,"Lowa",,,,,,0,"ltr",,"L"
3660,,"loz","loz",,"Lozi",,,,,,0,"ltr",,"L"
3661,,,"lpa",,"Lelepa",,,,,,0,"ltr",,"L"
3662,,,"lpe",,"Lepki",,,,,,0,"ltr",,"L"
3663,,,"lpo",,"Lipo",,,,,,0,"ltr",,"L"
3664,,,"lpx",,"Lopit",,,,,,0,"ltr",,"L"
3665,,,"lra",,"Lara'",,,,,,0,"ltr",,"L"
3666,,,"lrc",,"Luri",,"Northern",,,,0,"ltr",,"L"
3667,,,"lre",,"Laurentian",,,,,,0,"ltr",,"E"
3668,,,"lrg",,"Laragia",,,,,,0,"ltr",,"L"
3669,,,"lrk",,"Loarki",,,,,,0,"ltr",,"L"
3670,,,"lrl",,"Lari",,,,,,0,"ltr",,"L"
3671,,,"lrn",,"Lorang",,,,,,0,"ltr",,"L"
3672,,,"lro",,"Laro",,,,,,0,"ltr",,"L"
3673,,,"lrr",,"Lorung",,"Southern",,,,0,"ltr",,"L"
3674,,,"lrv",,"Larevat",,,,,,0,"ltr",,"L"
3675,,,"lsa",,"Lasgerdi",,,,,,0,"ltr",,"L"
3676,,,"lsd",,"Lishana Deni",,,,,,0,"ltr",,"L"
3677,,,"lse",,"Lusengo",,,,,,0,"ltr",,"L"
3678,,,"lsg",,"Lyons Sign Language",,,,,,0,"ltr",,"L"
3679,,,"lsi",,"Lashi",,,,,,0,"ltr",,"L"
3680,,,"lsl",,"Latvian Sign Language",,,,,,0,"ltr",,"L"
3681,,,"lso",,"Laos Sign Language",,,,,,0,"ltr",,"L"
3682,,,"lsr",,"Aruop",,,,,,0,"ltr",,"L"
3683,,,"lss",,"Lasi",,,,,,0,"ltr",,"L"
3684,,,"ltc",,"Chinese",,"Late Middle",,,,0,"ltr",,"H"
3685,,,"lti",,"Leti","Indonesia",,,,,0,"ltr",,"L"
3686,,,"ltu",,"Latu",,,,,,0,"ltr",,"L"
3687,"lb","ltz","ltz",,"Letzeburgesch",,,,,,0,"ltr",,"L"
3688,,"lua","lua",,"Luba-Lulua",,,,,,0,"ltr",,"L"
3689,"lu","lub","lub",,"Luba-Katanga",,,,,,0,"ltr",,"L"
3690,,,"luc",,"Aringa",,,,,,0,"ltr",,"L"
3691,,,"lud",,"Ludian",,,,,,0,"ltr",,"L"
3692,,,"lue",,"Luvale",,,,,,0,"ltr",,"L"
3693,,,"luf",,"Laua",,,,,,0,"ltr",,"L"
3694,"lg","lug","lug",,"Ganda",,,,,,0,"ltr",,"L"
3695,,"lui","lui",,"Luiseno",,,,,,0,"ltr",,"L"
3696,,,"luj",,"Luna",,,,,,0,"ltr",,"L"
3697,,,"luk",,"Lunanakha",,,,,,0,"ltr",,"L"
3698,,,"lul",,"Olu'bo",,,,,,0,"ltr",,"L"
3699,,,"lum",,"Luimbi",,,,,,0,"ltr",,"L"
3700,,"lun","lun",,"Lunda",,,,,,0,"ltr",,"L"
3701,,"luo","luo",,"Luo","Kenya and Tanzania",,,,,0,"ltr",,"L"
3702,,,"lup",,"Lumbu",,,,,,0,"ltr",,"L"
3703,,,"luq",,"Lucumi",,,,,,0,"ltr",,"L"
3704,,,"lur",,"Laura",,,,,,0,"ltr",,"L"
3705,,"lus","lus",,"Lushai",,,,,,0,"ltr",,"L"
3706,,,"lut",,"Lushootseed",,,,,,0,"ltr",,"L"
3707,,,"luu",,"Lumba-Yakkha",,,,,,0,"ltr",,"L"
3708,,,"luv",,"Luwati",,,,,,0,"ltr",,"L"
3709,,,"luw",,"Luo",,,,,,0,"ltr",,"L"
3710,,,"luy",,"Luyia",,,,,,0,"ltr",,"L"
3711,,,"luz",,"Luri",,"Southern",,,,0,"ltr",,"L"
3712,,,"lva",,"Maku'a",,,,,,0,"ltr",,"L"
3713,,,"lvk",,"Lavukaleve",,,,,,0,"ltr",,"L"
3714,,,"lvu",,"Levuka",,,,,,0,"ltr",,"L"
3715,,,"lwa",,"Lwalu",,,,,,0,"ltr",,"L"
3716,,,"lwe",,"Lewo Eleng",,,,,,0,"ltr",,"L"
3717,,,"lwh",,"Lachi",,"White",,,,0,"ltr",,"L"
3718,,,"lwl",,"Lawa",,"Eastern",,,,0,"ltr",,"L"
3719,,,"lwo",,"Luwo",,,,,,0,"ltr",,"L"
3720,,,"lwt",,"Lewotobi",,,,,,0,"ltr",,"L"
3721,,,"lww",,"Lewo",,,,,,0,"ltr",,"L"
3722,,,"lya",,"Layakha",,,,,,0,"ltr",,"L"
3723,,,"lyn",,"Luyana",,,,,,0,"ltr",,"L"
3724,,,"lzl",,"Litzlitz",,,,,,0,"ltr",,"L"
3725,,,"lzz",,"Laz",,,,,,0,"ltr",,"L"
3726,,,"maa",,"Mazatec",,"San Jerónimo Tecóatl",,,,0,"ltr",,"L"
3727,,,"mab",,"Mixtec",,"Yutanduchi",,,,0,"ltr",,"L"
3728,,"mad","mad",,"Madurese",,,,,,0,"ltr",,"L"
3729,,,"mae",,"Bo-Rukul",,,,,,0,"ltr",,"L"
3730,,,"maf",,"Mafa",,,,,,0,"ltr",,"L"
3731,,"mag","mag",,"Magahi",,,,,,0,"ltr",,"L"
3732,"mh","mah","mah",,"Marshall",,,,,,0,"ltr",,"L"
3733,,"mai","mai",,"Maithili",,,,,,0,"ltr",,"L"
3734,,,"maj",,"Mazatec",,"Jalapa De Díaz",,,,0,"ltr",,"L"
3735,,"mak","mak",,"Makasar",,,,,,0,"ltr",,"L"
3736,"ml","mal","mal",,"Malayalam",,,,,,0,"ltr",,"L"
3737,,,"mam",,"Mam",,"Northern",,,,0,"ltr",,"L"
3738,,"man","man",,"Mandingo",,,,,,1,"ltr",,"L"
3739,,,"maq",,"Mazatec",,"Chiquihuitlán",,,,0,"ltr",,"L"
3740,"mr","mar","mar",,"Marathi",,,,,,0,"ltr",,"L"
3741,,"mas","mas",,"Masai",,,,,,0,"ltr",,"L"
3742,,,"mat",,"Matlatzinca",,"San Francisco",,,,0,"ltr",,"L"
3743,,,"mau",,"Mazatec",,"Huautla",,,,0,"ltr",,"L"
3744,,,"mav",,"Sateré-Mawé",,,,,,0,"ltr",,"L"
3745,,,"maw",,"Mampruli",,,,,,0,"ltr",,"L"
3746,,,"max",,"Malay",,"North Moluccan",,,,0,"ltr",,"L"
3747,,,"maz",,"Mazahua Central",,,,,,0,"ltr",,"L"
3748,,,"mba",,"Higaonon",,,,,,0,"ltr",,"L"
3749,,,"mbb",,"Manobo",,"Western Bukidnon",,,,0,"ltr",,"L"
3750,,,"mbc",,"Macushi",,,,,,0,"ltr",,"L"
3751,,,"mbd",,"Manobo",,"Dibabawon",,,,0,"ltr",,"L"
3752,,,"mbe",,"Molale",,,,,,0,"ltr",,"E"
3753,,,"mbf",,"Malay",,"Baba",,,,0,"ltr",,"L"
3754,,,"mbg",,"Nambikuára",,"Northern",,,,0,"ltr",,"L"
3755,,,"mbh",,"Mangseng",,,,,,0,"ltr",,"L"
3756,,,"mbi",,"Manobo",,"Ilianen",,,,0,"ltr",,"L"
3757,,,"mbj",,"Nadëb",,,,,,0,"ltr",,"L"
3758,,,"mbk",,"Malol",,,,,,0,"ltr",,"L"
3759,,,"mbl",,"Maxakalí",,,,,,0,"ltr",,"L"
3760,,,"mbm",,"Ombamba",,,,,,0,"ltr",,"L"
3761,,,"mbn",,"Macaguán",,,,,,0,"ltr",,"L"
3762,,,"mbo",,"Mbo","Cameroon",,,,,0,"ltr",,"L"
3763,,,"mbp",,"Malayo",,,,,,0,"ltr",,"L"
3764,,,"mbq",,"Maisin",,,,,,0,"ltr",,"L"
3765,,,"mbr",,"Nukak Makú",,,,,,0,"ltr",,"L"
3766,,,"mbs",,"Manobo",,"Sarangani",,,,0,"ltr",,"L"
3767,,,"mbt",,"Manobo",,"Matigsalug",,,,0,"ltr",,"L"
3768,,,"mbu",,"Mbula-Bwazza",,,,,,0,"ltr",,"L"
3769,,,"mbv",,"Mbulungish",,,,,,0,"ltr",,"L"
3770,,,"mbw",,"Maring",,,,,,0,"ltr",,"L"
3771,,,"mbx",,"Mari","East Sepik Province",,,,,0,"ltr",,"L"
3772,,,"mby",,"Memoni",,,,,,0,"ltr",,"L"
3773,,,"mbz",,"Mixtec",,"Amoltepec",,,,0,"ltr",,"L"
3774,,,"mca",,"Maca",,,,,,0,"ltr",,"L"
3775,,,"mcb",,"Machiguenga",,,,,,0,"ltr",,"L"
3776,,,"mcc",,"Bitur",,,,,,0,"ltr",,"L"
3777,,,"mcd",,"Sharanahua",,,,,,0,"ltr",,"L"
3778,,,"mce",,"Mixtec",,"Itundujia",,,,0,"ltr",,"L"
3779,,,"mcf",,"Matsés",,,,,,0,"ltr",,"L"
3780,,,"mcg",,"Mapoyo",,,,,,0,"ltr",,"L"
3781,,,"mch",,"Maquiritari",,,,,,0,"ltr",,"L"
3782,,,"mci",,"Mese",,,,,,0,"ltr",,"L"
3783,,,"mcj",,"Mvanip",,,,,,0,"ltr",,"L"
3784,,,"mck",,"Mbunda",,,,,,0,"ltr",,"L"
3785,,,"mcl",,"Macaguaje",,,,,,0,"ltr",,"E"
3786,,,"mcm",,"Malaccan Creole Portuguese",,,,,,0,"ltr",,"L"
3787,,,"mcn",,"Masana",,,,,,0,"ltr",,"L"
3788,,,"mco",,"Mixe",,"Coatlán",,,,0,"ltr",,"L"
3789,,,"mcp",,"Makaa",,,,,,0,"ltr",,"L"
3790,,,"mcq",,"Ese",,,,,,0,"ltr",,"L"
3791,,,"mcr",,"Menya",,,,,,0,"ltr",,"L"
3792,,,"mcs",,"Mambai",,,,,,0,"ltr",,"L"
3793,,,"mct",,"Mengisa",,,,,,0,"ltr",,"L"
3794,,,"mcu",,"Mambila",,"Cameroon",,,,0,"ltr",,"L"
3795,,,"mcv",,"Minanibai",,,,,,0,"ltr",,"L"
3796,,,"mcw",,"Mawa","Chad",,,,,0,"ltr",,"L"
3797,,,"mcx",,"Mpiemo",,,,,,0,"ltr",,"L"
3798,,,"mcy",,"Watut",,"South",,,,0,"ltr",,"L"
3799,,,"mcz",,"Mawan",,,,,,0,"ltr",,"L"
3800,,,"mda",,"Mada","Nigeria",,,,,0,"ltr",,"L"
3801,,,"mdb",,"Morigi",,,,,,0,"ltr",,"L"
3802,,,"mdc",,"Male","Papua New Guinea",,,,,0,"ltr",,"L"
3803,,,"mdd",,"Mbum",,,,,,0,"ltr",,"L"
3804,,,"mde",,"Maba","Chad",,,,,0,"ltr",,"L"
3805,,"mdf","mdf",,"Moksha",,,,,,0,"ltr",,"L"
3806,,,"mdg",,"Massalat",,,,,,0,"ltr",,"L"
3807,,,"mdh",,"Maguindanao",,,,,,0,"ltr",,"L"
3808,,,"mdi",,"Mamvu",,,,,,0,"ltr",,"L"
3809,,,"mdj",,"Mangbetu",,,,,,0,"ltr",,"L"
3810,,,"mdk",,"Mangbutu",,,,,,0,"ltr",,"L"
3811,,,"mdl",,"Maltese Sign Language",,,,,,0,"ltr",,"L"
3812,,,"mdm",,"Mayogo",,,,,,0,"ltr",,"L"
3813,,,"mdn",,"Mbati",,,,,,0,"ltr",,"L"
3814,,,"mdo",,"Gbaya",,"Southwest",,,,0,"ltr",,"L"
3815,,,"mdp",,"Mbala",,,,,,0,"ltr",,"L"
3816,,,"mdq",,"Mbole",,,,,,0,"ltr",,"L"
3817,,"mdr","mdr",,"Mandar",,,,,,0,"ltr",,"L"
3818,,,"mds",,"Maria","Papua New Guinea",,,,,0,"ltr",,"L"
3819,,,"mdt",,"Mbere",,,,,,0,"ltr",,"L"
3820,,,"mdu",,"Mboko",,,,,,0,"ltr",,"L"
3821,,,"mdv",,"Mixtec",,"Santa Lucía Monteverde",,,,0,"ltr",,"L"
3822,,,"mdw",,"Mbosi",,,,,,0,"ltr",,"L"
3823,,,"mdx",,"Dizi",,,,,,0,"ltr",,"L"
3824,,,"mdy",,"Male","Ethiopia",,,,,0,"ltr",,"L"
3825,,,"mdz",,"Suruí Do Pará",,,,,,0,"ltr",,"L"
3826,,,"mea",,"Menka",,,,,,0,"ltr",,"L"
3827,,,"meb",,"Ikobi-Mena",,,,,,0,"ltr",,"L"
3828,,,"mec",,"Mara",,,,,,0,"ltr",,"L"
3829,,,"med",,"Melpa",,,,,,0,"ltr",,"L"
3830,,,"mee",,"Mengen",,,,,,0,"ltr",,"L"
3831,,,"mef",,"Megam",,,,,,0,"ltr",,"L"
3832,,,"meg",,"Mea",,,,,,0,"ltr",,"L"
3833,,,"meh",,"Mixtec",,"Southwestern Tlaxiaco",,,,0,"ltr",,"L"
3834,,,"mei",,"Midob",,,,,,0,"ltr",,"L"
3835,,,"mej",,"Meyah",,,,,,0,"ltr",,"L"
3836,,,"mek",,"Mekeo",,,,,,0,"ltr",,"L"
3837,,,"mel",,"Melanau",,,,,,0,"ltr",,"L"
3838,,,"mem",,"Mangala",,,,,,0,"ltr",,"E"
3839,,"men","men",,"Mende","Sierra Leone",,,,,0,"ltr",,"L"
3840,,,"meo",,"Malay",,"Kedah",,,,0,"ltr",,"L"
3841,,,"mep",,"Miriwung",,,,,,0,"ltr",,"L"
3842,,,"meq",,"Merey",,,,,,0,"ltr",,"L"
3843,,,"mer",,"Meru",,,,,,0,"ltr",,"L"
3844,,,"mes",,"Masmaje",,,,,,0,"ltr",,"L"
3845,,,"met",,"Mato",,,,,,0,"ltr",,"L"
3846,,,"meu",,"Motu",,,,,,0,"ltr",,"L"
3847,,,"mev",,"Mann",,,,,,0,"ltr",,"L"
3848,,,"mew",,"Maaka",,,,,,0,"ltr",,"L"
3849,,,"mey",,"Hassaniyya",,,,,,0,"ltr",,"L"
3850,,,"mez",,"Menominee",,,,,,0,"ltr",,"L"
3851,,,"mfa",,"Malay",,"Pattani",,,,0,"ltr",,"L"
3852,,,"mfb",,"Lom",,,,,,0,"ltr",,"L"
3853,,,"mfc",,"Mba",,,,,,0,"ltr",,"L"
3854,,,"mfd",,"Mendankwe-Nkwen",,,,,,0,"ltr",,"L"
3855,,,"mfe",,"Morisyen",,,,,,0,"ltr",,"L"
3856,,,"mff",,"Naki",,,,,,0,"ltr",,"L"
3857,,,"mfg",,"Mixifore",,,,,,0,"ltr",,"L"
3858,,,"mfh",,"Matal",,,,,,0,"ltr",,"L"
3859,,,"mfi",,"Wandala",,,,,,0,"ltr",,"L"
3860,,,"mfj",,"Mefele",,,,,,0,"ltr",,"L"
3861,,,"mfk",,"Mofu",,"North",,,,0,"ltr",,"L"
3862,,,"mfl",,"Putai",,,,,,0,"ltr",,"L"
3863,,,"mfm",,"Marghi South",,,,,,0,"ltr",,"L"
3864,,,"mfn",,"Mbembe",,"Cross River",,,,0,"ltr",,"L"
3865,,,"mfo",,"Mbe",,,,,,0,"ltr",,"L"
3866,,,"mfp",,"Malay",,"Makassar",,,,0,"ltr",,"L"
3867,,,"mfq",,"Moba",,,,,,0,"ltr",,"L"
3868,,,"mfr",,"Marithiel",,,,,,0,"ltr",,"L"
3869,,,"mfs",,"Mexican Sign Language",,,,,,0,"ltr",,"L"
3870,,,"mft",,"Mokerang",,,,,,0,"ltr",,"L"
3871,,,"mfu",,"Mbwela",,,,,,0,"ltr",,"L"
3872,,,"mfv",,"Mandjak",,,,,,0,"ltr",,"L"
3873,,,"mfw",,"Mulaha",,,,,,0,"ltr",,"E"
3874,,,"mfx",,"Melo",,,,,,0,"ltr",,"L"
3875,,,"mfy",,"Mayo",,,,,,0,"ltr",,"L"
3876,,,"mfz",,"Mabaan",,,,,,0,"ltr",,"L"
3877,,"mga","mga",,"Irish",,"Middle (900-1200)",,,,0,"ltr",,"H"
3878,,,"mgb",,"Mararit",,,,,,0,"ltr",,"L"
3879,,,"mgc",,"Morokodo",,,,,,0,"ltr",,"L"
3880,,,"mgd",,"Moru",,,,,,0,"ltr",,"L"
3881,,,"mge",,"Mango",,,,,,0,"ltr",,"L"
3882,,,"mgf",,"Maklew",,,,,,0,"ltr",,"L"
3883,,,"mgg",,"Mpongmpong",,,,,,0,"ltr",,"L"
3884,,,"mgh",,"Makhuwa-Meetto",,,,,,0,"ltr",,"L"
3885,,,"mgi",,"Lijili",,,,,,0,"ltr",,"L"
3886,,,"mgj",,"Abureni",,,,,,0,"ltr",,"L"
3887,,,"mgk",,"Mawes",,,,,,0,"ltr",,"L"
3888,,,"mgl",,"Maleu-Kilenge",,,,,,0,"ltr",,"L"
3889,,,"mgm",,"Mambae",,,,,,0,"ltr",,"L"
3890,,,"mgn",,"Mbangi",,,,,,0,"ltr",,"L"
3891,,,"mgo",,"Meta'",,,,,,0,"ltr",,"L"
3892,,,"mgp",,"Magar",,"Eastern",,,,0,"ltr",,"L"
3893,,,"mgq",,"Malila",,,,,,0,"ltr",,"L"
3894,,,"mgr",,"Mambwe-Lungu",,,,,,0,"ltr",,"L"
3895,,,"mgs",,"Manda","Tanzania",,,,,0,"ltr",,"L"
3896,,,"mgt",,"Mongol",,,,,,0,"ltr",,"L"
3897,,,"mgu",,"Mailu",,,,,,0,"ltr",,"L"
3898,,,"mgv",,"Matengo",,,,,,0,"ltr",,"L"
3899,,,"mgw",,"Matumbi",,,,,,0,"ltr",,"L"
3900,,,"mgx",,"Omati",,,,,,0,"ltr",,"L"
3901,,,"mgy",,"Mbunga",,,,,,0,"ltr",,"L"
3902,,,"mgz",,"Mbugwe",,,,,,0,"ltr",,"L"
3903,,,"mha",,"Manda","India",,,,,0,"ltr",,"L"
3904,,,"mhb",,"Mahongwe",,,,,,0,"ltr",,"L"
3905,,,"mhc",,"Mocho",,,,,,0,"ltr",,"L"
3906,,,"mhd",,"Mbugu",,,,,,0,"ltr",,"L"
3907,,,"mhe",,"Besisi",,,,,,0,"ltr",,"L"
3908,,,"mhf",,"Mamaa",,,,,,0,"ltr",,"L"
3909,,,"mhg",,"Margu",,,,,,0,"ltr",,"L"
3910,,,"mhh",,"Maskoy Pidgin",,,,,,0,"ltr",,"L"
3911,,,"mhi",,"Ma'di",,,,,,0,"ltr",,"L"
3912,,,"mhj",,"Mogholi",,,,,,0,"ltr",,"L"
3913,,,"mhk",,"Mungaka",,,,,,0,"ltr",,"L"
3914,,,"mhl",,"Mauwake",,,,,,0,"ltr",,"L"
3915,,,"mhm",,"Makhuwa-Moniga",,,,,,0,"ltr",,"L"
3916,,,"mhn",,"Mócheno",,,,,,0,"ltr",,"L"
3917,,,"mho",,"Mashi","Zambia",,,,,0,"ltr",,"L"
3918,,,"mhp",,"Malay",,"Balinese",,,,0,"ltr",,"L"
3919,,,"mhq",,"Mandan",,,,,,0,"ltr",,"L"
3920,,,"mhr",,"Mari",,"Eastern",,,,0,"ltr",,"L"
3921,,,"mhs",,"Buru","Indonesia",,,,,0,"ltr",,"L"
3922,,,"mht",,"Mandahuaca",,,,,,0,"ltr",,"L"
3923,,,"mhu",,"Digaro-Mishmi",,,,,,0,"ltr",,"L"
3924,,,"mhv",,"Arakanese",,,,,,0,"ltr",,"L"
3925,,,"mhw",,"Mbukushu",,,,,,0,"ltr",,"L"
3926,,,"mhx",,"Maru",,,,,,0,"ltr",,"L"
3927,,,"mhy",,"Ma'anyan",,,,,,0,"ltr",,"L"
3928,,,"mhz",,"Mor","Mor Islands",,,,,0,"ltr",,"L"
3929,,,"mia",,"Miami",,,,,,0,"ltr",,"E"
3930,,,"mib",,"Mixtec",,"Atatláhuca",,,,0,"ltr",,"L"
3931,,"mic","mic",,"Micmac",,,,,,0,"ltr",,"L"
3932,,,"mid",,"Mandaic",,,,,,0,"ltr",,"L"
3933,,,"mie",,"Mixtec",,"Ocotepec",,,,0,"ltr",,"L"
3934,,,"mif",,"Mofu-Gudur",,,,,,0,"ltr",,"L"
3935,,,"mig",,"Mixtec",,"San Miguel El Grande",,,,0,"ltr",,"L"
3936,,,"mih",,"Mixtec",,"Chayuco",,,,0,"ltr",,"L"
3937,,,"mii",,"Mixtec",,"Chigmecatitlán",,,,0,"ltr",,"L"
3938,,,"mij",,"Abar",,,,,,0,"ltr",,"L"
3939,,,"mik",,"Mikasuki",,,,,,0,"ltr",,"L"
3940,,,"mil",,"Mixtec",,"Peñoles",,,,0,"ltr",,"L"
3941,,,"mim",,"Mixtec",,"Alacatlatzala",,,,0,"ltr",,"L"
3942,,"min","min",,"Minangkabau",,,,,,0,"ltr",,"L"
3943,,,"mio",,"Mixtec",,"Pinotepa Nacional",,,,0,"ltr",,"L"
3944,,,"mip",,"Mixtec",,"Apasco-Apoala",,,,0,"ltr",,"L"
3945,,,"miq",,"Mískito",,,,,,0,"ltr",,"L"
3946,,,"mir",,"Mixe",,"Isthmus",,,,0,"ltr",,"L"
3947,,,"mit",,"Mixtec",,"Southern Puebla",,,,0,"ltr",,"L"
3948,,,"miu",,"Mixtec",,"Cacaloxtepec",,,,0,"ltr",,"L"
3949,,,"miv",,"Mimi",,,,,,0,"ltr",,"L"
3950,,,"miw",,"Akoye",,,,,,0,"ltr",,"L"
3951,,,"mix",,"Mixtec",,"Mixtepec",,,,0,"ltr",,"L"
3952,,,"miy",,"Mixtec",,"Ayutla",,,,0,"ltr",,"L"
3953,,,"miz",,"Mixtec",,"Coatzospan",,,,0,"ltr",,"L"
3954,,,"mja",,"Mahei",,,,,,0,"ltr",,"L"
3955,,,"mjc",,"Mixtec",,"San Juan Colorado",,,,0,"ltr",,"L"
3956,,,"mjd",,"Maidu",,"Northwest",,,,0,"ltr",,"L"
3957,,,"mje",,"Muskum",,,,,,0,"ltr",,"E"
3958,,,"mjg",,"Tu",,,,,,0,"ltr",,"L"
3959,,,"mjh",,"Mwera","Nyasa",,,,,0,"ltr",,"L"
3960,,,"mji",,"Kim Mun",,,,,,0,"ltr",,"L"
3961,,,"mjj",,"Mawak",,,,,,0,"ltr",,"L"
3962,,,"mjk",,"Matukar",,,,,,0,"ltr",,"L"
3963,,,"mjl",,"Mandeali",,,,,,0,"ltr",,"L"
3964,,,"mjm",,"Medebur",,,,,,0,"ltr",,"L"
3965,,,"mjn",,"Ma","Papua New Guinea",,,,,0,"ltr",,"L"
3966,,,"mjo",,"Malankuravan",,,,,,0,"ltr",,"L"
3967,,,"mjp",,"Malapandaram",,,,,,0,"ltr",,"L"
3968,,,"mjq",,"Malaryan",,,,,,0,"ltr",,"L"
3969,,,"mjr",,"Malavedan",,,,,,0,"ltr",,"L"
3970,,,"mjs",,"Miship",,,,,,0,"ltr",,"L"
3971,,,"mjt",,"Sauria Paharia",,,,,,0,"ltr",,"L"
3972,,,"mju",,"Manna-Dora",,,,,,0,"ltr",,"L"
3973,,,"mjv",,"Mannan",,,,,,0,"ltr",,"L"
3974,,,"mjw",,"Karbi",,,,,,0,"ltr",,"L"
3975,,,"mjx",,"Mahali",,,,,,0,"ltr",,"L"
3976,,,"mjy",,"Mahican",,,,,,0,"ltr",,"E"
3977,,,"mjz",,"Majhi",,,,,,0,"ltr",,"L"
3978,,,"mka",,"Mbre",,,,,,0,"ltr",,"L"
3979,,,"mkb",,"Mal Paharia",,,,,,0,"ltr",,"L"
3980,,,"mkc",,"Siliput",,,,,,0,"ltr",,"L"
3981,"mk","mkd","mkd",,"Macedonian",,,"Македонски",,,0,"ltr",,"L"
3982,,,"mke",,"Mawchi",,,,,,0,"ltr",,"L"
3983,,,"mkf",,"Miya",,,,,,0,"ltr",,"L"
3984,,,"mkg",,"Mak","China",,,,,0,"ltr",,"L"
3985,,,"mki",,"Dhatki",,,,,,0,"ltr",,"L"
3986,,,"mkj",,"Mokilese",,,,,,0,"ltr",,"L"
3987,,,"mkk",,"Byep",,,,,,0,"ltr",,"L"
3988,,,"mkl",,"Mokole",,,,,,0,"ltr",,"L"
3989,,,"mkm",,"Moklen",,,,,,0,"ltr",,"L"
3990,,,"mkn",,"Malay",,"Kupang",,,,0,"ltr",,"L"
3991,,,"mko",,"Mingang Doso",,,,,,0,"ltr",,"L"
3992,,,"mkp",,"Moikodi",,,,,,0,"ltr",,"L"
3993,,,"mkq",,"Miwok",,"Bay",,,,0,"ltr",,"E"
3994,,,"mkr",,"Malas",,,,,,0,"ltr",,"L"
3995,,,"mks",,"Mixtec",,"Silacayoapan",,,,0,"ltr",,"L"
3996,,,"mkt",,"Vamale",,,,,,0,"ltr",,"L"
3997,,,"mku",,"Maninka",,"Konyanka",,,,0,"ltr",,"L"
3998,,,"mkv",,"Mafea",,,,,,0,"ltr",,"L"
3999,,,"mkw",,"Kituba","Congo",,,,,0,"ltr",,"L"
4000,,,"mkx",,"Manobo",,"Cinamiguin",,,,0,"ltr",,"L"
4001,,,"mky",,"Makian",,"East",,,,0,"ltr",,"L"
4002,,,"mkz",,"Makasae",,,,,,0,"ltr",,"L"
4003,,,"mla",,"Malo",,,,,,0,"ltr",,"L"
4004,,,"mlb",,"Mbule",,,,,,0,"ltr",,"L"
4005,,,"mlc",,"Cao Lan",,,,,,0,"ltr",,"L"
4006,,,"mld",,"Malakhel",,,,,,0,"ltr",,"L"
4007,,,"mle",,"Manambu",,,,,,0,"ltr",,"L"
4008,,,"mlf",,"Mal",,,,,,0,"ltr",,"L"
4009,"mg","mlg","mlg",,"Malagasy",,,,,,1,"ltr",,"L"
4010,,,"mlh",,"Mape",,,,,,0,"ltr",,"L"
4011,,,"mli",,"Malimpung",,,,,,0,"ltr",,"L"
4012,,,"mlj",,"Miltu",,,,,,0,"ltr",,"L"
4013,,,"mlk",,"Malakote",,,,,,0,"ltr",,"L"
4014,,,"mll",,"Malua Bay",,,,,,0,"ltr",,"L"
4015,,,"mlm",,"Mulam",,,,,,0,"ltr",,"L"
4016,,,"mln",,"Malango",,,,,,0,"ltr",,"L"
4017,,,"mlo",,"Mlomp",,,,,,0,"ltr",,"L"
4018,,,"mlp",,"Bargam",,,,,,0,"ltr",,"L"
4019,,,"mlq",,"Maninkakan",,"Western",,,,0,"ltr",,"L"
4020,,,"mlr",,"Vame",,,,,,0,"ltr",,"L"
4021,,,"mls",,"Masalit",,,,,,0,"ltr",,"L"
4022,"mt","mlt","mlt",,"Maltese",,,"Malti",,,0,"ltr",,"L"
4023,,,"mlu",,"To'abaita",,,,,,0,"ltr",,"L"
4024,,,"mlv",,"Motlav",,,,,,0,"ltr",,"L"
4025,,,"mlw",,"Moloko",,,,,,0,"ltr",,"L"
4026,,,"mlx",,"Malfaxal",,,,,,0,"ltr",,"L"
4027,,,"mly",,"Malay","specific",,,,,0,"ltr",,"L"
4028,,,"mlz",,"Malaynon",,,,,,0,"ltr",,"L"
4029,,,"mma",,"Mama",,,,,,0,"ltr",,"L"
4030,,,"mmb",,"Momina",,,,,,0,"ltr",,"L"
4031,,,"mmc",,"Mazahua",,"Michoacán",,,,0,"ltr",,"L"
4032,,,"mmd",,"Maonan",,,,,,0,"ltr",,"L"
4033,,,"mme",,"Mae",,,,,,0,"ltr",,"L"
4034,,,"mmf",,"Mundat",,,,,,0,"ltr",,"L"
4035,,,"mmg",,"Ambrym",,"North",,,,0,"ltr",,"L"
4036,,,"mmh",,"Mehináku",,,,,,0,"ltr",,"L"
4037,,,"mmi",,"Musar",,,,,,0,"ltr",,"L"
4038,,,"mmj",,"Majhwar",,,,,,0,"ltr",,"L"
4039,,,"mmk",,"Mukha-Dora",,,,,,0,"ltr",,"L"
4040,,,"mml",,"Man Met",,,,,,0,"ltr",,"L"
4041,,,"mmm",,"Maii",,,,,,0,"ltr",,"L"
4042,,,"mmn",,"Mamanwa",,,,,,0,"ltr",,"L"
4043,,,"mmo",,"Buang",,"Mangga",,,,0,"ltr",,"L"
4044,,,"mmp",,"Musan",,,,,,0,"ltr",,"L"
4045,,,"mmq",,"Musak",,,,,,0,"ltr",,"L"
4046,,,"mmr",,"Hmong",,"Western Xiangxi",,,,0,"ltr",,"L"
4047,,,"mms",,"Mam",,"Southern",,,,0,"ltr",,"L"
4048,,,"mmt",,"Malalamai",,,,,,0,"ltr",,"L"
4049,,,"mmu",,"Mmaala",,,,,,0,"ltr",,"L"
4050,,,"mmv",,"Miriti",,,,,,0,"ltr",,"E"
4051,,,"mmw",,"Emae",,,,,,0,"ltr",,"L"
4052,,,"mmx",,"Madak",,,,,,0,"ltr",,"L"
4053,,,"mmy",,"Migaama",,,,,,0,"ltr",,"L"
4054,,,"mmz",,"Mabaale",,,,,,0,"ltr",,"L"
4055,,,"mna",,"Mbula",,,,,,0,"ltr",,"L"
4056,,,"mnb",,"Muna",,,,,,0,"ltr",,"L"
4057,,"mnc","mnc",,"Manchu",,,,,,0,"ltr",,"L"
4058,,,"mnd",,"Mondé",,,,,,0,"ltr",,"L"
4059,,,"mne",,"Naba",,,,,,0,"ltr",,"L"
4060,,,"mnf",,"Mundani",,,,,,0,"ltr",,"L"
4061,,,"mng",,"Mnong",,"Eastern",,,,0,"ltr",,"L"
4062,,,"mnh",,"Mono","Democratic Republic of Congo",,,,,0,"ltr",,"L"
4063,,"mni","mni",,"Manipuri",,,,,,0,"ltr",,"L"
4064,,,"mnj",,"Munji",,,,,,0,"ltr",,"L"
4065,,,"mnk",,"Mandinka",,,,,,0,"ltr",,"L"
4066,,,"mnl",,"Tiale",,,,,,0,"ltr",,"L"
4067,,,"mnm",,"Mapena",,,,,,0,"ltr",,"L"
4068,,,"mnn",,"Mnong",,"Southern",,,,0,"ltr",,"L"
4069,,,"mnp",,"Chinese",,"Min Bei",,,,0,"ltr",,"L"
4070,,,"mnq",,"Minriq",,,,,,0,"ltr",,"L"
4071,,,"mnr",,"Mono","USA",,,,,0,"ltr",,"L"
4072,,,"mns",,"Mansi",,,,,,0,"ltr",,"L"
4073,,,"mnt",,"Maykulan",,,,,,0,"ltr",,"E"
4074,,,"mnu",,"Mer",,,,,,0,"ltr",,"L"
4075,,,"mnv",,"Rennell-Belona",,,,,,0,"ltr",,"L"
4076,,,"mnw",,"Mon",,,,,,0,"ltr",,"L"
4077,,,"mnx",,"Manikion",,,,,,0,"ltr",,"L"
4078,,,"mny",,"Manyawa",,,,,,0,"ltr",,"L"
4079,,,"mnz",,"Moni",,,,,,0,"ltr",,"L"
4080,,,"moa",,"Mwan",,,,,,0,"ltr",,"L"
4081,,,"mob",,"Moinba",,,,,,0,"ltr",,"L"
4082,,,"moc",,"Mocoví",,,,,,0,"ltr",,"L"
4083,,,"mod",,"Mobilian",,,,,,0,"ltr",,"E"
4084,,,"moe",,"Montagnais",,,,,,0,"ltr",,"L"
4085,,,"mof",,"Mohegan-Montauk-Narragansett",,,,,,0,"ltr",,"E"
4086,,,"mog",,"Mongondow",,,,,,0,"ltr",,"L"
4087,,"moh","moh",,"Mohawk",,,,,,0,"ltr",,"L"
4088,,,"moi",,"Mboi",,,,,,0,"ltr",,"L"
4089,,,"moj",,"Monzombo",,,,,,0,"ltr",,"L"
4090,,,"mok",,"Morori",,,,,,0,"ltr",,"L"
4091,"mo","mol","mol",,"Moldavian",,,,,,0,"ltr",,"L"
4092,,,"mom",,"Monimbo",,,,,,0,"ltr",,"E"
4093,"mn","mon","mon",,"Mongolian",,,,,,1,"ltr",,"L"
4094,,,"moo",,"Monom",,,,,,0,"ltr",,"L"
4095,,,"mop",,"Mopán Maya",,,,,,0,"ltr",,"L"
4096,,,"moq",,"Mor","Bomberai Peninsula",,,,,0,"ltr",,"L"
4097,,,"mor",,"Moro",,,,,,0,"ltr",,"L"
4098,,"mos","mos",,"Mossi",,,,,,0,"ltr",,"L"
4099,,,"mot",,"Barí",,,,,,0,"ltr",,"L"
4100,,,"mou",,"Mogum",,,,,,0,"ltr",,"L"
4101,,,"mov",,"Mohave",,,,,,0,"ltr",,"L"
4102,,,"mow",,"Moi","Congo",,,,,0,"ltr",,"L"
4103,,,"mox",,"Molima",,,,,,0,"ltr",,"L"
4104,,,"moy",,"Shekkacho",,,,,,0,"ltr",,"L"
4105,,,"moz",,"Mukulu",,,,,,0,"ltr",,"L"
4106,,,"mpa",,"Mpoto",,,,,,0,"ltr",,"L"
4107,,,"mpb",,"Mullukmulluk",,,,,,0,"ltr",,"L"
4108,,,"mpc",,"Mangarayi",,,,,,0,"ltr",,"L"
4109,,,"mpd",,"Machinere",,,,,,0,"ltr",,"L"
4110,,,"mpe",,"Majang",,,,,,0,"ltr",,"L"
4111,,,"mpf",,"Mam",,"Tajumulco",,,,0,"ltr",,"L"
4112,,,"mpg",,"Marba",,,,,,0,"ltr",,"L"
4113,,,"mph",,"Maung",,,,,,0,"ltr",,"L"
4114,,,"mpi",,"Mpade",,,,,,0,"ltr",,"L"
4115,,,"mpj",,"Martu Wangka",,,,,,0,"ltr",,"L"
4116,,,"mpk",,"Mbara","Chad",,,,,0,"ltr",,"L"
4117,,,"mpl",,"Watut",,"Middle",,,,0,"ltr",,"L"
4118,,,"mpm",,"Mixtec",,"Yosondúa",,,,0,"ltr",,"L"
4119,,,"mpn",,"Mindiri",,,,,,0,"ltr",,"L"
4120,,,"mpo",,"Miu",,,,,,0,"ltr",,"L"
4121,,,"mpp",,"Migabac",,,,,,0,"ltr",,"L"
4122,,,"mpq",,"Matís",,,,,,0,"ltr",,"L"
4123,,,"mpr",,"Vangunu",,,,,,0,"ltr",,"L"
4124,,,"mps",,"Dadibi",,,,,,0,"ltr",,"L"
4125,,,"mpt",,"Mian",,,,,,0,"ltr",,"L"
4126,,,"mpu",,"Makuráp",,,,,,0,"ltr",,"L"
4127,,,"mpv",,"Munkip",,,,,,0,"ltr",,"L"
4128,,,"mpw",,"Mapidian",,,,,,0,"ltr",,"L"
4129,,,"mpx",,"Misima-Paneati",,,,,,0,"ltr",,"L"
4130,,,"mpy",,"Mapia",,,,,,0,"ltr",,"L"
4131,,,"mpz",,"Mpi",,,,,,0,"ltr",,"L"
4132,,,"mqa",,"Maba","Indonesia",,,,,0,"ltr",,"L"
4133,,,"mqb",,"Mbuko",,,,,,0,"ltr",,"L"
4134,,,"mqc",,"Mangole",,,,,,0,"ltr",,"L"
4135,,,"mqd",,"Madang",,,,,,0,"ltr",,"L"
4136,,,"mqe",,"Matepi",,,,,,0,"ltr",,"L"
4137,,,"mqf",,"Momuna",,,,,,0,"ltr",,"L"
4138,,,"mqg",,"Malay",,"Kota Bangun Kutai",,,,0,"ltr",,"L"
4139,,,"mqh",,"Mixtec",,"Tlazoyaltepec",,,,0,"ltr",,"L"
4140,,,"mqi",,"Mariri",,,,,,0,"ltr",,"L"
4141,,,"mqj",,"Mamasa",,,,,,0,"ltr",,"L"
4142,,,"mqk",,"Manobo",,"Rajah Kabunsuwan",,,,0,"ltr",,"L"
4143,,,"mql",,"Mbelime",,,,,,0,"ltr",,"L"
4144,,,"mqm",,"Marquesan",,"South",,,,0,"ltr",,"L"
4145,,,"mqn",,"Moronene",,,,,,0,"ltr",,"L"
4146,,,"mqo",,"Modole",,,,,,0,"ltr",,"L"
4147,,,"mqp",,"Manipa",,,,,,0,"ltr",,"L"
4148,,,"mqq",,"Minokok",,,,,,0,"ltr",,"L"
4149,,,"mqr",,"Mander",,,,,,0,"ltr",,"L"
4150,,,"mqs",,"Makian",,"West",,,,0,"ltr",,"L"
4151,,,"mqt",,"Mok",,,,,,0,"ltr",,"L"
4152,,,"mqu",,"Mandari",,,,,,0,"ltr",,"L"
4153,,,"mqv",,"Mosimo",,,,,,0,"ltr",,"L"
4154,,,"mqw",,"Murupi",,,,,,0,"ltr",,"L"
4155,,,"mqx",,"Mamuju",,,,,,0,"ltr",,"L"
4156,,,"mqy",,"Manggarai",,,,,,0,"ltr",,"L"
4157,,,"mqz",,"Malasanga",,,,,,0,"ltr",,"L"
4158,,,"mra",,"Mlabri",,,,,,0,"ltr",,"L"
4159,,,"mrb",,"Marino",,,,,,0,"ltr",,"L"
4160,,,"mrc",,"Maricopa",,,,,,0,"ltr",,"L"
4161,,,"mrd",,"Magar",,"Western",,,,0,"ltr",,"L"
4162,,,"mre",,"Martha's Vineyard Sign Language",,,,,,0,"ltr",,"E"
4163,,,"mrf",,"Elseng",,,,,,0,"ltr",,"L"
4164,,,"mrg",,"Miri",,,,,,0,"ltr",,"L"
4165,,,"mrh",,"Chin",,"Mara",,,,0,"ltr",,"L"
4166,"mi","mri","mri",,"Maori",,,,,,0,"ltr",,"L"
4167,,,"mrj",,"Mari",,"Western",,,,0,"ltr",,"L"
4168,,,"mrk",,"Hmwaveke",,,,,,0,"ltr",,"L"
4169,,,"mrl",,"Mortlockese",,,,,,0,"ltr",,"L"
4170,,,"mrm",,"Merlav",,,,,,0,"ltr",,"L"
4171,,,"mrn",,"Cheke Holo",,,,,,0,"ltr",,"L"
4172,,,"mro",,"Mru",,,,,,0,"ltr",,"L"
4173,,,"mrp",,"Morouas",,,,,,0,"ltr",,"L"
4174,,,"mrq",,"Marquesan",,"North",,,,0,"ltr",,"L"
4175,,,"mrr",,"Maria","India",,,,,0,"ltr",,"L"
4176,,,"mrs",,"Maragus",,,,,,0,"ltr",,"L"
4177,,,"mrt",,"Marghi Central",,,,,,0,"ltr",,"L"
4178,,,"mru",,"Mono","Cameroon",,,,,0,"ltr",,"L"
4179,,,"mrv",,"Mangareva",,,,,,0,"ltr",,"L"
4180,,,"mrw",,"Maranao",,,,,,0,"ltr",,"L"
4181,,,"mrx",,"Maremgi",,,,,,0,"ltr",,"L"
4182,,,"mry",,"Mandaya",,"Karaga",,,,0,"ltr",,"L"
4183,,,"mrz",,"Marind",,,,,,0,"ltr",,"L"
4184,"ms","msa","msa",,"Malay","generic",,"Bahasa melayu",,,1,"ltr",,"L"
4185,,,"msb",,"Masbatenyo",,,,,,0,"ltr",,"L"
4186,,,"msc",,"Maninka",,"Sankaran",,,,0,"ltr",,"L"
4187,,,"msd",,"Yucatec Maya Sign Language",,,,,,0,"ltr",,"L"
4188,,,"mse",,"Musey",,,,,,0,"ltr",,"L"
4189,,,"msf",,"Mekwei",,,,,,0,"ltr",,"L"
4190,,,"msg",,"Moraid",,,,,,0,"ltr",,"L"
4191,,,"msh",,"Malagasy",,"Masikoro",,,,0,"ltr",,"L"
4192,,,"msi",,"Malay",,"Sabah",,,,0,"ltr",,"L"
4193,,,"msj",,"Ma","Democratic Republic of Congo",,,,,0,"ltr",,"L"
4194,,,"msk",,"Mansaka",,,,,,0,"ltr",,"L"
4195,,,"msl",,"Molof",,,,,,0,"ltr",,"L"
4196,,,"msm",,"Manobo",,"Agusan",,,,0,"ltr",,"L"
4197,,,"msn",,"Mosina",,,,,,0,"ltr",,"L"
4198,,,"mso",,"Mombum",,,,,,0,"ltr",,"L"
4199,,,"msp",,"Maritsauá",,,,,,0,"ltr",,"E"
4200,,,"msq",,"Caac",,,,,,0,"ltr",,"L"
4201,,,"msr",,"Mongolian Sign Language",,,,,,0,"ltr",,"L"
4202,,,"mss",,"Masela",,"West",,,,0,"ltr",,"L"
4203,,,"mst",,"Mandaya",,"Cataelano",,,,0,"ltr",,"L"
4204,,,"msu",,"Musom",,,,,,0,"ltr",,"L"
4205,,,"msv",,"Maslam",,,,,,0,"ltr",,"L"
4206,,,"msw",,"Mansoanka",,,,,,0,"ltr",,"L"
4207,,,"msx",,"Moresada",,,,,,0,"ltr",,"L"
4208,,,"msy",,"Aruamu",,,,,,0,"ltr",,"L"
4209,,,"msz",,"Momare",,,,,,0,"ltr",,"L"
4210,,,"mta",,"Manobo",,"Cotabato",,,,0,"ltr",,"L"
4211,,,"mtb",,"Anyin Morofo",,,,,,0,"ltr",,"L"
4212,,,"mtc",,"Munit",,,,,,0,"ltr",,"L"
4213,,,"mtd",,"Mualang",,,,,,0,"ltr",,"L"
4214,,,"mte",,"Mono","Solomon Islands",,,,,0,"ltr",,"L"
4215,,,"mtf",,"Murik",,,,,,0,"ltr",,"L"
4216,,,"mtg",,"Una",,,,,,0,"ltr",,"L"
4217,,,"mth",,"Munggui",,,,,,0,"ltr",,"L"
4218,,,"mti",,"Maiwa","Papua New Guinea",,,,,0,"ltr",,"L"
4219,,,"mtj",,"Moskona",,,,,,0,"ltr",,"L"
4220,,,"mtk",,"Mbe'",,,,,,0,"ltr",,"L"
4221,,,"mtl",,"Montol",,,,,,0,"ltr",,"L"
4222,,,"mtm",,"Mator",,,,,,0,"ltr",,"E"
4223,,,"mtn",,"Matagalpa",,,,,,0,"ltr",,"E"
4224,,,"mto",,"Mixe",,"Totontepec",,,,0,"ltr",,"L"
4225,,,"mtp",,"Wichí Lhamtés Nocten",,,,,,0,"ltr",,"L"
4226,,,"mtq",,"Muong",,,,,,0,"ltr",,"L"
4227,,,"mtr",,"Mewari",,,,,,0,"ltr",,"L"
4228,,,"mts",,"Yora",,,,,,0,"ltr",,"L"
4229,,,"mtt",,"Mota",,,,,,0,"ltr",,"L"
4230,,,"mtu",,"Mixtec",,"Tututepec",,,,0,"ltr",,"L"
4231,,,"mtv",,"Asaro'o",,,,,,0,"ltr",,"L"
4232,,,"mtw",,"Magahat",,,,,,0,"ltr",,"L"
4233,,,"mtx",,"Mixtec",,"Tidaá",,,,0,"ltr",,"L"
4234,,,"mty",,"Nabi",,,,,,0,"ltr",,"L"
4235,,,"mtz",,"Tacanec",,,,,,0,"ltr",,"L"
4236,,,"mua",,"Mundang",,,,,,0,"ltr",,"L"
4237,,,"mub",,"Mubi",,,,,,0,"ltr",,"L"
4238,,,"muc",,"Mbu'",,,,,,0,"ltr",,"L"
4239,,,"mud",,"Aleut",,"Mednyj",,,,0,"ltr",,"L"
4240,,,"mue",,"Media Lengua",,,,,,0,"ltr",,"L"
4241,,,"mug",,"Musgu",,,,,,0,"ltr",,"L"
4242,,,"muh",,"Mündü",,,,,,0,"ltr",,"L"
4243,,,"mui",,"Musi",,,,,,0,"ltr",,"L"
4244,,,"muj",,"Mabire",,,,,,0,"ltr",,"L"
4245,,,"muk",,"Mugom",,,,,,0,"ltr",,"L"
4246,,"mul","mul",,"Multiple globalize_languages",,,,,,0,"ltr",,""
4247,,,"mum",,"Maiwala",,,,,,0,"ltr",,"L"
4248,,,"muo",,"Nyong",,,,,,0,"ltr",,"L"
4249,,,"mup",,"Malvi",,,,,,0,"ltr",,"L"
4250,,,"muq",,"Hmong",,"Eastern Xiangxi",,,,0,"ltr",,"L"
4251,,,"mur",,"Murle",,,,,,0,"ltr",,"L"
4252,,"mus","mus",,"Creek",,,,,,0,"ltr",,"L"
4253,,,"mut",,"Muria",,"Western",,,,0,"ltr",,"L"
4254,,,"muu",,"Yaaku",,,,,,0,"ltr",,"L"
4255,,,"muv",,"Muthuvan",,,,,,0,"ltr",,"L"
4256,,,"muw",,"Mundari",,,,,,0,"ltr",,"L"
4257,,,"mux",,"Mbo-Ung",,,,,,0,"ltr",,"L"
4258,,,"muy",,"Muyang",,,,,,0,"ltr",,"L"
4259,,,"muz",,"Mursi",,,,,,0,"ltr",,"L"
4260,,,"mva",,"Manam",,,,,,0,"ltr",,"L"
4261,,,"mvb",,"Mattole",,,,,,0,"ltr",,"E"
4262,,,"mvc",,"Mam",,"Central",,,,0,"ltr",,"L"
4263,,,"mvd",,"Mamboru",,,,,,0,"ltr",,"L"
4264,,,"mve",,"Marwari","Pakistan",,,,,0,"ltr",,"L"
4265,,,"mvf",,"Mongolian",,"Peripheral",,,,0,"ltr",,"L"
4266,,,"mvg",,"Mixtec",,"Yucuañe",,,,0,"ltr",,"L"
4267,,,"mvh",,"Mire",,,,,,0,"ltr",,"L"
4268,,,"mvi",,"Miyako",,,,,,0,"ltr",,"L"
4269,,,"mvj",,"Mam",,"Todos Santos Cuchumatán",,,,0,"ltr",,"L"
4270,,,"mvk",,"Mekmek",,,,,,0,"ltr",,"L"
4271,,,"mvl",,"Mbara","Australia",,,,,0,"ltr",,"E"
4272,,,"mvm",,"Muya",,,,,,0,"ltr",,"L"
4273,,,"mvn",,"Minaveha",,,,,,0,"ltr",,"L"
4274,,,"mvo",,"Marovo",,,,,,0,"ltr",,"L"
4275,,,"mvp",,"Duri",,,,,,0,"ltr",,"L"
4276,,,"mvq",,"Moere",,,,,,0,"ltr",,"L"
4277,,,"mvr",,"Marau",,,,,,0,"ltr",,"L"
4278,,,"mvs",,"Massep",,,,,,0,"ltr",,"L"
4279,,,"mvt",,"Mpotovoro",,,,,,0,"ltr",,"L"
4280,,,"mvu",,"Marfa",,,,,,0,"ltr",,"L"
4281,,,"mvv",,"Tagal Murut",,,,,,0,"ltr",,"L"
4282,,,"mvw",,"Machinga",,,,,,0,"ltr",,"L"
4283,,,"mvx",,"Meoswar",,,,,,0,"ltr",,"L"
4284,,,"mvy",,"Kohistani",,"Indus",,,,0,"ltr",,"L"
4285,,,"mvz",,"Mesqan",,,,,,0,"ltr",,"L"
4286,,,"mwa",,"Mwatebu",,,,,,0,"ltr",,"L"
4287,,,"mwb",,"Juwal",,,,,,0,"ltr",,"L"
4288,,,"mwc",,"Are",,,,,,0,"ltr",,"L"
4289,,,"mwd",,"Mudbura",,,,,,0,"ltr",,"L"
4290,,,"mwe",,"Mwera","Chimwera",,,,,0,"ltr",,"L"
4291,,,"mwf",,"Murrinh-Patha",,,,,,0,"ltr",,"L"
4292,,,"mwg",,"Aiklep",,,,,,0,"ltr",,"L"
4293,,,"mwh",,"Mouk-Aria",,,,,,0,"ltr",,"L"
4294,,,"mwi",,"Labo",,,,,,0,"ltr",,"L"
4295,,,"mwj",,"Maligo",,,,,,0,"ltr",,"L"
4296,,,"mwk",,"Maninkakan",,"Kita",,,,0,"ltr",,"L"
4297,,"mwl","mwl",,"Mirandese",,,,,,0,"ltr",,"L"
4298,,,"mwm",,"Sar",,,,,,0,"ltr",,"L"
4299,,,"mwn",,"Nyamwanga",,,,,,0,"ltr",,"L"
4300,,,"mwo",,"Maewo",,"Central",,,,0,"ltr",,"L"
4301,,,"mwp",,"Kala Lagaw Ya",,,,,,0,"ltr",,"L"
4302,,,"mwq",,"Chin",,"Mün",,,,0,"ltr",,"L"
4303,,"mwr","mwr",,"Marwari",,,,,,1,"ltr",,"L"
4304,,,"mws",,"Mwimbi-Muthambi",,,,,,0,"ltr",,"L"
4305,,,"mwt",,"Moken",,,,,,0,"ltr",,"L"
4306,,,"mwu",,"Mittu",,,,,,0,"ltr",,"E"
4307,,,"mwv",,"Mentawai",,,,,,0,"ltr",,"L"
4308,,,"mww",,"Hmong Daw",,,,,,0,"ltr",,"L"
4309,,,"mwx",,"Mediak",,,,,,0,"ltr",,"L"
4310,,,"mwy",,"Mosiro",,,,,,0,"ltr",,"L"
4311,,,"mwz",,"Moingi",,,,,,0,"ltr",,"L"
4312,,,"mxa",,"Mixtec",,"Northwest Oaxaca",,,,0,"ltr",,"L"
4313,,,"mxb",,"Mixtec",,"Tezoatlán",,,,0,"ltr",,"L"
4314,,,"mxc",,"Manyika",,,,,,0,"ltr",,"L"
4315,,,"mxd",,"Modang",,,,,,0,"ltr",,"L"
4316,,,"mxe",,"Mele-Fila",,,,,,0,"ltr",,"L"
4317,,,"mxf",,"Malgbe",,,,,,0,"ltr",,"L"
4318,,,"mxg",,"Mbangala",,,,,,0,"ltr",,"L"
4319,,,"mxh",,"Mvuba",,,,,,0,"ltr",,"L"
4320,,,"mxi",,"Mozarabic",,,,,,0,"rtl",,"E"
4321,,,"mxj",,"Miju-Mishmi",,,,,,0,"ltr",,"L"
4322,,,"mxk",,"Monumbo",,,,,,0,"ltr",,"L"
4323,,,"mxl",,"Gbe",,"Maxi",,,,0,"ltr",,"L"
4324,,,"mxm",,"Meramera",,,,,,0,"ltr",,"L"
4325,,,"mxn",,"Moi","Indonesia",,,,,0,"ltr",,"L"
4326,,,"mxo",,"Mbowe",,,,,,0,"ltr",,"L"
4327,,,"mxp",,"Mixe",,"Tlahuitoltepec",,,,0,"ltr",,"L"
4328,,,"mxq",,"Mixe",,"Juquila",,,,0,"ltr",,"L"
4329,,,"mxr",,"Kayan",,"Murik",,,,0,"ltr",,"L"
4330,,,"mxs",,"Mixtec",,"Huitepec",,,,0,"ltr",,"L"
4331,,,"mxt",,"Mixtec",,"Jamiltepec",,,,0,"ltr",,"L"
4332,,,"mxu",,"Mada","Cameroon",,,,,0,"ltr",,"L"
4333,,,"mxv",,"Mixtec",,"Metlatónoc",,,,0,"ltr",,"L"
4334,,,"mxw",,"Namo",,,,,,0,"ltr",,"L"
4335,,,"mxx",,"Mahou",,,,,,0,"ltr",,"L"
4336,,,"mxy",,"Mixtec",,"Southeastern Nochixtlán",,,,0,"ltr",,"L"
4337,,,"mxz",,"Masela",,"Central",,,,0,"ltr",,"L"
4338,"my","mya","mya",,"Burmese",,,,,,0,"ltr",,"L"
4339,,,"myb",,"Mbay",,,,,,0,"ltr",,"L"
4340,,,"myc",,"Mayeka",,,,,,0,"ltr",,"L"
4341,,,"myd",,"Maramba",,,,,,0,"ltr",,"L"
4342,,,"mye",,"Myene",,,,,,0,"ltr",,"L"
4343,,,"myf",,"Bambassi",,,,,,0,"ltr",,"L"
4344,,,"myg",,"Manta",,,,,,0,"ltr",,"L"
4345,,,"myh",,"Makah",,,,,,0,"ltr",,"E"
4346,,,"myi",,"Mina","India",,,,,0,"ltr",,"L"
4347,,,"myj",,"Mangayat",,,,,,0,"ltr",,"L"
4348,,,"myk",,"Senoufo",,"Mamara",,,,0,"ltr",,"L"
4349,,,"myl",,"Moma",,,,,,0,"ltr",,"L"
4350,,,"mym",,"Me'en",,,,,,0,"ltr",,"L"
4351,,,"myo",,"Anfillo",,,,,,0,"ltr",,"L"
4352,,,"myp",,"Pirahã",,,,,,0,"ltr",,"L"
4353,,,"myq",,"Maninka",,"Forest",,,,0,"ltr",,"L"
4354,,,"myr",,"Muniche",,,,,,0,"ltr",,"L"
4355,,,"mys",,"Mesmes",,,,,,0,"ltr",,"E"
4356,,,"myt",,"Mandaya",,"Sangab",,,,0,"ltr",,"L"
4357,,,"myu",,"Mundurukú",,,,,,0,"ltr",,"L"
4358,,"myv","myv",,"Erzya",,,,,,0,"ltr",,"L"
4359,,,"myw",,"Muyuw",,,,,,0,"ltr",,"L"
4360,,,"myx",,"Masaba",,,,,,0,"ltr",,"L"
4361,,,"myy",,"Macuna",,,,,,0,"ltr",,"L"
4362,,,"myz",,"Mandaic",,"Classical",,,,0,"ltr",,"H"
4363,,,"mza",,"Mixtec",,"Santa María Zacatepec",,,,0,"ltr",,"L"
4364,,,"mzb",,"Tumzabt",,,,,,0,"ltr",,"L"
4365,,,"mzc",,"Madagascar Sign Language",,,,,,0,"ltr",,"L"
4366,,,"mzd",,"Malimba",,,,,,0,"ltr",,"L"
4367,,,"mze",,"Morawa",,,,,,0,"ltr",,"L"
4368,,,"mzf",,"Aiku",,,,,,0,"ltr",,"L"
4369,,,"mzg",,"Monastic Sign Language",,,,,,0,"ltr",,"L"
4370,,,"mzh",,"Wichí Lhamtés Güisnay",,,,,,0,"ltr",,"L"
4371,,,"mzi",,"Mazatec",,"Ixcatlán",,,,0,"ltr",,"L"
4372,,,"mzj",,"Manya",,,,,,0,"ltr",,"L"
4373,,,"mzk",,"Mambila",,"Nigeria",,,,0,"ltr",,"L"
4374,,,"mzl",,"Mixe",,"Mazatlán",,,,0,"ltr",,"L"
4375,,,"mzm",,"Mumuye",,,,,,0,"ltr",,"L"
4376,,,"mzn",,"Mazanderani",,,,,,0,"ltr",,"L"
4377,,,"mzo",,"Matipuhy",,,,,,0,"ltr",,"L"
4378,,,"mzp",,"Movima",,,,,,0,"ltr",,"L"
4379,,,"mzq",,"Mori Atas",,,,,,0,"ltr",,"L"
4380,,,"mzr",,"Marúbo",,,,,,0,"ltr",,"L"
4381,,,"mzs",,"Macanese",,,,,,0,"ltr",,"L"
4382,,,"mzt",,"Mintil",,,,,,0,"ltr",,"L"
4383,,,"mzu",,"Inapang",,,,,,0,"ltr",,"L"
4384,,,"mzv",,"Manza",,,,,,0,"ltr",,"L"
4385,,,"mzw",,"Deg",,,,,,0,"ltr",,"L"
4386,,,"mzx",,"Mawayana",,,,,,0,"ltr",,"L"
4387,,,"mzy",,"Mozambican Sign Language",,,,,,0,"ltr",,"L"
4388,,,"mzz",,"Maiadomu",,,,,,0,"ltr",,"L"
4389,,,"nab",,"Nambikuára",,"Southern",,,,0,"ltr",,"L"
4390,,,"nac",,"Narak",,,,,,0,"ltr",,"L"
4391,,,"nad",,"Nijadali",,,,,,0,"ltr",,"L"
4392,,,"nae",,"Naka'ela",,,,,,0,"ltr",,"L"
4393,,,"naf",,"Nabak",,,,,,0,"ltr",,"L"
4394,,,"nag",,"Naga Pidgin",,,,,,0,"ltr",,"L"
4395,,,"naj",,"Nalu",,,,,,0,"ltr",,"L"
4396,,,"nak",,"Nakanai",,,,,,0,"ltr",,"L"
4397,,,"nal",,"Nalik",,,,,,0,"ltr",,"L"
4398,,,"nam",,"Nangikurrunggurr",,,,,,0,"ltr",,"L"
4399,,,"nan",,"Chinese",,"Min Nan",,,,0,"ltr",,"L"
4400,,,"nao",,"Naaba",,,,,,0,"ltr",,"L"
4401,,"nap","nap",,"Neapolitan",,,,,,0,"ltr",,"L"
4402,,,"naq",,"Nama","Namibia",,,,,0,"ltr",,"L"
4403,,,"nar",,"Iguta",,,,,,0,"ltr",,"L"
4404,,,"nas",,"Naasioi",,,,,,0,"ltr",,"L"
4405,,,"nat",,"Hungworo",,,,,,0,"ltr",,"L"
4406,"na","nau","nau",,"Nauru",,,,,,0,"ltr",,"L"
4407,"nv","nav","nav",,"Navajo",,,,,,0,"ltr",,"L"
4408,,,"naw",,"Nawuri",,,,,,0,"ltr",,"L"
4409,,,"nax",,"Nakwi",,,,,,0,"ltr",,"L"
4410,,,"nay",,"Narrinyeri",,,,,,0,"ltr",,"E"
4411,,,"naz",,"Nahuatl",,"Coatepec",,,,0,"ltr",,"L"
4412,,,"nba",,"Nyemba",,,,,,0,"ltr",,"L"
4413,,,"nbb",,"Ndoe",,,,,,0,"ltr",,"L"
4414,,,"nbc",,"Naga",,"Chang",,,,0,"ltr",,"L"
4415,,,"nbd",,"Ngbinda",,,,,,0,"ltr",,"L"
4416,,,"nbe",,"Naga",,"Konyak",,,,0,"ltr",,"L"
4417,,,"nbf",,"Naxi",,,,,,0,"ltr",,"L"
4418,,,"nbg",,"Nagarchal",,,,,,0,"ltr",,"L"
4419,,,"nbh",,"Ngamo",,,,,,0,"ltr",,"L"
4420,,,"nbi",,"Naga",,"Mao",,,,0,"ltr",,"L"
4421,,,"nbj",,"Ngarinman",,,,,,0,"ltr",,"L"
4422,,,"nbk",,"Nake",,,,,,0,"ltr",,"L"
4423,"nr","nbl","nbl",,"Ndebele",,"South",,,,0,"ltr",,"L"
4424,,,"nbm",,"Ngbaka Ma'bo",,,,,,0,"ltr",,"L"
4425,,,"nbn",,"Kuri",,,,,,0,"ltr",,"L"
4426,,,"nbo",,"Nkukoli",,,,,,0,"ltr",,"L"
4427,,,"nbp",,"Nnam",,,,,,0,"ltr",,"L"
4428,,,"nbq",,"Nggem",,,,,,0,"ltr",,"L"
4429,,,"nbr",,"Numana-Nunku-Gbantu-Numbu",,,,,,0,"ltr",,"L"
4430,,,"nbs",,"Namibian Sign Language",,,,,,0,"ltr",,"L"
4431,,,"nbt",,"Na",,,,,,0,"ltr",,"L"
4432,,,"nbu",,"Naga",,"Rongmei",,,,0,"ltr",,"L"
4433,,,"nbv",,"Ngamambo",,,,,,0,"ltr",,"L"
4434,,,"nbw",,"Ngbandi",,"Southern",,,,0,"ltr",,"L"
4435,,,"nbx",,"Ngura",,,,,,0,"ltr",,"L"
4436,,,"nby",,"Ningera",,,,,,0,"ltr",,"L"
4437,,,"nca",,"Iyo",,,,,,0,"ltr",,"L"
4438,,,"ncb",,"Nicobarese",,"Central",,,,0,"ltr",,"L"
4439,,,"ncc",,"Ponam",,,,,,0,"ltr",,"L"
4440,,,"ncd",,"Nachering",,,,,,0,"ltr",,"L"
4441,,,"nce",,"Yale",,,,,,0,"ltr",,"L"
4442,,,"ncf",,"Notsi",,,,,,0,"ltr",,"L"
4443,,,"ncg",,"Nisga'a",,,,,,0,"ltr",,"L"
4444,,,"nch",,"Nahuatl",,"Central Huasteca",,,,0,"ltr",,"L"
4445,,,"nci",,"Nahuatl",,"Classical",,,,0,"ltr",,"H"
4446,,,"ncj",,"Nahuatl",,"Northern Puebla",,,,0,"ltr",,"L"
4447,,,"nck",,"Nakara",,,,,,0,"ltr",,"L"
4448,,,"ncl",,"Nahuatl",,"Michoacán",,,,0,"ltr",,"L"
4449,,,"ncm",,"Nambo",,,,,,0,"ltr",,"L"
4450,,,"ncn",,"Nauna",,,,,,0,"ltr",,"L"
4451,,,"nco",,"Sibe",,,,,,0,"ltr",,"L"
4452,,,"ncp",,"Ndaktup",,,,,,0,"ltr",,"L"
4453,,,"ncr",,"Ncane",,,,,,0,"ltr",,"L"
4454,,,"ncs",,"Nicaraguan Sign Language",,,,,,0,"ltr",,"L"
4455,,,"nct",,"Naga",,"Chothe",,,,0,"ltr",,"L"
4456,,,"ncu",,"Chumburung",,,,,,0,"ltr",,"L"
4457,,,"ncx",,"Nahuatl",,"Central Puebla",,,,0,"ltr",,"L"
4458,,,"ncz",,"Natchez",,,,,,0,"ltr",,"E"
4459,,,"nda",,"Ndasa",,,,,,0,"ltr",,"L"
4460,,,"ndb",,"Kenswei Nsei",,,,,,0,"ltr",,"L"
4461,,,"ndc",,"Ndau",,,,,,0,"ltr",,"L"
4462,,,"ndd",,"Nde-Nsele-Nta",,,,,,0,"ltr",,"L"
4463,"nd","nde","nde",,"Ndebele",,"North",,,,0,"ltr",,"L"
4464,,,"ndf",,"Nadruvian",,,,,,0,"ltr",,"E"
4465,,,"ndg",,"Ndengereko",,,,,,0,"ltr",,"L"
4466,,,"ndh",,"Ndali",,,,,,0,"ltr",,"L"
4467,,,"ndi",,"Samba Leko",,,,,,0,"ltr",,"L"
4468,,,"ndj",,"Ndamba",,,,,,0,"ltr",,"L"
4469,,,"ndk",,"Ndaka",,,,,,0,"ltr",,"L"
4470,,,"ndl",,"Ndolo",,,,,,0,"ltr",,"L"
4471,,,"ndm",,"Ndam",,,,,,0,"ltr",,"L"
4472,,,"ndn",,"Ngundi",,,,,,0,"ltr",,"L"
4473,"ng","ndo","ndo",,"Ndonga",,,,,,0,"ltr",,"L"
4474,,,"ndp",,"Ndo",,,,,,0,"ltr",,"L"
4475,,,"ndq",,"Ndombe",,,,,,0,"ltr",,"L"
4476,,,"ndr",,"Ndoola",,,,,,0,"ltr",,"L"
4477,,"nds","nds",,"Low German; Low Saxon",,,,,,0,"ltr",,"L"
4478,,,"ndt",,"Ndunga",,,,,,0,"ltr",,"L"
4479,,,"ndu",,"Dugun",,,,,,0,"ltr",,"L"
4480,,,"ndv",,"Ndut",,,,,,0,"ltr",,"L"
4481,,,"ndw",,"Ndobo",,,,,,0,"ltr",,"L"
4482,,,"ndx",,"Nduga",,,,,,0,"ltr",,"L"
4483,,,"ndy",,"Lutos",,,,,,0,"ltr",,"L"
4484,,,"ndz",,"Ndogo",,,,,,0,"ltr",,"L"
4485,,,"nea",,"Ngad'a",,"Eastern",,,,0,"ltr",,"L"
4486,,,"neb",,"Toura","Côte d'Ivoire",,,,,0,"ltr",,"L"
4487,,,"nec",,"Nedebang",,,,,,0,"ltr",,"L"
4488,,,"ned",,"Nde-Gbite",,,,,,0,"ltr",,"L"
4489,,,"nee",,"Kumak",,,,,,0,"ltr",,"L"
4490,,,"nef",,"Nefamese",,,,,,0,"ltr",,"L"
4491,,,"neg",,"Negidal",,,,,,0,"ltr",,"L"
4492,,,"neh",,"Nyenkha",,,,,,0,"ltr",,"L"
4493,,,"nei",,"Hittite",,"Neo-",,,,0,"ltr",,"A"
4494,,,"nej",,"Neko",,,,,,0,"ltr",,"L"
4495,,,"nek",,"Neku",,,,,,0,"ltr",,"L"
4496,,,"nem",,"Nemi",,,,,,0,"ltr",,"L"
4497,,,"nen",,"Nengone",,,,,,0,"ltr",,"L"
4498,,,"neo",,"Ná-Meo",,,,,,0,"ltr",,"L"
4499,"ne","nep","nep",,"Nepali",,,,,,0,"ltr",,"L"
4500,,,"neq",,"Mixe",,"North Central",,,,0,"ltr",,"L"
4501,,,"ner",,"Yahadian",,,,,,0,"ltr",,"L"
4502,,,"nes",,"Kinnauri",,"Bhoti",,,,0,"ltr",,"L"
4503,,,"net",,"Nete",,,,,,0,"ltr",,"L"
4504,,,"nev",,"Nyaheun",,,,,,0,"ltr",,"L"
4505,,"new","new",,"Newari",,,,,,0,"ltr",,"L"
4506,,,"nex",,"Neme",,,,,,0,"ltr",,"L"
4507,,,"ney",,"Neyo",,,,,,0,"ltr",,"L"
4508,,,"nez",,"Nez Perce",,,,,,0,"ltr",,"L"
4509,,,"nfa",,"Dhao",,,,,,0,"ltr",,"L"
4510,,,"nfd",,"Ndun",,,,,,0,"ltr",,"L"
4511,,,"nfg",,"Nyeng",,,,,,0,"ltr",,"L"
4512,,,"nfk",,"Shakara",,,,,,0,"ltr",,"L"
4513,,,"nfl",,"Ayiwo",,,,,,0,"ltr",,"L"
4514,,,"nfr",,"Nafaanra",,,,,,0,"ltr",,"L"
4515,,,"nfu",,"Mfumte",,,,,,0,"ltr",,"L"
4516,,,"nga",,"Ngbaka",,,,,,0,"ltr",,"L"
4517,,,"ngb",,"Ngbandi",,"Northern",,,,0,"ltr",,"L"
4518,,,"ngc",,"Ngombe","Democratic Republic of Congo",,,,,0,"ltr",,"L"
4519,,,"ngd",,"Ngando","Central African Republic",,,,,0,"ltr",,"L"
4520,,,"nge",,"Ngemba",,,,,,0,"ltr",,"L"
4521,,,"ngg",,"Ngbaka Manza",,,,,,0,"ltr",,"L"
4522,,,"ngh",,"N/u",,,,,,0,"ltr",,"L"
4523,,,"ngi",,"Ngizim",,,,,,0,"ltr",,"L"
4524,,,"ngj",,"Ngie",,,,,,0,"ltr",,"L"
4525,,,"ngk",,"Ngalkbun",,,,,,0,"ltr",,"L"
4526,,,"ngl",,"Lomwe",,,,,,0,"ltr",,"L"
4527,,,"ngm",,"Ngatik Men's Creole",,,,,,0,"ltr",,"L"
4528,,,"ngn",,"Ngwo",,,,,,0,"ltr",,"L"
4529,,,"ngo",,"Ngoni",,,,,,0,"ltr",,"L"
4530,,,"ngp",,"Ngulu",,,,,,0,"ltr",,"L"
4531,,,"ngq",,"Ngurimi",,,,,,0,"ltr",,"L"
4532,,,"ngr",,"Nanggu",,,,,,0,"ltr",,"L"
4533,,,"ngs",,"Gvoko",,,,,,0,"ltr",,"L"
4534,,,"ngt",,"Ngeq",,,,,,0,"ltr",,"L"
4535,,,"ngu",,"Nahuatl",,"Guerrero",,,,0,"ltr",,"L"
4536,,,"ngv",,"Nagumi",,,,,,0,"ltr",,"E"
4537,,,"ngw",,"Ngwaba",,,,,,0,"ltr",,"L"
4538,,,"ngx",,"Nggwahyi",,,,,,0,"ltr",,"L"
4539,,,"ngy",,"Tibea",,,,,,0,"ltr",,"L"
4540,,,"ngz",,"Ngungwel",,,,,,0,"ltr",,"L"
4541,,,"nhb",,"Beng",,,,,,0,"ltr",,"L"
4542,,,"nhc",,"Nahuatl",,"Tabasco",,,,0,"ltr",,"E"
4543,,,"nhd",,"Chiripá",,,,,,0,"ltr",,"L"
4544,,,"nhe",,"Nahuatl",,"Eastern Huasteca",,,,0,"ltr",,"L"
4545,,,"nhf",,"Nhuwala",,,,,,0,"ltr",,"L"
4546,,,"nhg",,"Nahuatl",,"Tetelcingo",,,,0,"ltr",,"L"
4547,,,"nhh",,"Nahari",,,,,,0,"ltr",,"L"
4548,,,"nhi",,"Nahuatl",,"Tenango",,,,0,"ltr",,"L"
4549,,,"nhj",,"Nahuatl",,"Tlalitzlipa",,,,0,"ltr",,"L"
4550,,,"nhk",,"Nahuatl",,"Isthmus-Cosoleacaque",,,,0,"ltr",,"L"
4551,,,"nhm",,"Nahuatl",,"Morelos",,,,0,"ltr",,"L"
4552,,,"nhn",,"Nahuatl",,"Central",,,,0,"ltr",,"L"
4553,,,"nho",,"Takuu",,,,,,0,"ltr",,"L"
4554,,,"nhp",,"Nahuatl",,"Isthmus-Pajapan",,,,0,"ltr",,"L"
4555,,,"nhq",,"Nahuatl",,"Huaxcaleca",,,,0,"ltr",,"L"
4556,,,"nhr",,"Naro",,,,,,0,"ltr",,"L"
4557,,,"nhs",,"Nahuatl",,"Southeastern Puebla",,,,0,"ltr",,"L"
4558,,,"nht",,"Nahuatl",,"Ometepec",,,,0,"ltr",,"L"
4559,,,"nhu",,"Noone",,,,,,0,"ltr",,"L"
4560,,,"nhv",,"Nahuatl",,"Temascaltepec",,,,0,"ltr",,"L"
4561,,,"nhw",,"Nahuatl",,"Western Huasteca",,,,0,"ltr",,"L"
4562,,,"nhx",,"Nahuatl",,"Isthmus-Mecayapan",,,,0,"ltr",,"L"
4563,,,"nhy",,"Nahuatl",,"Northern Oaxaca",,,,0,"ltr",,"L"
4564,,,"nhz",,"Nahuatl",,"Santa María La Alta",,,,0,"ltr",,"L"
4565,,"nia","nia",,"Nias",,,,,,0,"ltr",,"L"
4566,,,"nib",,"Nakama",,,,,,0,"ltr",,"L"
4567,,,"nid",,"Ngandi",,,,,,0,"ltr",,"E"
4568,,,"nie",,"Niellim",,,,,,0,"ltr",,"L"
4569,,,"nif",,"Nek",,,,,,0,"ltr",,"L"
4570,,,"nig",,"Ngalakan",,,,,,0,"ltr",,"L"
4571,,,"nih",,"Nyiha",,,,,,0,"ltr",,"L"
4572,,,"nii",,"Nii",,,,,,0,"ltr",,"L"
4573,,,"nij",,"Ngaju",,,,,,0,"ltr",,"L"
4574,,,"nik",,"Nicobarese",,"Southern",,,,0,"ltr",,"L"
4575,,,"nil",,"Nila",,,,,,0,"ltr",,"L"
4576,,,"nim",,"Nilamba",,,,,,0,"ltr",,"L"
4577,,,"nin",,"Ninzo",,,,,,0,"ltr",,"L"
4578,,,"nio",,"Nganasan",,,,,,0,"ltr",,"L"
4579,,,"nir",,"Nimboran",,,,,,0,"ltr",,"L"
4580,,,"nis",,"Nimi",,,,,,0,"ltr",,"L"
4581,,,"nit",,"Kolami",,"Southeastern",,,,0,"ltr",,"L"
4582,,"niu","niu",,"Niuean",,,,,,0,"ltr",,"L"
4583,,,"niv",,"Gilyak",,,,,,0,"ltr",,"L"
4584,,,"niw",,"Nimo",,,,,,0,"ltr",,"L"
4585,,,"nix",,"Hema",,,,,,0,"ltr",,"L"
4586,,,"niy",,"Ngiti",,,,,,0,"ltr",,"L"
4587,,,"niz",,"Ningil",,,,,,0,"ltr",,"L"
4588,,,"nja",,"Nzanyi",,,,,,0,"ltr",,"L"
4589,,,"njb",,"Naga",,"Nocte",,,,0,"ltr",,"L"
4590,,,"njd",,"Ndonde Hamba",,,,,,0,"ltr",,"L"
4591,,,"njh",,"Naga",,"Lotha",,,,0,"ltr",,"L"
4592,,,"nji",,"Gudanji",,,,,,0,"ltr",,"L"
4593,,,"njj",,"Njen",,,,,,0,"ltr",,"L"
4594,,,"njl",,"Njalgulgule",,,,,,0,"ltr",,"L"
4595,,,"njm",,"Naga",,"Angami",,,,0,"ltr",,"L"
4596,,,"njn",,"Naga",,"Liangmai",,,,0,"ltr",,"L"
4597,,,"njo",,"Naga",,"Ao",,,,0,"ltr",,"L"
4598,,,"njr",,"Njerep",,,,,,0,"ltr",,"L"
4599,,,"njs",,"Nisa",,,,,,0,"ltr",,"L"
4600,,,"njt",,"Ndyuka-Trio Pidgin",,,,,,0,"ltr",,"L"
4601,,,"nju",,"Ngadjunmaya",,,,,,0,"ltr",,"L"
4602,,,"njx",,"Kunyi",,,,,,0,"ltr",,"L"
4603,,,"njy",,"Njyem",,,,,,0,"ltr",,"L"
4604,,,"nka",,"Nkoya",,,,,,0,"ltr",,"L"
4605,,,"nkb",,"Naga",,"Khoibu",,,,0,"ltr",,"L"
4606,,,"nkc",,"Nkongho",,,,,,0,"ltr",,"L"
4607,,,"nkd",,"Koireng",,,,,,0,"ltr",,"L"
4608,,,"nke",,"Duke",,,,,,0,"ltr",,"L"
4609,,,"nkf",,"Naga",,"Inpui",,,,0,"ltr",,"L"
4610,,,"nkg",,"Nekgini",,,,,,0,"ltr",,"L"
4611,,,"nkh",,"Naga",,"Khezha",,,,0,"ltr",,"L"
4612,,,"nki",,"Naga",,"Thangal",,,,0,"ltr",,"L"
4613,,,"nkj",,"Nakai",,,,,,0,"ltr",,"L"
4614,,,"nkk",,"Nokuku",,,,,,0,"ltr",,"L"
4615,,,"nkm",,"Namat",,,,,,0,"ltr",,"L"
4616,,,"nkn",,"Nkangala",,,,,,0,"ltr",,"L"
4617,,,"nko",,"Nkonya",,,,,,0,"ltr",,"L"
4618,,,"nkp",,"Niuatoputapu",,,,,,0,"ltr",,"E"
4619,,,"nkr",,"Nukuoro",,,,,,0,"ltr",,"L"
4620,,,"nks",,"Asmat",,"North",,,,0,"ltr",,"L"
4621,,,"nku",,"Kulango",,"Bouna",,,,0,"ltr",,"L"
4622,,,"nkw",,"Nkutu",,,,,,0,"ltr",,"L"
4623,,,"nkx",,"Nkoroo",,,,,,0,"ltr",,"L"
4624,,,"nky",,"Naga",,"Khiamniungan",,,,0,"ltr",,"L"
4625,,,"nkz",,"Nkari",,,,,,0,"ltr",,"L"
4626,,,"nla",,"Ngombale",,,,,,0,"ltr",,"L"
4627,,,"nlc",,"Nalca",,,,,,0,"ltr",,"L"
4628,"nl","nld","nld",,"Dutch",,,"Nederlands",,,0,"ltr","c == 1 ? 1 : 2","L"
4629,,,"nle",,"Nyala",,"East",,,,0,"ltr",,"L"
4630,,,"nlg",,"Gela",,,,,,0,"ltr",,"L"
4631,,,"nli",,"Grangali",,,,,,0,"ltr",,"L"
4632,,,"nlj",,"Nyali",,,,,,0,"ltr",,"L"
4633,,,"nlk",,"Yali",,"Ninia",,,,0,"ltr",,"L"
4634,,,"nll",,"Nihali",,,,,,0,"ltr",,"L"
4635,,,"nln",,"Nahuatl",,"Durango",,,,0,"ltr",,"L"
4636,,,"nlo",,"Ngul",,,,,,0,"ltr",,"L"
4637,,,"nlr",,"Ngarla",,,,,,0,"ltr",,"L"
4638,,,"nlu",,"Nchumbulu",,,,,,0,"ltr",,"L"
4639,,,"nlv",,"Nahuatl",,"Orizaba",,,,0,"ltr",,"L"
4640,,,"nlx",,"Nahali",,,,,,0,"ltr",,"L"
4641,,,"nly",,"Nyamal",,,,,,0,"ltr",,"L"
4642,,,"nma",,"Naga",,"Maram",,,,0,"ltr",,"L"
4643,,,"nmb",,"Nambas",,"Big",,,,0,"ltr",,"L"
4644,,,"nmc",,"Ngam",,,,,,0,"ltr",,"L"
4645,,,"nmd",,"Ndumu",,,,,,0,"ltr",,"L"
4646,,,"nme",,"Naga",,"Mzieme",,,,0,"ltr",,"L"
4647,,,"nmf",,"Naga",,"Tangkhul",,,,0,"ltr",,"L"
4648,,,"nmg",,"Ngumba",,,,,,0,"ltr",,"L"
4649,,,"nmh",,"Naga",,"Monsang",,,,0,"ltr",,"L"
4650,,,"nmi",,"Nyam",,,,,,0,"ltr",,"L"
4651,,,"nmj",,"Ngombe","Central African Republic",,,,,0,"ltr",,"L"
4652,,,"nmk",,"Namakura",,,,,,0,"ltr",,"L"
4653,,,"nml",,"Ndemli",,,,,,0,"ltr",,"L"
4654,,,"nmm",,"Manangba",,,,,,0,"ltr",,"L"
4655,,,"nmn",,"!Xóõ",,,,,,0,"ltr",,"L"
4656,,,"nmo",,"Naga",,"Moyon",,,,0,"ltr",,"L"
4657,,,"nmp",,"Nimanbur",,,,,,0,"ltr",,"L"
4658,,,"nmq",,"Nambya",,,,,,0,"ltr",,"L"
4659,,,"nmr",,"Nimbari",,,,,,0,"ltr",,"L"
4660,,,"nms",,"Letemboi",,,,,,0,"ltr",,"L"
4661,,,"nmt",,"Namonuito",,,,,,0,"ltr",,"L"
4662,,,"nmu",,"Maidu",,"Northeast",,,,0,"ltr",,"L"
4663,,,"nmv",,"Ngamini",,,,,,0,"ltr",,"L"
4664,,,"nmw",,"Nimoa",,,,,,0,"ltr",,"L"
4665,,,"nmx",,"Nama","Papua New Guinea",,,,,0,"ltr",,"L"
4666,,,"nmy",,"Namuyi",,,,,,0,"ltr",,"L"
4667,,,"nmz",,"Nawdm",,,,,,0,"ltr",,"L"
4668,,,"nna",,"Nyangumarta",,,,,,0,"ltr",,"L"
4669,,,"nnb",,"Nande",,,,,,0,"ltr",,"L"
4670,,,"nnc",,"Nancere",,,,,,0,"ltr",,"L"
4671,,,"nnd",,"Ambae",,"West",,,,0,"ltr",,"L"
4672,,,"nne",,"Ngandyera",,,,,,0,"ltr",,"L"
4673,,,"nnf",,"Ngaing",,,,,,0,"ltr",,"L"
4674,,,"nng",,"Naga",,"Maring",,,,0,"ltr",,"L"
4675,,,"nnh",,"Ngiemboon",,,,,,0,"ltr",,"L"
4676,,,"nni",,"Nuaulu",,"North",,,,0,"ltr",,"L"
4677,,,"nnj",,"Nyangatom",,,,,,0,"ltr",,"L"
4678,,,"nnk",,"Nankina",,,,,,0,"ltr",,"L"
4679,,,"nnl",,"Naga",,"Northern Rengma",,,,0,"ltr",,"L"
4680,,,"nnm",,"Namia",,,,,,0,"ltr",,"L"
4681,,,"nnn",,"Ngete",,,,,,0,"ltr",,"L"
4682,"nn","nno","nno",,"Norwegian Nynorsk",,,,,,0,"ltr",,"L"
4683,,,"nnp",,"Naga",,"Wancho",,,,0,"ltr",,"L"
4684,,,"nnq",,"Ngindo",,,,,,0,"ltr",,"L"
4685,,,"nnr",,"Narungga",,,,,,0,"ltr",,"E"
4686,,,"nns",,"Ningye",,,,,,0,"ltr",,"L"
4687,,,"nnt",,"Nanticoke",,,,,,0,"ltr",,"E"
4688,,,"nnu",,"Dwang",,,,,,0,"ltr",,"L"
4689,,,"nnv",,"Nugunu","Australia",,,,,0,"ltr",,"E"
4690,,,"nnw",,"Nuni",,"Southern",,,,0,"ltr",,"L"
4691,,,"nnx",,"Ngong",,,,,,0,"ltr",,"L"
4692,,,"nny",,"Nyangga",,,,,,0,"ltr",,"L"
4693,,,"nnz",,"Nda'nda'",,,,,,0,"ltr",,"L"
4694,,,"noa",,"Woun Meu",,,,,,0,"ltr",,"L"
4695,"nb","nob","nob",,"Norwegian Bokmål",,,,,,0,"ltr",,"L"
4696,,,"noc",,"Nuk",,,,,,0,"ltr",,"L"
4697,,,"nod",,"Thai",,"Northern",,,,0,"ltr",,"L"
4698,,,"noe",,"Nimadi",,,,,,0,"ltr",,"L"
4699,,,"nof",,"Nomane",,,,,,0,"ltr",,"L"
4700,,"nog","nog",,"Nogai",,,,,,0,"ltr",,"L"
4701,,,"noh",,"Nomu",,,,,,0,"ltr",,"L"
4702,,,"noi",,"Noiri",,,,,,0,"ltr",,"L"
4703,,,"nok",,"Nooksack",,,,,,0,"ltr",,"E"
4704,,,"nom",,"Nocamán",,,,,,0,"ltr",,"E"
4705,,"non","non",,"Norse",,"Old",,,,0,"ltr",,"H"
4706,,,"noo",,"Nootka",,,,,,0,"ltr",,"L"
4707,,,"nop",,"Numanggang",,,,,,0,"ltr",,"L"
4708,,,"noq",,"Ngongo",,,,,,0,"ltr",,"L"
4709,"no","nor","nor",,"Norwegian",,,"Norsk",,,1,"ltr","c == 1 ? 1 : 2","L"
4710,,,"nos",,"Yi",,"Southern",,,,0,"ltr",,"L"
4711,,,"not",,"Nomatsiguenga",,,,,,0,"ltr",,"L"
4712,,,"nou",,"Ewage-Notu",,,,,,0,"ltr",,"L"
4713,,,"nov",,"Novial",,,,,,0,"ltr",,"C"
4714,,,"now",,"Nyambo",,,,,,0,"ltr",,"L"
4715,,,"noy",,"Noy",,,,,,0,"ltr",,"L"
4716,,,"noz",,"Nayi",,,,,,0,"ltr",,"L"
4717,,,"npa",,"Nar Phu",,,,,,0,"ltr",,"L"
4718,,,"npb",,"Nupbikha",,,,,,0,"ltr",,"L"
4719,,,"nph",,"Naga",,"Phom",,,,0,"ltr",,"L"
4720,,,"npn",,"Mondropolon",,,,,,0,"ltr",,"L"
4721,,,"npo",,"Naga",,"Pochuri",,,,0,"ltr",,"L"
4722,,,"nps",,"Nipsan",,,,,,0,"ltr",,"L"
4723,,,"npu",,"Naga",,"Puimei",,,,0,"ltr",,"L"
4724,,,"npy",,"Napu",,,,,,0,"ltr",,"L"
4725,,,"nqg",,"Ede Nago",,,,,,0,"ltr",,"L"
4726,,,"nqk",,"Ede Nago",,"Kura",,,,0,"ltr",,"L"
4727,,,"nqm",,"Ndom",,,,,,0,"ltr",,"L"
4728,,,"nqn",,"Nen",,,,,,0,"ltr",,"L"
4729,,,"nra",,"Ngom",,,,,,0,"ltr",,"L"
4730,,,"nrb",,"Nara",,,,,,0,"ltr",,"L"
4731,,,"nrc",,"Noric",,,,,,0,"ltr",,"A"
4732,,,"nre",,"Naga",,"Southern Rengma",,,,0,"ltr",,"L"
4733,,,"nrg",,"Narango",,,,,,0,"ltr",,"L"
4734,,,"nri",,"Naga",,"Chokri",,,,0,"ltr",,"L"
4735,,,"nrl",,"Ngarluma",,,,,,0,"ltr",,"L"
4736,,,"nrm",,"Narom",,,,,,0,"ltr",,"L"
4737,,,"nrn",,"Norn",,,,,,0,"ltr",,"E"
4738,,,"nrp",,"North Picene",,,,,,0,"ltr",,"A"
4739,,,"nrr",,"Norra",,,,,,0,"ltr",,"L"
4740,,,"nrt",,"Northern Kalapuya",,,,,,0,"ltr",,"E"
4741,,,"nrx",,"Ngurmbur",,,,,,0,"ltr",,"L"
4742,,,"nrz",,"Lala",,,,,,0,"ltr",,"L"
4743,,,"nsa",,"Naga",,"Sangtam",,,,0,"ltr",,"L"
4744,,,"nsc",,"Nshi",,,,,,0,"ltr",,"L"
4745,,,"nse",,"Nsenga",,,,,,0,"ltr",,"L"
4746,,,"nsg",,"Ngasa",,,,,,0,"ltr",,"L"
4747,,,"nsh",,"Ngoshie",,,,,,0,"ltr",,"L"
4748,,,"nsi",,"Nigerian Sign Language",,,,,,0,"ltr",,"L"
4749,,,"nsk",,"Naskapi",,,,,,0,"ltr",,"L"
4750,,,"nsl",,"Norwegian Sign Language",,,,,,0,"ltr",,"L"
4751,,,"nsm",,"Naga",,"Sumi",,,,0,"ltr",,"L"
4752,,,"nsn",,"Nehan",,,,,,0,"ltr",,"L"
4753,,"nso","nso",,"Sotho",,"Northern",,,,0,"ltr",,"L"
4754,,,"nsp",,"Nepalese Sign Language",,,,,,0,"ltr",,"L"
4755,,,"nsq",,"Miwok",,"Northern Sierra",,,,0,"ltr",,"L"
4756,,,"nsr",,"Maritime Sign Language",,,,,,0,"ltr",,"L"
4757,,,"nss",,"Nali",,,,,,0,"ltr",,"L"
4758,,,"nst",,"Naga",,"Tase",,,,0,"ltr",,"L"
4759,,,"nsw",,"Navut",,,,,,0,"ltr",,"L"
4760,,,"nsx",,"Nsongo",,,,,,0,"ltr",,"L"
4761,,,"nsz",,"Nisenan",,,,,,0,"ltr",,"L"
4762,,,"nte",,"Nathembo",,,,,,0,"ltr",,"L"
4763,,,"nti",,"Natioro",,,,,,0,"ltr",,"L"
4764,,,"ntj",,"Ngaanyatjarra",,,,,,0,"ltr",,"L"
4765,,,"ntk",,"Ikoma",,,,,,0,"ltr",,"L"
4766,,,"ntm",,"Nateni",,,,,,0,"ltr",,"L"
4767,,,"nto",,"Ntomba",,,,,,0,"ltr",,"L"
4768,,,"ntp",,"Tepehuan",,"Northern",,,,0,"ltr",,"L"
4769,,,"ntr",,"Delo",,,,,,0,"ltr",,"L"
4770,,,"nts",,"Natagaimas",,,,,,0,"ltr",,"E"
4771,,,"ntw",,"Nottoway",,,,,,0,"ltr",,"E"
4772,,,"nty",,"Mantsi",,,,,,0,"ltr",,"L"
4773,,,"ntz",,"Natanzi",,,,,,0,"ltr",,"L"
4774,,,"nua",,"Yuaga",,,,,,0,"ltr",,"L"
4775,,,"nuc",,"Nukuini",,,,,,0,"ltr",,"E"
4776,,,"nud",,"Ngala",,,,,,0,"ltr",,"L"
4777,,,"nue",,"Ngundu",,,,,,0,"ltr",,"L"
4778,,,"nuf",,"Nusu",,,,,,0,"ltr",,"L"
4779,,,"nug",,"Nungali",,,,,,0,"ltr",,"L"
4780,,,"nuh",,"Ndunda",,,,,,0,"ltr",,"L"
4781,,,"nui",,"Ngumbi",,,,,,0,"ltr",,"L"
4782,,,"nuj",,"Nyole",,,,,,0,"ltr",,"L"
4783,,,"nul",,"Nusa Laut",,,,,,0,"ltr",,"L"
4784,,,"num",,"Niuafo'ou",,,,,,0,"ltr",,"L"
4785,,,"nun",,"Nung","Myanmar",,,,,0,"ltr",,"L"
4786,,,"nuo",,"Nguôn",,,,,,0,"ltr",,"L"
4787,,,"nup",,"Nupe-Nupe-Tako",,,,,,0,"ltr",,"L"
4788,,,"nuq",,"Nukumanu",,,,,,0,"ltr",,"L"
4789,,,"nur",,"Nukuria",,,,,,0,"ltr",,"L"
4790,,,"nus",,"Nuer",,,,,,0,"ltr",,"L"
4791,,,"nut",,"Nung","Viet Nam",,,,,0,"ltr",,"L"
4792,,,"nuu",,"Ngbundu",,,,,,0,"ltr",,"L"
4793,,,"nuv",,"Nuni",,"Northern",,,,0,"ltr",,"L"
4794,,,"nuw",,"Nguluwan",,,,,,0,"ltr",,"L"
4795,,,"nux",,"Mehek",,,,,,0,"ltr",,"L"
4796,,,"nuy",,"Nunggubuyu",,,,,,0,"ltr",,"L"
4797,,,"nuz",,"Nahuatl",,"Tlamacazapa",,,,0,"ltr",,"L"
4798,,,"nvh",,"Nasarian",,,,,,0,"ltr",,"L"
4799,,,"nvm",,"Namiae",,,,,,0,"ltr",,"L"
4800,,,"nwa",,"Nawathinehena",,,,,,0,"ltr",,"E"
4801,,,"nwb",,"Nyabwa",,,,,,0,"ltr",,"L"
4802,,"nwc","nwc",,"Newari",,"Classical; Old Newari",,,,0,"ltr",,"H"
4803,,,"nwe",,"Ngwe",,,,,,0,"ltr",,"L"
4804,,,"nwi",,"Tanna",,"Southwest",,,,0,"ltr",,"L"
4805,,,"nwm",,"Nyamusa-Molo",,,,,,0,"ltr",,"L"
4806,,,"nwr",,"Nawaru",,,,,,0,"ltr",,"L"
4807,,,"nwx",,"Newar",,"Middle",,,,0,"ltr",,"H"
4808,,,"nwy",,"Nottoway-Meherrin",,,,,,0,"ltr",,"E"
4809,,,"nxa",,"Nauete",,,,,,0,"ltr",,"L"
4810,,,"nxd",,"Ngando","Democratic Republic of Congo",,,,,0,"ltr",,"L"
4811,,,"nxe",,"Nage",,,,,,0,"ltr",,"L"
4812,,,"nxg",,"Ngad'a",,,,,,0,"ltr",,"L"
4813,,,"nxi",,"Nindi",,,,,,0,"ltr",,"L"
4814,,,"nxj",,"Nyadu",,,,,,0,"ltr",,"L"
4815,,,"nxl",,"Nuaulu",,"South",,,,0,"ltr",,"L"
4816,,,"nxm",,"Numidian",,,,,,0,"ltr",,"A"
4817,,,"nxn",,"Ngawun",,,,,,0,"ltr",,"L"
4818,,,"nxr",,"Ninggerum",,,,,,0,"ltr",,"L"
4819,,,"nxu",,"Narau",,,,,,0,"ltr",,"L"
4820,,,"nxx",,"Nafri",,,,,,0,"ltr",,"L"
4821,"ny","nya","nya",,"Chichewa; Nyanja",,,,,,0,"ltr",,"L"
4822,,,"nyb",,"Nyangbo",,,,,,0,"ltr",,"L"
4823,,,"nyc",,"Nyanga-li",,,,,,0,"ltr",,"L"
4824,,,"nyd",,"Nyore",,,,,,0,"ltr",,"L"
4825,,,"nye",,"Nyengo",,,,,,0,"ltr",,"L"
4826,,,"nyf",,"Giryama",,,,,,0,"ltr",,"L"
4827,,,"nyg",,"Nyindu",,,,,,0,"ltr",,"L"
4828,,,"nyh",,"Nyigina",,,,,,0,"ltr",,"L"
4829,,,"nyi",,"Ama","Sudan",,,,,0,"ltr",,"L"
4830,,,"nyj",,"Nyanga",,,,,,0,"ltr",,"L"
4831,,,"nyk",,"Nyaneka",,,,,,0,"ltr",,"L"
4832,,,"nyl",,"Nyeu",,,,,,0,"ltr",,"L"
4833,,"nym","nym",,"Nyamwezi",,,,,,0,"ltr",,"L"
4834,,"nyn","nyn",,"Nyankole",,,,,,0,"ltr",,"L"
4835,,"nyo","nyo",,"Nyoro",,,,,,0,"ltr",,"L"
4836,,,"nyp",,"Nyang'i",,,,,,0,"ltr",,"E"
4837,,,"nyq",,"Nayini",,,,,,0,"ltr",,"L"
4838,,,"nys",,"Nyunga",,,,,,0,"ltr",,"E"
4839,,,"nyt",,"Nyawaygi",,,,,,0,"ltr",,"L"
4840,,,"nyu",,"Nyungwe",,,,,,0,"ltr",,"L"
4841,,,"nyv",,"Nyulnyul",,,,,,0,"ltr",,"L"
4842,,,"nyw",,"Nyaw",,,,,,0,"ltr",,"L"
4843,,,"nyx",,"Nganyaywana",,,,,,0,"ltr",,"E"
4844,,,"nyy",,"Nyakyusa-Ngonde",,,,,,0,"ltr",,"L"
4845,,,"nza",,"Mbembe",,"Tigon",,,,0,"ltr",,"L"
4846,,,"nzb",,"Njebi",,,,,,0,"ltr",,"L"
4847,,"nzi","nzi",,"Nzima",,,,,,0,"ltr",,"L"
4848,,,"nzk",,"Nzakara",,,,,,0,"ltr",,"L"
4849,,,"nzm",,"Naga",,"Zeme",,,,0,"ltr",,"L"
4850,,,"nzs",,"New Zealand Sign Language",,,,,,0,"ltr",,"L"
4851,,,"nzu",,"Teke-Nzikou",,,,,,0,"ltr",,"L"
4852,,,"nzy",,"Nzakambay",,,,,,0,"ltr",,"L"
4853,,,"oaa",,"Orok",,,,,,0,"ltr",,"L"
4854,,,"oac",,"Oroch",,,,,,0,"ltr",,"L"
4855,,,"oar",,"Aramaic",,"Old",,,,0,"ltr",,"A"
4856,,,"oav",,"Avar",,"Old",,,,0,"ltr",,"H"
4857,,,"obi",,"Obispeño",,,,,,0,"ltr",,"E"
4858,,,"obl",,"Oblo",,,,,,0,"ltr",,"L"
4859,,,"obm",,"Moabite",,,,,,0,"ltr",,"A"
4860,,,"obo",,"Manobo",,"Obo",,,,0,"ltr",,"L"
4861,,,"obr",,"Burmese",,"Old",,,,0,"ltr",,"H"
4862,,,"obt",,"Breton",,"Old",,,,0,"ltr",,"H"
4863,,,"obu",,"Obulom",,,,,,0,"ltr",,"L"
4864,,,"oca",,"Ocaina",,,,,,0,"ltr",,"L"
4865,,,"occ",,"Occidental",,,,,,0,"ltr",,"C"
4866,,,"och",,"Chinese",,"Old",,,,0,"ltr",,"A"
4867,"oc","oci","oci",,"Occitan","post 1500",,,,,1,"ltr",,"L"
4868,,,"oco",,"Cornish",,"Old",,,,0,"ltr",,"H"
4869,,,"ocu",,"Matlatzinca",,"Atzingo",,,,0,"ltr",,"L"
4870,,,"oda",,"Odut",,,,,,0,"ltr",,"L"
4871,,,"odk",,"Od",,,,,,0,"ltr",,"L"
4872,,,"odt",,"Dutch",,"Old",,,,0,"ltr",,"H"
4873,,,"odu",,"Odual",,,,,,0,"ltr",,"L"
4874,,,"ofo",,"Ofo",,,,,,0,"ltr",,"E"
4875,,,"ofs",,"Frisian",,"Old",,,,0,"ltr",,"H"
4876,,,"ofu",,"Efutop",,,,,,0,"ltr",,"L"
4877,,,"ogb",,"Ogbia",,,,,,0,"ltr",,"L"
4878,,,"ogc",,"Ogbah",,,,,,0,"ltr",,"L"
4879,,,"oge",,"Georgian",,"Old",,,,0,"ltr",,"H"
4880,,,"ogg",,"Ogbogolo",,,,,,0,"ltr",,"L"
4881,,,"ogn",,"Ogan",,,,,,0,"ltr",,"L"
4882,,,"ogo",,"Khana",,,,,,0,"ltr",,"L"
4883,,,"ogu",,"Ogbronuagum",,,,,,0,"ltr",,"L"
4884,,,"oht",,"Hittite",,"Old",,,,0,"ltr",,"A"
4885,,,"ohu",,"Hungarian",,"Old",,,,0,"ltr",,"H"
4886,,,"oia",,"Oirata",,,,,,0,"ltr",,"L"
4887,,,"oin",,"One",,"Inebu",,,,0,"ltr",,"L"
4888,,,"ojb",,"Ojibwa",,"Northwestern",,,,0,"ltr",,"L"
4889,,,"ojc",,"Ojibwa",,"Central",,,,0,"ltr",,"L"
4890,,,"ojg",,"Ojibwa",,"Eastern",,,,0,"ltr",,"L"
4891,"oj","oji","oji",,"Ojibwa",,,,,,1,"ltr",,"L"
4892,,,"ojp",,"Japanese",,"Old",,,,0,"ltr",,"H"
4893,,,"ojs",,"Ojibwa",,"Severn",,,,0,"ltr",,"L"
4894,,,"ojv",,"Ontong Java",,,,,,0,"ltr",,"L"
4895,,,"ojw",,"Ojibwa",,"Western",,,,0,"ltr",,"L"
4896,,,"oka",,"Okanagan",,,,,,0,"ltr",,"L"
4897,,,"okb",,"Okobo",,,,,,0,"ltr",,"L"
4898,,,"okd",,"Okodia",,,,,,0,"ltr",,"L"
4899,,,"oke",,"Okpe","Southwestern Edo",,,,,0,"ltr",,"L"
4900,,,"okh",,"Koresh-e Rostam",,,,,,0,"ltr",,"L"
4901,,,"oki",,"Okiek",,,,,,0,"ltr",,"L"
4902,,,"okj",,"Oko-Juwoi",,,,,,0,"ltr",,"E"
4903,,,"okk",,"One",,"Kwamtim",,,,0,"ltr",,"L"
4904,,,"okl",,"Old Kentish Sign Language",,,,,,0,"ltr",,"E"
4905,,,"okm",,"Korean",,"Middle (10th - 16th cent.)",,,,0,"ltr",,"H"
4906,,,"okn",,"Oki-No-Erabu",,,,,,0,"ltr",,"L"
4907,,,"oko",,"Korean",,"Old (3rd - 9th cent.)",,,,0,"ltr",,"H"
4908,,,"okr",,"Kirike",,,,,,0,"ltr",,"L"
4909,,,"oks",,"Oko-Eni-Osayen",,,,,,0,"ltr",,"L"
4910,,,"oku",,"Oku",,,,,,0,"ltr",,"L"
4911,,,"okx",,"Okpe","Northwestern Edo",,,,,0,"ltr",,"L"
4912,,,"ola",,"Walungge",,,,,,0,"ltr",,"L"
4913,,,"old",,"Mochi",,,,,,0,"ltr",,"L"
4914,,,"ole",,"Olekha",,,,,,0,"ltr",,"L"
4915,,,"olm",,"Oloma",,,,,,0,"ltr",,"L"
4916,,,"olo",,"Livvi",,,,,,0,"ltr",,"L"
4917,,,"oma",,"Omaha-Ponca",,,,,,0,"ltr",,"L"
4918,,,"omb",,"Ambae",,"East",,,,0,"ltr",,"L"
4919,,,"omc",,"Mochica",,,,,,0,"ltr",,"E"
4920,,,"ome",,"Omejes",,,,,,0,"ltr",,"E"
4921,,,"omg",,"Omagua",,,,,,0,"ltr",,"L"
4922,,,"omi",,"Omi",,,,,,0,"ltr",,"L"
4923,,,"omk",,"Omok",,,,,,0,"ltr",,"E"
4924,,,"oml",,"Ombo",,,,,,0,"ltr",,"L"
4925,,,"omn",,"Minoan",,,,,,0,"ltr",,"A"
4926,,,"omo",,"Utarmbung",,,,,,0,"ltr",,"L"
4927,,,"omp",,"Manipuri",,"Old",,,,0,"ltr",,"H"
4928,,,"omr",,"Marathi",,"Old",,,,0,"ltr",,"H"
4929,,,"omt",,"Omotik",,,,,,0,"ltr",,"L"
4930,,,"omu",,"Omurano",,,,,,0,"ltr",,"E"
4931,,,"omw",,"Tairora",,"South",,,,0,"ltr",,"L"
4932,,,"omx",,"Mon",,"Old",,,,0,"ltr",,"H"
4933,,,"ona",,"Ona",,,,,,0,"ltr",,"L"
4934,,,"onb",,"Lingao",,,,,,0,"ltr",,"L"
4935,,,"one",,"Oneida",,,,,,0,"ltr",,"L"
4936,,,"ong",,"Olo",,,,,,0,"ltr",,"L"
4937,,,"oni",,"Onin",,,,,,0,"ltr",,"L"
4938,,,"onj",,"Onjob",,,,,,0,"ltr",,"L"
4939,,,"onk",,"One",,"Kabore",,,,0,"ltr",,"L"
4940,,,"onn",,"Onobasulu",,,,,,0,"ltr",,"L"
4941,,,"ono",,"Onondaga",,,,,,0,"ltr",,"L"
4942,,,"onr",,"One",,"Northern",,,,0,"ltr",,"L"
4943,,,"ons",,"Ono",,,,,,0,"ltr",,"L"
4944,,,"ont",,"Ontenu",,,,,,0,"ltr",,"L"
4945,,,"onu",,"Unua",,,,,,0,"ltr",,"L"
4946,,,"onw",,"Nubian",,"Old",,,,0,"ltr",,"H"
4947,,,"onx",,"Onin Based Pidgin",,,,,,0,"ltr",,"L"
4948,,,"ood",,"Tohono O'odham",,,,,,0,"ltr",,"L"
4949,,,"oog",,"Ong",,,,,,0,"ltr",,"L"
4950,,,"oon",,"Önge",,,,,,0,"ltr",,"L"
4951,,,"oor",,"Oorlams",,,,,,0,"ltr",,"L"
4952,,,"oos",,"Ossetic",,"Old",,,,0,"ltr",,"A"
4953,,,"opa",,"Okpamheri",,,,,,0,"ltr",,"L"
4954,,,"ope",,"Persian",,"Old",,,,0,"ltr",,"A"
4955,,,"opk",,"Kopkaka",,,,,,0,"ltr",,"L"
4956,,,"opm",,"Oksapmin",,,,,,0,"ltr",,"L"
4957,,,"opo",,"Opao",,,,,,0,"ltr",,"L"
4958,,,"opt",,"Opata",,,,,,0,"ltr",,"L"
4959,,,"opy",,"Ofayé",,,,,,0,"ltr",,"L"
4960,,,"ora",,"Oroha",,,,,,0,"ltr",,"L"
4961,,,"orc",,"Orma",,,,,,0,"ltr",,"L"
4962,,,"ore",,"Orejón",,,,,,0,"ltr",,"L"
4963,,,"org",,"Oring",,,,,,0,"ltr",,"L"
4964,,,"orh",,"Oroqen",,,,,,0,"ltr",,"L"
4965,"or","ori","ori",,"Oriya",,,,,,0,"ltr",,"L"
4966,,,"ork",,"Orokaiva",,,,,,0,"ltr",,"L"
4967,"om","orm","orm",,"Oromo",,,,,,1,"ltr",,"L"
4968,,,"orn",,"Orang Kanaq",,,,,,0,"ltr",,"L"
4969,,,"oro",,"Orokolo",,,,,,0,"ltr",,"L"
4970,,,"orq",,"Orcish",,,,,,0,"ltr",,"C"
4971,,,"orr",,"Oruma",,,,,,0,"ltr",,"L"
4972,,,"ors",,"Orang Seletar",,,,,,0,"ltr",,"L"
4973,,,"ort",,"Oriya",,"Adivasi",,,,0,"ltr",,"L"
4974,,,"oru",,"Ormuri",,,,,,0,"ltr",,"L"
4975,,,"orv",,"Russian",,"Old",,,,0,"ltr",,"H"
4976,,,"orw",,"Oro Win",,,,,,0,"ltr",,"L"
4977,,,"orx",,"Oro",,,,,,0,"ltr",,"L"
4978,,,"orz",,"Ormu",,,,,,0,"ltr",,"L"
4979,,"osa","osa",,"Osage",,,,,,0,"ltr",,"L"
4980,,,"osc",,"Oscan",,,,,,0,"ltr",,"A"
4981,,,"osi",,"Osing",,,,,,0,"ltr",,"L"
4982,,,"oso",,"Ososo",,,,,,0,"ltr",,"L"
4983,,,"osp",,"Spanish",,"Old",,,,0,"ltr",,"H"
4984,"os","oss","oss",,"Ossetian; Ossetic",,,,,,0,"ltr",,"L"
4985,,,"ost",,"Osatu",,,,,,0,"ltr",,"L"
4986,,,"osu",,"One",,"Southern",,,,0,"ltr",,"L"
4987,,,"osx",,"Saxon",,"Old",,,,0,"ltr",,"H"
4988,,"ota","ota",,"Turkish",,"Ottoman (1500-1928)",,,,0,"ltr",,"H"
4989,,,"otb",,"Tibetan",,"Old",,,,0,"ltr",,"H"
4990,,,"otd",,"Dohoi",,,,,,0,"ltr",,"L"
4991,,,"ote",,"Otomi",,"Mezquital",,,,0,"ltr",,"L"
4992,,,"oti",,"Oti",,,,,,0,"ltr",,"E"
4993,,,"otk",,"Turkish",,"Old",,,,0,"ltr",,"H"
4994,,,"otl",,"Otomi",,"Tilapa",,,,0,"ltr",,"L"
4995,,,"otm",,"Otomi",,"Eastern Highland",,,,0,"ltr",,"L"
4996,,,"otn",,"Otomi",,"Tenango",,,,0,"ltr",,"L"
4997,,,"otq",,"Otomi",,"Querétaro",,,,0,"ltr",,"L"
4998,,,"otr",,"Otoro",,,,,,0,"ltr",,"L"
4999,,,"ots",,"Otomi",,"Estado de México",,,,0,"ltr",,"L"
5000,,,"ott",,"Otomi",,"Temoaya",,,,0,"ltr",,"L"
5001,,,"otu",,"Otuke",,,,,,0,"ltr",,"E"
5002,,,"otw",,"Ottawa",,,,,,0,"ltr",,"L"
5003,,,"otx",,"Otomi",,"Texcatepec",,,,0,"ltr",,"L"
5004,,,"oty",,"Tamil",,"Old",,,,0,"ltr",,"A"
5005,,,"otz",,"Otomi",,"Ixtenco",,,,0,"ltr",,"L"
5006,,,"oua",,"Tagargrent",,,,,,0,"ltr",,"L"
5007,,,"oub",,"Glio-Oubi",,,,,,0,"ltr",,"L"
5008,,,"oue",,"Oune",,,,,,0,"ltr",,"L"
5009,,,"oui",,"Uighur",,"Old",,,,0,"ltr",,"H"
5010,,,"oum",,"Ouma",,,,,,0,"ltr",,"E"
5011,,,"oun",,"!O!ung",,,,,,0,"ltr",,"L"
5012,,,"owi",,"Owiniga",,,,,,0,"ltr",,"L"
5013,,,"owl",,"Welsh",,"Old",,,,0,"ltr",,"H"
5014,,,"oyb",,"Oy",,,,,,0,"ltr",,"L"
5015,,,"oyd",,"Oyda",,,,,,0,"ltr",,"L"
5016,,,"oym",,"Wayampi",,,,,,0,"ltr",,"L"
5017,,,"oyy",,"Oya'oya",,,,,,0,"ltr",,"L"
5018,,,"ozm",,"Koonzime",,,,,,0,"ltr",,"L"
5019,,,"pab",,"Parecís",,,,,,0,"ltr",,"L"
5020,,,"pac",,"Pacoh",,,,,,0,"ltr",,"L"
5021,,,"pad",,"Paumarí",,,,,,0,"ltr",,"L"
5022,,,"pae",,"Pagibete",,,,,,0,"ltr",,"L"
5023,,,"paf",,"Paranawát",,,,,,0,"ltr",,"E"
5024,,"pag","pag",,"Pangasinan",,,,,,0,"ltr",,"L"
5025,,,"pah",,"Tenharim",,,,,,0,"ltr",,"L"
5026,,,"pai",,"Pe",,,,,,0,"ltr",,"L"
5027,,,"paj",,"Ipeka-Tapuia",,,,,,0,"ltr",,"L"
5028,,,"pak",,"Parakanã",,,,,,0,"ltr",,"L"
5029,,"pal","pal",,"Pahlavi",,,,,,0,"ltr",,"A"
5030,,"pam","pam",,"Pampanga",,,,,,0,"ltr",,"L"
5031,"pa","pan","pan",,"Panjabi",,,,,,0,"ltr",,"L"
5032,,,"pao",,"Paiute",,"Northern",,,,0,"ltr",,"L"
5033,,"pap","pap",,"Papiamento",,,,,,0,"ltr",,"L"
5034,,,"paq",,"Parya",,,,,,0,"ltr",,"L"
5035,,,"par",,"Panamint",,,,,,0,"ltr",,"L"
5036,,,"pas",,"Papasena",,,,,,0,"ltr",,"L"
5037,,,"pat",,"Papitalai",,,,,,0,"ltr",,"L"
5038,,"pau","pau",,"Palauan",,,,,,0,"ltr",,"L"
5039,,,"pav",,"Pakaásnovos",,,,,,0,"ltr",,"L"
5040,,,"paw",,"Pawnee",,,,,,0,"ltr",,"L"
5041,,,"pax",,"Pankararé",,,,,,0,"ltr",,"E"
5042,,,"pay",,"Pech",,,,,,0,"ltr",,"L"
5043,,,"paz",,"Pankararú",,,,,,0,"ltr",,"E"
5044,,,"pbb",,"Páez",,,,,,0,"ltr",,"L"
5045,,,"pbc",,"Patamona",,,,,,0,"ltr",,"L"
5046,,,"pbe",,"Popoloca",,"Mezontla",,,,0,"ltr",,"L"
5047,,,"pbf",,"Popoloca",,"Coyotepec",,,,0,"ltr",,"L"
5048,,,"pbg",,"Paraujano",,,,,,0,"ltr",,"E"
5049,,,"pbh",,"Eñepa",,,,,,0,"ltr",,"L"
5050,,,"pbi",,"Parkwa",,,,,,0,"ltr",,"L"
5051,,,"pbl",,"Mak","Nigeria",,,,,0,"ltr",,"L"
5052,,,"pbn",,"Kpasam",,,,,,0,"ltr",,"L"
5053,,,"pbo",,"Papel",,,,,,0,"ltr",,"L"
5054,,,"pbp",,"Badyara",,,,,,0,"ltr",,"L"
5055,,,"pbr",,"Pangwa",,,,,,0,"ltr",,"L"
5056,,,"pbs",,"Pame",,"Central",,,,0,"ltr",,"L"
5057,,,"pbt",,"Pashto",,"Southern",,,,0,"ltr",,"L"
5058,,,"pbu",,"Pashto",,"Northern",,,,0,"ltr",,"L"
5059,,,"pbv",,"Pnar",,,,,,0,"ltr",,"L"
5060,,,"pby",,"Pyu",,,,,,0,"ltr",,"L"
5061,,,"pbz",,"Palu",,,,,,0,"ltr",,"L"
5062,,,"pca",,"Popoloca",,"Santa Inés Ahuatempan",,,,0,"ltr",,"L"
5063,,,"pcb",,"Pear",,,,,,0,"ltr",,"L"
5064,,,"pcc",,"Bouyei",,,,,,0,"ltr",,"L"
5065,,,"pcd",,"Picard",,,,,,0,"ltr",,"L"
5066,,,"pce",,"Palaung",,"Pale",,,,0,"ltr",,"L"
5067,,,"pcf",,"Paliyan",,,,,,0,"ltr",,"L"
5068,,,"pcg",,"Paniya",,,,,,0,"ltr",,"L"
5069,,,"pch",,"Pardhan",,,,,,0,"ltr",,"L"
5070,,,"pci",,"Duruwa",,,,,,0,"ltr",,"L"
5071,,,"pcj",,"Parenga",,,,,,0,"ltr",,"L"
5072,,,"pck",,"Chin",,"Paite",,,,0,"ltr",,"L"
5073,,,"pcl",,"Pardhi",,,,,,0,"ltr",,"L"
5074,,,"pcm",,"Pidgin",,"Nigerian",,,,0,"ltr",,"L"
5075,,,"pcn",,"Piti",,,,,,0,"ltr",,"L"
5076,,,"pcp",,"Pacahuara",,,,,,0,"ltr",,"L"
5077,,,"pcr",,"Panang",,,,,,0,"ltr",,"L"
5078,,,"pcw",,"Pyapun",,,,,,0,"ltr",,"L"
5079,,,"pda",,"Anam",,,,,,0,"ltr",,"L"
5080,,,"pdc",,"German",,"Pennsylvania",,,,0,"ltr",,"L"
5081,,,"pdi",,"Pa Di",,,,,,0,"ltr",,"L"
5082,,,"pdn",,"Podena",,,,,,0,"ltr",,"L"
5083,,,"pdo",,"Padoe",,,,,,0,"ltr",,"L"
5084,,,"pdt",,"Plautdietsch",,,,,,0,"ltr",,"L"
5085,,,"pdu",,"Kayan",,,,,,0,"ltr",,"L"
5086,,,"pea",,"Indonesian",,"Peranakan",,,,0,"ltr",,"L"
5087,,,"peb",,"Pomo",,"Eastern",,,,0,"ltr",,"E"
5088,,,"pec",,"Pesisir",,"Southern",,,,0,"ltr",,"L"
5089,,,"ped",,"Mala","Papua New Guinea",,,,,0,"ltr",,"L"
5090,,,"pee",,"Taje",,,,,,0,"ltr",,"L"
5091,,,"pef",,"Pomo",,"Northeastern",,,,0,"ltr",,"E"
5092,,,"peg",,"Pengo",,,,,,0,"ltr",,"L"
5093,,,"peh",,"Bonan",,,,,,0,"ltr",,"L"
5094,,,"pei",,"Chichimeca-Jonaz",,,,,,0,"ltr",,"L"
5095,,,"pej",,"Pomo",,"Northern",,,,0,"ltr",,"E"
5096,,,"pek",,"Penchal",,,,,,0,"ltr",,"L"
5097,,,"pel",,"Pekal",,,,,,0,"ltr",,"L"
5098,,,"pem",,"Phende",,,,,,0,"ltr",,"L"
5099,,,"pen",,"Penesak",,,,,,0,"ltr",,"L"
5100,,"peo","peo",,"Persian",,"Old (ca.600-400 B.C.)",,,,0,"ltr",,"H"
5101,,,"pep",,"Kunja",,,,,,0,"ltr",,"L"
5102,,,"peq",,"Pomo",,"Southern",,,,0,"ltr",,"L"
5103,,,"pes",,"Farsi",,"Western",,,,0,"ltr",,"L"
5104,,,"pev",,"Pémono",,,,,,0,"ltr",,"L"
5105,,,"pex",,"Petats",,,,,,0,"ltr",,"L"
5106,,,"pey",,"Petjo",,,,,,0,"ltr",,"L"
5107,,,"pez",,"Penan",,"Eastern",,,,0,"ltr",,"L"
5108,,,"pfa",,"Pááfang",,,,,,0,"ltr",,"L"
5109,,,"pfe",,"Peere",,,,,,0,"ltr",,"L"
5110,,,"pfl",,"Pfaelzisch",,,,,,0,"ltr",,"L"
5111,,,"pga",,"Arabic",,"Sudanese Creole",,,,0,"rtl",,"L"
5112,,,"pgg",,"Pangwali",,,,,,0,"ltr",,"L"
5113,,,"pgi",,"Pagi",,,,,,0,"ltr",,"L"
5114,,,"pgk",,"Rerep",,,,,,0,"ltr",,"L"
5115,,,"pgn",,"Paelignian",,,,,,0,"ltr",,"A"
5116,,,"pgs",,"Pangseng",,,,,,0,"ltr",,"L"
5117,,,"pgu",,"Pagu",,,,,,0,"ltr",,"L"
5118,,,"pgy",,"Pongyong",,,,,,0,"ltr",,"L"
5119,,,"pha",,"Pa-Hng",,,,,,0,"ltr",,"L"
5120,,,"phd",,"Phudagi",,,,,,0,"ltr",,"L"
5121,,,"phg",,"Phuong",,,,,,0,"ltr",,"L"
5122,,,"phh",,"Phula",,,,,,0,"ltr",,"L"
5123,,,"phk",,"Phake",,,,,,0,"ltr",,"L"
5124,,,"phl",,"Phalura",,,,,,0,"ltr",,"L"
5125,,,"phm",,"Phimbi",,,,,,0,"ltr",,"L"
5126,,"phn","phn",,"Phoenician",,,,,,0,"ltr",,"A"
5127,,,"pho",,"Phunoi",,,,,,0,"ltr",,"L"
5128,,,"phq",,"Phana'",,,,,,0,"ltr",,"L"
5129,,,"phr",,"Pahari-Potwari",,,,,,0,"ltr",,"L"
5130,,,"pht",,"Phu Thai",,,,,,0,"ltr",,"L"
5131,,,"phu",,"Phuan",,,,,,0,"ltr",,"L"
5132,,,"phv",,"Pahlavani",,,,,,0,"ltr",,"L"
5133,,,"phw",,"Phangduwali",,,,,,0,"ltr",,"L"
5134,,,"pia",,"Pima Bajo",,,,,,0,"ltr",,"L"
5135,,,"pib",,"Yine",,,,,,0,"ltr",,"L"
5136,,,"pic",,"Pinji",,,,,,0,"ltr",,"L"
5137,,,"pid",,"Piaroa",,,,,,0,"ltr",,"L"
5138,,,"pie",,"Piro",,,,,,0,"ltr",,"E"
5139,,,"pif",,"Pingelapese",,,,,,0,"ltr",,"L"
5140,,,"pig",,"Pisabo",,,,,,0,"ltr",,"L"
5141,,,"pih",,"Pitcairn-Norfolk",,,,,,0,"ltr",,"L"
5142,,,"pii",,"Pini",,,,,,0,"ltr",,"L"
5143,,,"pij",,"Pijao",,,,,,0,"ltr",,"E"
5144,,,"pil",,"Yom",,,,,,0,"ltr",,"L"
5145,,,"pim",,"Powhatan",,,,,,0,"ltr",,"E"
5146,,,"pin",,"Piame",,,,,,0,"ltr",,"L"
5147,,,"pio",,"Piapoco",,,,,,0,"ltr",,"L"
5148,,,"pip",,"Pero",,,,,,0,"ltr",,"L"
5149,,,"pir",,"Piratapuyo",,,,,,0,"ltr",,"L"
5150,,,"pis",,"Pijin",,,,,,0,"ltr",,"L"
5151,,,"pit",,"Pitta Pitta",,,,,,0,"ltr",,"L"
5152,,,"piu",,"Pintupi-Luritja",,,,,,0,"ltr",,"L"
5153,,,"piv",,"Pileni",,,,,,0,"ltr",,"L"
5154,,,"piw",,"Pimbwe",,,,,,0,"ltr",,"L"
5155,,,"pix",,"Piu",,,,,,0,"ltr",,"L"
5156,,,"piy",,"Piya-Kwonci",,,,,,0,"ltr",,"L"
5157,,,"piz",,"Pije",,,,,,0,"ltr",,"L"
5158,,,"pjt",,"Pitjantjatjara",,,,,,0,"ltr",,"L"
5159,,,"pkb",,"Pokomo",,"Upper",,,,0,"ltr",,"L"
5160,,,"pkc",,"Paekche",,,,,,0,"ltr",,"E"
5161,,,"pkg",,"Pak-Tong",,,,,,0,"ltr",,"L"
5162,,,"pkh",,"Pankhu",,,,,,0,"ltr",,"L"
5163,,,"pkn",,"Pakanha",,,,,,0,"ltr",,"L"
5164,,,"pko",,"Pökoot",,,,,,0,"ltr",,"L"
5165,,,"pkp",,"Pukapuka",,,,,,0,"ltr",,"L"
5166,,,"pks",,"Pakistan Sign Language",,,,,,0,"ltr",,"L"
5167,,,"pkt",,"Maleng",,,,,,0,"ltr",,"L"
5168,,,"pku",,"Paku",,,,,,0,"ltr",,"L"
5169,,,"pla",,"Miani",,,,,,0,"ltr",,"L"
5170,,,"plb",,"Polonombauk",,,,,,0,"ltr",,"L"
5171,,,"plc",,"Palawano",,"Central",,,,0,"ltr",,"L"
5172,,,"pld",,"Polari",,,,,,0,"ltr",,"L"
5173,,,"ple",,"Palu'e",,,,,,0,"ltr",,"L"
5174,,,"plg",,"Pilagá",,,,,,0,"ltr",,"L"
5175,,,"plh",,"Paulohi",,,,,,0,"ltr",,"L"
5176,"pi","pli","pli",,"Pali",,,,,,0,"ltr",,"A"
5177,,,"plj",,"Polci",,,,,,0,"ltr",,"L"
5178,,,"plk",,"Shina",,"Kohistani",,,,0,"ltr",,"L"
5179,,,"pll",,"Palaung",,"Shwe",,,,0,"ltr",,"L"
5180,,,"plm",,"Palembang",,,,,,0,"ltr",,"L"
5181,,,"pln",,"Palenquero",,,,,,0,"ltr",,"L"
5182,,,"plo",,"Popoluca",,"Oluta",,,,0,"ltr",,"L"
5183,,,"plp",,"Palpa",,,,,,0,"ltr",,"L"
5184,,,"plq",,"Palaic",,,,,,0,"ltr",,"A"
5185,,,"plr",,"Senoufo",,"Palaka",,,,0,"ltr",,"L"
5186,,,"pls",,"Popoloca",,"San Marcos Tlalcoyalco",,,,0,"ltr",,"L"
5187,,,"plt",,"Malagasy",,"Plateau",,,,0,"ltr",,"L"
5188,,,"plu",,"Palikúr",,,,,,0,"ltr",,"L"
5189,,,"plv",,"Palawano",,"Southwest",,,,0,"ltr",,"L"
5190,,,"plw",,"Palawano",,"Brooke's Point",,,,0,"ltr",,"L"
5191,,,"ply",,"Bolyu",,,,,,0,"ltr",,"L"
5192,,,"plz",,"Paluan",,,,,,0,"ltr",,"L"
5193,,,"pma",,"Paama",,,,,,0,"ltr",,"L"
5194,,,"pmb",,"Pambia",,,,,,0,"ltr",,"L"
5195,,,"pmc",,"Palumata",,,,,,0,"ltr",,"E"
5196,,,"pme",,"Pwaamei",,,,,,0,"ltr",,"L"
5197,,,"pmi",,"Pumi",,"Northern",,,,0,"ltr",,"L"
5198,,,"pmj",,"Pumi",,"Southern",,,,0,"ltr",,"L"
5199,,,"pmk",,"Pamlico",,,,,,0,"ltr",,"E"
5200,,,"pml",,"Lingua Franca",,,,,,0,"ltr",,"E"
5201,,,"pmm",,"Pomo",,,,,,0,"ltr",,"L"
5202,,,"pmn",,"Pam",,,,,,0,"ltr",,"L"
5203,,,"pmo",,"Pom",,,,,,0,"ltr",,"L"
5204,,,"pmq",,"Pame",,"Northern",,,,0,"ltr",,"L"
5205,,,"pmr",,"Paynamar",,,,,,0,"ltr",,"L"
5206,,,"pms",,"Piemontese",,,,,,0,"ltr",,"L"
5207,,,"pmt",,"Tuamotuan",,,,,,0,"ltr",,"L"
5208,,,"pmu",,"Panjabi",,"Mirpur",,,,0,"ltr",,"L"
5209,,,"pmw",,"Miwok",,"Plains",,,,0,"ltr",,"L"
5210,,,"pmx",,"Naga",,"Poumei",,,,0,"ltr",,"L"
5211,,,"pmz",,"Pame",,"Southern",,,,0,"ltr",,"E"
5212,,,"pna",,"Punan Bah-Biau",,,,,,0,"ltr",,"L"
5213,,,"pnb",,"Panjabi",,"Western",,,,0,"ltr",,"L"
5214,,,"pnc",,"Pannei",,,,,,0,"ltr",,"L"
5215,,,"pne",,"Penan",,"Western",,,,0,"ltr",,"L"
5216,,,"png",,"Pongu",,,,,,0,"ltr",,"L"
5217,,,"pnh",,"Penrhyn",,,,,,0,"ltr",,"L"
5218,,,"pni",,"Aoheng",,,,,,0,"ltr",,"L"
5219,,,"pnm",,"Punan Batu 1",,,,,,0,"ltr",,"L"
5220,,,"pnn",,"Pinai-Hagahai",,,,,,0,"ltr",,"L"
5221,,,"pno",,"Panobo",,,,,,0,"ltr",,"E"
5222,,,"pnp",,"Pancana",,,,,,0,"ltr",,"L"
5223,,,"pnq",,"Pana","Burkina Faso",,,,,0,"ltr",,"L"
5224,,,"pnr",,"Panim",,,,,,0,"ltr",,"L"
5225,,,"pns",,"Ponosakan",,,,,,0,"ltr",,"L"
5226,,,"pnt",,"Pontic",,,,,,0,"ltr",,"L"
5227,,,"pnu",,"Bunu",,"Jiongnai",,,,0,"ltr",,"L"
5228,,,"pnv",,"Pinigura",,,,,,0,"ltr",,"L"
5229,,,"pnw",,"Panytyima",,,,,,0,"ltr",,"L"
5230,,,"pnx",,"Phong-Kniang",,,,,,0,"ltr",,"L"
5231,,,"pny",,"Pinyin",,,,,,0,"ltr",,"L"
5232,,,"pnz",,"Pana","Central African Republic",,,,,0,"ltr",,"L"
5233,,,"poa",,"Pokomam",,"Eastern",,,,0,"ltr",,"L"
5234,,,"pob",,"Pokomchí",,"Western",,,,0,"ltr",,"L"
5235,,,"poc",,"Pokomam",,"Central",,,,0,"ltr",,"L"
5236,,,"pod",,"Ponares",,,,,,0,"ltr",,"E"
5237,,,"poe",,"Popoloca",,"San Juan Atzingo",,,,0,"ltr",,"L"
5238,,,"pof",,"Poke",,,,,,0,"ltr",,"L"
5239,,,"pog",,"Potiguára",,,,,,0,"ltr",,"E"
5240,,,"poh",,"Pokomchí",,"Eastern",,,,0,"ltr",,"L"
5241,,,"poi",,"Popoluca",,"Highland",,,,0,"ltr",,"L"
5242,,,"poj",,"Pokomo",,"Lower",,,,0,"ltr",,"L"
5243,,,"pok",,"Pokangá",,,,,,0,"ltr",,"L"
5244,"pl","pol","pol",,"Polish",,,"Polski",,,0,"ltr","c==1 ? 1 : c%10>=2 && c%10<=4 && (c%100<10 || c%100>=20) ? 2 : 3","L"
5245,,,"pom",,"Pomo",,"Southeastern",,,,0,"ltr",,"L"
5246,,"pon","pon",,"Pohnpeian",,,,,,0,"ltr",,"L"
5247,,,"poo",,"Pomo",,"Central",,,,0,"ltr",,"L"
5248,,,"pop",,"Pwapwa",,,,,,0,"ltr",,"L"
5249,,,"poq",,"Popoluca",,"Texistepec",,,,0,"ltr",,"L"
5250,"pt","por","por",,"Portuguese",,,"português",,,0,"ltr","c == 1 ? 1 : 2","L"
5251,,,"pos",,"Popoluca",,"Sayula",,,,0,"ltr",,"L"
5252,,,"pot",,"Potawatomi",,,,,,0,"ltr",,"L"
5253,,,"pou",,"Pokomam",,"Southern",,,,0,"ltr",,"L"
5254,,,"pov",,"Crioulo",,"Upper Guinea",,,,0,"ltr",,"L"
5255,,,"pow",,"Popoloca",,"San Felipe Otlaltepec",,,,0,"ltr",,"L"
5256,,,"pox",,"Polabian",,,,,,0,"ltr",,"E"
5257,,,"poy",,"Pogolo",,,,,,0,"ltr",,"L"
5258,,,"ppa",,"Pao",,,,,,0,"ltr",,"L"
5259,,,"ppe",,"Papi",,,,,,0,"ltr",,"L"
5260,,,"ppi",,"Paipai",,,,,,0,"ltr",,"L"
5261,,,"ppk",,"Uma",,,,,,0,"ltr",,"L"
5262,,,"ppl",,"Pipil",,,,,,0,"ltr",,"L"
5263,,,"ppm",,"Papuma",,,,,,0,"ltr",,"L"
5264,,,"ppn",,"Papapana",,,,,,0,"ltr",,"L"
5265,,,"ppo",,"Folopa",,,,,,0,"ltr",,"L"
5266,,,"ppp",,"Pelende",,,,,,0,"ltr",,"L"
5267,,,"ppq",,"Pei",,,,,,0,"ltr",,"L"
5268,,,"ppr",,"Piru",,,,,,0,"ltr",,"L"
5269,,,"pps",,"Popoloca",,"San Luís Temalacayuca",,,,0,"ltr",,"L"
5270,,,"ppt",,"Pare",,,,,,0,"ltr",,"L"
5271,,,"ppu",,"Papora",,,,,,0,"ltr",,"E"
5272,,,"ppv",,"Papavô",,,,,,0,"ltr",,"L"
5273,,,"pqa",,"Pa'a",,,,,,0,"ltr",,"L"
5274,,,"pqm",,"Malecite-Passamaquoddy",,,,,,0,"ltr",,"L"
5275,,,"prb",,"Lua'",,,,,,0,"ltr",,"L"
5276,,,"prc",,"Parachi",,,,,,0,"ltr",,"L"
5277,,,"prd",,"Parsi-Dari",,,,,,0,"ltr",,"L"
5278,,,"pre",,"Principense",,,,,,0,"ltr",,"L"
5279,,,"prg",,"Prussian",,,,,,0,"ltr",,"E"
5280,,,"prh",,"Porohanon",,,,,,0,"ltr",,"L"
5281,,,"pri",,"Paicî",,,,,,0,"ltr",,"L"
5282,,,"prk",,"Parauk",,,,,,0,"ltr",,"L"
5283,,,"prl",,"Peruvian Sign Language",,,,,,0,"ltr",,"L"
5284,,,"prm",,"Kibiri",,,,,,0,"ltr",,"L"
5285,,,"prn",,"Prasuni",,,,,,0,"ltr",,"L"
5286,,"pro","pro",,"Provençal",,"Old (to 1500)",,,,0,"ltr",,"H"
5287,,,"prp",,"Parsi",,,,,,0,"ltr",,"L"
5288,,,"prq",,"Ashéninka Perené",,,,,,0,"ltr",,"L"
5289,,,"prr",,"Puri",,,,,,0,"ltr",,"E"
5290,,,"prs",,"Farsi",,"Eastern",,,,0,"ltr",,"L"
5291,,,"prt",,"Phai",,,,,,0,"ltr",,"L"
5292,,,"pru",,"Puragi",,,,,,0,"ltr",,"L"
5293,,,"prv",,"Provençal",,,,,,0,"ltr",,"L"
5294,,,"prw",,"Parawen",,,,,,0,"ltr",,"L"
5295,,,"prx",,"Purik",,,,,,0,"ltr",,"L"
5296,,,"pry",,"Pray 3",,,,,,0,"ltr",,"L"
5297,,,"prz",,"Providencia Sign Language",,,,,,0,"ltr",,"L"
5298,,,"psa",,"Awyu",,"Asue",,,,0,"ltr",,"L"
5299,,,"psc",,"Persian Sign Language",,,,,,0,"ltr",,"L"
5300,,,"psd",,"Plains Indian Sign Language",,,,,,0,"ltr",,"L"
5301,,,"pse",,"Pasemah",,,,,,0,"ltr",,"L"
5302,,,"psg",,"Penang Sign Language",,,,,,0,"ltr",,"L"
5303,,,"psh",,"Pashayi",,"Southwest",,,,0,"ltr",,"L"
5304,,,"psi",,"Pashayi",,"Southeast",,,,0,"ltr",,"L"
5305,,,"psl",,"Puerto Rican Sign Language",,,,,,0,"ltr",,"L"
5306,,,"psm",,"Pauserna",,,,,,0,"ltr",,"E"
5307,,,"psn",,"Panasuan",,,,,,0,"ltr",,"L"
5308,,,"pso",,"Polish Sign Language",,,,,,0,"ltr",,"L"
5309,,,"psp",,"Philippine Sign Language",,,,,,0,"ltr",,"L"
5310,,,"psq",,"Pasi",,,,,,0,"ltr",,"L"
5311,,,"psr",,"Portuguese Sign Language",,,,,,0,"ltr",,"L"
5312,,,"pss",,"Kaulong",,,,,,0,"ltr",,"L"
5313,,,"pst",,"Pashto",,"Central",,,,0,"ltr",,"L"
5314,,,"psw",,"Port Sandwich",,,,,,0,"ltr",,"L"
5315,,,"psy",,"Piscataway",,,,,,0,"ltr",,"E"
5316,,,"pta",,"Pai Tavytera",,,,,,0,"ltr",,"L"
5317,,,"pth",,"Pataxó-Hãhaãi",,,,,,0,"ltr",,"E"
5318,,,"pti",,"Pintiini",,,,,,0,"ltr",,"L"
5319,,,"ptn",,"Patani",,,,,,0,"ltr",,"L"
5320,,,"pto",,"Zo'é",,,,,,0,"ltr",,"L"
5321,,,"ptp",,"Patep",,,,,,0,"ltr",,"L"
5322,,,"ptr",,"Piamatsina",,,,,,0,"ltr",,"L"
5323,,,"ptt",,"Enrekang",,,,,,0,"ltr",,"L"
5324,,,"ptu",,"Bambam",,,,,,0,"ltr",,"L"
5325,,,"ptv",,"Port Vato",,,,,,0,"ltr",,"L"
5326,,,"ptw",,"Pentlatch",,,,,,0,"ltr",,"E"
5327,,,"pua",,"Purepecha",,"Western Highland",,,,0,"ltr",,"L"
5328,,,"pub",,"Purum",,,,,,0,"ltr",,"L"
5329,,,"puc",,"Punan Merap",,,,,,0,"ltr",,"L"
5330,,,"pud",,"Punan Aput",,,,,,0,"ltr",,"L"
5331,,,"pue",,"Puelche",,,,,,0,"ltr",,"L"
5332,,,"puf",,"Punan Merah",,,,,,0,"ltr",,"L"
5333,,,"pug",,"Phuie",,,,,,0,"ltr",,"L"
5334,,,"pui",,"Puinave",,,,,,0,"ltr",,"L"
5335,,,"puj",,"Punan Tubu",,,,,,0,"ltr",,"L"
5336,,,"puk",,"Pu Ko",,,,,,0,"ltr",,"L"
5337,,,"pum",,"Puma",,,,,,0,"ltr",,"L"
5338,,,"pun",,"Pubian",,,,,,0,"ltr",,"L"
5339,,,"puo",,"Puoc",,,,,,0,"ltr",,"L"
5340,,,"pup",,"Pulabu",,,,,,0,"ltr",,"L"
5341,,,"puq",,"Puquina",,,,,,0,"ltr",,"E"
5342,,,"pur",,"Puruborá",,,,,,0,"ltr",,"L"
5343,"ps","pus","pus",,"Pushto",,,"پښتو",,,1,"ltr",,"L"
5344,,,"put",,"Putoh",,,,,,0,"ltr",,"L"
5345,,,"puu",,"Punu",,,,,,0,"ltr",,"L"
5346,,,"puw",,"Puluwatese",,,,,,0,"ltr",,"L"
5347,,,"pux",,"Puari",,,,,,0,"ltr",,"L"
5348,,,"puy",,"Purisimeño",,,,,,0,"ltr",,"E"
5349,,,"puz",,"Naga",,"Purum",,,,0,"ltr",,"L"
5350,,,"pwa",,"Pawaia",,,,,,0,"ltr",,"L"
5351,,,"pwg",,"Gapapaiwa",,,,,,0,"ltr",,"L"
5352,,,"pwm",,"Molbog",,,,,,0,"ltr",,"L"
5353,,,"pwn",,"Paiwan",,,,,,0,"ltr",,"L"
5354,,,"pwo",,"Karen",,"Pwo Western",,,,0,"ltr",,"L"
5355,,,"pwr",,"Powari",,,,,,0,"ltr",,"L"
5356,,,"pww",,"Karen",,"Pwo Northern",,,,0,"ltr",,"L"
5357,,,"pxm",,"Mixe",,"Quetzaltepec",,,,0,"ltr",,"L"
5358,,,"pye",,"Krumen",,"Pye",,,,0,"ltr",,"L"
5359,,,"pym",,"Fyam",,,,,,0,"ltr",,"L"
5360,,,"pyn",,"Poyanáwa",,,,,,0,"ltr",,"L"
5361,,,"pyu",,"Puyuma",,,,,,0,"ltr",,"L"
5362,,,"pyx",,"Pyu","Myanmar",,,,,0,"ltr",,"A"
5363,,,"pyy",,"Pyen",,,,,,0,"ltr",,"L"
5364,,,"qua",,"Quapaw",,,,,,0,"ltr",,"L"
5365,,,"qub",,"Quechua",,"Huallaga Huánuco",,,,0,"ltr",,"L"
5366,,,"quc",,"Quiché",,"Central",,,,0,"ltr",,"L"
5367,,,"qud",,"Quichua",,"Calderón Highland",,,,0,"ltr",,"L"
5368,"qu","que","que",,"Quechua",,,,,,1,"ltr",,"L"
5369,,,"quf",,"Quechua",,"Lambayeque",,,,0,"ltr",,"L"
5370,,,"qug",,"Quichua",,"Chimborazo Highland",,,,0,"ltr",,"L"
5371,,,"quh",,"Quechua",,"South Bolivian",,,,0,"ltr",,"L"
5372,,,"qui",,"Quileute",,,,,,0,"ltr",,"L"
5373,,,"quj",,"Quiché",,"Joyabaj",,,,0,"ltr",,"L"
5374,,,"quk",,"Quechua",,"Chachapoyas",,,,0,"ltr",,"L"
5375,,,"qul",,"Quechua",,"North Bolivian",,,,0,"ltr",,"L"
5376,,,"qum",,"Sipacapense",,,,,,0,"ltr",,"L"
5377,,,"qun",,"Quinault",,,,,,0,"ltr",,"E"
5378,,,"qup",,"Quechua",,"Southern Pastaza",,,,0,"ltr",,"L"
5379,,,"quq",,"Quinqui",,,,,,0,"ltr",,"L"
5380,,,"qur",,"Quechua",,"Yanahuanca Pasco",,,,0,"ltr",,"L"
5381,,,"qus",,"Quichua",,"Santiago del Estero",,,,0,"ltr",,"L"
5382,,,"qut",,"Quiché",,"West Central",,,,0,"ltr",,"L"
5383,,,"quu",,"Quiché",,"Eastern",,,,0,"ltr",,"L"
5384,,,"quv",,"Sacapulteco",,,,,,0,"ltr",,"L"
5385,,,"quw",,"Quichua",,"Tena Lowland",,,,0,"ltr",,"L"
5386,,,"qux",,"Quechua",,"Yauyos",,,,0,"ltr",,"L"
5387,,,"quy",,"Quechua",,"Ayacucho",,,,0,"ltr",,"L"
5388,,,"quz",,"Quechua",,"Cusco",,,,0,"ltr",,"L"
5389,,,"qva",,"Quechua",,"Ambo-Pasco",,,,0,"ltr",,"L"
5390,,,"qvc",,"Quechua",,"Cajamarca",,,,0,"ltr",,"L"
5391,,,"qve",,"Quechua",,"Eastern Apurímac",,,,0,"ltr",,"L"
5392,,,"qvh",,"Quechua",,"Huamalíes-Dos de Mayo Huánuco",,,,0,"ltr",,"L"
5393,,,"qvi",,"Quichua",,"Imbabura Highland",,,,0,"ltr",,"L"
5394,,,"qvj",,"Quichua",,"Loja Highland",,,,0,"ltr",,"L"
5395,,,"qvl",,"Quechua",,"Cajatambo North Lima",,,,0,"ltr",,"L"
5396,,,"qvm",,"Quechua",,"Margos-Yarowilca-Lauricocha",,,,0,"ltr",,"L"
5397,,,"qvn",,"Quechua",,"North Junín",,,,0,"ltr",,"L"
5398,,,"qvo",,"Quechua",,"Napo Lowland",,,,0,"ltr",,"L"
5399,,,"qvp",,"Quechua",,"Pacaraos",,,,0,"ltr",,"L"
5400,,,"qvs",,"Quechua",,"San Martín",,,,0,"ltr",,"L"
5401,,,"qvw",,"Quechua",,"Huaylla Wanca",,,,0,"ltr",,"L"
5402,,,"qvy",,"Queyu",,,,,,0,"ltr",,"L"
5403,,,"qvz",,"Quichua",,"Northern Pastaza",,,,0,"ltr",,"L"
5404,,,"qwa",,"Quechua",,"Corongo Ancash",,,,0,"ltr",,"L"
5405,,,"qwc",,"Quechua",,"Classical",,,,0,"ltr",,"H"
5406,,,"qwh",,"Quechua",,"Huaylas Ancash",,,,0,"ltr",,"L"
5407,,,"qwm",,"Kuman","Russia",,,,,0,"ltr",,"E"
5408,,,"qws",,"Quechua",,"Sihuas Ancash",,,,0,"ltr",,"L"
5409,,,"qwt",,"Kwalhioqua-Tlatskanai",,,,,,0,"ltr",,"E"
5410,,,"qxa",,"Quechua",,"Chiquián Ancash",,,,0,"ltr",,"L"
5411,,,"qxc",,"Quechua",,"Chincha",,,,0,"ltr",,"L"
5412,,,"qxh",,"Quechua",,"Panao Huánuco",,,,0,"ltr",,"L"
5413,,,"qxi",,"Quiché",,"San Andrés",,,,0,"ltr",,"L"
5414,,,"qxl",,"Quichua",,"Salasaca Highland",,,,0,"ltr",,"L"
5415,,,"qxn",,"Quechua",,"Northern Conchucos Ancash",,,,0,"ltr",,"L"
5416,,,"qxo",,"Quechua",,"Southern Conchucos Ancash",,,,0,"ltr",,"L"
5417,,,"qxp",,"Quechua",,"Puno",,,,0,"ltr",,"L"
5418,,,"qxq",,"Qashqa'i",,,,,,0,"ltr",,"L"
5419,,,"qxr",,"Quichua",,"Cañar Highland",,,,0,"ltr",,"L"
5420,,,"qxs",,"Qiang",,"Southern",,,,0,"ltr",,"L"
5421,,,"qxt",,"Quechua",,"Santa Ana de Tusi Pasco",,,,0,"ltr",,"L"
5422,,,"qxu",,"Quechua",,"Arequipa-La Unión",,,,0,"ltr",,"L"
5423,,,"qxw",,"Quechua",,"Jauja Wanca",,,,0,"ltr",,"L"
5424,,,"qya",,"Quenya",,,,,,0,"ltr",,"C"
5425,,,"raa",,"Dungmali",,,,,,0,"ltr",,"L"
5426,,,"rab",,"Camling",,,,,,0,"ltr",,"L"
5427,,,"rac",,"Rasawa",,,,,,0,"ltr",,"L"
5428,,,"rad",,"Rade",,,,,,0,"ltr",,"L"
5429,,,"rae",,"Ranau",,,,,,0,"ltr",,"L"
5430,,,"raf",,"Meohang",,"Western",,,,0,"ltr",,"L"
5431,,,"rag",,"Logooli",,,,,,0,"ltr",,"L"
5432,,,"rah",,"Rabha",,,,,,0,"ltr",,"L"
5433,,,"rai",,"Ramoaaina",,,,,,0,"ltr",,"L"
5434,,"raj","raj",,"Rajasthani",,,,,,1,"ltr",,"L"
5435,,,"rak",,"Tulu-Bohuai",,,,,,0,"ltr",,"L"
5436,,,"ral",,"Ralte",,,,,,0,"ltr",,"L"
5437,,,"ram",,"Canela",,,,,,0,"ltr",,"L"
5438,,,"ran",,"Riantana",,,,,,0,"ltr",,"L"
5439,,,"rao",,"Rao",,,,,,0,"ltr",,"L"
5440,,"rap","rap",,"Rapanui",,,,,,0,"ltr",,"L"
5441,,,"raq",,"Saam",,,,,,0,"ltr",,"L"
5442,,"rar","rar",,"Rarotongan",,,,,,0,"ltr",,"L"
5443,,,"ras",,"Tegali",,,,,,0,"ltr",,"L"
5444,,,"rat",,"Razajerdi",,,,,,0,"ltr",,"L"
5445,,,"rau",,"Raute",,,,,,0,"ltr",,"L"
5446,,,"rav",,"Sampang",,,,,,0,"ltr",,"L"
5447,,,"raw",,"Rawang",,,,,,0,"ltr",,"L"
5448,,,"rax",,"Rang",,,,,,0,"ltr",,"L"
5449,,,"ray",,"Rapa",,,,,,0,"ltr",,"L"
5450,,,"raz",,"Rahambuu",,,,,,0,"ltr",,"L"
5451,,,"rbb",,"Palaung",,"Rumai",,,,0,"ltr",,"L"
5452,,,"rcf",,"Réunion Creole French",,,,,,0,"ltr",,"L"
5453,,,"rdb",,"Rudbari",,,,,,0,"ltr",,"L"
5454,,,"rea",,"Rerau",,,,,,0,"ltr",,"L"
5455,,,"reb",,"Rembong",,,,,,0,"ltr",,"L"
5456,,,"ree",,"Kayan",,"Rejang",,,,0,"ltr",,"L"
5457,,,"reg",,"Kara","Tanzania",,,,,0,"ltr",,"L"
5458,,,"rei",,"Reli",,,,,,0,"ltr",,"L"
5459,,,"rej",,"Rejang",,,,,,0,"ltr",,"L"
5460,,,"rel",,"Rendille",,,,,,0,"ltr",,"L"
5461,,,"rem",,"Remo",,,,,,0,"ltr",,"E"
5462,,,"ren",,"Rengao",,,,,,0,"ltr",,"L"
5463,,,"rer",,"Rer Bare",,,,,,0,"ltr",,"E"
5464,,,"res",,"Reshe",,,,,,0,"ltr",,"L"
5465,,,"ret",,"Retta",,,,,,0,"ltr",,"L"
5466,,,"rey",,"Reyesano",,,,,,0,"ltr",,"L"
5467,,,"rga",,"Roria",,,,,,0,"ltr",,"L"
5468,,,"rge",,"Romano-Greek",,,,,,0,"ltr",,"L"
5469,,,"rgk",,"Rangkas",,,,,,0,"ltr",,"E"
5470,,,"rgr",,"Resígaro",,,,,,0,"ltr",,"L"
5471,,,"rgs",,"Roglai",,"Southern",,,,0,"ltr",,"L"
5472,,,"rgu",,"Ringgou",,,,,,0,"ltr",,"L"
5473,,,"rhp",,"Yahang",,,,,,0,"ltr",,"L"
5474,,,"ria",,"Riang","India",,,,,0,"ltr",,"L"
5475,,,"rie",,"Rien",,,,,,0,"ltr",,"L"
5476,,,"rif",,"Tarifit",,,,,,0,"ltr",,"L"
5477,,,"ril",,"Riang","Myanmar",,,,,0,"ltr",,"L"
5478,,,"rim",,"Nyaturu",,,,,,0,"ltr",,"L"
5479,,,"rin",,"Nungu",,,,,,0,"ltr",,"L"
5480,,,"rir",,"Ribun",,,,,,0,"ltr",,"L"
5481,,,"rit",,"Ritarungo",,,,,,0,"ltr",,"L"
5482,,,"riu",,"Riung",,,,,,0,"ltr",,"L"
5483,,,"rjb",,"Rajbanshi",,,,,,0,"ltr",,"L"
5484,,,"rjg",,"Rajong",,,,,,0,"ltr",,"L"
5485,,,"rji",,"Raji",,,,,,0,"ltr",,"L"
5486,,,"rka",,"Kraol",,,,,,0,"ltr",,"L"
5487,,,"rkb",,"Rikbaktsa",,,,,,0,"ltr",,"L"
5488,,,"rkh",,"Rakahanga-Manihiki",,,,,,0,"ltr",,"L"
5489,,,"rkm",,"Marka",,,,,,0,"ltr",,"L"
5490,,,"rma",,"Rama",,,,,,0,"ltr",,"L"
5491,,,"rmb",,"Rembarunga",,,,,,0,"ltr",,"L"
5492,,,"rmc",,"Romani",,"Carpathian",,,,0,"ltr",,"L"
5493,,,"rmd",,"Traveller Danish",,,,,,0,"ltr",,"L"
5494,,,"rme",,"Angloromani",,,,,,0,"ltr",,"L"
5495,,,"rmf",,"Romani",,"Kalo Finnish",,,,0,"ltr",,"L"
5496,,,"rmg",,"Traveller Norwegian",,,,,,0,"ltr",,"L"
5497,,,"rmh",,"Murkim",,,,,,0,"ltr",,"L"
5498,,,"rmi",,"Lomavren",,,,,,0,"ltr",,"L"
5499,,,"rmk",,"Romkun",,,,,,0,"ltr",,"L"
5500,,,"rml",,"Romani",,"Baltic",,,,0,"ltr",,"L"
5501,,,"rmm",,"Roma",,,,,,0,"ltr",,"L"
5502,,,"rmn",,"Romani",,"Balkan",,,,0,"ltr",,"L"
5503,,,"rmo",,"Romani",,"Sinte",,,,0,"ltr",,"L"
5504,,,"rmp",,"Rempi",,,,,,0,"ltr",,"L"
5505,,,"rmr",,"Caló",,,,,,0,"ltr",,"L"
5506,,,"rms",,"Romanian Sign Language",,,,,,0,"ltr",,"L"
5507,,,"rmt",,"Domari",,,,,,0,"ltr",,"L"
5508,,,"rmu",,"Romani",,"Tavringer",,,,0,"ltr",,"L"
5509,,,"rmv",,"Romanova",,,,,,0,"ltr",,"C"
5510,,,"rmw",,"Romani",,"Welsh",,,,0,"ltr",,"L"
5511,,,"rmx",,"Romam",,,,,,0,"ltr",,"L"
5512,,,"rmy",,"Romani",,"Vlax",,,,0,"ltr",,"L"
5513,,,"rna",,"Runa",,,,,,0,"ltr",,"E"
5514,,,"rnd",,"Ruund",,,,,,0,"ltr",,"L"
5515,,,"rng",,"Ronga",,,,,,0,"ltr",,"L"
5516,,,"rnn",,"Roon",,,,,,0,"ltr",,"L"
5517,,,"rnp",,"Rongpo",,,,,,0,"ltr",,"L"
5518,,,"rnw",,"Rungwa",,,,,,0,"ltr",,"L"
5519,,,"rob",,"Tae'",,,,,,0,"ltr",,"L"
5520,,,"roc",,"Roglai",,"Cacgia",,,,0,"ltr",,"L"
5521,,,"rod",,"Rogo",,,,,,0,"ltr",,"L"
5522,,,"roe",,"Ronji",,,,,,0,"ltr",,"L"
5523,,,"rof",,"Rombo",,,,,,0,"ltr",,"L"
5524,,,"rog",,"Roglai",,"Northern",,,,0,"ltr",,"L"
5525,"rm","roh","roh",,"Raeto-Romance",,,,,,0,"ltr",,"L"
5526,,,"rol",,"Romblomanon",,,,,,0,"ltr",,"L"
5527,,"rom","rom",,"Romany",,,,,,1,"ltr",,"L"
5528,"ro","ron","ron",,"Romanian",,,"Română",,,0,"ltr",,"L"
5529,,,"roo",,"Rotokas",,,,,,0,"ltr",,"L"
5530,,,"rop",,"Kriol",,,,,,0,"ltr",,"L"
5531,,,"ror",,"Rongga",,,,,,0,"ltr",,"L"
5532,,,"rou",,"Runga",,,,,,0,"ltr",,"L"
5533,,,"row",,"Dela-Oenale",,,,,,0,"ltr",,"L"
5534,,,"rpn",,"Repanbitip",,,,,,0,"ltr",,"L"
5535,,,"rpt",,"Rapting",,,,,,0,"ltr",,"L"
5536,,,"rri",,"Ririo",,,,,,0,"ltr",,"L"
5537,,,"rro",,"Waima",,,,,,0,"ltr",,"L"
5538,,,"rsb",,"Romano-Serbian",,,,,,0,"ltr",,"L"
5539,,,"rsi",,"Rennellese Sign Language",,,,,,0,"ltr",,"L"
5540,,,"rsl",,"Russian Sign Language",,,,,,0,"ltr",,"L"
5541,,,"rth",,"Ratahan",,,,,,0,"ltr",,"L"
5542,,,"rtm",,"Rotuman",,,,,,0,"ltr",,"L"
5543,,,"rtw",,"Rathawi",,,,,,0,"ltr",,"L"
5544,,,"rub",,"Gungu",,,,,,0,"ltr",,"L"
5545,,,"ruc",,"Ruli",,,,,,0,"ltr",,"L"
5546,,,"rue",,"Rusyn",,,,,,0,"ltr",,"L"
5547,,,"ruf",,"Luguru",,,,,,0,"ltr",,"L"
5548,,,"rug",,"Roviana",,,,,,0,"ltr",,"L"
5549,,,"ruh",,"Ruga",,,,,,0,"ltr",,"L"
5550,,,"rui",,"Rufiji",,,,,,0,"ltr",,"L"
5551,,,"ruk",,"Che",,,,,,0,"ltr",,"L"
5552,"rn","run","run",,"Rundi",,,"Kirundi",,,0,"ltr",,"L"
5553,,,"ruo",,"Romanian",,"Istro",,,,0,"ltr",,"L"
5554,,,"rup",,"Romanian",,"Macedo",,,,0,"ltr",,"L"
5555,,,"ruq",,"Romanian",,"Megleno",,,,0,"ltr",,"L"
5556,"ru","rus","rus",,"Russian",,,"Pyccĸий",,,0,"ltr","c%10==1 && c%100!=11 ? 1 : c%10>=2 && c%10<=4 && (c%100<10 || c%100>=20) ? 2 : 3","L"
5557,,,"rut",,"Rutul",,,,,,0,"ltr",,"L"
5558,,,"ruu",,"Lobu",,"Lanas",,,,0,"ltr",,"L"
5559,,,"ruy",,"Mala","Nigeria",,,,,0,"ltr",,"L"
5560,,,"ruz",,"Ruma",,,,,,0,"ltr",,"L"
5561,,,"rwa",,"Rawo",,,,,,0,"ltr",,"L"
5562,,,"rwk",,"Rwa",,,,,,0,"ltr",,"L"
5563,,,"rwm",,"Amba","Uganda",,,,,0,"ltr",,"L"
5564,,,"rwo",,"Rawa",,,,,,0,"ltr",,"L"
5565,,,"rwr",,"Marwari","India",,,,,0,"ltr",,"L"
5566,,,"rws",,"Rawas",,,,,,0,"ltr",,"L"
5567,,,"ryn",,"Amami-Oshima",,"Northern",,,,0,"ltr",,"L"
5568,,,"rys",,"Yaeyama",,,,,,0,"ltr",,"L"
5569,,,"ryu",,"Okinawan",,"Central",,,,0,"ltr",,"L"
5570,,,"saa",,"Saba",,,,,,0,"ltr",,"L"
5571,,,"sab",,"Buglere",,,,,,0,"ltr",,"L"
5572,,,"sac",,"Mesquakie",,,,,,0,"ltr",,"L"
5573,,"sad","sad",,"Sandawe",,,,,,0,"ltr",,"L"
5574,,,"sae",,"Sabanês",,,,,,0,"ltr",,"L"
5575,,,"saf",,"Safaliba",,,,,,0,"ltr",,"L"
5576,"sg","sag","sag",,"Sango",,,,,,0,"ltr",,"L"
5577,,"sah","sah",,"Yakut",,,,,,0,"ltr",,"L"
5578,,,"saj",,"Sahu",,,,,,0,"ltr",,"L"
5579,,,"sak",,"Sake",,,,,,0,"ltr",,"L"
5580,,"sam","sam",,"Aramaic",,"Samaritan",,,,0,"ltr",,"E"
5581,"sa","san","san",,"Sanskrit",,,,,,0,"ltr",,"A"
5582,,,"sao",,"Sause",,,,,,0,"ltr",,"L"
5583,,,"sap",,"Sanapaná",,,,,,0,"ltr",,"L"
5584,,,"saq",,"Samburu",,,,,,0,"ltr",,"L"
5585,,,"sar",,"Saraveca",,,,,,0,"ltr",,"E"
5586,,"sas","sas",,"Sasak",,,,,,0,"ltr",,"L"
5587,,"sat","sat",,"Santali",,,,,,0,"ltr",,"L"
5588,,,"sau",,"Saleman",,,,,,0,"ltr",,"L"
5589,,,"sav",,"Saafi-Saafi",,,,,,0,"ltr",,"L"
5590,,,"saw",,"Sawi",,,,,,0,"ltr",,"L"
5591,,,"sax",,"Sa",,,,,,0,"ltr",,"L"
5592,,,"say",,"Saya",,,,,,0,"ltr",,"L"
5593,,,"saz",,"Saurashtra",,,,,,0,"ltr",,"L"
5594,,,"sba",,"Ngambay",,,,,,0,"ltr",,"L"
5595,,,"sbb",,"Simbo",,,,,,0,"ltr",,"L"
5596,,,"sbc",,"Kele","Papua New Guinea",,,,,0,"ltr",,"L"
5597,,,"sbd",,"Samo",,"Southern",,,,0,"ltr",,"L"
5598,,,"sbe",,"Saliba",,,,,,0,"ltr",,"L"
5599,,,"sbf",,"Shabo",,,,,,0,"ltr",,"L"
5600,,,"sbg",,"Seget",,,,,,0,"ltr",,"L"
5601,,,"sbh",,"Sori-Harengan",,,,,,0,"ltr",,"L"
5602,,,"sbi",,"Seti",,,,,,0,"ltr",,"L"
5603,,,"sbj",,"Surbakhal",,,,,,0,"ltr",,"L"
5604,,,"sbk",,"Safwa",,,,,,0,"ltr",,"L"
5605,,,"sbl",,"Sambal",,"Botolan",,,,0,"ltr",,"L"
5606,,,"sbm",,"Sagala",,,,,,0,"ltr",,"L"
5607,,,"sbn",,"Sindhi Bhil",,,,,,0,"ltr",,"L"
5608,,,"sbo",,"Sabüm",,,,,,0,"ltr",,"L"
5609,,,"sbp",,"Sangu","Tanzania",,,,,0,"ltr",,"L"
5610,,,"sbq",,"Sileibi",,,,,,0,"ltr",,"L"
5611,,,"sbr",,"Sembakung Murut",,,,,,0,"ltr",,"L"
5612,,,"sbs",,"Subiya",,,,,,0,"ltr",,"L"
5613,,,"sbt",,"Kimki",,,,,,0,"ltr",,"L"
5614,,,"sbu",,"Stod Bhoti",,,,,,0,"ltr",,"L"
5615,,,"sbv",,"Sabine",,,,,,0,"ltr",,"A"
5616,,,"sbw",,"Simba",,,,,,0,"ltr",,"L"
5617,,,"sbx",,"Seberuang",,,,,,0,"ltr",,"L"
5618,,,"sby",,"Soli",,,,,,0,"ltr",,"L"
5619,,,"sbz",,"Sara Kaba",,,,,,0,"ltr",,"L"
5620,,,"sca",,"Sansu",,,,,,0,"ltr",,"L"
5621,,,"scb",,"Chut",,,,,,0,"ltr",,"L"
5622,,,"sce",,"Dongxiang",,,,,,0,"ltr",,"L"
5623,,,"scf",,"San Miguel Creole French",,,,,,0,"ltr",,"L"
5624,,,"scg",,"Sanggau",,,,,,0,"ltr",,"L"
5625,,,"sch",,"Sakechep",,,,,,0,"ltr",,"L"
5626,,,"sci",,"Sri Lankan Creole Malay",,,,,,0,"ltr",,"L"
5627,,,"sck",,"Sadri",,,,,,0,"ltr",,"L"
5628,,,"scl",,"Shina",,,,,,0,"ltr",,"L"
5629,,"scn","scn",,"Sicilian",,,,,,0,"ltr",,"L"
5630,,"sco","sco",,"Scots",,,,,,0,"ltr",,"L"
5631,,,"scp",,"Helambu Sherpa",,,,,,0,"ltr",,"L"
5632,,,"scq",,"Sa'och",,,,,,0,"ltr",,"L"
5633,,,"scs",,"Slavey",,"North",,,,0,"ltr",,"L"
5634,,,"scu",,"Shumcho",,,,,,0,"ltr",,"L"
5635,,,"scv",,"Sheni",,,,,,0,"ltr",,"L"
5636,,,"scw",,"Sha",,,,,,0,"ltr",,"L"
5637,,,"scx",,"Sicel",,,,,,0,"ltr",,"A"
5638,,,"sda",,"Toraja-Sa'dan",,,,,,0,"ltr",,"L"
5639,,,"sdb",,"Shabak",,,,,,0,"ltr",,"L"
5640,,,"sdc",,"Sardinian",,"Sassarese",,,,0,"ltr",,"L"
5641,,,"sdd",,"Semendo",,,,,,0,"ltr",,"L"
5642,,,"sde",,"Surubu",,,,,,0,"ltr",,"L"
5643,,,"sdf",,"Sarli",,,,,,0,"ltr",,"L"
5644,,,"sdg",,"Savi",,,,,,0,"ltr",,"L"
5645,,,"sdh",,"Kurdish",,"Southern",,,,0,"ltr",,"L"
5646,,,"sdi",,"Sindang Kelingi",,,,,,0,"ltr",,"L"
5647,,,"sdj",,"Suundi",,,,,,0,"ltr",,"L"
5648,,,"sdl",,"Saudi Arabian Sign Language",,,,,,0,"ltr",,"L"
5649,,,"sdm",,"Semandang",,,,,,0,"ltr",,"L"
5650,,,"sdn",,"Sardinian",,"Gallurese",,,,0,"ltr",,"L"
5651,,,"sdo",,"Bukar Sadong",,,,,,0,"ltr",,"L"
5652,,,"sdp",,"Sherdukpen",,,,,,0,"ltr",,"L"
5653,,,"sdr",,"Sadri",,"Oraon",,,,0,"ltr",,"L"
5654,,,"sds",,"Sened",,,,,,0,"ltr",,"E"
5655,,,"sdt",,"Shuadit",,,,,,0,"ltr",,"E"
5656,,,"sdu",,"Sarudu",,,,,,0,"ltr",,"L"
5657,,,"sdx",,"Sibu",,,,,,0,"ltr",,"L"
5658,,,"sdz",,"Sallands",,,,,,0,"ltr",,"L"
5659,,,"sea",,"Semai",,,,,,0,"ltr",,"L"
5660,,,"seb",,"Senoufo",,"Shempire",,,,0,"ltr",,"L"
5661,,,"sec",,"Sechelt",,,,,,0,"ltr",,"L"
5662,,,"sed",,"Sedang",,,,,,0,"ltr",,"L"
5663,,,"see",,"Seneca",,,,,,0,"ltr",,"L"
5664,,,"sef",,"Senoufo",,"Cebaara",,,,0,"ltr",,"L"
5665,,,"seg",,"Segeju",,,,,,0,"ltr",,"L"
5666,,,"seh",,"Sena",,,,,,0,"ltr",,"L"
5667,,,"sei",,"Seri",,,,,,0,"ltr",,"L"
5668,,,"sej",,"Sene",,,,,,0,"ltr",,"L"
5669,,,"sek",,"Sekani",,,,,,0,"ltr",,"L"
5670,,"sel","sel",,"Selkup",,,,,,0,"ltr",,"L"
5671,,,"sen",,"Sénoufo",,"Nanerigé",,,,0,"ltr",,"L"
5672,,,"seo",,"Suarmin",,,,,,0,"ltr",,"L"
5673,,,"sep",,"Sénoufo",,"Sìcìté",,,,0,"ltr",,"L"
5674,,,"seq",,"Sénoufo",,"Senara",,,,0,"ltr",,"L"
5675,,,"ser",,"Serrano",,,,,,0,"ltr",,"L"
5676,,,"ses",,"Songhai",,"Koyraboro Senni",,,,0,"ltr",,"L"
5677,,,"set",,"Sentani",,,,,,0,"ltr",,"L"
5678,,,"seu",,"Serui-Laut",,,,,,0,"ltr",,"L"
5679,,,"sev",,"Senoufo",,"Nyarafolo",,,,0,"ltr",,"L"
5680,,,"sew",,"Sewa Bay",,,,,,0,"ltr",,"L"
5681,,,"sey",,"Secoya",,,,,,0,"ltr",,"L"
5682,,,"sez",,"Chin",,"Senthang",,,,0,"ltr",,"L"
5683,,,"sfs",,"South African Sign Language",,,,,,0,"ltr",,"L"
5684,,,"sfw",,"Sehwi",,,,,,0,"ltr",,"L"
5685,,"sga","sga",,"Irish",,"Old (to 900)",,,,0,"ltr",,"H"
5686,,,"sgb",,"Ayta",,"Mag-Anchi",,,,0,"ltr",,"L"
5687,,,"sge",,"Segai",,,,,,0,"ltr",,"L"
5688,,,"sgg",,"Swiss-German Sign Language",,,,,,0,"ltr",,"L"
5689,,,"sgh",,"Shughni",,,,,,0,"ltr",,"L"
5690,,,"sgi",,"Suga",,,,,,0,"ltr",,"L"
5691,,,"sgl",,"Sanglechi-Ishkashimi",,,,,,0,"ltr",,"L"
5692,,,"sgm",,"Singa",,,,,,0,"ltr",,"E"
5693,,,"sgo",,"Songa",,,,,,0,"ltr",,"L"
5694,,,"sgp",,"Singpho",,,,,,0,"ltr",,"L"
5695,,,"sgr",,"Sangisari",,,,,,0,"ltr",,"L"
5696,,,"sgt",,"Brokpake",,,,,,0,"ltr",,"L"
5697,,,"sgu",,"Salas",,,,,,0,"ltr",,"L"
5698,,,"sgw",,"Sebat Bet Gurage",,,,,,0,"ltr",,"L"
5699,,,"sgx",,"Sierra Leone Sign Language",,,,,,0,"ltr",,"L"
5700,,,"sgz",,"Sursurunga",,,,,,0,"ltr",,"L"
5701,,,"sha",,"Shall-Zwall",,,,,,0,"ltr",,"L"
5702,,,"shb",,"Ninam",,,,,,0,"ltr",,"L"
5703,,,"shc",,"Sonde",,,,,,0,"ltr",,"L"
5704,,,"she",,"Sheko",,,,,,0,"ltr",,"L"
5705,,,"shg",,"Shua",,,,,,0,"ltr",,"L"
5706,,,"shh",,"Shoshoni",,,,,,0,"ltr",,"L"
5707,,,"shi",,"Tachelhit",,,,,,0,"ltr",,"L"
5708,,,"shj",,"Shatt",,,,,,0,"ltr",,"L"
5709,,,"shk",,"Shilluk",,,,,,0,"ltr",,"L"
5710,,,"shl",,"Shendu",,,,,,0,"ltr",,"L"
5711,,,"shm",,"Shahrudi",,,,,,0,"ltr",,"L"
5712,,"shn","shn",,"Shan",,,,,,0,"ltr",,"L"
5713,,,"sho",,"Shanga",,,,,,0,"ltr",,"L"
5714,,,"shp",,"Shipibo-Conibo",,,,,,0,"ltr",,"L"
5715,,,"shq",,"Sala",,,,,,0,"ltr",,"L"
5716,,,"shr",,"Shi",,,,,,0,"ltr",,"L"
5717,,,"shs",,"Shuswap",,,,,,0,"ltr",,"L"
5718,,,"sht",,"Shasta",,,,,,0,"ltr",,"E"
5719,,,"shu",,"Arabic",,"Chadian Spoken",,,,0,"rtl",,"L"
5720,,,"shv",,"Shehri",,,,,,0,"ltr",,"L"
5721,,,"shw",,"Shwai",,,,,,0,"ltr",,"L"
5722,,,"shx",,"She",,,,,,0,"ltr",,"L"
5723,,,"shy",,"Tachawit",,,,,,0,"ltr",,"L"
5724,,,"shz",,"Senoufo",,"Syenara",,,,0,"ltr",,"L"
5725,,,"sia",,"Sami",,"Akkala",,,,0,"ltr",,"L"
5726,,,"sib",,"Kenyah",,"Sebob",,,,0,"ltr",,"L"
5727,,,"sic",,"Malinguat",,,,,,0,"ltr",,"L"
5728,,"sid","sid",,"Sidamo",,,,,,0,"ltr",,"L"
5729,,,"sie",,"Simaa",,,,,,0,"ltr",,"L"
5730,,,"sif",,"Siamou",,,,,,0,"ltr",,"L"
5731,,,"sig",,"Paasaal",,,,,,0,"ltr",,"L"
5732,,,"sih",,"Zire",,,,,,0,"ltr",,"L"
5733,,,"sii",,"Shom Peng",,,,,,0,"ltr",,"L"
5734,,,"sij",,"Numbami",,,,,,0,"ltr",,"L"
5735,,,"sik",,"Sikiana",,,,,,0,"ltr",,"L"
5736,,,"sil",,"Sisaala",,"Tumulung",,,,0,"ltr",,"L"
5737,,,"sim",,"Mende","Papua New Guinea",,,,,0,"ltr",,"L"
5738,"si","sin","sin",,"Sinhalese",,,,,,0,"ltr",,"L"
5739,,,"sip",,"Sikkimese",,,,,,0,"ltr",,"L"
5740,,,"siq",,"Sonia",,,,,,0,"ltr",,"L"
5741,,,"sir",,"Siri",,,,,,0,"ltr",,"L"
5742,,,"sis",,"Siuslaw",,,,,,0,"ltr",,"E"
5743,,,"siu",,"Sinagen",,,,,,0,"ltr",,"L"
5744,,,"siv",,"Sumariup",,,,,,0,"ltr",,"L"
5745,,,"siw",,"Siwai",,,,,,0,"ltr",,"L"
5746,,,"six",,"Sumau",,,,,,0,"ltr",,"L"
5747,,,"siy",,"Sivandi",,,,,,0,"ltr",,"L"
5748,,,"siz",,"Siwi",,,,,,0,"ltr",,"L"
5749,,,"sja",,"Epena",,,,,,0,"ltr",,"L"
5750,,,"sjb",,"Sajau Basap",,,,,,0,"ltr",,"L"
5751,,,"sjd",,"Sami",,"Kildin",,,,0,"ltr",,"L"
5752,,,"sje",,"Sami",,"Pite",,,,0,"ltr",,"L"
5753,,,"sjg",,"Assangori",,,,,,0,"ltr",,"L"
5754,,,"sjk",,"Sami",,"Kemi",,,,0,"ltr",,"E"
5755,,,"sjl",,"Sajalong",,,,,,0,"ltr",,"L"
5756,,,"sjm",,"Mapun",,,,,,0,"ltr",,"L"
5757,,,"sjn",,"Sindarin",,,,,,0,"ltr",,"C"
5758,,,"sjo",,"Xibe",,,,,,0,"ltr",,"L"
5759,,,"sjp",,"Surajpuri",,,,,,0,"ltr",,"L"
5760,,,"sjr",,"Siar-Lak",,,,,,0,"ltr",,"L"
5761,,,"sjs",,"Senhaja De Srair",,,,,,0,"ltr",,"E"
5762,,,"sjt",,"Sami",,"Ter",,,,0,"ltr",,"L"
5763,,,"sju",,"Sami",,"Ume",,,,0,"ltr",,"L"
5764,,,"sjw",,"Shawnee",,,,,,0,"ltr",,"L"
5765,,,"ska",,"Skagit",,,,,,0,"ltr",,"L"
5766,,,"skb",,"Saek",,,,,,0,"ltr",,"L"
5767,,,"skc",,"Sauk",,,,,,0,"ltr",,"L"
5768,,,"skd",,"Miwok",,"Southern Sierra",,,,0,"ltr",,"L"
5769,,,"ske",,"Seke","Vanuatu",,,,,0,"ltr",,"L"
5770,,,"skf",,"Sakirabiá",,,,,,0,"ltr",,"L"
5771,,,"skg",,"Malagasy",,"Sakalava",,,,0,"ltr",,"L"
5772,,,"skh",,"Sikule",,,,,,0,"ltr",,"L"
5773,,,"ski",,"Sika",,,,,,0,"ltr",,"L"
5774,,,"skj",,"Seke","Nepal",,,,,0,"ltr",,"L"
5775,,,"skk",,"Sok",,,,,,0,"ltr",,"L"
5776,,,"skl",,"Selako",,,,,,0,"ltr",,"L"
5777,,,"skm",,"Sakam",,,,,,0,"ltr",,"L"
5778,,,"skn",,"Subanon",,"Kolibugan",,,,0,"ltr",,"L"
5779,,,"sko",,"Seko Tengah",,,,,,0,"ltr",,"L"
5780,,,"skp",,"Sekapan",,,,,,0,"ltr",,"L"
5781,,,"skq",,"Sininkere",,,,,,0,"ltr",,"L"
5782,,,"skr",,"Seraiki",,,,,,0,"ltr",,"L"
5783,,,"sks",,"Maia",,,,,,0,"ltr",,"L"
5784,,,"skt",,"Sakata",,,,,,0,"ltr",,"L"
5785,,,"sku",,"Sakao",,,,,,0,"ltr",,"L"
5786,,,"skv",,"Skou",,,,,,0,"ltr",,"L"
5787,,,"skw",,"Skepi Creole Dutch",,,,,,0,"ltr",,"E"
5788,,,"skx",,"Seko Padang",,,,,,0,"ltr",,"L"
5789,,,"sky",,"Sikaiana",,,,,,0,"ltr",,"L"
5790,,,"skz",,"Sekar",,,,,,0,"ltr",,"L"
5791,,,"slb",,"Saluan",,"Kahumamahon",,,,0,"ltr",,"L"
5792,,,"slc",,"Sáliba",,,,,,0,"ltr",,"L"
5793,,,"sld",,"Sissala",,,,,,0,"ltr",,"L"
5794,,,"sle",,"Sholaga",,,,,,0,"ltr",,"L"
5795,,,"slf",,"Swiss-Italian Sign Language",,,,,,0,"ltr",,"L"
5796,,,"slg",,"Selungai Murut",,,,,,0,"ltr",,"L"
5797,,,"slh",,"Salish",,"Southern Puget Sound",,,,0,"ltr",,"L"
5798,,,"sli",,"Silesian",,"Lower",,,,0,"ltr",,"L"
5799,,,"slj",,"Salumá",,,,,,0,"ltr",,"L"
5800,"sk","slk","slk",,"Slovak",,,"Slovenčina",,,0,"ltr","c%10==1 && c%100!=11 ? 1 : c%10>=2 && c%10<=4 && (c%100<10 || c%100>=20) ? 2 : 3","L"
5801,,,"sll",,"Salt-Yui",,,,,,0,"ltr",,"L"
5802,,,"slm",,"Sama",,"Pangutaran",,,,0,"ltr",,"L"
5803,,,"sln",,"Salinan",,,,,,0,"ltr",,"E"
5804,,,"slp",,"Lamaholot",,,,,,0,"ltr",,"L"
5805,,,"slq",,"Salchuq",,,,,,0,"ltr",,"L"
5806,,,"slr",,"Salar",,,,,,0,"ltr",,"L"
5807,,,"sls",,"Singapore Sign Language",,,,,,0,"ltr",,"L"
5808,,,"slt",,"Sila",,,,,,0,"ltr",,"L"
5809,,,"slu",,"Selaru",,,,,,0,"ltr",,"L"
5810,"sl","slv","slv",,"Slovenian",,,"Slovenščina",,,0,"ltr","c%100==1 ? 1 : c%100==2 ? 2 : c%100==3 || c%100==4 ? 3 : 4","L"
5811,,,"slw",,"Sialum",,,,,,0,"ltr",,"L"
5812,,,"slx",,"Salampasu",,,,,,0,"ltr",,"L"
5813,,,"sly",,"Selayar",,,,,,0,"ltr",,"L"
5814,,,"slz",,"Ma'ya",,,,,,0,"ltr",,"L"
5815,,"sma","sma",,"Southern Sami",,,,,,0,"ltr",,"L"
5816,,,"smb",,"Simbari",,,,,,0,"ltr",,"L"
5817,,,"smc",,"Som",,,,,,0,"ltr",,"L"
5818,,,"smd",,"Sama",,,,,,0,"ltr",,"L"
5819,"se","sme","sme",,"Northern Sami",,,,,,0,"ltr",,"L"
5820,,,"smf",,"Auwe",,,,,,0,"ltr",,"L"
5821,,,"smg",,"Simbali",,,,,,0,"ltr",,"L"
5822,,,"smh",,"Samei",,,,,,0,"ltr",,"L"
5823,,"smj","smj",,"Lule Sami",,,,,,0,"ltr",,"L"
5824,,,"smk",,"Bolinao",,,,,,0,"ltr",,"L"
5825,,,"sml",,"Sama",,"Central",,,,0,"ltr",,"L"
5826,,,"smm",,"Musasa",,,,,,0,"ltr",,"L"
5827,,"smn","smn",,"Inari Sami",,,,,,0,"ltr",,"L"
5828,"sm","smo","smo",,"Samoan",,,,,,0,"ltr",,"L"
5829,,,"smp",,"Samaritan",,,,,,0,"ltr",,"E"
5830,,,"smq",,"Samo",,,,,,0,"ltr",,"L"
5831,,,"smr",,"Simeulue",,,,,,0,"ltr",,"L"
5832,,"sms","sms",,"Skolt Sami",,,,,,0,"ltr",,"L"
5833,,,"smt",,"Simte",,,,,,0,"ltr",,"L"
5834,,,"smu",,"Somray",,,,,,0,"ltr",,"L"
5835,,,"smv",,"Samvedi",,,,,,0,"ltr",,"L"
5836,,,"smw",,"Sumbawa",,,,,,0,"ltr",,"L"
5837,,,"smx",,"Samba",,,,,,0,"ltr",,"L"
5838,,,"smy",,"Semnani",,,,,,0,"ltr",,"L"
5839,,,"smz",,"Simeku",,,,,,0,"ltr",,"L"
5840,"sn","sna","sna",,"Shona",,,,,,0,"ltr",,"L"
5841,,,"snb",,"Sebuyau",,,,,,0,"ltr",,"L"
5842,,,"snc",,"Sinaugoro",,,,,,0,"ltr",,"L"
5843,"sd","snd","snd",,"Sindhi",,,,,,0,"ltr",,"L"
5844,,,"sne",,"Jagoi",,,,,,0,"ltr",,"L"
5845,,,"snf",,"Noon",,,,,,0,"ltr",,"L"
5846,,,"sng",,"Sanga","Democratic Republic of Congo",,,,,0,"ltr",,"L"
5847,,,"snh",,"Shinabo",,,,,,0,"ltr",,"E"
5848,,,"sni",,"Sensi",,,,,,0,"ltr",,"E"
5849,,,"snj",,"Sango",,"Riverain",,,,0,"ltr",,"L"
5850,,"snk","snk",,"Soninke",,,,,,0,"ltr",,"L"
5851,,,"snl",,"Sangil",,,,,,0,"ltr",,"L"
5852,,,"snm",,"Ma'di",,"Southern",,,,0,"ltr",,"L"
5853,,,"snn",,"Siona",,,,,,0,"ltr",,"L"
5854,,,"sno",,"Snohomish",,,,,,0,"ltr",,"L"
5855,,,"snp",,"Siane",,,,,,0,"ltr",,"L"
5856,,,"snq",,"Sangu","Gabon",,,,,0,"ltr",,"L"
5857,,,"snr",,"Sihan",,,,,,0,"ltr",,"L"
5858,,,"sns",,"South West Bay",,,,,,0,"ltr",,"L"
5859,,,"snu",,"Senggi",,,,,,0,"ltr",,"L"
5860,,,"snv",,"Sa'ban",,,,,,0,"ltr",,"L"
5861,,,"snw",,"Selee",,,,,,0,"ltr",,"L"
5862,,,"snx",,"Sam",,,,,,0,"ltr",,"L"
5863,,,"sny",,"Saniyo-Hiyewe",,,,,,0,"ltr",,"L"
5864,,,"snz",,"Sinsauru",,,,,,0,"ltr",,"L"
5865,,,"soa",,"Thai Song",,,,,,0,"ltr",,"L"
5866,,,"sob",,"Sobei",,,,,,0,"ltr",,"L"
5867,,,"soc",,"So","Democratic Republic of Congo",,,,,0,"ltr",,"L"
5868,,,"sod",,"Songoora",,,,,,0,"ltr",,"L"
5869,,,"soe",,"Songomeno",,,,,,0,"ltr",,"L"
5870,,"sog","sog",,"Sogdian",,,,,,0,"ltr",,"A"
5871,,,"soh",,"Aka",,,,,,0,"ltr",,"L"
5872,,,"soi",,"Sonha",,,,,,0,"ltr",,"L"
5873,,,"soj",,"Soi",,,,,,0,"ltr",,"L"
5874,,,"sok",,"Sokoro",,,,,,0,"ltr",,"L"
5875,,,"sol",,"Solos",,,,,,0,"ltr",,"L"
5876,"so","som","som",,"Somali",,,"Somali",,,0,"ltr",,"L"
5877,,,"soo",,"Songo",,,,,,0,"ltr",,"L"
5878,,,"sop",,"Songe",,,,,,0,"ltr",,"L"
5879,,,"soq",,"Kanasi",,,,,,0,"ltr",,"L"
5880,,,"sor",,"Somrai",,,,,,0,"ltr",,"L"
5881,,,"sos",,"Seeku",,,,,,0,"ltr",,"L"
5882,"st","sot","sot",,"Sotho",,"Southern",,,,0,"ltr",,"L"
5883,,,"sou",,"Thai",,"Southern",,,,0,"ltr",,"L"
5884,,,"sov",,"Sonsorol",,,,,,0,"ltr",,"L"
5885,,,"sow",,"Sowanda",,,,,,0,"ltr",,"L"
5886,,,"sox",,"So","Cameroon",,,,,0,"ltr",,"L"
5887,,,"soy",,"Miyobe",,,,,,0,"ltr",,"L"
5888,,,"soz",,"Temi",,,,,,0,"ltr",,"L"
5889,"es","spa","spa",,"Spanish",,,"Español",,,0,"ltr","c == 1 ? 1 : 2","L"
5890,,,"spb",,"Sepa","Indonesia",,,,,0,"ltr",,"L"
5891,,,"spc",,"Sapé",,,,,,0,"ltr",,"L"
5892,,,"spd",,"Saep",,,,,,0,"ltr",,"L"
5893,,,"spe",,"Sepa","Papua New Guinea",,,,,0,"ltr",,"L"
5894,,,"spg",,"Sian",,,,,,0,"ltr",,"L"
5895,,,"spi",,"Saponi",,,,,,0,"ltr",,"L"
5896,,,"spk",,"Sengo",,,,,,0,"ltr",,"L"
5897,,,"spl",,"Selepet",,,,,,0,"ltr",,"L"
5898,,,"spm",,"Sepen",,,,,,0,"ltr",,"L"
5899,,,"spo",,"Spokane",,,,,,0,"ltr",,"L"
5900,,,"spp",,"Senoufo",,"Supyire",,,,0,"ltr",,"L"
5901,,,"spq",,"Spanish",,"Loreto-Ucayali",,,,0,"ltr",,"L"
5902,,,"spr",,"Saparua",,,,,,0,"ltr",,"L"
5903,,,"sps",,"Saposa",,,,,,0,"ltr",,"L"
5904,,,"spt",,"Spiti Bhoti",,,,,,0,"ltr",,"L"
5905,,,"spu",,"Sapuan",,,,,,0,"ltr",,"L"
5906,,,"spx",,"South Picene",,,,,,0,"ltr",,"A"
5907,,,"spy",,"Sabaot",,,,,,0,"ltr",,"L"
5908,,,"sqa",,"Shama-Sambuga",,,,,,0,"ltr",,"L"
5909,,,"sqh",,"Shau",,,,,,0,"ltr",,"L"
5910,"sq","sqi","sqi",,"Albanian",,,"shqip",,,1,"ltr",,"L"
5911,,,"sqm",,"Suma",,,,,,0,"ltr",,"L"
5912,,,"sqn",,"Susquehannock",,,,,,0,"ltr",,"E"
5913,,,"sqo",,"Sorkhei",,,,,,0,"ltr",,"L"
5914,,,"sqq",,"Sou",,,,,,0,"ltr",,"L"
5915,,,"sqs",,"Sri Lankan Sign Language",,,,,,0,"ltr",,"L"
5916,,,"sqt",,"Soqotri",,,,,,0,"ltr",,"L"
5917,,,"squ",,"Squamish",,,,,,0,"ltr",,"L"
5918,,,"sra",,"Saruga",,,,,,0,"ltr",,"L"
5919,,,"srb",,"Sora",,,,,,0,"ltr",,"L"
5920,,,"src",,"Sardinian",,"Logudorese",,,,0,"ltr",,"L"
5921,"sc","srd","srd",,"Sardinian",,,,,,1,"ltr",,"L"
5922,,,"sre",,"Sara",,,,,,0,"ltr",,"L"
5923,,,"srf",,"Nafi",,,,,,0,"ltr",,"L"
5924,,,"srg",,"Sulod",,,,,,0,"ltr",,"L"
5925,,,"srh",,"Sarikoli",,,,,,0,"ltr",,"L"
5926,,,"sri",,"Siriano",,,,,,0,"ltr",,"L"
5927,,,"srj",,"Serawai",,,,,,0,"ltr",,"L"
5928,,,"srk",,"Serudung Murut",,,,,,0,"ltr",,"L"
5929,,,"srl",,"Isirawa",,,,,,0,"ltr",,"L"
5930,,,"srm",,"Saramaccan",,,,,,0,"ltr",,"L"
5931,,,"srn",,"Sranan",,,,,,0,"ltr",,"L"
5932,,,"sro",,"Sardinian",,"Campidanese",,,,0,"ltr",,"L"
5933,"sr","srp","srp",,"Serbian",,,"Srpski",,,0,"ltr",,"L"
5934,,,"srq",,"Sirionó",,,,,,0,"ltr",,"L"
5935,,"srr","srr",,"Serer",,,,,,0,"ltr",,"L"
5936,,,"srs",,"Sarsi",,,,,,0,"ltr",,"L"
5937,,,"srt",,"Sauri",,,,,,0,"ltr",,"L"
5938,,,"sru",,"Suruí",,,,,,0,"ltr",,"L"
5939,,,"srv",,"Sorsogon",,"Waray",,,,0,"ltr",,"L"
5940,,,"srw",,"Serua",,,,,,0,"ltr",,"L"
5941,,,"srx",,"Sirmauri",,,,,,0,"ltr",,"L"
5942,,,"sry",,"Sera",,,,,,0,"ltr",,"L"
5943,,,"srz",,"Shahmirzadi",,,,,,0,"ltr",,"L"
5944,,,"ssb",,"Sama",,"Southern",,,,0,"ltr",,"L"
5945,,,"ssd",,"Siroi",,,,,,0,"ltr",,"L"
5946,,,"sse",,"Balangingi",,,,,,0,"ltr",,"L"
5947,,,"ssf",,"Thao",,,,,,0,"ltr",,"L"
5948,,,"ssg",,"Seimat",,,,,,0,"ltr",,"L"
5949,,,"ssh",,"Arabic",,"Shihhi Spoken",,,,0,"rtl",,"L"
5950,,,"ssi",,"Sansi",,,,,,0,"ltr",,"L"
5951,,,"ssj",,"Sausi",,,,,,0,"ltr",,"L"
5952,,,"ssk",,"Sunam",,,,,,0,"ltr",,"L"
5953,,,"ssl",,"Sisaala",,"Western",,,,0,"ltr",,"L"
5954,,,"ssm",,"Semnam",,,,,,0,"ltr",,"L"
5955,,,"ssn",,"Sanye",,,,,,0,"ltr",,"L"
5956,,,"sso",,"Sissano",,,,,,0,"ltr",,"L"
5957,,,"ssp",,"Spanish Sign Language",,,,,,0,"ltr",,"L"
5958,,,"ssq",,"So'a",,,,,,0,"ltr",,"L"
5959,,,"ssr",,"Swiss-French Sign Language",,,,,,0,"ltr",,"L"
5960,,,"sss",,"Sô",,,,,,0,"ltr",,"L"
5961,,,"sst",,"Sinasina",,,,,,0,"ltr",,"L"
5962,,,"ssu",,"Susuami",,,,,,0,"ltr",,"L"
5963,,,"ssv",,"Shark Bay",,,,,,0,"ltr",,"L"
5964,"ss","ssw","ssw",,"Swati",,,,,,0,"ltr",,"L"
5965,,,"ssx",,"Samberigi",,,,,,0,"ltr",,"L"
5966,,,"ssy",,"Saho",,,,,,0,"ltr",,"L"
5967,,,"ssz",,"Sengseng",,,,,,0,"ltr",,"L"
5968,,,"sta",,"Settla",,,,,,0,"ltr",,"L"
5969,,,"stb",,"Subanen",,"Northern",,,,0,"ltr",,"L"
5970,,,"stc",,"Santa Cruz",,,,,,0,"ltr",,"L"
5971,,,"std",,"Sentinel",,,,,,0,"ltr",,"L"
5972,,,"ste",,"Liana-Seti",,,,,,0,"ltr",,"L"
5973,,,"stf",,"Seta",,,,,,0,"ltr",,"L"
5974,,,"stg",,"Trieng",,,,,,0,"ltr",,"L"
5975,,,"sth",,"Shelta",,,,,,0,"ltr",,"L"
5976,,,"sti",,"Stieng",,"Bulo",,,,0,"ltr",,"L"
5977,,,"stj",,"Samo",,"Matya",,,,0,"ltr",,"L"
5978,,,"stk",,"Arammba",,,,,,0,"ltr",,"L"
5979,,,"stl",,"Stellingwerfs",,,,,,0,"ltr",,"L"
5980,,,"stm",,"Setaman",,,,,,0,"ltr",,"L"
5981,,,"stn",,"Owa",,,,,,0,"ltr",,"L"
5982,,,"sto",,"Stoney",,,,,,0,"ltr",,"L"
5983,,,"stp",,"Tepehuan",,"Southeastern",,,,0,"ltr",,"L"
5984,,,"stq",,"Saterfriesisch",,,,,,0,"ltr",,"L"
5985,,,"str",,"Salish",,"Straits",,,,0,"ltr",,"L"
5986,,,"sts",,"Shumashti",,,,,,0,"ltr",,"L"
5987,,,"stt",,"Stieng",,"Budeh",,,,0,"ltr",,"L"
5988,,,"stu",,"Samtao",,,,,,0,"ltr",,"L"
5989,,,"stw",,"Satawalese",,,,,,0,"ltr",,"L"
5990,,,"sua",,"Sulka",,,,,,0,"ltr",,"L"
5991,,,"sub",,"Suku",,,,,,0,"ltr",,"L"
5992,,,"suc",,"Subanon",,"Western",,,,0,"ltr",,"L"
5993,,,"sue",,"Suena",,,,,,0,"ltr",,"L"
5994,,,"suf",,"Tarpia",,,,,,0,"ltr",,"L"
5995,,,"sug",,"Suganga",,,,,,0,"ltr",,"L"
5996,,,"suh",,"Suba",,,,,,0,"ltr",,"L"
5997,,,"sui",,"Suki",,,,,,0,"ltr",,"L"
5998,,,"suj",,"Shubi",,,,,,0,"ltr",,"L"
5999,,"suk","suk",,"Sukuma",,,,,,0,"ltr",,"L"
6000,,,"sul",,"Surigaonon",,,,,,0,"ltr",,"L"
6001,,,"sum",,"Sumo-Mayangna",,,,,,0,"ltr",,"L"
6002,"su","sun","sun",,"Sundanese",,,,,,0,"ltr",,"L"
6003,,,"suq",,"Suri",,,,,,0,"ltr",,"L"
6004,,,"sur",,"Mwaghavul",,,,,,0,"ltr",,"L"
6005,,"sus","sus",,"Susu",,,,,,0,"ltr",,"L"
6006,,,"sut",,"Subtiaba",,,,,,0,"ltr",,"E"
6007,,,"suu",,"Sungkai",,,,,,0,"ltr",,"L"
6008,,,"suv",,"Sulung",,,,,,0,"ltr",,"L"
6009,,,"suw",,"Sumbwa",,,,,,0,"ltr",,"L"
6010,,"sux","sux",,"Sumerian",,,,,,0,"ltr",,"A"
6011,,,"suy",,"Suyá",,,,,,0,"ltr",,"L"
6012,,,"suz",,"Sunwar",,,,,,0,"ltr",,"L"
6013,,,"sva",,"Svan",,,,,,0,"ltr",,"L"
6014,,,"svb",,"Ulau-Suain",,,,,,0,"ltr",,"L"
6015,,,"svc",,"Vincentian Creole English",,,,,,0,"ltr",,"L"
6016,,,"sve",,"Serili",,,,,,0,"ltr",,"L"
6017,,,"svk",,"Slovakian Sign Language",,,,,,0,"ltr",,"L"
6018,,,"svr",,"Savara",,,,,,0,"ltr",,"L"
6019,,,"svs",,"Savosavo",,,,,,0,"ltr",,"L"
6020,,,"svx",,"Skalvian",,,,,,0,"ltr",,"E"
6021,"sw","swa","swa",,"Swahili","generic",,"Kiswahili",,,1,"ltr",,"L"
6022,,,"swb",,"Comorian",,,,,,0,"ltr",,"L"
6023,,,"swc",,"Swahili",,"Congo",,,,0,"ltr",,"L"
6024,"sv","swe","swe",,"Swedish",,,"svenska",,,0,"ltr","c == 1 ? 1 : 2","L"
6025,,,"swf",,"Sere",,,,,,0,"ltr",,"L"
6026,,,"swg",,"Swabian",,,,,,0,"ltr",,"L"
6027,,,"swh",,"Swahili","specific",,,,,0,"ltr",,"L"
6028,,,"swi",,"Sui",,,,,,0,"ltr",,"L"
6029,,,"swj",,"Sira",,,,,,0,"ltr",,"L"
6030,,,"swk",,"Sena",,"Malawi",,,,0,"ltr",,"L"
6031,,,"swl",,"Swedish Sign Language",,,,,,0,"ltr",,"L"
6032,,,"swm",,"Samosa",,,,,,0,"ltr",,"L"
6033,,,"swn",,"Sawknah",,,,,,0,"ltr",,"L"
6034,,,"swp",,"Suau",,,,,,0,"ltr",,"L"
6035,,,"swq",,"Sharwa",,,,,,0,"ltr",,"L"
6036,,,"swr",,"Saweru",,,,,,0,"ltr",,"L"
6037,,,"sws",,"Seluwasan",,,,,,0,"ltr",,"L"
6038,,,"swt",,"Sawila",,,,,,0,"ltr",,"L"
6039,,,"swu",,"Suwawa",,,,,,0,"ltr",,"L"
6040,,,"swv",,"Shekhawati",,,,,,0,"ltr",,"L"
6041,,,"sww",,"Sowa",,,,,,0,"ltr",,"L"
6042,,,"swx",,"Suruahá",,,,,,0,"ltr",,"L"
6043,,,"swy",,"Sarua",,,,,,0,"ltr",,"L"
6044,,,"sxc",,"Sicanian",,,,,,0,"ltr",,"A"
6045,,,"sxe",,"Sighu",,,,,,0,"ltr",,"L"
6046,,,"sxg",,"Shixing",,,,,,0,"ltr",,"L"
6047,,,"sxk",,"Kalapuya",,"Southern",,,,0,"ltr",,"E"
6048,,,"sxl",,"Selian",,,,,,0,"ltr",,"E"
6049,,,"sxm",,"Samre",,,,,,0,"ltr",,"L"
6050,,,"sxn",,"Sangir",,,,,,0,"ltr",,"L"
6051,,,"sxo",,"Sorothaptic",,,,,,0,"ltr",,"A"
6052,,,"sxr",,"Saaroa",,,,,,0,"ltr",,"L"
6053,,,"sxs",,"Sasaru",,,,,,0,"ltr",,"L"
6054,,,"sxu",,"Saxon",,"Upper",,,,0,"ltr",,"L"
6055,,,"sxw",,"Gbe",,"Saxwe",,,,0,"ltr",,"L"
6056,,,"sya",,"Siang",,,,,,0,"ltr",,"L"
6057,,,"syb",,"Subanen",,"Central",,,,0,"ltr",,"L"
6058,,,"syc",,"Syriac",,"Classical",,,,0,"ltr",,"H"
6059,,,"syi",,"Seki",,,,,,0,"ltr",,"L"
6060,,,"syk",,"Sukur",,,,,,0,"ltr",,"L"
6061,,,"syl",,"Sylheti",,,,,,0,"ltr",,"L"
6062,,,"sym",,"Samo",,"Maya",,,,0,"ltr",,"L"
6063,,,"syn",,"Senaya",,,,,,0,"ltr",,"L"
6064,,,"syo",,"Suoy",,,,,,0,"ltr",,"L"
6065,,"syr","syr",,"Syriac",,,,,,1,"ltr",,"L"
6066,,,"sys",,"Sinyar",,,,,,0,"ltr",,"L"
6067,,,"syw",,"Kagate",,,,,,0,"ltr",,"L"
6068,,,"sza",,"Semelai",,,,,,0,"ltr",,"L"
6069,,,"szb",,"Ngalum",,,,,,0,"ltr",,"L"
6070,,,"szc",,"Semaq Beri",,,,,,0,"ltr",,"L"
6071,,,"szd",,"Seru",,,,,,0,"ltr",,"E"
6072,,,"sze",,"Seze",,,,,,0,"ltr",,"L"
6073,,,"szg",,"Sengele",,,,,,0,"ltr",,"L"
6074,,,"szk",,"Sizaki",,,,,,0,"ltr",,"L"
6075,,,"szn",,"Sula",,,,,,0,"ltr",,"L"
6076,,,"szp",,"Suabo",,,,,,0,"ltr",,"L"
6077,,,"szv",,"Isu","Fako Division",,,,,0,"ltr",,"L"
6078,,,"szw",,"Sawai",,,,,,0,"ltr",,"L"
6079,,,"taa",,"Tanana",,"Lower",,,,0,"ltr",,"L"
6080,,,"tab",,"Tabassaran",,,,,,0,"ltr",,"L"
6081,,,"tac",,"Tarahumara",,"Lowland",,,,0,"ltr",,"L"
6082,,,"tad",,"Tause",,,,,,0,"ltr",,"L"
6083,,,"tae",,"Tariano",,,,,,0,"ltr",,"L"
6084,,,"taf",,"Tapirapé",,,,,,0,"ltr",,"L"
6085,,,"tag",,"Tagoi",,,,,,0,"ltr",,"L"
6086,"ty","tah","tah",,"Tahitian",,,,,,0,"ltr",,"L"
6087,,,"taj",,"Tamang",,"Eastern",,,,0,"ltr",,"L"
6088,,,"tak",,"Tala",,,,,,0,"ltr",,"L"
6089,,,"tal",,"Tal",,,,,,0,"ltr",,"L"
6090,"ta","tam","tam",,"Tamil",,,,,,0,"ltr",,"L"
6091,,,"tan",,"Tangale",,,,,,0,"ltr",,"L"
6092,,,"tao",,"Yami",,,,,,0,"ltr",,"L"
6093,,,"tap",,"Taabwa",,,,,,0,"ltr",,"L"
6094,,,"taq",,"Tamasheq",,,,,,0,"ltr",,"L"
6095,,,"tar",,"Tarahumara",,"Central",,,,0,"ltr",,"L"
6096,,,"tas",,"Tay Boi",,,,,,0,"ltr",,"E"
6097,"tt","tat","tat",,"Tatar",,,,,,0,"ltr",,"L"
6098,,,"tau",,"Tanana",,"Upper",,,,0,"ltr",,"L"
6099,,,"tav",,"Tatuyo",,,,,,0,"ltr",,"L"
6100,,,"taw",,"Tai",,,,,,0,"ltr",,"L"
6101,,,"tax",,"Tamki",,,,,,0,"ltr",,"L"
6102,,,"tay",,"Atayal",,,,,,0,"ltr",,"L"
6103,,,"taz",,"Tocho",,,,,,0,"ltr",,"L"
6104,,,"tba",,"Tubarão",,,,,,0,"ltr",,"L"
6105,,,"tbb",,"Tapeba",,,,,,0,"ltr",,"E"
6106,,,"tbc",,"Takia",,,,,,0,"ltr",,"L"
6107,,,"tbd",,"Kaki Ae",,,,,,0,"ltr",,"L"
6108,,,"tbe",,"Tanimbili",,,,,,0,"ltr",,"L"
6109,,,"tbf",,"Mandara",,,,,,0,"ltr",,"L"
6110,,,"tbg",,"Tairora",,"North",,,,0,"ltr",,"L"
6111,,,"tbh",,"Thurawal",,,,,,0,"ltr",,"E"
6112,,,"tbi",,"Gaam",,,,,,0,"ltr",,"L"
6113,,,"tbj",,"Tiang",,,,,,0,"ltr",,"L"
6114,,,"tbk",,"Tagbanwa",,"Calamian",,,,0,"ltr",,"L"
6115,,,"tbl",,"Tboli",,,,,,0,"ltr",,"L"
6116,,,"tbm",,"Tagbu",,,,,,0,"ltr",,"L"
6117,,,"tbn",,"Tunebo",,"Barro Negro",,,,0,"ltr",,"L"
6118,,,"tbo",,"Tawala",,,,,,0,"ltr",,"L"
6119,,,"tbp",,"Taworta",,,,,,0,"ltr",,"L"
6120,,,"tbr",,"Tumtum",,,,,,0,"ltr",,"L"
6121,,,"tbs",,"Tanguat",,,,,,0,"ltr",,"L"
6122,,,"tbt",,"Tembo","Kitembo",,,,,0,"ltr",,"L"
6123,,,"tbu",,"Tubar",,,,,,0,"ltr",,"E"
6124,,,"tbv",,"Tobo",,,,,,0,"ltr",,"L"
6125,,,"tbw",,"Tagbanwa",,,,,,0,"ltr",,"L"
6126,,,"tbx",,"Kapin",,,,,,0,"ltr",,"L"
6127,,,"tby",,"Tabaru",,,,,,0,"ltr",,"L"
6128,,,"tbz",,"Ditammari",,,,,,0,"ltr",,"L"
6129,,,"tca",,"Ticuna",,,,,,0,"ltr",,"L"
6130,,,"tcb",,"Tanacross",,,,,,0,"ltr",,"L"
6131,,,"tcc",,"Datooga",,,,,,0,"ltr",,"L"
6132,,,"tcd",,"Tafi",,,,,,0,"ltr",,"L"
6133,,,"tce",,"Tutchone",,"Southern",,,,0,"ltr",,"L"
6134,,,"tcf",,"Tlapanec",,"Malinaltepec",,,,0,"ltr",,"L"
6135,,,"tcg",,"Tamagario",,,,,,0,"ltr",,"L"
6136,,,"tch",,"Turks And Caicos Creole English",,,,,,0,"ltr",,"L"
6137,,,"tci",,"Wára",,,,,,0,"ltr",,"L"
6138,,,"tcj",,"Tceqli",,,,,,0,"ltr",,"C"
6139,,,"tck",,"Tchitchege",,,,,,0,"ltr",,"L"
6140,,,"tcl",,"Taman","Myanmar",,,,,0,"ltr",,"L"
6141,,,"tcm",,"Tanahmerah",,,,,,0,"ltr",,"L"
6142,,,"tcn",,"Tichurong",,,,,,0,"ltr",,"L"
6143,,,"tco",,"Taungyo",,,,,,0,"ltr",,"L"
6144,,,"tcp",,"Chin",,"Tawr",,,,0,"ltr",,"L"
6145,,,"tcq",,"Kaiy",,,,,,0,"ltr",,"L"
6146,,,"tcs",,"Torres Strait Creole",,,,,,0,"ltr",,"L"
6147,,,"tct",,"T'en",,,,,,0,"ltr",,"L"
6148,,,"tcu",,"Tarahumara",,"Southeastern",,,,0,"ltr",,"L"
6149,,,"tcx",,"Toda",,,,,,0,"ltr",,"L"
6150,,,"tcy",,"Tulu",,,,,,0,"ltr",,"L"
6151,,,"tcz",,"Chin",,"Thado",,,,0,"ltr",,"L"
6152,,,"tda",,"Tagdal",,,,,,0,"ltr",,"L"
6153,,,"tdb",,"Panchpargania",,,,,,0,"ltr",,"L"
6154,,,"tdc",,"Emberá-Tadó",,,,,,0,"ltr",,"L"
6155,,,"tdd",,"Tai Nüa",,,,,,0,"ltr",,"L"
6156,,,"tdf",,"Talieng",,,,,,0,"ltr",,"L"
6157,,,"tdg",,"Tamang",,"Western",,,,0,"ltr",,"L"
6158,,,"tdh",,"Thulung",,,,,,0,"ltr",,"L"
6159,,,"tdi",,"Tomadino",,,,,,0,"ltr",,"L"
6160,,,"tdj",,"Tajio",,,,,,0,"ltr",,"L"
6161,,,"tdk",,"Tambas",,,,,,0,"ltr",,"L"
6162,,,"tdl",,"Sur",,,,,,0,"ltr",,"L"
6163,,,"tdn",,"Tondano",,,,,,0,"ltr",,"L"
6164,,,"tdo",,"Teme",,,,,,0,"ltr",,"L"
6165,,,"tdq",,"Tita",,,,,,0,"ltr",,"L"
6166,,,"tdr",,"Todrah",,,,,,0,"ltr",,"L"
6167,,,"tds",,"Doutai",,,,,,0,"ltr",,"L"
6168,,,"tdt",,"Tetun Dili",,,,,,0,"ltr",,"L"
6169,,,"tdu",,"Dusun",,"Tempasuk",,,,0,"ltr",,"L"
6170,,,"tdv",,"Toro",,,,,,0,"ltr",,"L"
6171,,,"tdx",,"Malagasy",,"Tandroy-Mahafaly",,,,0,"ltr",,"L"
6172,,,"tdy",,"Tadyawan",,,,,,0,"ltr",,"L"
6173,,,"tea",,"Temiar",,,,,,0,"ltr",,"L"
6174,,,"teb",,"Tetete",,,,,,0,"ltr",,"E"
6175,,,"ted",,"Krumen",,"Tepo",,,,0,"ltr",,"L"
6176,,,"tee",,"Tepehua",,"Huehuetla",,,,0,"ltr",,"L"
6177,,,"tef",,"Teressa",,,,,,0,"ltr",,"L"
6178,,,"teg",,"Teke-Tege",,,,,,0,"ltr",,"L"
6179,,,"teh",,"Tehuelche",,,,,,0,"ltr",,"L"
6180,,,"tei",,"Torricelli",,,,,,0,"ltr",,"L"
6181,,,"tek",,"Teke",,"Ibali",,,,0,"ltr",,"L"
6182,"te","tel","tel",,"Telugu",,,"తెలుగు",,,0,"ltr",,"L"
6183,,"tem","tem",,"Timne",,,,,,0,"ltr",,"L"
6184,,,"ten",,"Tama","Colombia",,,,,0,"ltr",,"E"
6185,,,"teo",,"Teso",,,,,,0,"ltr",,"L"
6186,,,"tep",,"Tepecano",,,,,,0,"ltr",,"E"
6187,,,"teq",,"Temein",,,,,,0,"ltr",,"L"
6188,,"ter","ter",,"Tereno",,,,,,0,"ltr",,"L"
6189,,,"tes",,"Tengger",,,,,,0,"ltr",,"L"
6190,,"tet","tet",,"Tetum",,,,,,0,"ltr",,"L"
6191,,,"teu",,"Soo",,,,,,0,"ltr",,"L"
6192,,,"tev",,"Teor",,,,,,0,"ltr",,"L"
6193,,,"tew",,"Tewa","USA",,,,,0,"ltr",,"L"
6194,,,"tex",,"Tennet",,,,,,0,"ltr",,"L"
6195,,,"tey",,"Tulishi",,,,,,0,"ltr",,"L"
6196,,,"tfi",,"Gbe",,"Tofin",,,,0,"ltr",,"L"
6197,,,"tfn",,"Tanaina",,,,,,0,"ltr",,"L"
6198,,,"tfo",,"Tefaro",,,,,,0,"ltr",,"L"
6199,,,"tfr",,"Teribe",,,,,,0,"ltr",,"L"
6200,,,"tft",,"Ternate",,,,,,0,"ltr",,"L"
6201,,,"tga",,"Sagalla",,,,,,0,"ltr",,"L"
6202,,,"tgb",,"Tebilung",,,,,,0,"ltr",,"L"
6203,,,"tgc",,"Tigak",,,,,,0,"ltr",,"L"
6204,,,"tgd",,"Ciwogai",,,,,,0,"ltr",,"L"
6205,,,"tge",,"Tamang",,"Eastern Gorkha",,,,0,"ltr",,"L"
6206,,,"tgf",,"Chalikha",,,,,,0,"ltr",,"L"
6207,,,"tgg",,"Tangga",,,,,,0,"ltr",,"L"
6208,,,"tgh",,"Tobagonian Creole English",,,,,,0,"ltr",,"L"
6209,,,"tgi",,"Lawunuia",,,,,,0,"ltr",,"L"
6210,"tg","tgk","tgk",,"Tajik",,,,,,0,"ltr",,"L"
6211,"tl","tgl","tgl",,"Tagalog",,,,,,0,"ltr",,"L"
6212,,,"tgo",,"Sudest",,,,,,0,"ltr",,"L"
6213,,,"tgp",,"Tangoa",,,,,,0,"ltr",,"L"
6214,,,"tgq",,"Tring",,,,,,0,"ltr",,"L"
6215,,,"tgr",,"Tareng",,,,,,0,"ltr",,"L"
6216,,,"tgs",,"Nume",,,,,,0,"ltr",,"L"
6217,,,"tgt",,"Tagbanwa",,"Central",,,,0,"ltr",,"L"
6218,,,"tgu",,"Tanggu",,,,,,0,"ltr",,"L"
6219,,,"tgv",,"Tingui-Boto",,,,,,0,"ltr",,"E"
6220,,,"tgw",,"Senoufo",,"Tagwana",,,,0,"ltr",,"L"
6221,,,"tgx",,"Tagish",,,,,,0,"ltr",,"L"
6222,,,"tgy",,"Togoyo",,,,,,0,"ltr",,"E"
6223,"th","tha","tha",,"Thai",,,"ภาษาไทย",,,0,"ltr",,"L"
6224,,,"thc",,"Tai Hang Tong",,,,,,0,"ltr",,"L"
6225,,,"thd",,"Thayore",,,,,,0,"ltr",,"L"
6226,,,"the",,"Tharu",,"Chitwania",,,,0,"ltr",,"L"
6227,,,"thf",,"Thangmi",,,,,,0,"ltr",,"L"
6228,,,"thh",,"Tarahumara",,"Northern",,,,0,"ltr",,"L"
6229,,,"thi",,"Tai Long",,,,,,0,"ltr",,"L"
6230,,,"thk",,"Tharaka",,,,,,0,"ltr",,"L"
6231,,,"thl",,"Tharu",,"Dangaura",,,,0,"ltr",,"L"
6232,,,"thm",,"Aheu",,,,,,0,"ltr",,"L"
6233,,,"thp",,"Thompson",,,,,,0,"ltr",,"L"
6234,,,"thq",,"Tharu",,"Kochila",,,,0,"ltr",,"L"
6235,,,"thr",,"Tharu",,"Rana",,,,0,"ltr",,"L"
6236,,,"ths",,"Thakali",,,,,,0,"ltr",,"L"
6237,,,"tht",,"Tahltan",,,,,,0,"ltr",,"L"
6238,,,"thu",,"Thuri",,,,,,0,"ltr",,"L"
6239,,,"thv",,"Tamahaq",,"Tahaggart",,,,0,"ltr",,"L"
6240,,,"thw",,"Thudam",,,,,,0,"ltr",,"L"
6241,,,"thx",,"The",,,,,,0,"ltr",,"L"
6242,,,"thy",,"Tha",,,,,,0,"ltr",,"L"
6243,,,"thz",,"Tamajeq",,"Tayart",,,,0,"ltr",,"L"
6244,,,"tia",,"Tamazight",,"Tidikelt",,,,0,"ltr",,"L"
6245,,,"tic",,"Tira",,,,,,0,"ltr",,"L"
6246,,,"tid",,"Tidong",,,,,,0,"ltr",,"L"
6247,,,"tie",,"Tingal",,,,,,0,"ltr",,"L"
6248,,,"tif",,"Tifal",,,,,,0,"ltr",,"L"
6249,,"tig","tig",,"Tigre",,,,,,0,"ltr",,"L"
6250,,,"tih",,"Timugon Murut",,,,,,0,"ltr",,"L"
6251,,,"tii",,"Tiene",,,,,,0,"ltr",,"L"
6252,,,"tij",,"Tilung",,,,,,0,"ltr",,"L"
6253,,,"tik",,"Tikar",,,,,,0,"ltr",,"L"
6254,,,"til",,"Tillamook",,,,,,0,"ltr",,"E"
6255,,,"tim",,"Timbe",,,,,,0,"ltr",,"L"
6256,,,"tin",,"Tindi",,,,,,0,"ltr",,"L"
6257,,,"tio",,"Teop",,,,,,0,"ltr",,"L"
6258,,,"tip",,"Trimuris",,,,,,0,"ltr",,"L"
6259,,,"tiq",,"Tiéfo",,,,,,0,"ltr",,"L"
6260,"ti","tir","tir",,"Tigrinya",,,,,,0,"ltr",,"L"
6261,,,"tis",,"Itneg",,"Masadiit",,,,0,"ltr",,"L"
6262,,,"tit",,"Tinigua",,,,,,0,"ltr",,"L"
6263,,,"tiu",,"Itneg",,"Adasen",,,,0,"ltr",,"L"
6264,,"tiv","tiv",,"Tiv",,,,,,0,"ltr",,"L"
6265,,,"tiw",,"Tiwi",,,,,,0,"ltr",,"L"
6266,,,"tix",,"Tiwa",,"Southern",,,,0,"ltr",,"L"
6267,,,"tiy",,"Tiruray",,,,,,0,"ltr",,"L"
6268,,,"tiz",,"Tai Hongjin",,,,,,0,"ltr",,"L"
6269,,,"tja",,"Tajuasohn",,,,,,0,"ltr",,"L"
6270,,,"tjg",,"Tunjung",,,,,,0,"ltr",,"L"
6271,,,"tji",,"Tujia",,"Northern",,,,0,"ltr",,"L"
6272,,,"tjm",,"Timucua",,,,,,0,"ltr",,"E"
6273,,,"tjn",,"Tonjon",,,,,,0,"ltr",,"E"
6274,,,"tjo",,"Tamazight",,"Temacine",,,,0,"ltr",,"L"
6275,,,"tjs",,"Tujia",,"Southern",,,,0,"ltr",,"L"
6276,,,"tju",,"Tjurruru",,,,,,0,"ltr",,"E"
6277,,,"tka",,"Truká",,,,,,0,"ltr",,"E"
6278,,,"tkb",,"Buksa",,,,,,0,"ltr",,"L"
6279,,,"tkd",,"Tukudede",,,,,,0,"ltr",,"L"
6280,,,"tke",,"Takwane",,,,,,0,"ltr",,"L"
6281,,,"tkf",,"Tukumanféd",,,,,,0,"ltr",,"E"
6282,,,"tkk",,"Takpa",,,,,,0,"ltr",,"L"
6283,,"tkl","tkl",,"Tokelau",,,,,,0,"ltr",,"L"
6284,,,"tkm",,"Takelma",,,,,,0,"ltr",,"E"
6285,,,"tkn",,"Toku-No-Shima",,,,,,0,"ltr",,"L"
6286,,,"tkp",,"Tikopia",,,,,,0,"ltr",,"L"
6287,,,"tkq",,"Tee",,,,,,0,"ltr",,"L"
6288,,,"tkr",,"Tsakhur",,,,,,0,"ltr",,"L"
6289,,,"tks",,"Takestani",,,,,,0,"ltr",,"L"
6290,,,"tkt",,"Tharu",,"Kathoriya",,,,0,"ltr",,"L"
6291,,,"tkw",,"Teanu",,,,,,0,"ltr",,"L"
6292,,,"tkx",,"Tangko",,,,,,0,"ltr",,"L"
6293,,,"tkz",,"Takua",,,,,,0,"ltr",,"L"
6294,,,"tla",,"Tepehuan",,"Southwestern",,,,0,"ltr",,"L"
6295,,,"tlb",,"Tobelo",,,,,,0,"ltr",,"L"
6296,,,"tlc",,"Totonac",,"Yecuatla",,,,0,"ltr",,"L"
6297,,,"tld",,"Talaud",,,,,,0,"ltr",,"L"
6298,,,"tle",,"Talai",,,,,,0,"ltr",,"L"
6299,,,"tlf",,"Telefol",,,,,,0,"ltr",,"L"
6300,,,"tlg",,"Tofanma",,,,,,0,"ltr",,"L"
6301,,"tlh","tlh",,"Klingon; tlhIngan-Hol",,,,,,0,"ltr",,"C"
6302,,"tli","tli",,"Tlingit",,,,,,0,"ltr",,"L"
6303,,,"tlj",,"Talinga-Bwisi",,,,,,0,"ltr",,"L"
6304,,,"tlk",,"Taloki",,,,,,0,"ltr",,"L"
6305,,,"tll",,"Tetela",,,,,,0,"ltr",,"L"
6306,,,"tlm",,"Tolomako",,,,,,0,"ltr",,"L"
6307,,,"tln",,"Talondo'",,,,,,0,"ltr",,"L"
6308,,,"tlo",,"Talodi",,,,,,0,"ltr",,"L"
6309,,,"tlp",,"Totonac",,"Filomena Mata-Coahuitlán",,,,0,"ltr",,"L"
6310,,,"tlq",,"Tai Loi",,,,,,0,"ltr",,"L"
6311,,,"tlr",,"Talise",,,,,,0,"ltr",,"L"
6312,,,"tls",,"Tambotalo",,,,,,0,"ltr",,"L"
6313,,,"tlt",,"Teluti",,,,,,0,"ltr",,"L"
6314,,,"tlu",,"Tulehu",,,,,,0,"ltr",,"L"
6315,,,"tlv",,"Taliabu",,,,,,0,"ltr",,"L"
6316,,,"tlw",,"Wemale",,"South",,,,0,"ltr",,"L"
6317,,,"tlx",,"Khehek",,,,,,0,"ltr",,"L"
6318,,,"tly",,"Talysh",,,,,,0,"ltr",,"L"
6319,,,"tlz",,"Toala'",,,,,,0,"ltr",,"L"
6320,,,"tma",,"Tama","Chad",,,,,0,"ltr",,"L"
6321,,,"tmb",,"Katbol",,,,,,0,"ltr",,"L"
6322,,,"tmc",,"Tumak",,,,,,0,"ltr",,"L"
6323,,,"tmd",,"Haruai",,,,,,0,"ltr",,"L"
6324,,,"tme",,"Tremembé",,,,,,0,"ltr",,"L"
6325,,,"tmf",,"Toba-Maskoy",,,,,,0,"ltr",,"L"
6326,,,"tmg",,"Ternateño",,,,,,0,"ltr",,"E"
6327,,"tmh","tmh",,"Tamashek",,,,,,1,"ltr",,"L"
6328,,,"tmi",,"Tutuba",,,,,,0,"ltr",,"L"
6329,,,"tmj",,"Samarokena",,,,,,0,"ltr",,"L"
6330,,,"tmk",,"Tamang",,"Northwestern",,,,0,"ltr",,"L"
6331,,,"tml",,"Citak",,"Tamnim",,,,0,"ltr",,"L"
6332,,,"tmm",,"Tai Thanh",,,,,,0,"ltr",,"L"
6333,,,"tmn",,"Taman","Indonesia",,,,,0,"ltr",,"L"
6334,,,"tmo",,"Temoq",,,,,,0,"ltr",,"L"
6335,,,"tmp",,"Tai Mène",,,,,,0,"ltr",,"L"
6336,,,"tmq",,"Tumleo",,,,,,0,"ltr",,"L"
6337,,,"tmr",,"Aramaic",,"Talmudic",,,,0,"ltr",,"A"
6338,,,"tms",,"Tima",,,,,,0,"ltr",,"L"
6339,,,"tmt",,"Tasmate",,,,,,0,"ltr",,"L"
6340,,,"tmu",,"Iau",,,,,,0,"ltr",,"L"
6341,,,"tmv",,"Tembo","Motembo",,,,,0,"ltr",,"L"
6342,,,"tmw",,"Temuan",,,,,,0,"ltr",,"L"
6343,,,"tmx",,"Tomyang",,,,,,0,"ltr",,"L"
6344,,,"tmy",,"Tami",,,,,,0,"ltr",,"L"
6345,,,"tmz",,"Tamanaku",,,,,,0,"ltr",,"E"
6346,,,"tna",,"Tacana",,,,,,0,"ltr",,"L"
6347,,,"tnb",,"Tunebo",,"Western",,,,0,"ltr",,"L"
6348,,,"tnc",,"Tanimuca-Retuarã",,,,,,0,"ltr",,"L"
6349,,,"tnd",,"Tunebo",,"Angosturas",,,,0,"ltr",,"L"
6350,,,"tne",,"Kallahan",,"Tinoc",,,,0,"ltr",,"L"
6351,,,"tnf",,"Tangshewi",,,,,,0,"ltr",,"L"
6352,,,"tng",,"Tobanga",,,,,,0,"ltr",,"L"
6353,,,"tnh",,"Maiani",,,,,,0,"ltr",,"L"
6354,,,"tni",,"Tandia",,,,,,0,"ltr",,"L"
6355,,,"tnj",,"Tanjong",,,,,,0,"ltr",,"L"
6356,,,"tnk",,"Kwamera",,,,,,0,"ltr",,"L"
6357,,,"tnl",,"Lenakel",,,,,,0,"ltr",,"L"
6358,,,"tnm",,"Tabla",,,,,,0,"ltr",,"L"
6359,,,"tnn",,"Tanna",,"North",,,,0,"ltr",,"L"
6360,,,"tno",,"Toromono",,,,,,0,"ltr",,"L"
6361,,,"tnp",,"Whitesands",,,,,,0,"ltr",,"L"
6362,,,"tnq",,"Taino",,,,,,0,"ltr",,"E"
6363,,,"tnr",,"Budik",,,,,,0,"ltr",,"L"
6364,,,"tns",,"Tenis",,,,,,0,"ltr",,"L"
6365,,,"tnt",,"Tontemboan",,,,,,0,"ltr",,"L"
6366,,,"tnu",,"Tay Khang",,,,,,0,"ltr",,"L"
6367,,,"tnv",,"Tangchangya",,,,,,0,"ltr",,"L"
6368,,,"tnw",,"Tonsawang",,,,,,0,"ltr",,"L"
6369,,,"tnx",,"Tanema",,,,,,0,"ltr",,"L"
6370,,,"tny",,"Tongwe",,,,,,0,"ltr",,"L"
6371,,,"tnz",,"Tonga","Thailand",,,,,0,"ltr",,"L"
6372,,,"tob",,"Toba",,,,,,0,"ltr",,"L"
6373,,,"toc",,"Totonac",,"Coyutla",,,,0,"ltr",,"L"
6374,,,"tod",,"Toma",,,,,,0,"ltr",,"L"
6375,,,"toe",,"Tomedes",,,,,,0,"ltr",,"E"
6376,,,"tof",,"Gizrra",,,,,,0,"ltr",,"L"
6377,,"tog","tog",,"Tonga","Nyasa",,,,,0,"ltr",,"L"
6378,,,"toh",,"Gitonga",,,,,,0,"ltr",,"L"
6379,,,"toi",,"Tonga","Zambia",,,,,0,"ltr",,"L"
6380,,,"toj",,"Tojolabal",,,,,,0,"ltr",,"L"
6381,,,"tol",,"Tolowa",,,,,,0,"ltr",,"L"
6382,,,"tom",,"Tombulu",,,,,,0,"ltr",,"L"
6383,"to","ton","ton",,"Tonga","Tonga Islands",,,,,0,"ltr",,"L"
6384,,,"too",,"Totonac",,"Xicotepec De Juárez",,,,0,"ltr",,"L"
6385,,,"top",,"Totonac",,"Papantla",,,,0,"ltr",,"L"
6386,,,"toq",,"Toposa",,,,,,0,"ltr",,"L"
6387,,,"tor",,"Banda",,"Togbo-Vara",,,,0,"ltr",,"L"
6388,,,"tos",,"Totonac",,"Highland",,,,0,"ltr",,"L"
6389,,,"tot",,"Totonac",,"Patla-Chicontla",,,,0,"ltr",,"L"
6390,,,"tou",,"Tho",,,,,,0,"ltr",,"L"
6391,,,"tov",,"Taromi",,"Upper",,,,0,"ltr",,"L"
6392,,,"tow",,"Jemez",,,,,,0,"ltr",,"L"
6393,,,"tox",,"Tobian",,,,,,0,"ltr",,"L"
6394,,,"toy",,"Topoiyo",,,,,,0,"ltr",,"L"
6395,,,"toz",,"To",,,,,,0,"ltr",,"L"
6396,,,"tpa",,"Taupota",,,,,,0,"ltr",,"L"
6397,,,"tpc",,"Tlapanec",,"Azoyú",,,,0,"ltr",,"L"
6398,,,"tpe",,"Tippera",,,,,,0,"ltr",,"L"
6399,,,"tpg",,"Kula",,,,,,0,"ltr",,"L"
6400,,"tpi","tpi",,"Tok Pisin",,,,,,0,"ltr",,"L"
6401,,,"tpj",,"Tapieté",,,,,,0,"ltr",,"L"
6402,,,"tpk",,"Tupinikin",,,,,,0,"ltr",,"E"
6403,,,"tpl",,"Tlapanec",,"Tlacoapa",,,,0,"ltr",,"L"
6404,,,"tpm",,"Tampulma",,,,,,0,"ltr",,"L"
6405,,,"tpn",,"Tupinambá",,,,,,0,"ltr",,"E"
6406,,,"tpo",,"Tai Pao",,,,,,0,"ltr",,"L"
6407,,,"tpp",,"Tepehua",,"Pisaflores",,,,0,"ltr",,"L"
6408,,,"tpq",,"Tukpa",,,,,,0,"ltr",,"L"
6409,,,"tpr",,"Tuparí",,,,,,0,"ltr",,"L"
6410,,,"tpt",,"Tepehua",,"Tlachichilco",,,,0,"ltr",,"L"
6411,,,"tpu",,"Tampuan",,,,,,0,"ltr",,"L"
6412,,,"tpv",,"Tanapag",,,,,,0,"ltr",,"L"
6413,,,"tpw",,"Tupí",,,,,,0,"ltr",,"E"
6414,,,"tpx",,"Tlapanec",,"Acatepec",,,,0,"ltr",,"L"
6415,,,"tpy",,"Trumaí",,,,,,0,"ltr",,"L"
6416,,,"tpz",,"Tinputz",,,,,,0,"ltr",,"L"
6417,,,"tqb",,"Tembé",,,,,,0,"ltr",,"L"
6418,,,"tql",,"Lehali",,,,,,0,"ltr",,"L"
6419,,,"tqm",,"Turumsa",,,,,,0,"ltr",,"L"
6420,,,"tqn",,"Tenino",,,,,,0,"ltr",,"L"
6421,,,"tqo",,"Toaripi",,,,,,0,"ltr",,"L"
6422,,,"tqp",,"Tomoip",,,,,,0,"ltr",,"L"
6423,,,"tqq",,"Tunni",,,,,,0,"ltr",,"L"
6424,,,"tqr",,"Torona",,,,,,0,"ltr",,"E"
6425,,,"tqt",,"Totonac",,"Ozumatlán",,,,0,"ltr",,"L"
6426,,,"tqu",,"Touo",,,,,,0,"ltr",,"L"
6427,,,"tqw",,"Tonkawa",,,,,,0,"ltr",,"E"
6428,,,"tra",,"Tirahi",,,,,,0,"ltr",,"L"
6429,,,"trb",,"Terebu",,,,,,0,"ltr",,"L"
6430,,,"trc",,"Triqui",,"Copala",,,,0,"ltr",,"L"
6431,,,"trd",,"Turi",,,,,,0,"ltr",,"L"
6432,,,"tre",,"Tarangan",,"East",,,,0,"ltr",,"L"
6433,,,"trf",,"Trinidadian Creole English",,,,,,0,"ltr",,"L"
6434,,,"trg",,"Lishán Didán",,,,,,0,"ltr",,"L"
6435,,,"trh",,"Turaka",,,,,,0,"ltr",,"L"
6436,,,"tri",,"Trió",,,,,,0,"ltr",,"L"
6437,,,"trj",,"Toram",,,,,,0,"ltr",,"L"
6438,,,"trl",,"Traveller Scottish",,,,,,0,"ltr",,"L"
6439,,,"trm",,"Tregami",,,,,,0,"ltr",,"L"
6440,,,"trn",,"Trinitario",,,,,,0,"ltr",,"L"
6441,,,"tro",,"Naga",,"Tarao",,,,0,"ltr",,"L"
6442,,,"trp",,"Kok Borok",,,,,,0,"ltr",,"L"
6443,,,"trq",,"Triqui",,"San Martín Itunyoso",,,,0,"ltr",,"L"
6444,,,"trr",,"Taushiro",,,,,,0,"ltr",,"L"
6445,,,"trs",,"Triqui",,"Chicahuaxtla",,,,0,"ltr",,"L"
6446,,,"trt",,"Tunggare",,,,,,0,"ltr",,"L"
6447,,,"tru",,"Turoyo",,,,,,0,"ltr",,"L"
6448,,,"trv",,"Taroko",,,,,,0,"ltr",,"L"
6449,,,"trw",,"Torwali",,,,,,0,"ltr",,"L"
6450,,,"trx",,"Tringgus",,,,,,0,"ltr",,"L"
6451,,,"try",,"Turung",,,,,,0,"ltr",,"E"
6452,,,"trz",,"Torá",,,,,,0,"ltr",,"L"
6453,,,"tsa",,"Tsaangi",,,,,,0,"ltr",,"L"
6454,,,"tsb",,"Tsamai",,,,,,0,"ltr",,"L"
6455,,,"tsc",,"Tswa",,,,,,0,"ltr",,"L"
6456,,,"tsd",,"Tsakonian",,,,,,0,"ltr",,"L"
6457,,,"tse",,"Tunisian Sign Language",,,,,,0,"ltr",,"L"
6458,,,"tsf",,"Tamang",,"Southwestern",,,,0,"ltr",,"L"
6459,,,"tsg",,"Tausug",,,,,,0,"ltr",,"L"
6460,,,"tsh",,"Tsuvan",,,,,,0,"ltr",,"L"
6461,,"tsi","tsi",,"Tsimshian",,,,,,0,"ltr",,"L"
6462,,,"tsj",,"Tshangla",,,,,,0,"ltr",,"L"
6463,,,"tsk",,"Tseku",,,,,,0,"ltr",,"L"
6464,,,"tsl",,"Ts'ün-Lao",,,,,,0,"ltr",,"L"
6465,,,"tsm",,"Turkish Sign Language",,,,,,0,"ltr",,"L"
6466,"tn","tsn","tsn",,"Tswana",,,,,,0,"ltr",,"L"
6467,"ts","tso","tso",,"Tsonga",,,,,,0,"ltr",,"L"
6468,,,"tsp",,"Toussian",,"Northern",,,,0,"ltr",,"L"
6469,,,"tsq",,"Thai Sign Language",,,,,,0,"ltr",,"L"
6470,,,"tsr",,"Akei",,,,,,0,"ltr",,"L"
6471,,,"tss",,"Taiwan Sign Language",,,,,,0,"ltr",,"L"
6472,,,"tsu",,"Tsou",,,,,,0,"ltr",,"L"
6473,,,"tsv",,"Tsogo",,,,,,0,"ltr",,"L"
6474,,,"tsw",,"Tsishingini",,,,,,0,"ltr",,"L"
6475,,,"tsx",,"Mubami",,,,,,0,"ltr",,"L"
6476,,,"tsz",,"Purepecha",,,,,,0,"ltr",,"L"
6477,,,"tta",,"Tutelo",,,,,,0,"ltr",,"E"
6478,,,"ttb",,"Gaa",,,,,,0,"ltr",,"L"
6479,,,"ttc",,"Tektiteko",,,,,,0,"ltr",,"L"
6480,,,"ttd",,"Tauade",,,,,,0,"ltr",,"L"
6481,,,"tte",,"Bwanabwana",,,,,,0,"ltr",,"L"
6482,,,"ttf",,"Tuotomb",,,,,,0,"ltr",,"L"
6483,,,"ttg",,"Tutong 2",,,,,,0,"ltr",,"L"
6484,,,"tth",,"Ta'oih",,"Upper",,,,0,"ltr",,"L"
6485,,,"tti",,"Tobati",,,,,,0,"ltr",,"L"
6486,,,"ttj",,"Tooro",,,,,,0,"ltr",,"L"
6487,,,"ttk",,"Totoro",,,,,,0,"ltr",,"L"
6488,,,"ttl",,"Totela",,,,,,0,"ltr",,"L"
6489,,,"ttm",,"Tutchone",,"Northern",,,,0,"ltr",,"L"
6490,,,"ttn",,"Towei",,,,,,0,"ltr",,"L"
6491,,,"tto",,"Ta'oih",,"Lower",,,,0,"ltr",,"L"
6492,,,"ttp",,"Tombelala",,,,,,0,"ltr",,"L"
6493,,,"ttq",,"Tamajaq",,"Tawallammat",,,,0,"ltr",,"L"
6494,,,"ttr",,"Tera",,,,,,0,"ltr",,"L"
6495,,,"tts",,"Thai",,"Northeastern",,,,0,"ltr",,"L"
6496,,,"ttt",,"Tat",,"Muslim",,,,0,"ltr",,"L"
6497,,,"ttu",,"Torau",,,,,,0,"ltr",,"L"
6498,,,"ttv",,"Titan",,,,,,0,"ltr",,"L"
6499,,,"ttw",,"Kenyah",,"Tutoh",,,,0,"ltr",,"L"
6500,,,"ttx",,"Tutong 1",,,,,,0,"ltr",,"L"
6501,,,"tty",,"Sikaritai",,,,,,0,"ltr",,"L"
6502,,,"ttz",,"Tsum",,,,,,0,"ltr",,"L"
6503,,,"tua",,"Wiarumus",,,,,,0,"ltr",,"L"
6504,,,"tub",,"Tübatulabal",,,,,,0,"ltr",,"L"
6505,,,"tuc",,"Mutu",,,,,,0,"ltr",,"L"
6506,,,"tud",,"Tuxá",,,,,,0,"ltr",,"E"
6507,,,"tue",,"Tuyuca",,,,,,0,"ltr",,"L"
6508,,,"tuf",,"Tunebo",,"Central",,,,0,"ltr",,"L"
6509,,,"tug",,"Tunia",,,,,,0,"ltr",,"L"
6510,,,"tuh",,"Taulil",,,,,,0,"ltr",,"L"
6511,,,"tui",,"Tupuri",,,,,,0,"ltr",,"L"
6512,,,"tuj",,"Tugutil",,,,,,0,"ltr",,"L"
6513,"tk","tuk","tuk",,"Turkmen",,,,,,0,"ltr",,"L"
6514,,,"tul",,"Tula",,,,,,0,"ltr",,"L"
6515,,"tum","tum",,"Tumbuka",,,,,,0,"ltr",,"L"
6516,,,"tun",,"Tunica",,,,,,0,"ltr",,"E"
6517,,,"tuo",,"Tucano",,,,,,0,"ltr",,"L"
6518,,,"tuq",,"Tedaga",,,,,,0,"ltr",,"L"
6519,"tr","tur","tur",,"Turkish",,,"Tϋrkçe",,,0,"ltr","c = 1","L"
6520,,,"tus",,"Tuscarora",,,,,,0,"ltr",,"L"
6521,,,"tuu",,"Tututni",,,,,,0,"ltr",,"L"
6522,,,"tuv",,"Turkana",,,,,,0,"ltr",,"L"
6523,,,"tux",,"Tuxináwa",,,,,,0,"ltr",,"E"
6524,,,"tuy",,"Tugen",,"North",,,,0,"ltr",,"L"
6525,,,"tuz",,"Turka",,,,,,0,"ltr",,"L"
6526,,,"tva",,"Vaghua",,,,,,0,"ltr",,"L"
6527,,,"tvd",,"Tsuvadi",,,,,,0,"ltr",,"L"
6528,,,"tve",,"Te'un",,,,,,0,"ltr",,"L"
6529,,,"tvk",,"Ambrym",,"Southeast",,,,0,"ltr",,"L"
6530,,"tvl","tvl",,"Tuvalu",,,,,,0,"ltr",,"L"
6531,,,"tvm",,"Tela-Masbuar",,,,,,0,"ltr",,"L"
6532,,,"tvn",,"Tavoyan",,,,,,0,"ltr",,"L"
6533,,,"tvo",,"Tidore",,,,,,0,"ltr",,"L"
6534,,,"tvs",,"Taveta",,,,,,0,"ltr",,"L"
6535,,,"tvt",,"Naga",,"Tutsa",,,,0,"ltr",,"L"
6536,,,"tvw",,"Sedoa",,,,,,0,"ltr",,"L"
6537,,,"tvy",,"Pidgin",,"Timor",,,,0,"ltr",,"E"
6538,,,"twa",,"Twana",,,,,,0,"ltr",,"E"
6539,,,"twb",,"Tawbuid",,"Western",,,,0,"ltr",,"L"
6540,,,"twc",,"Teshenawa",,,,,,0,"ltr",,"E"
6541,,,"twd",,"Twents",,,,,,0,"ltr",,"L"
6542,,,"twe",,"Tewa","Indonesia",,,,,0,"ltr",,"L"
6543,,,"twf",,"Tiwa",,"Northern",,,,0,"ltr",,"L"
6544,,,"twg",,"Tereweng",,,,,,0,"ltr",,"L"
6545,,,"twh",,"Tai Dón",,,,,,0,"ltr",,"L"
6546,"tw","twi","twi",,"Twi",,,,,,0,"ltr",,"L"
6547,,,"twl",,"Tawara",,,,,,0,"ltr",,"L"
6548,,,"twn",,"Twendi",,,,,,0,"ltr",,"L"
6549,,,"two",,"Tswapong",,,,,,0,"ltr",,"L"
6550,,,"twp",,"Ere",,,,,,0,"ltr",,"L"
6551,,,"twq",,"Tasawaq",,,,,,0,"ltr",,"L"
6552,,,"twr",,"Tarahumara",,"Southwestern",,,,0,"ltr",,"L"
6553,,,"twt",,"Turiwára",,,,,,0,"ltr",,"E"
6554,,,"twu",,"Termanu",,,,,,0,"ltr",,"L"
6555,,,"tww",,"Tuwari",,,,,,0,"ltr",,"L"
6556,,,"twx",,"Tewe",,,,,,0,"ltr",,"L"
6557,,,"twy",,"Tawoyan",,,,,,0,"ltr",,"L"
6558,,,"txa",,"Tombonuwo",,,,,,0,"ltr",,"L"
6559,,,"txb",,"Tokharian B",,,,,,0,"ltr",,"A"
6560,,,"txc",,"Tsetsaut",,,,,,0,"ltr",,"E"
6561,,,"txe",,"Totoli",,,,,,0,"ltr",,"L"
6562,,,"txg",,"Tangut",,,,,,0,"ltr",,"A"
6563,,,"txh",,"Thracian",,,,,,0,"ltr",,"A"
6564,,,"txi",,"Ikpeng",,,,,,0,"ltr",,"L"
6565,,,"txm",,"Tomini",,,,,,0,"ltr",,"L"
6566,,,"txn",,"Tarangan",,"West",,,,0,"ltr",,"L"
6567,,,"txo",,"Toto",,,,,,0,"ltr",,"L"
6568,,,"txq",,"Tii",,,,,,0,"ltr",,"L"
6569,,,"txr",,"Tartessian",,,,,,0,"ltr",,"A"
6570,,,"txs",,"Tonsea",,,,,,0,"ltr",,"L"
6571,,,"txt",,"Citak",,,,,,0,"ltr",,"L"
6572,,,"txu",,"Kayapó",,,,,,0,"ltr",,"L"
6573,,,"txx",,"Tatana",,,,,,0,"ltr",,"L"
6574,,,"txy",,"Malagasy",,"Tanosy",,,,0,"ltr",,"L"
6575,,,"tya",,"Tauya",,,,,,0,"ltr",,"L"
6576,,,"tye",,"Kyenga",,,,,,0,"ltr",,"L"
6577,,,"tyh",,"O'du",,,,,,0,"ltr",,"L"
6578,,,"tyi",,"Teke-Tsaayi",,,,,,0,"ltr",,"L"
6579,,,"tyj",,"Tai Do",,,,,,0,"ltr",,"L"
6580,,,"tyl",,"Thu Lao",,,,,,0,"ltr",,"L"
6581,,,"tyn",,"Kombai",,,,,,0,"ltr",,"L"
6582,,,"typ",,"Thaypan",,,,,,0,"ltr",,"L"
6583,,,"tyr",,"Tai Daeng",,,,,,0,"ltr",,"L"
6584,,,"tys",,"Tày Sa Pa",,,,,,0,"ltr",,"L"
6585,,,"tyt",,"Tày Tac",,,,,,0,"ltr",,"L"
6586,,,"tyu",,"Kua",,,,,,0,"ltr",,"L"
6587,,"tyv","tyv",,"Tuvinian",,,,,,0,"ltr",,"L"
6588,,,"tyx",,"Teke-Tyee",,,,,,0,"ltr",,"L"
6589,,,"tyz",,"Tày",,,,,,0,"ltr",,"L"
6590,,,"tza",,"Tanzanian Sign Language",,,,,,0,"ltr",,"L"
6591,,,"tzb",,"Tzeltal",,"Bachajón",,,,0,"ltr",,"L"
6592,,,"tzc",,"Tzotzil",,"Chamula",,,,0,"ltr",,"L"
6593,,,"tze",,"Tzotzil",,"Chenalhó",,,,0,"ltr",,"L"
6594,,,"tzh",,"Tzeltal",,"Oxchuc",,,,0,"ltr",,"L"
6595,,,"tzj",,"Tzutujil",,"Eastern",,,,0,"ltr",,"L"
6596,,,"tzm",,"Tamazight",,"Central Atlas",,,,0,"ltr",,"L"
6597,,,"tzn",,"Tugun",,,,,,0,"ltr",,"L"
6598,,,"tzo",,"Tzotzil",,"Venustiano Carranza",,,,0,"ltr",,"L"
6599,,,"tzs",,"Tzotzil",,"San Andrés Larrainzar",,,,0,"ltr",,"L"
6600,,,"tzt",,"Tzutujil",,"Western",,,,0,"ltr",,"L"
6601,,,"tzu",,"Tzotzil",,"Huixtán",,,,0,"ltr",,"L"
6602,,,"tzx",,"Tabriak",,,,,,0,"ltr",,"L"
6603,,,"tzz",,"Tzotzil",,"Zinacantán",,,,0,"ltr",,"L"
6604,,,"uam",,"Uamué",,,,,,0,"ltr",,"E"
6605,,,"uan",,"Kuan",,,,,,0,"ltr",,"L"
6606,,,"uar",,"Tairuma",,,,,,0,"ltr",,"L"
6607,,,"uba",,"Ubang",,,,,,0,"ltr",,"L"
6608,,,"ubi",,"Ubi",,,,,,0,"ltr",,"L"
6609,,,"ubm",,"Kenyah",,"Upper Baram",,,,0,"ltr",,"L"
6610,,,"ubr",,"Ubir",,,,,,0,"ltr",,"L"
6611,,,"ubu",,"Umbu-Ungu",,,,,,0,"ltr",,"L"
6612,,,"uby",,"Ubykh",,,,,,0,"ltr",,"E"
6613,,,"uda",,"Uda",,,,,,0,"ltr",,"L"
6614,,,"ude",,"Udihe",,,,,,0,"ltr",,"L"
6615,,,"udi",,"Udi",,,,,,0,"ltr",,"L"
6616,,,"udj",,"Ujir",,,,,,0,"ltr",,"L"
6617,,,"udl",,"Wuzlam",,,,,,0,"ltr",,"L"
6618,,"udm","udm",,"Udmurt",,,,,,0,"ltr",,"L"
6619,,,"udu",,"Uduk",,,,,,0,"ltr",,"L"
6620,,,"ues",,"Kioko",,,,,,0,"ltr",,"L"
6621,,,"ufi",,"Ufim",,,,,,0,"ltr",,"L"
6622,,"uga","uga",,"Ugaritic",,,,,,0,"ltr",,"A"
6623,,,"ugb",,"Kuku-Ugbanh",,,,,,0,"ltr",,"L"
6624,,,"uge",,"Ughele",,,,,,0,"ltr",,"L"
6625,,,"ugn",,"Ugandan Sign Language",,,,,,0,"ltr",,"L"
6626,,,"ugo",,"Ugong",,,,,,0,"ltr",,"L"
6627,,,"ugy",,"Uruguayan Sign Language",,,,,,0,"ltr",,"L"
6628,,,"uha",,"Uhami",,,,,,0,"ltr",,"L"
6629,,,"uhn",,"Damal",,,,,,0,"ltr",,"L"
6630,"ug","uig","uig",,"Uighur",,,,,,0,"ltr",,"L"
6631,,,"uis",,"Uisai",,,,,,0,"ltr",,"L"
6632,,,"uiv",,"Iyive",,,,,,0,"ltr",,"L"
6633,,,"uji",,"Tanjijili",,,,,,0,"ltr",,"L"
6634,,,"uka",,"Kaburi",,,,,,0,"ltr",,"L"
6635,,,"ukg",,"Ukuriguma",,,,,,0,"ltr",,"L"
6636,,,"ukh",,"Ukhwejo",,,,,,0,"ltr",,"L"
6637,,,"ukl",,"Ukrainian Sign Language",,,,,,0,"ltr",,"L"
6638,,,"ukp",,"Ukpe-Bayobiri",,,,,,0,"ltr",,"L"
6639,,,"ukq",,"Ukwa",,,,,,0,"ltr",,"L"
6640,"uk","ukr","ukr",,"Ukrainian",,,"Українська",,,0,"ltr","c%10==1 && c%100!=11 ? 1 : c%10>=2 && c%10<=4 && (c%100<10 || c%100>=20) ? 2 : 3","L"
6641,,,"uks",,"Urubú-Kaapor Sign Language",,,,,,0,"ltr",,"L"
6642,,,"uku",,"Ukue",,,,,,0,"ltr",,"L"
6643,,,"ukw",,"Ukwuani-Aboh-Ndoni",,,,,,0,"ltr",,"L"
6644,,,"ula",,"Fungwa",,,,,,0,"ltr",,"L"
6645,,,"ulb",,"Ulukwumi",,,,,,0,"ltr",,"L"
6646,,,"ulc",,"Ulch",,,,,,0,"ltr",,"L"
6647,,,"ulf",,"Usku",,,,,,0,"ltr",,"L"
6648,,,"uli",,"Ulithian",,,,,,0,"ltr",,"L"
6649,,,"ulk",,"Meriam",,,,,,0,"ltr",,"L"
6650,,,"ull",,"Ullatan",,,,,,0,"ltr",,"L"
6651,,,"ulm",,"Ulumanda'",,,,,,0,"ltr",,"L"
6652,,,"uln",,"Unserdeutsch",,,,,,0,"ltr",,"L"
6653,,,"uma",,"Umatilla",,,,,,0,"ltr",,"L"
6654,,"umb","umb",,"Umbundu",,,,,,0,"ltr",,"L"
6655,,,"umc",,"Marrucinian",,,,,,0,"ltr",,"A"
6656,,,"umd",,"Umbindhamu",,,,,,0,"ltr",,"L"
6657,,,"umg",,"Umbuygamu",,,,,,0,"ltr",,"L"
6658,,,"umi",,"Ukit",,,,,,0,"ltr",,"L"
6659,,,"umm",,"Umon",,,,,,0,"ltr",,"L"
6660,,,"umo",,"Umotína",,,,,,0,"ltr",,"E"
6661,,,"ump",,"Umpila",,,,,,0,"ltr",,"L"
6662,,,"umr",,"Umbugarla",,,,,,0,"ltr",,"L"
6663,,,"ums",,"Pendau",,,,,,0,"ltr",,"L"
6664,,,"umu",,"Munsee",,,,,,0,"ltr",,"L"
6665,,,"una",,"Watut",,"North",,,,0,"ltr",,"L"
6666,,"und","und",,"Undetermined",,,,,,0,"ltr",,""
6667,,,"une",,"Uneme",,,,,,0,"ltr",,"L"
6668,,,"ung",,"Ngarinyin",,,,,,0,"ltr",,"L"
6669,,,"unk",,"Enawené-Nawé",,,,,,0,"ltr",,"L"
6670,,,"unm",,"Unami",,,,,,0,"ltr",,"E"
6671,,,"unp",,"Worora",,,,,,0,"ltr",,"L"
6672,,,"unz",,"Kaili",,"Unde",,,,0,"ltr",,"L"
6673,,,"uok",,"Uokha",,,,,,0,"ltr",,"L"
6674,,,"upi",,"Umeda",,,,,,0,"ltr",,"L"
6675,,,"upv",,"Uripiv-Wala-Rano-Atchin",,,,,,0,"ltr",,"L"
6676,,,"ura",,"Urarina",,,,,,0,"ltr",,"L"
6677,,,"urb",,"Urubú-Kaapor",,,,,,0,"ltr",,"L"
6678,,,"urc",,"Urningangg",,,,,,0,"ltr",,"L"
6679,"ur","urd","urd",,"Urdu",,,"اردو",,,0,"ltr",,"L"
6680,,,"ure",,"Uru",,,,,,0,"ltr",,"L"
6681,,,"urf",,"Uradhi",,,,,,0,"ltr",,"L"
6682,,,"urg",,"Urigina",,,,,,0,"ltr",,"L"
6683,,,"urh",,"Urhobo",,,,,,0,"ltr",,"L"
6684,,,"uri",,"Urim",,,,,,0,"ltr",,"L"
6685,,,"urk",,"Urak Lawoi'",,,,,,0,"ltr",,"L"
6686,,,"url",,"Urali",,,,,,0,"ltr",,"L"
6687,,,"urm",,"Urapmin",,,,,,0,"ltr",,"L"
6688,,,"urn",,"Uruangnirin",,,,,,0,"ltr",,"L"
6689,,,"uro",,"Ura","Papua New Guinea",,,,,0,"ltr",,"L"
6690,,,"urp",,"Uru-Pa-In",,,,,,0,"ltr",,"L"
6691,,,"urr",,"Lehalurup",,,,,,0,"ltr",,"L"
6692,,,"urt",,"Urat",,,,,,0,"ltr",,"L"
6693,,,"uru",,"Urumi",,,,,,0,"ltr",,"E"
6694,,,"urv",,"Uruava",,,,,,0,"ltr",,"E"
6695,,,"urw",,"Sop",,,,,,0,"ltr",,"L"
6696,,,"urx",,"Urimo",,,,,,0,"ltr",,"L"
6697,,,"ury",,"Orya",,,,,,0,"ltr",,"L"
6698,,,"urz",,"Uru-Eu-Wau-Wau",,,,,,0,"ltr",,"L"
6699,,,"usa",,"Usarufa",,,,,,0,"ltr",,"L"
6700,,,"ush",,"Ushojo",,,,,,0,"ltr",,"L"
6701,,,"usi",,"Usui",,,,,,0,"ltr",,"L"
6702,,,"usk",,"Usaghade",,,,,,0,"ltr",,"L"
6703,,,"usp",,"Uspanteco",,,,,,0,"ltr",,"L"
6704,,,"usu",,"Uya",,,,,,0,"ltr",,"L"
6705,,,"uta",,"Otank",,,,,,0,"ltr",,"L"
6706,,,"ute",,"Ute-Southern Paiute",,,,,,0,"ltr",,"L"
6707,,,"utp",,"Amba","Solomon Islands",,,,,0,"ltr",,"L"
6708,,,"utr",,"Etulo",,,,,,0,"ltr",,"L"
6709,,,"utu",,"Utu",,,,,,0,"ltr",,"L"
6710,,,"uum",,"Urum",,,,,,0,"ltr",,"L"
6711,,,"uun",,"Kulon-Pazeh",,,,,,0,"ltr",,"E"
6712,,,"uur",,"Ura","Vanuatu",,,,,0,"ltr",,"L"
6713,,,"uuu",,"U",,,,,,0,"ltr",,"L"
6714,,,"uve",,"Uvean",,"West",,,,0,"ltr",,"L"
6715,,,"uvh",,"Uri",,,,,,0,"ltr",,"L"
6716,,,"uvl",,"Lote",,,,,,0,"ltr",,"L"
6717,,,"uwa",,"Kuku-Uwanh",,,,,,0,"ltr",,"L"
6718,,,"uya",,"Doko-Uyanga",,,,,,0,"ltr",,"L"
6719,"uz","uzb","uzb",,"Uzbek",,,"o'zbek",,,1,"ltr",,"L"
6720,,,"uzn",,"Uzbek",,"Northern",,,,0,"ltr",,"L"
6721,,,"uzs",,"Uzbek",,"Southern",,,,0,"ltr",,"L"
6722,,,"vaa",,"Vaagri Booli",,,,,,0,"ltr",,"L"
6723,,,"vae",,"Vale",,,,,,0,"ltr",,"L"
6724,,,"vaf",,"Vafsi",,,,,,0,"ltr",,"L"
6725,,,"vag",,"Vagla",,,,,,0,"ltr",,"L"
6726,,,"vah",,"Varhadi-Nagpuri",,,,,,0,"ltr",,"L"
6727,,"vai","vai",,"Vai",,,,,,0,"ltr",,"L"
6728,,,"vaj",,"Vasekela Bushman",,,,,,0,"ltr",,"L"
6729,,,"val",,"Vehes",,,,,,0,"ltr",,"L"
6730,,,"vam",,"Vanimo",,,,,,0,"ltr",,"L"
6731,,,"van",,"Valman",,,,,,0,"ltr",,"L"
6732,,,"vao",,"Vao",,,,,,0,"ltr",,"L"
6733,,,"vap",,"Vaiphei",,,,,,0,"ltr",,"L"
6734,,,"var",,"Huarijio",,,,,,0,"ltr",,"L"
6735,,,"vas",,"Vasavi",,,,,,0,"ltr",,"L"
6736,,,"vau",,"Vanuma",,,,,,0,"ltr",,"L"
6737,,,"vav",,"Varli",,,,,,0,"ltr",,"L"
6738,,,"vay",,"Wayu",,,,,,0,"ltr",,"L"
6739,,,"vbb",,"Babar",,"Southeast",,,,0,"ltr",,"L"
6740,,,"vec",,"Venetian",,,,,,0,"ltr",,"L"
6741,,,"ved",,"Veddah",,,,,,0,"ltr",,"L"
6742,,,"vel",,"Veluws",,,,,,0,"ltr",,"L"
6743,,,"vem",,"Vemgo-Mabas",,,,,,0,"ltr",,"L"
6744,"ve","ven","ven",,"Venda",,,,,,0,"ltr",,"L"
6745,,,"veo",,"Ventureño",,,,,,0,"ltr",,"E"
6746,,,"vep",,"Veps",,,,,,0,"ltr",,"L"
6747,,,"ver",,"Mom Jango",,,,,,0,"ltr",,"L"
6748,,,"vgr",,"Vaghri",,,,,,0,"ltr",,"L"
6749,,,"vic",,"Virgin Islands Creole English",,,,,,0,"ltr",,"L"
6750,,,"vid",,"Vidunda",,,,,,0,"ltr",,"L"
6751,"vi","vie","vie",,"Vietnamese",,,"Tiếng Việt",,,0,"ltr",,"L"
6752,,,"vif",,"Vili",,,,,,0,"ltr",,"L"
6753,,,"vig",,"Viemo",,,,,,0,"ltr",,"L"
6754,,,"vil",,"Vilela",,,,,,0,"ltr",,"L"
6755,,,"vin",,"Vinza",,,,,,0,"ltr",,"L"
6756,,,"vis",,"Vishavan",,,,,,0,"ltr",,"L"
6757,,,"vit",,"Viti",,,,,,0,"ltr",,"L"
6758,,,"viv",,"Iduna",,,,,,0,"ltr",,"L"
6759,,,"vka",,"Kariyarra",,,,,,0,"ltr",,"E"
6760,,,"vki",,"Ija-Zuba",,,,,,0,"ltr",,"L"
6761,,,"vkj",,"Kujarge",,,,,,0,"ltr",,"L"
6762,,,"vkk",,"Kaur",,,,,,0,"ltr",,"L"
6763,,,"vkl",,"Kulisusu",,,,,,0,"ltr",,"L"
6764,,,"vkm",,"Kamakan",,,,,,0,"ltr",,"E"
6765,,,"vko",,"Kodeoha",,,,,,0,"ltr",,"L"
6766,,,"vkp",,"Korlai Creole Portuguese",,,,,,0,"ltr",,"L"
6767,,,"vkt",,"Malay",,"Tenggarong Kutai",,,,0,"ltr",,"L"
6768,,,"vku",,"Kurrama",,,,,,0,"ltr",,"L"
6769,,,"vky",,"Kayu Agung",,,,,,0,"ltr",,"L"
6770,,,"vlp",,"Valpei",,,,,,0,"ltr",,"L"
6771,,,"vlr",,"Vatrata",,,,,,0,"ltr",,"L"
6772,,,"vls",,"Vlaams",,,,,,0,"ltr",,"L"
6773,,,"vma",,"Martuyhunira",,,,,,0,"ltr",,"L"
6774,,,"vmb",,"Mbabaram",,,,,,0,"ltr",,"L"
6775,,,"vmc",,"Mixtec",,"Juxtlahuaca",,,,0,"ltr",,"L"
6776,,,"vmd",,"Koraga",,"Mudu",,,,0,"ltr",,"L"
6777,,,"vme",,"Masela",,"East",,,,0,"ltr",,"L"
6778,,,"vmf",,"Mainfränkisch",,,,,,0,"ltr",,"L"
6779,,,"vmg",,"Minigir",,,,,,0,"ltr",,"L"
6780,,,"vmh",,"Maraghei",,,,,,0,"ltr",,"L"
6781,,,"vmi",,"Miwa",,,,,,0,"ltr",,"L"
6782,,,"vmj",,"Mixtec",,"Ixtayutla",,,,0,"ltr",,"L"
6783,,,"vmk",,"Makhuwa-Shirima",,,,,,0,"ltr",,"L"
6784,,,"vml",,"Malgana",,,,,,0,"ltr",,"E"
6785,,,"vmm",,"Mixtec",,"Mitlatongo",,,,0,"ltr",,"L"
6786,,,"vmo",,"Muko-Muko",,,,,,0,"ltr",,"L"
6787,,,"vmp",,"Mazatec",,"Soyaltepec",,,,0,"ltr",,"L"
6788,,,"vmq",,"Mixtec",,"Soyaltepec",,,,0,"ltr",,"L"
6789,,,"vmr",,"Marenje",,,,,,0,"ltr",,"L"
6790,,,"vms",,"Moksela",,,,,,0,"ltr",,"E"
6791,,,"vmu",,"Muluridyi",,,,,,0,"ltr",,"L"
6792,,,"vmv",,"Maidu",,"Valley",,,,0,"ltr",,"E"
6793,,,"vmw",,"Makhuwa",,,,,,0,"ltr",,"L"
6794,,,"vmx",,"Mixtec",,"Tamazola",,,,0,"ltr",,"L"
6795,,,"vmy",,"Mazatec",,"Ayautla",,,,0,"ltr",,"L"
6796,,,"vmz",,"Mazatec",,"Mazatlán",,,,0,"ltr",,"L"
6797,,,"vnk",,"Vano",,,,,,0,"ltr",,"E"
6798,,,"vnm",,"Vinmavis",,,,,,0,"ltr",,"L"
6799,,,"vnp",,"Vunapu",,,,,,0,"ltr",,"L"
6800,"vo","vol","vol",,"Volapük",,,,,,0,"ltr",,"C"
6801,,,"vor",,"Voro",,,,,,0,"ltr",,"L"
6802,,"vot","vot",,"Votic",,,,,,0,"ltr",,"L"
6803,,,"vrs",,"Varisi",,,,,,0,"ltr",,"L"
6804,,,"vrt",,"Burmbar",,,,,,0,"ltr",,"L"
6805,,,"vsi",,"Moldova Sign Language",,,,,,0,"ltr",,"L"
6806,,,"vsl",,"Venezuelan Sign Language",,,,,,0,"ltr",,"L"
6807,,,"vum",,"Vumbu",,,,,,0,"ltr",,"L"
6808,,,"vun",,"Vunjo",,,,,,0,"ltr",,"L"
6809,,,"vut",,"Vute",,,,,,0,"ltr",,"L"
6810,,,"waa",,"Walla Walla",,,,,,0,"ltr",,"L"
6811,,,"wab",,"Wab",,,,,,0,"ltr",,"L"
6812,,,"wac",,"Wasco-Wishram",,,,,,0,"ltr",,"L"
6813,,,"wad",,"Wandamen",,,,,,0,"ltr",,"L"
6814,,,"wae",,"Walser",,,,,,0,"ltr",,"L"
6815,,,"waf",,"Wakoná",,,,,,0,"ltr",,"E"
6816,,,"wag",,"Wa'ema",,,,,,0,"ltr",,"L"
6817,,,"wah",,"Watubela",,,,,,0,"ltr",,"L"
6818,,,"wai",,"Wares",,,,,,0,"ltr",,"L"
6819,,,"waj",,"Waffa",,,,,,0,"ltr",,"L"
6820,,"wal","wal",,"Walamo",,,,,,0,"ltr",,"L"
6821,,,"wam",,"Wampanoag",,,,,,0,"ltr",,"E"
6822,,,"wan",,"Wan",,,,,,0,"ltr",,"L"
6823,,,"wao",,"Wappo",,,,,,0,"ltr",,"E"
6824,,,"wap",,"Wapishana",,,,,,0,"ltr",,"L"
6825,,,"waq",,"Wageman",,,,,,0,"ltr",,"L"
6826,,"war","war",,"Waray","Philippines",,,,,0,"ltr",,"L"
6827,,"was","was",,"Washo",,,,,,0,"ltr",,"L"
6828,,,"wat",,"Kaninuwa",,,,,,0,"ltr",,"L"
6829,,,"wau",,"Waurá",,,,,,0,"ltr",,"L"
6830,,,"wav",,"Waka",,,,,,0,"ltr",,"L"
6831,,,"waw",,"Waiwai",,,,,,0,"ltr",,"L"
6832,,,"wax",,"Watam",,,,,,0,"ltr",,"L"
6833,,,"way",,"Wayana",,,,,,0,"ltr",,"L"
6834,,,"waz",,"Wampur",,,,,,0,"ltr",,"L"
6835,,,"wba",,"Warao",,,,,,0,"ltr",,"L"
6836,,,"wbb",,"Wabo",,,,,,0,"ltr",,"L"
6837,,,"wbe",,"Waritai",,,,,,0,"ltr",,"L"
6838,,,"wbf",,"Wara",,,,,,0,"ltr",,"L"
6839,,,"wbh",,"Wanda",,,,,,0,"ltr",,"L"
6840,,,"wbi",,"Wanji",,,,,,0,"ltr",,"L"
6841,,,"wbj",,"Alagwa",,,,,,0,"ltr",,"L"
6842,,,"wbk",,"Waigali",,,,,,0,"ltr",,"L"
6843,,,"wbl",,"Wakhi",,,,,,0,"ltr",,"L"
6844,,,"wbm",,"Wa",,,,,,0,"ltr",,"L"
6845,,,"wbp",,"Warlpiri",,,,,,0,"ltr",,"L"
6846,,,"wbq",,"Waddar",,,,,,0,"ltr",,"L"
6847,,,"wbr",,"Wagdi",,,,,,0,"ltr",,"L"
6848,,,"wbt",,"Wanman",,,,,,0,"ltr",,"L"
6849,,,"wbv",,"Wajarri",,,,,,0,"ltr",,"L"
6850,,,"wbw",,"Woi",,,,,,0,"ltr",,"L"
6851,,,"wca",,"Yanomámi",,,,,,0,"ltr",,"L"
6852,,,"wci",,"Gbe",,"Waci",,,,0,"ltr",,"L"
6853,,,"wdd",,"Wandji",,,,,,0,"ltr",,"L"
6854,,,"wdg",,"Wadaginam",,,,,,0,"ltr",,"L"
6855,,,"wdj",,"Wadjiginy",,,,,,0,"ltr",,"L"
6856,,,"wdu",,"Wadjigu",,,,,,0,"ltr",,"L"
6857,,,"wea",,"Wewaw",,,,,,0,"ltr",,"L"
6858,,,"wec",,"Wè Western",,,,,,0,"ltr",,"L"
6859,,,"wed",,"Wedau",,,,,,0,"ltr",,"L"
6860,,,"weh",,"Weh",,,,,,0,"ltr",,"L"
6861,,,"wei",,"Were",,,,,,0,"ltr",,"L"
6862,,,"wem",,"Gbe",,"Weme",,,,0,"ltr",,"L"
6863,,,"weo",,"Wemale",,"North",,,,0,"ltr",,"L"
6864,,,"wep",,"Westphalien",,,,,,0,"ltr",,"L"
6865,,,"wer",,"Weri",,,,,,0,"ltr",,"L"
6866,,,"wes",,"Pidgin",,"Cameroon",,,,0,"ltr",,"L"
6867,,,"wet",,"Perai",,,,,,0,"ltr",,"L"
6868,,,"weu",,"Welaung",,,,,,0,"ltr",,"L"
6869,,,"wew",,"Wejewa",,,,,,0,"ltr",,"L"
6870,,,"wfg",,"Yafi",,,,,,0,"ltr",,"L"
6871,,,"wga",,"Wagaya",,,,,,0,"ltr",,"L"
6872,,,"wgg",,"Wangganguru",,,,,,0,"ltr",,"L"
6873,,,"wgi",,"Wahgi",,,,,,0,"ltr",,"L"
6874,,,"wgo",,"Waigeo",,,,,,0,"ltr",,"L"
6875,,,"wgw",,"Wagawaga",,,,,,0,"ltr",,"L"
6876,,,"wgy",,"Warrgamay",,,,,,0,"ltr",,"L"
6877,,,"wha",,"Manusela",,,,,,0,"ltr",,"L"
6878,,,"whg",,"Wahgi",,"North",,,,0,"ltr",,"L"
6879,,,"whk",,"Kenyah",,"Wahau",,,,0,"ltr",,"L"
6880,,,"whu",,"Kayan",,"Wahau",,,,0,"ltr",,"L"
6881,,,"wib",,"Toussian",,"Southern",,,,0,"ltr",,"L"
6882,,,"wic",,"Wichita",,,,,,0,"ltr",,"L"
6883,,,"wie",,"Wik-Epa",,,,,,0,"ltr",,"L"
6884,,,"wif",,"Wik-Keyangan",,,,,,0,"ltr",,"L"
6885,,,"wig",,"Wik-Ngathana",,,,,,0,"ltr",,"L"
6886,,,"wih",,"Wik-Me'anha",,,,,,0,"ltr",,"L"
6887,,,"wii",,"Wiaki",,,,,,0,"ltr",,"L"
6888,,,"wij",,"Wik-Iiyanh",,,,,,0,"ltr",,"L"
6889,,,"wik",,"Wikalkan",,,,,,0,"ltr",,"L"
6890,,,"wil",,"Wilawila",,,,,,0,"ltr",,"L"
6891,,,"wim",,"Wik-Mungkan",,,,,,0,"ltr",,"L"
6892,,,"win",,"Ho-Chunk",,,,,,0,"ltr",,"L"
6893,,,"wir",,"Wiraféd",,,,,,0,"ltr",,"E"
6894,,,"wit",,"Wintu",,,,,,0,"ltr",,"L"
6895,,,"wiu",,"Wiru",,,,,,0,"ltr",,"L"
6896,,,"wiv",,"Muduapa",,,,,,0,"ltr",,"L"
6897,,,"wiw",,"Wirangu",,,,,,0,"ltr",,"L"
6898,,,"wiy",,"Wiyot",,,,,,0,"ltr",,"E"
6899,,,"wja",,"Waja",,,,,,0,"ltr",,"L"
6900,,,"wji",,"Warji",,,,,,0,"ltr",,"L"
6901,,,"wka",,"Kw'adza",,,,,,0,"ltr",,"E"
6902,,,"wkd",,"Wakde",,,,,,0,"ltr",,"L"
6903,,,"wkw",,"Wakawaka",,,,,,0,"ltr",,"L"
6904,,,"wla",,"Walio",,,,,,0,"ltr",,"L"
6905,,,"wlc",,"Comorian",,"Mwali",,,,0,"ltr",,"L"
6906,,,"wlg",,"Kunbarlang",,,,,,0,"ltr",,"L"
6907,,,"wli",,"Waioli",,,,,,0,"ltr",,"L"
6908,,,"wlk",,"Wailaki",,,,,,0,"ltr",,"E"
6909,,,"wll",,"Wali","Sudan",,,,,0,"ltr",,"L"
6910,,,"wlm",,"Welsh",,"Middle",,,,0,"ltr",,"H"
6911,"wa","wln","wln",,"Walloon",,,,,,0,"ltr",,"L"
6912,,,"wlo",,"Wolio",,,,,,0,"ltr",,"L"
6913,,,"wlr",,"Wailapa",,,,,,0,"ltr",,"L"
6914,,,"wls",,"Wallisian",,,,,,0,"ltr",,"L"
6915,,,"wlu",,"Wuliwuli",,,,,,0,"ltr",,"E"
6916,,,"wlv",,"Wichí Lhamtés Vejoz",,,,,,0,"ltr",,"L"
6917,,,"wlw",,"Walak",,,,,,0,"ltr",,"L"
6918,,,"wlx",,"Wali","Ghana",,,,,0,"ltr",,"L"
6919,,,"wly",,"Waling",,,,,,0,"ltr",,"E"
6920,,,"wma",,"Mawa","Nigeria",,,,,0,"ltr",,"E"
6921,,,"wmb",,"Wambaya",,,,,,0,"ltr",,"L"
6922,,,"wmc",,"Wamas",,,,,,0,"ltr",,"L"
6923,,,"wme",,"Wambule",,,,,,0,"ltr",,"L"
6924,,,"wmh",,"Waima'a",,,,,,0,"ltr",,"L"
6925,,,"wmi",,"Wamin",,,,,,0,"ltr",,"L"
6926,,,"wmm",,"Maiwa","Indonesia",,,,,0,"ltr",,"L"
6927,,,"wmn",,"Waamwang",,,,,,0,"ltr",,"E"
6928,,,"wmo",,"Wom","Papua New Guinea",,,,,0,"ltr",,"L"
6929,,,"wms",,"Wambon",,,,,,0,"ltr",,"L"
6930,,,"wmt",,"Walmajarri",,,,,,0,"ltr",,"L"
6931,,,"wmw",,"Mwani",,,,,,0,"ltr",,"L"
6932,,,"wnb",,"Wanambre",,,,,,0,"ltr",,"L"
6933,,,"wnc",,"Wantoat",,,,,,0,"ltr",,"L"
6934,,,"wnd",,"Wandarang",,,,,,0,"ltr",,"E"
6935,,,"wne",,"Waneci",,,,,,0,"ltr",,"L"
6936,,,"wng",,"Wanggom",,,,,,0,"ltr",,"L"
6937,,,"wni",,"Comorian",,"Ndzwani",,,,0,"ltr",,"L"
6938,,,"wnk",,"Wanukaka",,,,,,0,"ltr",,"L"
6939,,,"wnm",,"Wanggamala",,,,,,0,"ltr",,"L"
6940,,,"wno",,"Wano",,,,,,0,"ltr",,"L"
6941,,,"wnp",,"Wanap",,,,,,0,"ltr",,"L"
6942,,,"wnu",,"Usan",,,,,,0,"ltr",,"L"
6943,,,"woa",,"Tyaraity",,,,,,0,"ltr",,"L"
6944,,,"wob",,"Wè Northern",,,,,,0,"ltr",,"L"
6945,,,"woc",,"Wogeo",,,,,,0,"ltr",,"L"
6946,,,"wod",,"Wolani",,,,,,0,"ltr",,"L"
6947,,,"woe",,"Woleaian",,,,,,0,"ltr",,"L"
6948,,,"wof",,"Wolof",,"Gambian",,,,0,"ltr",,"L"
6949,,,"wog",,"Wogamusin",,,,,,0,"ltr",,"L"
6950,,,"woi",,"Kamang",,,,,,0,"ltr",,"L"
6951,,,"wok",,"Longto",,,,,,0,"ltr",,"L"
6952,"wo","wol","wol",,"Wolof",,,"Wolof",,,0,"ltr",,"L"
6953,,,"wom",,"Wom","Nigeria",,,,,0,"ltr",,"L"
6954,,,"won",,"Wongo",,,,,,0,"ltr",,"L"
6955,,,"woo",,"Manombai",,,,,,0,"ltr",,"L"
6956,,,"wor",,"Woria",,,,,,0,"ltr",,"L"
6957,,,"wos",,"Hanga Hundi",,,,,,0,"ltr",,"L"
6958,,,"wow",,"Wawonii",,,,,,0,"ltr",,"L"
6959,,,"woy",,"Weyto",,,,,,0,"ltr",,"E"
6960,,,"wpc",,"Maco",,,,,,0,"ltr",,"L"
6961,,,"wra",,"Warapu",,,,,,0,"ltr",,"L"
6962,,,"wrb",,"Warluwara",,,,,,0,"ltr",,"L"
6963,,,"wrd",,"Warduji",,,,,,0,"ltr",,"L"
6964,,,"wre",,"Ware",,,,,,0,"ltr",,"L"
6965,,,"wrg",,"Warungu",,,,,,0,"ltr",,"L"
6966,,,"wrh",,"Wiradhuri",,,,,,0,"ltr",,"L"
6967,,,"wri",,"Wariyangga",,,,,,0,"ltr",,"E"
6968,,,"wrl",,"Warlmanpa",,,,,,0,"ltr",,"L"
6969,,,"wrm",,"Warumungu",,,,,,0,"ltr",,"L"
6970,,,"wrn",,"Warnang",,,,,,0,"ltr",,"L"
6971,,,"wrp",,"Waropen",,,,,,0,"ltr",,"L"
6972,,,"wrr",,"Wardaman",,,,,,0,"ltr",,"L"
6973,,,"wrs",,"Waris",,,,,,0,"ltr",,"L"
6974,,,"wru",,"Waru",,,,,,0,"ltr",,"L"
6975,,,"wrv",,"Waruna",,,,,,0,"ltr",,"L"
6976,,,"wrw",,"Gugu Warra",,,,,,0,"ltr",,"E"
6977,,,"wrx",,"Wae Rana",,,,,,0,"ltr",,"L"
6978,,,"wry",,"Merwari",,,,,,0,"ltr",,"L"
6979,,,"wrz",,"Waray","Australia",,,,,0,"ltr",,"L"
6980,,,"wsa",,"Warembori",,,,,,0,"ltr",,"L"
6981,,,"wsi",,"Wusi",,,,,,0,"ltr",,"L"
6982,,,"wsk",,"Waskia",,,,,,0,"ltr",,"L"
6983,,,"wsr",,"Owenia",,,,,,0,"ltr",,"L"
6984,,,"wss",,"Wasa",,,,,,0,"ltr",,"L"
6985,,,"wsu",,"Wasu",,,,,,0,"ltr",,"E"
6986,,,"wsv",,"Wotapuri-Katarqalai",,,,,,0,"ltr",,"L"
6987,,,"wtf",,"Dumpu",,,,,,0,"ltr",,"L"
6988,,,"wti",,"Berta",,,,,,0,"ltr",,"L"
6989,,,"wtk",,"Watakataui",,,,,,0,"ltr",,"L"
6990,,,"wtm",,"Mewati",,,,,,0,"ltr",,"L"
6991,,,"wtw",,"Wotu",,,,,,0,"ltr",,"L"
6992,,,"wua",,"Wikngenchera",,,,,,0,"ltr",,"L"
6993,,,"wub",,"Wunambal",,,,,,0,"ltr",,"L"
6994,,,"wud",,"Wudu",,,,,,0,"ltr",,"L"
6995,,,"wuh",,"Wutunhua",,,,,,0,"ltr",,"L"
6996,,,"wul",,"Silimo",,,,,,0,"ltr",,"L"
6997,,,"wum",,"Wumbvu",,,,,,0,"ltr",,"L"
6998,,,"wun",,"Bungu",,,,,,0,"ltr",,"L"
6999,,,"wur",,"Wurrugu",,,,,,0,"ltr",,"E"
7000,,,"wut",,"Wutung",,,,,,0,"ltr",,"L"
7001,,,"wuu",,"Chinese",,"Wu",,,,0,"ltr",,"L"
7002,,,"wuv",,"Wuvulu-Aua",,,,,,0,"ltr",,"L"
7003,,,"wux",,"Wulna",,,,,,0,"ltr",,"L"
7004,,,"wuy",,"Wauyai",,,,,,0,"ltr",,"L"
7005,,,"wwa",,"Waama",,,,,,0,"ltr",,"L"
7006,,,"wwo",,"Wetamut",,,,,,0,"ltr",,"L"
7007,,,"wwr",,"Warrwa",,,,,,0,"ltr",,"L"
7008,,,"www",,"Wawa",,,,,,0,"ltr",,"L"
7009,,,"wxa",,"Waxianghua",,,,,,0,"ltr",,"L"
7010,,,"wya",,"Wyandot",,,,,,0,"ltr",,"E"
7011,,,"wyb",,"Wangaaybuwan-Ngiyambaa",,,,,,0,"ltr",,"L"
7012,,,"wyr",,"Wayoró",,,,,,0,"ltr",,"L"
7013,,,"wyy",,"Fijian",,"Western",,,,0,"ltr",,"L"
7014,,,"xac",,"Kachari",,,,,,0,"ltr",,"L"
7015,,,"xad",,"Adai",,,,,,0,"ltr",,"E"
7016,,,"xae",,"Aequian",,,,,,0,"ltr",,"A"
7017,,,"xag",,"Aghwan",,,,,,0,"ltr",,"E"
7018,,,"xah",,"Kahayan",,,,,,0,"ltr",,"L"
7019,,,"xai",,"Kaimbé",,,,,,0,"ltr",,"E"
7020,,"xal","xal",,"Kalmyk; Oirat",,,,,,0,"ltr",,"L"
7021,,,"xam",,"/Xam",,,,,,0,"ltr",,"E"
7022,,,"xan",,"Xamtanga",,,,,,0,"ltr",,"L"
7023,,,"xao",,"Khao",,,,,,0,"ltr",,"L"
7024,,,"xap",,"Apalachee",,,,,,0,"ltr",,"E"
7025,,,"xaq",,"Aquitanian",,,,,,0,"ltr",,"A"
7026,,,"xar",,"Karami",,,,,,0,"ltr",,"E"
7027,,,"xas",,"Kamas",,,,,,0,"ltr",,"E"
7028,,,"xat",,"Katawixi",,,,,,0,"ltr",,"L"
7029,,,"xau",,"Kauwera",,,,,,0,"ltr",,"L"
7030,,,"xav",,"Xavánte",,,,,,0,"ltr",,"L"
7031,,,"xaw",,"Kawaiisu",,,,,,0,"ltr",,"L"
7032,,,"xay",,"Kayan Mahakam",,,,,,0,"ltr",,"L"
7033,,,"xba",,"Kamba","Brazil",,,,,0,"ltr",,"E"
7034,,,"xbc",,"Bactrian",,,,,,0,"ltr",,"A"
7035,,,"xbi",,"Kombio",,,,,,0,"ltr",,"L"
7036,,,"xbm",,"Breton",,"Middle",,,,0,"ltr",,"H"
7037,,,"xbo",,"Bolgarian",,,,,,0,"ltr",,"E"
7038,,,"xbr",,"Kambera",,,,,,0,"ltr",,"L"
7039,,,"xbw",,"Kambiwá",,,,,,0,"ltr",,"E"
7040,,,"xbx",,"Kabixí",,,,,,0,"ltr",,"L"
7041,,,"xcb",,"Cumbric",,,,,,0,"ltr",,"E"
7042,,,"xcc",,"Camunic",,,,,,0,"ltr",,"A"
7043,,,"xce",,"Celtiberian",,,,,,0,"ltr",,"A"
7044,,,"xcg",,"Gaulish",,"Cisalpine",,,,0,"ltr",,"A"
7045,,,"xch",,"Chemakum",,,,,,0,"ltr",,"E"
7046,,,"xcl",,"Armenian",,"Classical",,,,0,"ltr",,"H"
7047,,,"xcm",,"Comecrudo",,,,,,0,"ltr",,"E"
7048,,,"xcn",,"Cotoname",,,,,,0,"ltr",,"E"
7049,,,"xco",,"Chorasmian",,,,,,0,"ltr",,"A"
7050,,,"xcr",,"Carian",,,,,,0,"ltr",,"A"
7051,,,"xct",,"Tibetan",,"Classical",,,,0,"ltr",,"H"
7052,,,"xcu",,"Curonian",,,,,,0,"ltr",,"E"
7053,,,"xcv",,"Chuvantsy",,,,,,0,"ltr",,"E"
7054,,,"xcw",,"Coahuilteco",,,,,,0,"ltr",,"E"
7055,,,"xcy",,"Cayuse",,,,,,0,"ltr",,"E"
7056,,,"xdc",,"Dacian",,,,,,0,"ltr",,"A"
7057,,,"xdm",,"Edomite",,,,,,0,"ltr",,"A"
7058,,,"xdy",,"Malayic Dayak",,,,,,0,"ltr",,"L"
7059,,,"xeb",,"Eblan",,,,,,0,"ltr",,"A"
7060,,,"xed",,"Hdi",,,,,,0,"ltr",,"L"
7061,,,"xeg",,"//Xegwi",,,,,,0,"ltr",,"E"
7062,,,"xel",,"Kelo",,,,,,0,"ltr",,"L"
7063,,,"xem",,"Kembayan",,,,,,0,"ltr",,"L"
7064,,,"xep",,"Epi-Olmec",,,,,,0,"ltr",,"A"
7065,,,"xer",,"Xerénte",,,,,,0,"ltr",,"L"
7066,,,"xes",,"Kesawai",,,,,,0,"ltr",,"L"
7067,,,"xet",,"Xetá",,,,,,0,"ltr",,"L"
7068,,,"xeu",,"Keuru",,,,,,0,"ltr",,"L"
7069,,,"xfa",,"Faliscan",,,,,,0,"ltr",,"A"
7070,,,"xga",,"Galatian",,,,,,0,"ltr",,"A"
7071,,,"xgf",,"Gabrielino-Fernandeño",,,,,,0,"ltr",,"E"
7072,,,"xgl",,"Galindan",,,,,,0,"ltr",,"E"
7073,,,"xgr",,"Garza",,,,,,0,"ltr",,"E"
7074,,,"xha",,"Harami",,,,,,0,"ltr",,"A"
7075,,,"xhc",,"Hunnic",,,,,,0,"ltr",,"E"
7076,,,"xhd",,"Hadrami",,,,,,0,"ltr",,"A"
7077,,,"xhe",,"Khetrani",,,,,,0,"ltr",,"L"
7078,"xh","xho","xho",,"Xhosa",,,,,,0,"ltr",,"L"
7079,,,"xhr",,"Hernican",,,,,,0,"ltr",,"A"
7080,,,"xht",,"Hattic",,,,,,0,"ltr",,"A"
7081,,,"xhu",,"Hurrian",,,,,,0,"ltr",,"A"
7082,,,"xhv",,"Khua",,,,,,0,"ltr",,"L"
7083,,,"xia",,"Xiandao",,,,,,0,"ltr",,"L"
7084,,,"xib",,"Iberian",,,,,,0,"ltr",,"A"
7085,,,"xii",,"Xiri",,,,,,0,"ltr",,"L"
7086,,,"xil",,"Illyrian",,,,,,0,"ltr",,"A"
7087,,,"xin",,"Xinca",,,,,,0,"ltr",,"E"
7088,,,"xip",,"Xipináwa",,,,,,0,"ltr",,"E"
7089,,,"xir",,"Xiriâna",,,,,,0,"ltr",,"L"
7090,,,"xiv",,"Indus Valley Language",,,,,,0,"ltr",,"A"
7091,,,"xiy",,"Xipaya",,,,,,0,"ltr",,"L"
7092,,,"xka",,"Kalkoti",,,,,,0,"ltr",,"L"
7093,,,"xkb",,"Ede Nago",,"Manigri-Kambolé",,,,0,"ltr",,"L"
7094,,,"xkc",,"Kho'ini",,,,,,0,"ltr",,"L"
7095,,,"xkd",,"Kayan",,"Mendalam",,,,0,"ltr",,"L"
7096,,,"xke",,"Kereho-Uheng",,,,,,0,"ltr",,"L"
7097,,,"xkf",,"Khengkha",,,,,,0,"ltr",,"L"
7098,,,"xkg",,"Kagoro",,,,,,0,"ltr",,"L"
7099,,,"xkh",,"Karahawyana",,,,,,0,"ltr",,"L"
7100,,,"xki",,"Kenyan Sign Language",,,,,,0,"ltr",,"L"
7101,,,"xkj",,"Kajali",,,,,,0,"ltr",,"L"
7102,,,"xkk",,"Kaco'",,,,,,0,"ltr",,"L"
7103,,,"xkl",,"Kenyah",,"Kelinyau",,,,0,"ltr",,"L"
7104,,,"xkm",,"Kenyah",,"Mahakam",,,,0,"ltr",,"L"
7105,,,"xkn",,"Kayan",,"Kayan River",,,,0,"ltr",,"L"
7106,,,"xko",,"Kiorr",,,,,,0,"ltr",,"L"
7107,,,"xkp",,"Kabatei",,,,,,0,"ltr",,"L"
7108,,,"xkq",,"Koroni",,,,,,0,"ltr",,"L"
7109,,,"xkr",,"Xakriabá",,,,,,0,"ltr",,"E"
7110,,,"xks",,"Kumbewaha",,,,,,0,"ltr",,"L"
7111,,,"xkt",,"Kantosi",,,,,,0,"ltr",,"L"
7112,,,"xku",,"Kaamba",,,,,,0,"ltr",,"L"
7113,,,"xkv",,"Kgalagadi",,,,,,0,"ltr",,"L"
7114,,,"xkw",,"Kembra",,,,,,0,"ltr",,"L"
7115,,,"xkx",,"Karore",,,,,,0,"ltr",,"L"
7116,,,"xky",,"Kenyah",,"Western",,,,0,"ltr",,"L"
7117,,,"xkz",,"Kurtokha",,,,,,0,"ltr",,"L"
7118,,,"xla",,"Kamula",,,,,,0,"ltr",,"L"
7119,,,"xlb",,"Loup B",,,,,,0,"ltr",,"E"
7120,,,"xlc",,"Lycian",,,,,,0,"ltr",,"A"
7121,,,"xld",,"Lydian",,,,,,0,"ltr",,"A"
7122,,,"xle",,"Lemnian",,,,,,0,"ltr",,"A"
7123,,,"xlg",,"Ligurian","Ancient",,,,,0,"ltr",,"A"
7124,,,"xli",,"Liburnian",,,,,,0,"ltr",,"A"
7125,,,"xln",,"Alanic",,,,,,0,"ltr",,"A"
7126,,,"xlo",,"Loup A",,,,,,0,"ltr",,"E"
7127,,,"xlp",,"Lepontic",,,,,,0,"ltr",,"A"
7128,,,"xls",,"Lusitanian",,,,,,0,"ltr",,"A"
7129,,,"xlu",,"Luwian",,"Cuneiform",,,,0,"ltr",,"A"
7130,,,"xly",,"Elymian",,,,,,0,"ltr",,"A"
7131,,,"xma",,"Mushungulu",,,,,,0,"ltr",,"L"
7132,,,"xmb",,"Mbonga",,,,,,0,"ltr",,"L"
7133,,,"xmc",,"Makhuwa-Marrevone",,,,,,0,"ltr",,"L"
7134,,,"xmd",,"Mbedam",,,,,,0,"ltr",,"L"
7135,,,"xme",,"Median",,,,,,0,"ltr",,"A"
7136,,,"xmf",,"Mingrelian",,,,,,0,"ltr",,"L"
7137,,,"xmg",,"Mengaka",,,,,,0,"ltr",,"L"
7138,,,"xmh",,"Kuku-Muminh",,,,,,0,"ltr",,"L"
7139,,,"xmi",,"Miarrã",,,,,,0,"ltr",,"L"
7140,,,"xmj",,"Majera",,,,,,0,"ltr",,"L"
7141,,,"xmk",,"Macedonian",,"Ancient",,,,0,"ltr",,"A"
7142,,,"xml",,"Malaysian Sign Language",,,,,,0,"ltr",,"L"
7143,,,"xmm",,"Malay",,"Manado",,,,0,"ltr",,"L"
7144,,,"xmo",,"Morerebi",,,,,,0,"ltr",,"L"
7145,,,"xmp",,"Kuku-Mu'inh",,,,,,0,"ltr",,"L"
7146,,,"xmq",,"Kuku-Mangk",,,,,,0,"ltr",,"L"
7147,,,"xmr",,"Meroitic",,,,,,0,"ltr",,"A"
7148,,,"xms",,"Moroccan Sign Language",,,,,,0,"ltr",,"L"
7149,,,"xmt",,"Matbat",,,,,,0,"ltr",,"L"
7150,,,"xmu",,"Kamu",,,,,,0,"ltr",,"L"
7151,,,"xmv",,"Malagasy",,"Antankarana",,,,0,"ltr",,"L"
7152,,,"xmw",,"Malagasy",,"Tsimihety",,,,0,"ltr",,"L"
7153,,,"xmx",,"Maden",,,,,,0,"ltr",,"L"
7154,,,"xmy",,"Mayaguduna",,,,,,0,"ltr",,"L"
7155,,,"xmz",,"Mori Bawah",,,,,,0,"ltr",,"L"
7156,,,"xna",,"North Arabian",,"Ancient",,,,0,"ltr",,"A"
7157,,,"xnb",,"Kanakanabu",,,,,,0,"ltr",,"L"
7158,,,"xng",,"Mongolian",,"Middle",,,,0,"ltr",,"H"
7159,,,"xnh",,"Kuanhua",,,,,,0,"ltr",,"L"
7160,,,"xnn",,"Kankanay",,"Northern",,,,0,"ltr",,"L"
7161,,,"xno",,"Anglo-Norman",,,,,,0,"ltr",,"H"
7162,,,"xnr",,"Kangri",,,,,,0,"ltr",,"L"
7163,,,"xns",,"Kanashi",,,,,,0,"ltr",,"L"
7164,,,"xod",,"Kokoda",,,,,,0,"ltr",,"L"
7165,,,"xog",,"Soga",,,,,,0,"ltr",,"L"
7166,,,"xoi",,"Kominimung",,,,,,0,"ltr",,"L"
7167,,,"xok",,"Xokleng",,,,,,0,"ltr",,"L"
7168,,,"xom",,"Komo","Sudan",,,,,0,"ltr",,"L"
7169,,,"xon",,"Konkomba",,,,,,0,"ltr",,"L"
7170,,,"xoo",,"Xukurú",,,,,,0,"ltr",,"E"
7171,,,"xop",,"Kopar",,,,,,0,"ltr",,"L"
7172,,,"xor",,"Korubo",,,,,,0,"ltr",,"L"
7173,,,"xow",,"Kowaki",,,,,,0,"ltr",,"L"
7174,,,"xpc",,"Pecheneg",,,,,,0,"ltr",,"E"
7175,,,"xpe",,"Kpelle",,"Liberia",,,,0,"ltr",,"L"
7176,,,"xpg",,"Phrygian",,,,,,0,"ltr",,"A"
7177,,,"xpi",,"Pictish",,,,,,0,"ltr",,"E"
7178,,,"xpm",,"Pumpokol",,,,,,0,"ltr",,"E"
7179,,,"xpn",,"Kapinawá",,,,,,0,"ltr",,"E"
7180,,,"xpo",,"Pochutec",,,,,,0,"ltr",,"E"
7181,,,"xpp",,"Puyo-Paekche",,,,,,0,"ltr",,"E"
7182,,,"xpr",,"Parthian",,,,,,0,"ltr",,"A"
7183,,,"xps",,"Pisidian",,,,,,0,"ltr",,"E"
7184,,,"xpu",,"Punic",,,,,,0,"ltr",,"A"
7185,,,"xpy",,"Puyo",,,,,,0,"ltr",,"E"
7186,,,"xqt",,"Qatabanian",,,,,,0,"ltr",,"A"
7187,,,"xra",,"Krahô",,,,,,0,"ltr",,"L"
7188,,,"xrb",,"Karaboro",,"Eastern",,,,0,"ltr",,"L"
7189,,,"xre",,"Kreye",,,,,,0,"ltr",,"L"
7190,,,"xri",,"Krikati-Timbira",,,,,,0,"ltr",,"L"
7191,,,"xrm",,"Armazic",,,,,,0,"ltr",,"E"
7192,,,"xrn",,"Arin",,,,,,0,"ltr",,"E"
7193,,,"xrr",,"Raetic",,,,,,0,"ltr",,"A"
7194,,,"xrt",,"Aranama-Tamique",,,,,,0,"ltr",,"E"
7195,,,"xrw",,"Karawa",,,,,,0,"ltr",,"L"
7196,,,"xsa",,"Sabaean",,,,,,0,"ltr",,"A"
7197,,,"xsb",,"Sambal",,"Tinà",,,,0,"ltr",,"L"
7198,,,"xsc",,"Scythian",,,,,,0,"ltr",,"A"
7199,,,"xsd",,"Sidetic",,,,,,0,"ltr",,"A"
7200,,,"xse",,"Sempan",,,,,,0,"ltr",,"L"
7201,,,"xsh",,"Shamang",,,,,,0,"ltr",,"L"
7202,,,"xsi",,"Sio",,,,,,0,"ltr",,"L"
7203,,,"xsj",,"Subi",,,,,,0,"ltr",,"L"
7204,,,"xsk",,"Sakan",,,,,,0,"ltr",,"A"
7205,,,"xsl",,"Slavey",,"South",,,,0,"ltr",,"L"
7206,,,"xsm",,"Kasem",,,,,,0,"ltr",,"L"
7207,,,"xsn",,"Sanga","Nigeria",,,,,0,"ltr",,"L"
7208,,,"xso",,"Solano",,,,,,0,"ltr",,"E"
7209,,,"xsp",,"Silopi",,,,,,0,"ltr",,"L"
7210,,,"xsq",,"Makhuwa-Saka",,,,,,0,"ltr",,"L"
7211,,,"xsr",,"Sherpa",,,,,,0,"ltr",,"L"
7212,,,"xss",,"Assan",,,,,,0,"ltr",,"E"
7213,,,"xst",,"Silt'e",,,,,,0,"ltr",,"L"
7214,,,"xsu",,"Sanumá",,,,,,0,"ltr",,"L"
7215,,,"xsv",,"Sudovian",,,,,,0,"ltr",,"E"
7216,,,"xsy",,"Saisiyat",,,,,,0,"ltr",,"L"
7217,,,"xta",,"Mixtec",,"Alcozauca",,,,0,"ltr",,"L"
7218,,,"xtb",,"Mixtec",,"Chazumba",,,,0,"ltr",,"L"
7219,,,"xtc",,"Katcha-Kadugli-Miri",,,,,,0,"ltr",,"L"
7220,,,"xtd",,"Mixtec",,"Diuxi-Tilantongo",,,,0,"ltr",,"L"
7221,,,"xte",,"Ketengban",,,,,,0,"ltr",,"L"
7222,,,"xtg",,"Gaulish",,"Transalpine",,,,0,"ltr",,"A"
7223,,,"xti",,"Mixtec",,"Sinicahua",,,,0,"ltr",,"L"
7224,,,"xtj",,"Mixtec",,"San Juan Teita",,,,0,"ltr",,"L"
7225,,,"xtl",,"Mixtec",,"Tijaltepec",,,,0,"ltr",,"L"
7226,,,"xtm",,"Mixtec",,"Magdalena Peñasco",,,,0,"ltr",,"L"
7227,,,"xtn",,"Mixtec",,"Northern Tlaxiaco",,,,0,"ltr",,"L"
7228,,,"xto",,"Tokharian A",,,,,,0,"ltr",,"A"
7229,,,"xtp",,"Mixtec",,"San Miguel Piedras",,,,0,"ltr",,"L"
7230,,,"xtr",,"Tripuri",,"Early",,,,0,"ltr",,"A"
7231,,,"xts",,"Mixtec",,"Sindihui",,,,0,"ltr",,"L"
7232,,,"xtt",,"Mixtec",,"Tacahua",,,,0,"ltr",,"L"
7233,,,"xtu",,"Mixtec",,"Cuyamecalco",,,,0,"ltr",,"L"
7234,,,"xty",,"Mixtec",,"Yoloxochitl",,,,0,"ltr",,"L"
7235,,,"xtz",,"Tasmanian",,,,,,0,"ltr",,"E"
7236,,,"xua",,"Kurumba",,"Alu",,,,0,"ltr",,"L"
7237,,,"xub",,"Kurumba",,"Betta",,,,0,"ltr",,"L"
7238,,,"xuf",,"Kunfal",,,,,,0,"ltr",,"L"
7239,,,"xug",,"Kunigami",,,,,,0,"ltr",,"L"
7240,,,"xuj",,"Kurumba",,"Jennu",,,,0,"ltr",,"L"
7241,,,"xum",,"Umbrian",,,,,,0,"ltr",,"A"
7242,,,"xuo",,"Kuo",,,,,,0,"ltr",,"L"
7243,,,"xup",,"Umpqua",,"Upper",,,,0,"ltr",,"E"
7244,,,"xur",,"Urartian",,,,,,0,"ltr",,"A"
7245,,,"xut",,"Kuthant",,,,,,0,"ltr",,"L"
7246,,,"xuu",,"Kxoe",,,,,,0,"ltr",,"L"
7247,,,"xve",,"Venetic",,,,,,0,"ltr",,"A"
7248,,,"xvi",,"Kamviri",,,,,,0,"ltr",,"L"
7249,,,"xvn",,"Vandalic",,,,,,0,"ltr",,"A"
7250,,,"xvo",,"Volscian",,,,,,0,"ltr",,"A"
7251,,,"xvs",,"Vestinian",,,,,,0,"ltr",,"A"
7252,,,"xwc",,"Woccon",,,,,,0,"ltr",,"E"
7253,,,"xwe",,"Gbe",,"Xwela",,,,0,"ltr",,"L"
7254,,,"xwg",,"Kwegu",,,,,,0,"ltr",,"L"
7255,,,"xwl",,"Gbe",,"Western Xwla",,,,0,"ltr",,"L"
7256,,,"xwo",,"Oirat",,"Written",,,,0,"ltr",,"E"
7257,,,"xwr",,"Kwerba Mamberamo",,,,,,0,"ltr",,"L"
7258,,,"xxk",,"Ke'o",,,,,,0,"ltr",,"L"
7259,,,"xzh",,"Zhang-Zhung",,,,,,0,"ltr",,"A"
7260,,,"xzm",,"Zemgalian",,,,,,0,"ltr",,"E"
7261,,,"yaa",,"Yaminahua",,,,,,0,"ltr",,"L"
7262,,,"yab",,"Yuhup",,,,,,0,"ltr",,"L"
7263,,,"yac",,"Yali",,"Pass Valley",,,,0,"ltr",,"L"
7264,,,"yad",,"Yagua",,,,,,0,"ltr",,"L"
7265,,,"yae",,"Pumé",,,,,,0,"ltr",,"L"
7266,,,"yaf",,"Yaka","Democratic Republic of Congo",,,,,0,"ltr",,"L"
7267,,,"yag",,"Yámana",,,,,,0,"ltr",,"L"
7268,,,"yah",,"Yazgulyam",,,,,,0,"ltr",,"L"
7269,,,"yai",,"Yagnobi",,,,,,0,"ltr",,"L"
7270,,,"yaj",,"Banda-Yangere",,,,,,0,"ltr",,"L"
7271,,,"yak",,"Yakima",,,,,,0,"ltr",,"L"
7272,,,"yal",,"Yalunka",,,,,,0,"ltr",,"L"
7273,,,"yam",,"Yamba",,,,,,0,"ltr",,"L"
7274,,"yao","yao",,"Yao",,,,,,0,"ltr",,"L"
7275,,"yap","yap",,"Yapese",,,,,,0,"ltr",,"L"
7276,,,"yaq",,"Yaqui",,,,,,0,"ltr",,"L"
7277,,,"yar",,"Yabarana",,,,,,0,"ltr",,"L"
7278,,,"yas",,"Nugunu","Cameroon",,,,,0,"ltr",,"L"
7279,,,"yat",,"Yambeta",,,,,,0,"ltr",,"L"
7280,,,"yau",,"Yuwana",,,,,,0,"ltr",,"L"
7281,,,"yav",,"Yangben",,,,,,0,"ltr",,"L"
7282,,,"yaw",,"Yawalapití",,,,,,0,"ltr",,"E"
7283,,,"yax",,"Yauma",,,,,,0,"ltr",,"L"
7284,,,"yay",,"Agwagwune",,,,,,0,"ltr",,"L"
7285,,,"yaz",,"Lokaa",,,,,,0,"ltr",,"L"
7286,,,"yba",,"Yala",,,,,,0,"ltr",,"L"
7287,,,"ybb",,"Yemba",,,,,,0,"ltr",,"L"
7288,,,"ybd",,"Yangbye",,,,,,0,"ltr",,"L"
7289,,,"ybe",,"Yugur",,"West",,,,0,"ltr",,"L"
7290,,,"ybh",,"Yakha",,,,,,0,"ltr",,"L"
7291,,,"ybi",,"Yamphu",,,,,,0,"ltr",,"L"
7292,,,"ybj",,"Hasha",,,,,,0,"ltr",,"L"
7293,,,"ybl",,"Yukuben",,,,,,0,"ltr",,"L"
7294,,,"ybm",,"Yaben",,,,,,0,"ltr",,"L"
7295,,,"ybn",,"Yabaâna",,,,,,0,"ltr",,"E"
7296,,,"ybo",,"Yabong",,,,,,0,"ltr",,"L"
7297,,,"ybx",,"Yawiyo",,,,,,0,"ltr",,"L"
7298,,,"yby",,"Yaweyuha",,,,,,0,"ltr",,"L"
7299,,,"ycl",,"Yi",,"Central",,,,0,"ltr",,"L"
7300,,,"ycn",,"Yucuna",,,,,,0,"ltr",,"L"
7301,,,"ydd",,"Yiddish",,"Eastern",,,,0,"ltr",,"L"
7302,,,"ydg",,"Yidgha",,,,,,0,"ltr",,"L"
7303,,,"ydk",,"Yoidik",,,,,,0,"ltr",,"L"
7304,,,"yds",,"Yiddish Sign Language",,,,,,0,"ltr",,"L"
7305,,,"yea",,"Ravula",,,,,,0,"ltr",,"L"
7306,,,"yec",,"Yeniche",,,,,,0,"ltr",,"L"
7307,,,"yee",,"Yimas",,,,,,0,"ltr",,"L"
7308,,,"yei",,"Yeni",,,,,,0,"ltr",,"E"
7309,,,"yej",,"Yevanic",,,,,,0,"ltr",,"L"
7310,,,"yel",,"Yela",,,,,,0,"ltr",,"L"
7311,,,"yen",,"Yendang",,,,,,0,"ltr",,"L"
7312,,,"yer",,"Tarok",,,,,,0,"ltr",,"L"
7313,,,"yes",,"Yeskwa",,,,,,0,"ltr",,"L"
7314,,,"yet",,"Yetfa",,,,,,0,"ltr",,"L"
7315,,,"yeu",,"Yerukula",,,,,,0,"ltr",,"L"
7316,,,"yev",,"Yapunda",,,,,,0,"ltr",,"L"
7317,,,"yey",,"Yeyi",,,,,,0,"ltr",,"L"
7318,,,"ygm",,"Yagomi",,,,,,0,"ltr",,"L"
7319,,,"ygr",,"Yagaria",,,,,,0,"ltr",,"L"
7320,,,"ygw",,"Yagwoia",,,,,,0,"ltr",,"L"
7321,,,"yhd",,"Arabic",,"Judeo-Iraqi",,,,0,"rtl",,"L"
7322,,,"yia",,"Yinggarda",,,,,,0,"ltr",,"L"
7323,,,"yib",,"Yinglish",,,,,,0,"ltr",,"L"
7324,"yi","yid","yid",,"Yiddish",,,,,,1,"ltr",,"L"
7325,,,"yif",,"Yi",,"Ache",,,,0,"ltr",,"L"
7326,,,"yig",,"Yi",,"Guizhou",,,,0,"ltr",,"L"
7327,,,"yih",,"Yiddish",,"Western",,,,0,"ltr",,"L"
7328,,,"yii",,"Yidiny",,,,,,0,"ltr",,"L"
7329,,,"yij",,"Yindjibarndi",,,,,,0,"ltr",,"L"
7330,,,"yik",,"Yi",,"Xishan Lalu",,,,0,"ltr",,"L"
7331,,,"yil",,"Yindjilandji",,,,,,0,"ltr",,"L"
7332,,,"yim",,"Naga",,"Yimchungru",,,,0,"ltr",,"L"
7333,,,"yin",,"Yinchia",,,,,,0,"ltr",,"L"
7334,,,"yio",,"Yi",,"Dayao",,,,0,"ltr",,"L"
7335,,,"yip",,"Yi",,"Poluo",,,,0,"ltr",,"L"
7336,,,"yiq",,"Yi",,"Miqie",,,,0,"ltr",,"L"
7337,,,"yir",,"Awyu",,"North",,,,0,"ltr",,"L"
7338,,,"yis",,"Yis",,,,,,0,"ltr",,"L"
7339,,,"yit",,"Yi",,"Eastern Lalu",,,,0,"ltr",,"L"
7340,,,"yiu",,"Yi",,"Awu",,,,0,"ltr",,"L"
7341,,,"yiv",,"Yi",,"Eshan-Xinping",,,,0,"ltr",,"L"
7342,,,"yix",,"Yi",,"Axi",,,,0,"ltr",,"L"
7343,,,"yiy",,"Yir Yoront",,,,,,0,"ltr",,"L"
7344,,,"yiz",,"Yi",,"Azhe",,,,0,"ltr",,"L"
7345,,,"yka",,"Yakan",,,,,,0,"ltr",,"L"
7346,,,"ykg",,"Yukaghir",,"Northern",,,,0,"ltr",,"L"
7347,,,"yki",,"Yoke",,,,,,0,"ltr",,"L"
7348,,,"ykk",,"Yakaikeke",,,,,,0,"ltr",,"L"
7349,,,"ykm",,"Yakamul",,,,,,0,"ltr",,"L"
7350,,,"yko",,"Yasa",,,,,,0,"ltr",,"L"
7351,,,"ykr",,"Yekora",,,,,,0,"ltr",,"L"
7352,,,"yky",,"Yakoma",,,,,,0,"ltr",,"L"
7353,,,"yla",,"Yaul",,,,,,0,"ltr",,"L"
7354,,,"yle",,"Yele",,,,,,0,"ltr",,"L"
7355,,,"ylg",,"Yelogu",,,,,,0,"ltr",,"L"
7356,,,"yli",,"Yali",,"Angguruk",,,,0,"ltr",,"L"
7357,,,"yll",,"Yil",,,,,,0,"ltr",,"L"
7358,,,"ylm",,"Yi",,"Limi",,,,0,"ltr",,"L"
7359,,,"ylo",,"Yi",,"Naluo",,,,0,"ltr",,"L"
7360,,,"ylr",,"Yalarnnga",,,,,,0,"ltr",,"E"
7361,,,"ylu",,"Aribwaung",,,,,,0,"ltr",,"L"
7362,,,"yly",,"Nyâlayu",,,,,,0,"ltr",,"L"
7363,,,"yma",,"Yamphe",,,,,,0,"ltr",,"L"
7364,,,"ymb",,"Yambes",,,,,,0,"ltr",,"L"
7365,,,"yme",,"Yameo",,,,,,0,"ltr",,"E"
7366,,,"ymg",,"Yamongeri",,,,,,0,"ltr",,"L"
7367,,,"ymh",,"Yi",,"Mili",,,,0,"ltr",,"L"
7368,,,"ymj",,"Yi",,"Muji",,,,0,"ltr",,"L"
7369,,,"ymk",,"Makwe",,,,,,0,"ltr",,"L"
7370,,,"yml",,"Iamalele",,,,,,0,"ltr",,"L"
7371,,,"ymm",,"Maay",,,,,,0,"ltr",,"L"
7372,,,"ymn",,"Yamna",,,,,,0,"ltr",,"L"
7373,,,"ymp",,"Yamap",,,,,,0,"ltr",,"L"
7374,,,"yms",,"Mysian",,,,,,0,"ltr",,"A"
7375,,,"ymt",,"Mator-Taygi-Karagas",,,,,,0,"ltr",,"E"
7376,,,"ynd",,"Yandruwandha",,,,,,0,"ltr",,"L"
7377,,,"yng",,"Yango",,,,,,0,"ltr",,"L"
7378,,,"ynh",,"Yangho",,,,,,0,"ltr",,"L"
7379,,,"ynk",,"Yupik",,"Naukan",,,,0,"ltr",,"L"
7380,,,"ynl",,"Yangulam",,,,,,0,"ltr",,"L"
7381,,,"ynn",,"Yana",,,,,,0,"ltr",,"E"
7382,,,"yno",,"Yong",,,,,,0,"ltr",,"L"
7383,,,"yns",,"Yansi",,,,,,0,"ltr",,"L"
7384,,,"ynu",,"Yahuna",,,,,,0,"ltr",,"E"
7385,,,"yob",,"Yoba",,,,,,0,"ltr",,"E"
7386,,,"yog",,"Yogad",,,,,,0,"ltr",,"L"
7387,,,"yoi",,"Yonaguni",,,,,,0,"ltr",,"L"
7388,,,"yok",,"Yokuts",,,,,,0,"ltr",,"L"
7389,,,"yom",,"Yombe",,,,,,0,"ltr",,"L"
7390,,,"yon",,"Yonggom",,,,,,0,"ltr",,"L"
7391,,"yor","yor",,"Yoruba",,,,,,0,"ltr",,"L"
7392,,,"yos",,"Yos",,,,,,0,"ltr",,"L"
7393,,,"yox",,"Yoron",,,,,,0,"ltr",,"L"
7394,,,"yoy",,"Yoy",,,,,,0,"ltr",,"L"
7395,,,"ypl",,"Yi",,"Pula",,,,0,"ltr",,"L"
7396,,,"ypw",,"Yi",,"Puwa",,,,0,"ltr",,"L"
7397,,,"yra",,"Yerakai",,,,,,0,"ltr",,"L"
7398,,,"yrb",,"Yareba",,,,,,0,"ltr",,"L"
7399,,,"yre",,"Yaouré",,,,,,0,"ltr",,"L"
7400,,,"yri",,"Yarí",,,,,,0,"ltr",,"L"
7401,,,"yrk",,"Nenets",,,,,,0,"ltr",,"L"
7402,,,"yrl",,"Nhengatu",,,,,,0,"ltr",,"L"
7403,,,"yrn",,"Yerong",,,,,,0,"ltr",,"L"
7404,,,"yrs",,"Yarsun",,,,,,0,"ltr",,"L"
7405,,,"yrw",,"Yarawata",,,,,,0,"ltr",,"L"
7406,,,"ysc",,"Yassic",,,,,,0,"ltr",,"E"
7407,,,"ysl",,"Yugoslavian Sign Language",,,,,,0,"ltr",,"L"
7408,,,"ysn",,"Yi",,"Sani",,,,0,"ltr",,"L"
7409,,,"yso",,"Yi",,"Southeastern Lolo",,,,0,"ltr",,"L"
7410,,,"ysp",,"Yi",,"Southern Lolopho",,,,0,"ltr",,"L"
7411,,,"ysr",,"Yupik",,"Sirenik",,,,0,"ltr",,"E"
7412,,,"yss",,"Yessan-Mayo",,,,,,0,"ltr",,"L"
7413,,,"yua",,"Maya",,"Yucatán",,,,0,"ltr",,"L"
7414,,,"yub",,"Yugambal",,,,,,0,"ltr",,"E"
7415,,,"yuc",,"Yuchi",,,,,,0,"ltr",,"L"
7416,,,"yud",,"Arabic",,"Judeo-Tripolitanian",,,,0,"rtl",,"L"
7417,,,"yue",,"Chinese",,"Yue",,,,0,"ltr",,"L"
7418,,,"yuf",,"Havasupai-Walapai-Yavapai",,,,,,0,"ltr",,"L"
7419,,,"yug",,"Yug",,,,,,0,"ltr",,"E"
7420,,,"yui",,"Yurutí",,,,,,0,"ltr",,"L"
7421,,,"yuj",,"Karkar-Yuri",,,,,,0,"ltr",,"L"
7422,,,"yuk",,"Yuki",,,,,,0,"ltr",,"E"
7423,,,"yul",,"Yulu",,,,,,0,"ltr",,"L"
7424,,,"yum",,"Quechan",,,,,,0,"ltr",,"L"
7425,,,"yun",,"Bena","Nigeria",,,,,0,"ltr",,"L"
7426,,,"yup",,"Yukpa",,,,,,0,"ltr",,"L"
7427,,,"yuq",,"Yuqui",,,,,,0,"ltr",,"L"
7428,,,"yur",,"Yurok",,,,,,0,"ltr",,"L"
7429,,,"yus",,"Maya",,"Chan Santa Cruz",,,,0,"ltr",,"L"
7430,,,"yut",,"Yopno",,,,,,0,"ltr",,"L"
7431,,,"yuu",,"Yugh",,,,,,0,"ltr",,"L"
7432,,,"yuw",,"Yau","Morobe Province",,,,,0,"ltr",,"L"
7433,,,"yux",,"Yukaghir",,"Southern",,,,0,"ltr",,"L"
7434,,,"yuy",,"Yugur",,"East",,,,0,"ltr",,"L"
7435,,,"yuz",,"Yuracare",,,,,,0,"ltr",,"L"
7436,,,"yva",,"Yawa",,,,,,0,"ltr",,"L"
7437,,,"yvt",,"Yavitero",,,,,,0,"ltr",,"E"
7438,,,"ywa",,"Kalou",,,,,,0,"ltr",,"L"
7439,,,"ywl",,"Yi",,"Western Lalu",,,,0,"ltr",,"L"
7440,,,"ywm",,"Yi",,"Wumeng",,,,0,"ltr",,"L"
7441,,,"ywn",,"Yawanawa",,,,,,0,"ltr",,"L"
7442,,,"ywq",,"Yi",,"Wuding-Luquan",,,,0,"ltr",,"L"
7443,,,"ywr",,"Yawuru",,,,,,0,"ltr",,"L"
7444,,,"ywt",,"Yi",,"Western",,,,0,"ltr",,"L"
7445,,,"ywu",,"Yi",,"Wusa",,,,0,"ltr",,"L"
7446,,,"yww",,"Yawarawarga",,,,,,0,"ltr",,"L"
7447,,,"yym",,"Yi",,"Yuanjiang-Mojiang",,,,0,"ltr",,"L"
7448,,,"yyu",,"Yau","Sandaun Province",,,,,0,"ltr",,"L"
7449,,,"zaa",,"Zapotec",,"Sierra de Juárez",,,,0,"ltr",,"L"
7450,,,"zab",,"Zapotec",,"San Juan Guelavía",,,,0,"ltr",,"L"
7451,,,"zac",,"Zapotec",,"Ocotlán",,,,0,"ltr",,"L"
7452,,,"zad",,"Zapotec",,"Cajonos",,,,0,"ltr",,"L"
7453,,,"zae",,"Zapotec",,"Yareni",,,,0,"ltr",,"L"
7454,,,"zaf",,"Zapotec",,"Ayoquesco",,,,0,"ltr",,"L"
7455,,,"zag",,"Zaghawa",,,,,,0,"ltr",,"L"
7456,,,"zah",,"Zangwal",,,,,,0,"ltr",,"L"
7457,,,"zai",,"Zapotec",,"Isthmus",,,,0,"ltr",,"L"
7458,,,"zaj",,"Zaramo",,,,,,0,"ltr",,"L"
7459,,,"zak",,"Zanaki",,,,,,0,"ltr",,"L"
7460,,,"zal",,"Zauzou",,,,,,0,"ltr",,"L"
7461,,,"zam",,"Zapotec",,"Miahuatlán",,,,0,"ltr",,"L"
7462,,,"zao",,"Zapotec",,"Ozolotepec",,,,0,"ltr",,"L"
7463,,"zap","zap",,"Zapotec",,,,,,1,"ltr",,"L"
7464,,,"zaq",,"Zapotec",,"Aloápam",,,,0,"ltr",,"L"
7465,,,"zar",,"Zapotec",,"Rincón",,,,0,"ltr",,"L"
7466,,,"zas",,"Zapotec",,"Santo Domingo Albarradas",,,,0,"ltr",,"L"
7467,,,"zat",,"Zapotec",,"Tabaa",,,,0,"ltr",,"L"
7468,,,"zau",,"Zangskari",,,,,,0,"ltr",,"L"
7469,,,"zav",,"Zapotec",,"Yatzachi",,,,0,"ltr",,"L"
7470,,,"zaw",,"Zapotec",,"Mitla",,,,0,"ltr",,"L"
7471,,,"zax",,"Zapotec",,"Xadani",,,,0,"ltr",,"L"
7472,,,"zay",,"Zayse-Zergulla",,,,,,0,"ltr",,"L"
7473,,,"zaz",,"Zari",,,,,,0,"ltr",,"L"
7474,,,"zca",,"Zapotec",,"Coatecas Altas",,,,0,"ltr",,"L"
7475,,,"zdj",,"Comorian",,"Ngazidja",,,,0,"ltr",,"L"
7476,,,"zea",,"Zeeuws",,,,,,0,"ltr",,"L"
7477,,,"zeg",,"Zenag",,,,,,0,"ltr",,"L"
7478,,"zen","zen",,"Zenaga",,,,,,0,"ltr",,"L"
7479,,,"zga",,"Kinga",,,,,,0,"ltr",,"L"
7480,,,"zgr",,"Magori",,,,,,0,"ltr",,"L"
7481,"za","zha","zha",,"Zhuang",,,,,,1,"ltr",,"L"
7482,,,"zhb",,"Zhaba",,,,,,0,"ltr",,"L"
7483,,,"zhi",,"Zhire",,,,,,0,"ltr",,"L"
7484,"zh","zho","zho",,"Chinese",,,"中文",,,1,"ltr",,"L"
7485,,,"zhw",,"Zhoa",,,,,,0,"ltr",,"L"
7486,,,"zia",,"Zia",,,,,,0,"ltr",,"L"
7487,,,"zib",,"Zimbabwe Sign Language",,,,,,0,"ltr",,"L"
7488,,,"zik",,"Zimakani",,,,,,0,"ltr",,"L"
7489,,,"zim",,"Mesme",,,,,,0,"ltr",,"L"
7490,,,"zin",,"Zinza",,,,,,0,"ltr",,"L"
7491,,,"zir",,"Ziriya",,,,,,0,"ltr",,"L"
7492,,,"ziw",,"Zigula",,,,,,0,"ltr",,"L"
7493,,,"ziz",,"Zizilivakan",,,,,,0,"ltr",,"L"
7494,,,"zka",,"Kaimbulawa",,,,,,0,"ltr",,"L"
7495,,,"zkb",,"Koibal",,,,,,0,"ltr",,"E"
7496,,,"zkg",,"Koguryo",,,,,,0,"ltr",,"E"
7497,,,"zkh",,"Khorezmian",,,,,,0,"ltr",,"E"
7498,,,"zkk",,"Karankawa",,,,,,0,"ltr",,"E"
7499,,,"zko",,"Kott",,,,,,0,"ltr",,"E"
7500,,,"zkp",,"Kaingáng",,"São Paulo",,,,0,"ltr",,"E"
7501,,,"zkr",,"Zakhring",,,,,,0,"ltr",,"L"
7502,,,"zkt",,"Kitan",,,,,,0,"ltr",,"E"
7503,,,"zku",,"Kaurna",,,,,,0,"ltr",,"E"
7504,,,"zkv",,"Krevinian",,,,,,0,"ltr",,"E"
7505,,,"zkz",,"Khazar",,,,,,0,"ltr",,"E"
7506,,,"zma",,"Manda","Australia",,,,,0,"ltr",,"L"
7507,,,"zmb",,"Zimba",,,,,,0,"ltr",,"L"
7508,,,"zmc",,"Margany",,,,,,0,"ltr",,"L"
7509,,,"zmd",,"Maridan",,,,,,0,"ltr",,"L"
7510,,,"zme",,"Mangerr",,,,,,0,"ltr",,"L"
7511,,,"zmf",,"Mfinu",,,,,,0,"ltr",,"L"
7512,,,"zmg",,"Marti Ke",,,,,,0,"ltr",,"L"
7513,,,"zmh",,"Makolkol",,,,,,0,"ltr",,"L"
7514,,,"zmi",,"Negeri Sembilan Malay",,,,,,0,"ltr",,"L"
7515,,,"zmj",,"Maridjabin",,,,,,0,"ltr",,"L"
7516,,,"zmk",,"Mandandanyi",,,,,,0,"ltr",,"L"
7517,,,"zml",,"Madngele",,,,,,0,"ltr",,"L"
7518,,,"zmm",,"Marimanindji",,,,,,0,"ltr",,"L"
7519,,,"zmn",,"Mbangwe",,,,,,0,"ltr",,"L"
7520,,,"zmo",,"Molo",,,,,,0,"ltr",,"L"
7521,,,"zmp",,"Mpuono",,,,,,0,"ltr",,"L"
7522,,,"zmq",,"Mituku",,,,,,0,"ltr",,"L"
7523,,,"zmr",,"Maranunggu",,,,,,0,"ltr",,"L"
7524,,,"zms",,"Mbesa",,,,,,0,"ltr",,"L"
7525,,,"zmt",,"Maringarr",,,,,,0,"ltr",,"L"
7526,,,"zmu",,"Muruwari",,,,,,0,"ltr",,"L"
7527,,,"zmv",,"Mbariman-Gudhinma",,,,,,0,"ltr",,"L"
7528,,,"zmw",,"Mbo","Democratic Republic of Congo",,,,,0,"ltr",,"L"
7529,,,"zmx",,"Bomitaba",,,,,,0,"ltr",,"L"
7530,,,"zmy",,"Mariyedi",,,,,,0,"ltr",,"L"
7531,,,"zmz",,"Mbandja",,,,,,0,"ltr",,"L"
7532,,,"zna",,"Zan Gula",,,,,,0,"ltr",,"L"
7533,,,"zne",,"Zande","specific",,,,,0,"ltr",,"L"
7534,,,"zng",,"Mang",,,,,,0,"ltr",,"L"
7535,,,"znk",,"Manangkari",,,,,,0,"ltr",,"E"
7536,,,"zns",,"Mangas",,,,,,0,"ltr",,"L"
7537,,,"zoc",,"Zoque",,"Copainalá",,,,0,"ltr",,"L"
7538,,,"zoh",,"Zoque",,"Chimalapa",,,,0,"ltr",,"L"
7539,,,"zom",,"Zome",,,,,,0,"ltr",,"L"
7540,,,"zoo",,"Zapotec",,"Asunción Mixtepec",,,,0,"ltr",,"L"
7541,,,"zoq",,"Zoque",,"Tabasco",,,,0,"ltr",,"L"
7542,,,"zor",,"Zoque",,"Rayón",,,,0,"ltr",,"L"
7543,,,"zos",,"Zoque",,"Francisco León",,,,0,"ltr",,"L"
7544,,,"zpa",,"Zapotec",,"Lachiguiri",,,,0,"ltr",,"L"
7545,,,"zpb",,"Zapotec",,"Yautepec",,,,0,"ltr",,"L"
7546,,,"zpc",,"Zapotec",,"Choapan",,,,0,"ltr",,"L"
7547,,,"zpd",,"Zapotec",,"Southeastern Ixtlán",,,,0,"ltr",,"L"
7548,,,"zpe",,"Zapotec",,"Petapa",,,,0,"ltr",,"L"
7549,,,"zpf",,"Zapotec",,"San Pedro Quiatoni",,,,0,"ltr",,"L"
7550,,,"zpg",,"Zapotec",,"Guevea De Humboldt",,,,0,"ltr",,"L"
7551,,,"zph",,"Zapotec",,"Totomachapan",,,,0,"ltr",,"L"
7552,,,"zpi",,"Zapotec",,"Santa María Quiegolani",,,,0,"ltr",,"L"
7553,,,"zpj",,"Zapotec",,"Quiavicuzas",,,,0,"ltr",,"L"
7554,,,"zpk",,"Zapotec",,"Tlacolulita",,,,0,"ltr",,"L"
7555,,,"zpl",,"Zapotec",,"Lachixío",,,,0,"ltr",,"L"
7556,,,"zpm",,"Zapotec",,"Mixtepec",,,,0,"ltr",,"L"
7557,,,"zpn",,"Zapotec",,"Santa Inés Yatzechi",,,,0,"ltr",,"L"
7558,,,"zpo",,"Zapotec",,"Amatlán",,,,0,"ltr",,"L"
7559,,,"zpp",,"Zapotec",,"El Alto",,,,0,"ltr",,"L"
7560,,,"zpq",,"Zapotec",,"Zoogocho",,,,0,"ltr",,"L"
7561,,,"zpr",,"Zapotec",,"Santiago Xanica",,,,0,"ltr",,"L"
7562,,,"zps",,"Zapotec",,"Coatlán",,,,0,"ltr",,"L"
7563,,,"zpt",,"Zapotec",,"San Vicente Coatlán",,,,0,"ltr",,"L"
7564,,,"zpu",,"Zapotec",,"Yalálag",,,,0,"ltr",,"L"
7565,,,"zpv",,"Zapotec",,"Chichicapan",,,,0,"ltr",,"L"
7566,,,"zpw",,"Zapotec",,"Zaniza",,,,0,"ltr",,"L"
7567,,,"zpx",,"Zapotec",,"San Baltazar Loxicha",,,,0,"ltr",,"L"
7568,,,"zpy",,"Zapotec",,"Mazaltepec",,,,0,"ltr",,"L"
7569,,,"zpz",,"Zapotec",,"Texmelucan",,,,0,"ltr",,"L"
7570,,,"zra",,"Kara","Korea",,,,,0,"ltr",,"E"
7571,,,"zrg",,"Mirgan",,,,,,0,"ltr",,"L"
7572,,,"zrn",,"Zirenkel",,,,,,0,"ltr",,"L"
7573,,,"zro",,"Záparo",,,,,,0,"ltr",,"L"
7574,,,"zrp",,"Zarphatic",,,,,,0,"ltr",,"E"
7575,,,"zrs",,"Mairasi",,,,,,0,"ltr",,"L"
7576,,,"zsk",,"Kaskean",,,,,,0,"ltr",,"A"
7577,,,"zsl",,"Zambian Sign Language",,,,,,0,"ltr",,"L"
7578,,,"zsr",,"Zapotec",,"Southern Rincon",,,,0,"ltr",,"L"
7579,,,"ztc",,"Zapotec",,"Lachirioag",,,,0,"ltr",,"L"
7580,,,"zte",,"Zapotec",,"Elotepec",,,,0,"ltr",,"L"
7581,,,"ztg",,"Zapotec",,"Xanaguía",,,,0,"ltr",,"L"
7582,,,"ztl",,"Zapotec",,"Santiago Lapaguía",,,,0,"ltr",,"L"
7583,,,"ztm",,"Zapotec",,"San Agustín Mixtepec",,,,0,"ltr",,"L"
7584,,,"ztn",,"Zapotec",,"Santa Catarina Albarradas",,,,0,"ltr",,"L"
7585,,,"ztp",,"Zapotec",,"Loxicha",,,,0,"ltr",,"L"
7586,,,"ztq",,"Zapotec",,"Quioquitani-Quierí",,,,0,"ltr",,"L"
7587,,,"zts",,"Zapotec",,"Tilquiapan",,,,0,"ltr",,"L"
7588,,,"ztt",,"Zapotec",,"Tejalapan",,,,0,"ltr",,"L"
7589,,,"ztu",,"Zapotec",,"Güilá",,,,0,"ltr",,"L"
7590,,,"ztx",,"Zapotec",,"Zaachila",,,,0,"ltr",,"L"
7591,,,"zty",,"Zapotec",,"Yatee",,,,0,"ltr",,"L"
7592,,,"zua",,"Zeem",,,,,,0,"ltr",,"L"
7593,,,"zuh",,"Tokano",,,,,,0,"ltr",,"L"
7594,"zu","zul","zul",,"Zulu",,,"isiZulu",,,0,"ltr",,"L"
7595,,,"zum",,"Kumzari",,,,,,0,"ltr",,"L"
7596,,"zun","zun",,"Zuni",,,,,,0,"ltr",,"L"
7597,,,"zuy",,"Zumaya",,,,,,0,"ltr",,"L"
7598,,,"zwa",,"Zay",,,,,,0,"ltr",,"L"
7599,,,"zyp",,"Zyphe",,,,,,0,"ltr",,"L"
END_OF_DATA
  end

  def self.translation_data
    <<'END_OF_DATA'
"id","type","tr_key","table_name","item_id","facet","language_id","text","pluralization_index"
3611,"ViewTranslation","Sunday [weekday]","",,"",114,"Sondag",1
3612,"ViewTranslation","Monday [weekday]","",,"",114,"Maandag",1
3613,"ViewTranslation","Tuesday [weekday]","",,"",114,"Dinsdag",1
3614,"ViewTranslation","Wednesday [weekday]","",,"",114,"Woensdag",1
3615,"ViewTranslation","Thursday [weekday]","",,"",114,"Donderdag",1
3616,"ViewTranslation","Friday [weekday]","",,"",114,"Vrydag",1
3617,"ViewTranslation","Saturday [weekday]","",,"",114,"Saterdag",1
3618,"ViewTranslation","Sun [abbreviated weekday]","",,"",114,"So",1
3619,"ViewTranslation","Mon [abbreviated weekday]","",,"",114,"Ma",1
3620,"ViewTranslation","Tue [abbreviated weekday]","",,"",114,"Di",1
3621,"ViewTranslation","Wed [abbreviated weekday]","",,"",114,"Wo",1
3622,"ViewTranslation","Thu [abbreviated weekday]","",,"",114,"Do",1
3623,"ViewTranslation","Fri [abbreviated weekday]","",,"",114,"Vr",1
3624,"ViewTranslation","Sat [abbreviated weekday]","",,"",114,"Sa",1
3625,"ViewTranslation","January [month]","",,"",114,"Januarie",1
3626,"ViewTranslation","February [month]","",,"",114,"Februarie",1
3627,"ViewTranslation","March [month]","",,"",114,"Maart",1
3628,"ViewTranslation","April [month]","",,"",114,"April",1
3629,"ViewTranslation","May [month]","",,"",114,"Mei",1
3630,"ViewTranslation","June [month]","",,"",114,"Junie",1
3631,"ViewTranslation","July [month]","",,"",114,"Julie",1
3632,"ViewTranslation","August [month]","",,"",114,"Augustus",1
3633,"ViewTranslation","September [month]","",,"",114,"September",1
3634,"ViewTranslation","October [month]","",,"",114,"Oktober",1
3635,"ViewTranslation","November [month]","",,"",114,"November",1
3636,"ViewTranslation","December [month]","",,"",114,"Desember",1
3637,"ViewTranslation","Jan [abbreviated month]","",,"",114,"Jan",1
3638,"ViewTranslation","Feb [abbreviated month]","",,"",114,"Feb",1
3639,"ViewTranslation","Mar [abbreviated month]","",,"",114,"Mar",1
3640,"ViewTranslation","Apr [abbreviated month]","",,"",114,"Apr",1
3641,"ViewTranslation","May [abbreviated month]","",,"",114,"Mei",1
3642,"ViewTranslation","Jun [abbreviated month]","",,"",114,"Jun",1
3643,"ViewTranslation","Jul [abbreviated month]","",,"",114,"Jul",1
3644,"ViewTranslation","Aug [abbreviated month]","",,"",114,"Aug",1
3645,"ViewTranslation","Sep [abbreviated month]","",,"",114,"Sep",1
3646,"ViewTranslation","Oct [abbreviated month]","",,"",114,"Okt",1
3647,"ViewTranslation","Nov [abbreviated month]","",,"",114,"Nov",1
3648,"ViewTranslation","Dec [abbreviated month]","",,"",114,"Des",1
3649,"ViewTranslation","Sunday [weekday]","",,"",247,"እሑድ",1
3650,"ViewTranslation","Monday [weekday]","",,"",247,"ሰኞ",1
3651,"ViewTranslation","Tuesday [weekday]","",,"",247,"ማክሰኞ",1
3652,"ViewTranslation","Wednesday [weekday]","",,"",247,"ረቡዕ",1
3653,"ViewTranslation","Thursday [weekday]","",,"",247,"ሐሙስ",1
3654,"ViewTranslation","Friday [weekday]","",,"",247,"ዓርብ",1
3655,"ViewTranslation","Saturday [weekday]","",,"",247,"ቅዳሜ",1
3656,"ViewTranslation","Sun [abbreviated weekday]","",,"",247,"እሑድ",1
3657,"ViewTranslation","Mon [abbreviated weekday]","",,"",247,"ሰኞ ",1
3658,"ViewTranslation","Tue [abbreviated weekday]","",,"",247,"ማክሰ",1
3659,"ViewTranslation","Wed [abbreviated weekday]","",,"",247,"ረቡዕ",1
3660,"ViewTranslation","Thu [abbreviated weekday]","",,"",247,"ሐሙስ",1
3661,"ViewTranslation","Fri [abbreviated weekday]","",,"",247,"ዓርብ",1
3662,"ViewTranslation","Sat [abbreviated weekday]","",,"",247,"ቅዳሜ",1
3663,"ViewTranslation","January [month]","",,"",247,"ጃንዩወሪ",1
3664,"ViewTranslation","February [month]","",,"",247,"ፌብሩወሪ",1
3665,"ViewTranslation","March [month]","",,"",247,"ማርች",1
3666,"ViewTranslation","April [month]","",,"",247,"ኤፕረል",1
3667,"ViewTranslation","May [month]","",,"",247,"ሜይ",1
3668,"ViewTranslation","June [month]","",,"",247,"ጁን",1
3669,"ViewTranslation","July [month]","",,"",247,"ጁላይ",1
3670,"ViewTranslation","August [month]","",,"",247,"ኦገስት",1
3671,"ViewTranslation","September [month]","",,"",247,"ሴፕቴምበር",1
3672,"ViewTranslation","October [month]","",,"",247,"ኦክተውበር",1
3673,"ViewTranslation","November [month]","",,"",247,"ኖቬምበር",1
3674,"ViewTranslation","December [month]","",,"",247,"ዲሴምበር",1
3675,"ViewTranslation","Jan [abbreviated month]","",,"",247,"ጃንዩ",1
3676,"ViewTranslation","Feb [abbreviated month]","",,"",247,"ፌብሩ",1
3677,"ViewTranslation","Mar [abbreviated month]","",,"",247,"ማርች",1
3678,"ViewTranslation","Apr [abbreviated month]","",,"",247,"ኤፕረ",1
3679,"ViewTranslation","May [abbreviated month]","",,"",247,"ሜይ ",1
3680,"ViewTranslation","Jun [abbreviated month]","",,"",247,"ጁን ",1
3681,"ViewTranslation","Jul [abbreviated month]","",,"",247,"ጁላይ",1
3682,"ViewTranslation","Aug [abbreviated month]","",,"",247,"ኦገስ",1
3683,"ViewTranslation","Sep [abbreviated month]","",,"",247,"ሴፕቴ",1
3684,"ViewTranslation","Oct [abbreviated month]","",,"",247,"ኦክተ",1
3685,"ViewTranslation","Nov [abbreviated month]","",,"",247,"ኖቬም",1
3686,"ViewTranslation","Dec [abbreviated month]","",,"",247,"ዲሴም",1
3687,"ViewTranslation","Sunday [weekday]","",,"",346,"Domingo",1
3688,"ViewTranslation","Monday [weekday]","",,"",346,"Luns",1
3689,"ViewTranslation","Tuesday [weekday]","",,"",346,"Martes",1
3690,"ViewTranslation","Wednesday [weekday]","",,"",346,"Miecols",1
3691,"ViewTranslation","Thursday [weekday]","",,"",346,"Chuebes",1
3692,"ViewTranslation","Friday [weekday]","",,"",346,"Biernes",1
3693,"ViewTranslation","Saturday [weekday]","",,"",346,"Sabado",1
3694,"ViewTranslation","Sun [abbreviated weekday]","",,"",346,"Dom",1
3695,"ViewTranslation","Mon [abbreviated weekday]","",,"",346,"Lun",1
3696,"ViewTranslation","Tue [abbreviated weekday]","",,"",346,"Mar",1
3697,"ViewTranslation","Wed [abbreviated weekday]","",,"",346,"Mie",1
3698,"ViewTranslation","Thu [abbreviated weekday]","",,"",346,"Chu",1
3699,"ViewTranslation","Fri [abbreviated weekday]","",,"",346,"Bie",1
3700,"ViewTranslation","Sat [abbreviated weekday]","",,"",346,"Sab",1
3701,"ViewTranslation","January [month]","",,"",346,"Chinero",1
3702,"ViewTranslation","February [month]","",,"",346,"Frebero",1
3703,"ViewTranslation","March [month]","",,"",346,"Marzo",1
3704,"ViewTranslation","April [month]","",,"",346,"Abril",1
3705,"ViewTranslation","May [month]","",,"",346,"Mayo",1
3706,"ViewTranslation","June [month]","",,"",346,"Chunio",1
3707,"ViewTranslation","July [month]","",,"",346,"Chulio",1
3708,"ViewTranslation","August [month]","",,"",346,"Agosto",1
3709,"ViewTranslation","September [month]","",,"",346,"Setiembre",1
3710,"ViewTranslation","October [month]","",,"",346,"Octubre",1
3711,"ViewTranslation","November [month]","",,"",346,"Nobiembre",1
3712,"ViewTranslation","December [month]","",,"",346,"Abiento",1
3713,"ViewTranslation","Jan [abbreviated month]","",,"",346,"Chi",1
3714,"ViewTranslation","Feb [abbreviated month]","",,"",346,"Fre",1
3715,"ViewTranslation","Mar [abbreviated month]","",,"",346,"Mar",1
3716,"ViewTranslation","Apr [abbreviated month]","",,"",346,"Abr",1
3717,"ViewTranslation","May [abbreviated month]","",,"",346,"May",1
3718,"ViewTranslation","Jun [abbreviated month]","",,"",346,"Chn",1
3719,"ViewTranslation","Jul [abbreviated month]","",,"",346,"Chl",1
3720,"ViewTranslation","Aug [abbreviated month]","",,"",346,"Ago",1
3721,"ViewTranslation","Sep [abbreviated month]","",,"",346,"Set",1
3722,"ViewTranslation","Oct [abbreviated month]","",,"",346,"Oct",1
3723,"ViewTranslation","Nov [abbreviated month]","",,"",346,"Nob",1
3724,"ViewTranslation","Dec [abbreviated month]","",,"",346,"Abi",1
3725,"ViewTranslation","Sunday [weekday]","",,"",340,"الأحد",1
3726,"ViewTranslation","Monday [weekday]","",,"",340,"الاثنين",1
3727,"ViewTranslation","Tuesday [weekday]","",,"",340,"الثلاثاء",1
3728,"ViewTranslation","Wednesday [weekday]","",,"",340,"الأربعاء",1
3729,"ViewTranslation","Thursday [weekday]","",,"",340,"الخميس",1
3730,"ViewTranslation","Friday [weekday]","",,"",340,"الجمعة",1
3731,"ViewTranslation","Saturday [weekday]","",,"",340,"السبت",1
3732,"ViewTranslation","Sun [abbreviated weekday]","",,"",340,"ح",1
3733,"ViewTranslation","Mon [abbreviated weekday]","",,"",340,"ن",1
3734,"ViewTranslation","Tue [abbreviated weekday]","",,"",340,"ث",1
3735,"ViewTranslation","Wed [abbreviated weekday]","",,"",340,"ر",1
3736,"ViewTranslation","Thu [abbreviated weekday]","",,"",340,"خ",1
3737,"ViewTranslation","Fri [abbreviated weekday]","",,"",340,"ج",1
3738,"ViewTranslation","Sat [abbreviated weekday]","",,"",340,"س",1
3739,"ViewTranslation","January [month]","",,"",340,"يناير",1
3740,"ViewTranslation","February [month]","",,"",340,"فبراير",1
3741,"ViewTranslation","March [month]","",,"",340,"مارس",1
3742,"ViewTranslation","April [month]","",,"",340,"أبريل",1
3743,"ViewTranslation","May [month]","",,"",340,"مايو",1
3744,"ViewTranslation","June [month]","",,"",340,"يونيو",1
3745,"ViewTranslation","July [month]","",,"",340,"يوليو",1
3746,"ViewTranslation","August [month]","",,"",340,"أغسطس",1
3747,"ViewTranslation","September [month]","",,"",340,"سبتمبر",1
3748,"ViewTranslation","October [month]","",,"",340,"أكتوبر",1
3749,"ViewTranslation","November [month]","",,"",340,"نوفمبر",1
3750,"ViewTranslation","December [month]","",,"",340,"ديسمبر",1
3751,"ViewTranslation","Jan [abbreviated month]","",,"",340,"ينا",1
3752,"ViewTranslation","Feb [abbreviated month]","",,"",340,"فبر",1
3753,"ViewTranslation","Mar [abbreviated month]","",,"",340,"مار",1
3754,"ViewTranslation","Apr [abbreviated month]","",,"",340,"أبر",1
3755,"ViewTranslation","May [abbreviated month]","",,"",340,"ماي",1
3756,"ViewTranslation","Jun [abbreviated month]","",,"",340,"يون",1
3757,"ViewTranslation","Jul [abbreviated month]","",,"",340,"يول",1
3758,"ViewTranslation","Aug [abbreviated month]","",,"",340,"أغس",1
3759,"ViewTranslation","Sep [abbreviated month]","",,"",340,"سبت",1
3760,"ViewTranslation","Oct [abbreviated month]","",,"",340,"أكت",1
3761,"ViewTranslation","Nov [abbreviated month]","",,"",340,"نوف",1
3762,"ViewTranslation","Dec [abbreviated month]","",,"",340,"ديس",1
3763,"ViewTranslation","Sunday [weekday]","",,"",496,"Bazar günü",1
3764,"ViewTranslation","Monday [weekday]","",,"",496,"Birinci gün",1
3765,"ViewTranslation","Tuesday [weekday]","",,"",496,"Ikinci gün",1
3766,"ViewTranslation","Wednesday [weekday]","",,"",496,"Üçüncü gün",1
3767,"ViewTranslation","Thursday [weekday]","",,"",496,"Dördüncü gün",1
3768,"ViewTranslation","Friday [weekday]","",,"",496,"Beşinci gün",1
3769,"ViewTranslation","Saturday [weekday]","",,"",496,"Altıncı gün",1
3770,"ViewTranslation","Sun [abbreviated weekday]","",,"",496,"Baz",1
3771,"ViewTranslation","Mon [abbreviated weekday]","",,"",496,"Bir",1
3772,"ViewTranslation","Tue [abbreviated weekday]","",,"",496,"Iki",1
3773,"ViewTranslation","Wed [abbreviated weekday]","",,"",496,"Üçü",1
3774,"ViewTranslation","Thu [abbreviated weekday]","",,"",496,"Dör",1
3775,"ViewTranslation","Fri [abbreviated weekday]","",,"",496,"Beş",1
3776,"ViewTranslation","Sat [abbreviated weekday]","",,"",496,"Alt",1
3777,"ViewTranslation","January [month]","",,"",496,"Yanvar",1
3778,"ViewTranslation","February [month]","",,"",496,"Fevral",1
3779,"ViewTranslation","March [month]","",,"",496,"Mart",1
3780,"ViewTranslation","April [month]","",,"",496,"Aprel",1
3781,"ViewTranslation","May [month]","",,"",496,"May",1
3782,"ViewTranslation","June [month]","",,"",496,"Iyun",1
3783,"ViewTranslation","July [month]","",,"",496,"Iyul",1
3784,"ViewTranslation","August [month]","",,"",496,"Avqust",1
3785,"ViewTranslation","September [month]","",,"",496,"Sentyabr",1
3786,"ViewTranslation","October [month]","",,"",496,"Oktyabr",1
3787,"ViewTranslation","November [month]","",,"",496,"Noyabr",1
3788,"ViewTranslation","December [month]","",,"",496,"Dekabr",1
3789,"ViewTranslation","Jan [abbreviated month]","",,"",496,"Yan",1
3790,"ViewTranslation","Feb [abbreviated month]","",,"",496,"Fev",1
3791,"ViewTranslation","Mar [abbreviated month]","",,"",496,"Mar",1
3792,"ViewTranslation","Apr [abbreviated month]","",,"",496,"Apr",1
3793,"ViewTranslation","May [abbreviated month]","",,"",496,"May",1
3794,"ViewTranslation","Jun [abbreviated month]","",,"",496,"İyn",1
3795,"ViewTranslation","Jul [abbreviated month]","",,"",496,"İyl",1
3796,"ViewTranslation","Aug [abbreviated month]","",,"",496,"Avq",1
3797,"ViewTranslation","Sep [abbreviated month]","",,"",496,"Sen",1
3798,"ViewTranslation","Oct [abbreviated month]","",,"",496,"Okt",1
3799,"ViewTranslation","Nov [abbreviated month]","",,"",496,"Noy",1
3800,"ViewTranslation","Dec [abbreviated month]","",,"",496,"Dek",1
3801,"ViewTranslation","Sunday [weekday]","",,"",614,"Нядзеля",1
3802,"ViewTranslation","Monday [weekday]","",,"",614,"Панядзелак",1
3803,"ViewTranslation","Tuesday [weekday]","",,"",614,"Аўторак",1
3804,"ViewTranslation","Wednesday [weekday]","",,"",614,"Серада",1
3805,"ViewTranslation","Thursday [weekday]","",,"",614,"Чацвер",1
3806,"ViewTranslation","Friday [weekday]","",,"",614,"Пятніца",1
3807,"ViewTranslation","Saturday [weekday]","",,"",614,"Субота",1
3808,"ViewTranslation","Sun [abbreviated weekday]","",,"",614,"Няд",1
3809,"ViewTranslation","Mon [abbreviated weekday]","",,"",614,"Пан",1
3810,"ViewTranslation","Tue [abbreviated weekday]","",,"",614,"Аўт",1
3811,"ViewTranslation","Wed [abbreviated weekday]","",,"",614,"Срд",1
3812,"ViewTranslation","Thu [abbreviated weekday]","",,"",614,"Чцв",1
3813,"ViewTranslation","Fri [abbreviated weekday]","",,"",614,"Пят",1
3814,"ViewTranslation","Sat [abbreviated weekday]","",,"",614,"Суб",1
3815,"ViewTranslation","January [month]","",,"",614,"Студзень",1
3816,"ViewTranslation","February [month]","",,"",614,"Люты",1
3817,"ViewTranslation","March [month]","",,"",614,"Сакавік",1
3818,"ViewTranslation","April [month]","",,"",614,"Красавік",1
3819,"ViewTranslation","May [month]","",,"",614,"Травень",1
3820,"ViewTranslation","June [month]","",,"",614,"Чэрвень",1
3821,"ViewTranslation","July [month]","",,"",614,"Ліпень",1
3822,"ViewTranslation","August [month]","",,"",614,"Жнівень",1
3823,"ViewTranslation","September [month]","",,"",614,"Верасень",1
3824,"ViewTranslation","October [month]","",,"",614,"Кастрычнік",1
3825,"ViewTranslation","November [month]","",,"",614,"Лістапад",1
3826,"ViewTranslation","December [month]","",,"",614,"Снежань",1
3827,"ViewTranslation","Jan [abbreviated month]","",,"",614,"Стд",1
3828,"ViewTranslation","Feb [abbreviated month]","",,"",614,"Лют",1
3829,"ViewTranslation","Mar [abbreviated month]","",,"",614,"Сак",1
3830,"ViewTranslation","Apr [abbreviated month]","",,"",614,"Крс",1
3831,"ViewTranslation","May [abbreviated month]","",,"",614,"Тра",1
3832,"ViewTranslation","Jun [abbreviated month]","",,"",614,"Чэр",1
3833,"ViewTranslation","Jul [abbreviated month]","",,"",614,"Ліп",1
3834,"ViewTranslation","Aug [abbreviated month]","",,"",614,"Жнв",1
3835,"ViewTranslation","Sep [abbreviated month]","",,"",614,"Врс",1
3836,"ViewTranslation","Oct [abbreviated month]","",,"",614,"Кст",1
3837,"ViewTranslation","Nov [abbreviated month]","",,"",614,"Ліс",1
3838,"ViewTranslation","Dec [abbreviated month]","",,"",614,"Снж",1
3839,"ViewTranslation","Sunday [weekday]","",,"",1020,"Неделя",1
3840,"ViewTranslation","Monday [weekday]","",,"",1020,"Понеделник",1
3841,"ViewTranslation","Tuesday [weekday]","",,"",1020,"Вторник",1
3842,"ViewTranslation","Wednesday [weekday]","",,"",1020,"Сряда",1
3843,"ViewTranslation","Thursday [weekday]","",,"",1020,"Четвъртък",1
3844,"ViewTranslation","Friday [weekday]","",,"",1020,"Петък",1
3845,"ViewTranslation","Saturday [weekday]","",,"",1020,"Събота",1
3846,"ViewTranslation","Sun [abbreviated weekday]","",,"",1020,"Нд",1
3847,"ViewTranslation","Mon [abbreviated weekday]","",,"",1020,"Пн",1
3848,"ViewTranslation","Tue [abbreviated weekday]","",,"",1020,"Вт",1
3849,"ViewTranslation","Wed [abbreviated weekday]","",,"",1020,"Ср",1
3850,"ViewTranslation","Thu [abbreviated weekday]","",,"",1020,"Чт",1
3851,"ViewTranslation","Fri [abbreviated weekday]","",,"",1020,"Пт",1
3852,"ViewTranslation","Sat [abbreviated weekday]","",,"",1020,"Сб",1
3853,"ViewTranslation","January [month]","",,"",1020,"Януари",1
3854,"ViewTranslation","February [month]","",,"",1020,"Февруари",1
3855,"ViewTranslation","March [month]","",,"",1020,"Март",1
3856,"ViewTranslation","April [month]","",,"",1020,"Април",1
3857,"ViewTranslation","May [month]","",,"",1020,"Май",1
3858,"ViewTranslation","June [month]","",,"",1020,"Юни",1
3859,"ViewTranslation","July [month]","",,"",1020,"Юли",1
3860,"ViewTranslation","August [month]","",,"",1020,"Август",1
3861,"ViewTranslation","September [month]","",,"",1020,"Септември",1
3862,"ViewTranslation","October [month]","",,"",1020,"Октомври",1
3863,"ViewTranslation","November [month]","",,"",1020,"Ноември",1
3864,"ViewTranslation","December [month]","",,"",1020,"Декември",1
3865,"ViewTranslation","Jan [abbreviated month]","",,"",1020,"Яну",1
3866,"ViewTranslation","Feb [abbreviated month]","",,"",1020,"Фев",1
3867,"ViewTranslation","Mar [abbreviated month]","",,"",1020,"Мар",1
3868,"ViewTranslation","Apr [abbreviated month]","",,"",1020,"Апр",1
3869,"ViewTranslation","May [abbreviated month]","",,"",1020,"Май",1
3870,"ViewTranslation","Jun [abbreviated month]","",,"",1020,"Юни",1
3871,"ViewTranslation","Jul [abbreviated month]","",,"",1020,"Юли",1
3872,"ViewTranslation","Aug [abbreviated month]","",,"",1020,"Авг",1
3873,"ViewTranslation","Sep [abbreviated month]","",,"",1020,"Сеп",1
3874,"ViewTranslation","Oct [abbreviated month]","",,"",1020,"Окт",1
3875,"ViewTranslation","Nov [abbreviated month]","",,"",1020,"Ное",1
3876,"ViewTranslation","Dec [abbreviated month]","",,"",1020,"Дек",1
3877,"ViewTranslation","Sunday [weekday]","",,"",616,"রবিবার",1
3878,"ViewTranslation","Monday [weekday]","",,"",616,"সোমবার",1
3879,"ViewTranslation","Tuesday [weekday]","",,"",616,"মঙগলবার",1
3880,"ViewTranslation","Wednesday [weekday]","",,"",616,"বুধবার",1
3881,"ViewTranslation","Thursday [weekday]","",,"",616,"বৃহস্পতিবার",1
3882,"ViewTranslation","Friday [weekday]","",,"",616,"শুক্রবার",1
3883,"ViewTranslation","Saturday [weekday]","",,"",616,"শনিবার",1
3884,"ViewTranslation","Sun [abbreviated weekday]","",,"",616,"রবি",1
3885,"ViewTranslation","Mon [abbreviated weekday]","",,"",616,"সোম",1
3886,"ViewTranslation","Tue [abbreviated weekday]","",,"",616,"মঙগল",1
3887,"ViewTranslation","Wed [abbreviated weekday]","",,"",616,"বুধ",1
3888,"ViewTranslation","Thu [abbreviated weekday]","",,"",616,"বৃহস্পতি",1
3889,"ViewTranslation","Fri [abbreviated weekday]","",,"",616,"শুক্র",1
3890,"ViewTranslation","Sat [abbreviated weekday]","",,"",616,"শনি",1
3891,"ViewTranslation","January [month]","",,"",616,"জানুয়ারী",1
3892,"ViewTranslation","February [month]","",,"",616,"ফেব্রুয়ারী",1
3893,"ViewTranslation","March [month]","",,"",616,"মার্চ",1
3894,"ViewTranslation","April [month]","",,"",616,"এপ্রিল",1
3895,"ViewTranslation","May [month]","",,"",616,"মে",1
3896,"ViewTranslation","June [month]","",,"",616,"জুন",1
3897,"ViewTranslation","July [month]","",,"",616,"জুলাই",1
3898,"ViewTranslation","August [month]","",,"",616,"আগস্ট",1
3899,"ViewTranslation","September [month]","",,"",616,"সেপ্টেম্বার",1
3900,"ViewTranslation","October [month]","",,"",616,"অক্টোবার",1
3901,"ViewTranslation","November [month]","",,"",616,"নভেম্বার",1
3902,"ViewTranslation","December [month]","",,"",616,"ডিসেম্বার",1
3903,"ViewTranslation","Jan [abbreviated month]","",,"",616,"জান",1
3904,"ViewTranslation","Feb [abbreviated month]","",,"",616,"ফেব",1
3905,"ViewTranslation","Mar [abbreviated month]","",,"",616,"মার",1
3906,"ViewTranslation","Apr [abbreviated month]","",,"",616,"এপ্র",1
3907,"ViewTranslation","May [abbreviated month]","",,"",616,"মে",1
3908,"ViewTranslation","Jun [abbreviated month]","",,"",616,"জুন",1
3909,"ViewTranslation","Jul [abbreviated month]","",,"",616,"জুল",1
3910,"ViewTranslation","Aug [abbreviated month]","",,"",616,"আগ",1
3911,"ViewTranslation","Sep [abbreviated month]","",,"",616,"সেপ",1
3912,"ViewTranslation","Oct [abbreviated month]","",,"",616,"অক্টোবর",1
3913,"ViewTranslation","Nov [abbreviated month]","",,"",616,"নভেম্বর",1
3914,"ViewTranslation","Dec [abbreviated month]","",,"",616,"ডিসেম্বর",1
3915,"ViewTranslation","Sunday [weekday]","",,"",936,"Sul",1
3916,"ViewTranslation","Monday [weekday]","",,"",936,"Lun",1
3917,"ViewTranslation","Tuesday [weekday]","",,"",936,"Meurzh",1
3918,"ViewTranslation","Wednesday [weekday]","",,"",936,"Merc'her",1
3919,"ViewTranslation","Thursday [weekday]","",,"",936,"Yaou",1
3920,"ViewTranslation","Friday [weekday]","",,"",936,"Gwener",1
3921,"ViewTranslation","Saturday [weekday]","",,"",936,"Sadorn",1
3922,"ViewTranslation","Sun [abbreviated weekday]","",,"",936,"Sul",1
3923,"ViewTranslation","Mon [abbreviated weekday]","",,"",936,"Lun",1
3924,"ViewTranslation","Tue [abbreviated weekday]","",,"",936,"Meu",1
3925,"ViewTranslation","Wed [abbreviated weekday]","",,"",936,"Mer",1
3926,"ViewTranslation","Thu [abbreviated weekday]","",,"",936,"Yao",1
3927,"ViewTranslation","Fri [abbreviated weekday]","",,"",936,"Gwe",1
3928,"ViewTranslation","Sat [abbreviated weekday]","",,"",936,"Sad",1
3929,"ViewTranslation","January [month]","",,"",936,"Genver",1
3930,"ViewTranslation","February [month]","",,"",936,"C'hwevrer",1
3931,"ViewTranslation","March [month]","",,"",936,"Meurzh",1
3932,"ViewTranslation","April [month]","",,"",936,"Ebrel",1
3933,"ViewTranslation","May [month]","",,"",936,"Mae",1
3934,"ViewTranslation","June [month]","",,"",936,"Mezheven",1
3935,"ViewTranslation","July [month]","",,"",936,"Gouere",1
3936,"ViewTranslation","August [month]","",,"",936,"Eost",1
3937,"ViewTranslation","September [month]","",,"",936,"Gwengolo",1
3938,"ViewTranslation","October [month]","",,"",936,"Here",1
3939,"ViewTranslation","November [month]","",,"",936,"Du",1
3940,"ViewTranslation","December [month]","",,"",936,"Kerzu",1
3941,"ViewTranslation","Jan [abbreviated month]","",,"",936,"Gen ",1
3942,"ViewTranslation","Feb [abbreviated month]","",,"",936,"C'hw",1
3943,"ViewTranslation","Mar [abbreviated month]","",,"",936,"Meu ",1
3944,"ViewTranslation","Apr [abbreviated month]","",,"",936,"Ebr ",1
3945,"ViewTranslation","May [abbreviated month]","",,"",936,"Mae ",1
3946,"ViewTranslation","Jun [abbreviated month]","",,"",936,"Eve ",1
3947,"ViewTranslation","Jul [abbreviated month]","",,"",936,"Gou ",1
3948,"ViewTranslation","Aug [abbreviated month]","",,"",936,"Eos ",1
3949,"ViewTranslation","Sep [abbreviated month]","",,"",936,"Gwe ",1
3950,"ViewTranslation","Oct [abbreviated month]","",,"",936,"Her ",1
3951,"ViewTranslation","Nov [abbreviated month]","",,"",936,"Du ",1
3952,"ViewTranslation","Dec [abbreviated month]","",,"",936,"Ker ",1
3953,"ViewTranslation","Sunday [weekday]","",,"",875,"Nedjelja",1
3954,"ViewTranslation","Monday [weekday]","",,"",875,"Ponedjeljak",1
3955,"ViewTranslation","Tuesday [weekday]","",,"",875,"Utorak",1
3956,"ViewTranslation","Wednesday [weekday]","",,"",875,"Srijeda",1
3957,"ViewTranslation","Thursday [weekday]","",,"",875,"Četvrtak",1
3958,"ViewTranslation","Friday [weekday]","",,"",875,"Petak",1
3959,"ViewTranslation","Saturday [weekday]","",,"",875,"Subota",1
3960,"ViewTranslation","Sun [abbreviated weekday]","",,"",875,"Ned",1
3961,"ViewTranslation","Mon [abbreviated weekday]","",,"",875,"Pon",1
3962,"ViewTranslation","Tue [abbreviated weekday]","",,"",875,"Uto",1
3963,"ViewTranslation","Wed [abbreviated weekday]","",,"",875,"Sri",1
3964,"ViewTranslation","Thu [abbreviated weekday]","",,"",875,"Čet",1
3965,"ViewTranslation","Fri [abbreviated weekday]","",,"",875,"Pet",1
3966,"ViewTranslation","Sat [abbreviated weekday]","",,"",875,"Sub",1
3967,"ViewTranslation","January [month]","",,"",875,"Januar",1
3968,"ViewTranslation","February [month]","",,"",875,"Februar",1
3969,"ViewTranslation","March [month]","",,"",875,"Mart",1
3970,"ViewTranslation","April [month]","",,"",875,"April",1
3971,"ViewTranslation","May [month]","",,"",875,"Maj",1
3972,"ViewTranslation","June [month]","",,"",875,"Juni",1
3973,"ViewTranslation","July [month]","",,"",875,"Juli",1
3974,"ViewTranslation","August [month]","",,"",875,"August",1
3975,"ViewTranslation","September [month]","",,"",875,"Septembar",1
3976,"ViewTranslation","October [month]","",,"",875,"Oktobar",1
3977,"ViewTranslation","November [month]","",,"",875,"Novembar",1
3978,"ViewTranslation","December [month]","",,"",875,"Decembar",1
3979,"ViewTranslation","Jan [abbreviated month]","",,"",875,"Jan",1
3980,"ViewTranslation","Feb [abbreviated month]","",,"",875,"Feb",1
3981,"ViewTranslation","Mar [abbreviated month]","",,"",875,"Mar",1
3982,"ViewTranslation","Apr [abbreviated month]","",,"",875,"Apr",1
3983,"ViewTranslation","May [abbreviated month]","",,"",875,"Maj",1
3984,"ViewTranslation","Jun [abbreviated month]","",,"",875,"Jun",1
3985,"ViewTranslation","Jul [abbreviated month]","",,"",875,"Jul",1
3986,"ViewTranslation","Aug [abbreviated month]","",,"",875,"Aug",1
3987,"ViewTranslation","Sep [abbreviated month]","",,"",875,"Sep",1
3988,"ViewTranslation","Oct [abbreviated month]","",,"",875,"Okt",1
3989,"ViewTranslation","Nov [abbreviated month]","",,"",875,"Nov",1
3990,"ViewTranslation","Dec [abbreviated month]","",,"",875,"Dec",1
3991,"ViewTranslation","Sunday [weekday]","",,"",1122,"ሰንበር ቅዳዅ",1
3992,"ViewTranslation","Monday [weekday]","",,"",1122,"ሰኑ",1
3993,"ViewTranslation","Tuesday [weekday]","",,"",1122,"ሰሊጝ",1
3994,"ViewTranslation","Wednesday [weekday]","",,"",1122,"ለጓ ወሪ ለብዋ",1
3995,"ViewTranslation","Thursday [weekday]","",,"",1122,"ኣምድ",1
3996,"ViewTranslation","Friday [weekday]","",,"",1122,"ኣርብ",1
3997,"ViewTranslation","Saturday [weekday]","",,"",1122,"ሰንበር ሽጓዅ",1
3998,"ViewTranslation","Sun [abbreviated weekday]","",,"",1122,"ሰ/ቅ",1
3999,"ViewTranslation","Mon [abbreviated weekday]","",,"",1122,"ሰኑ",1
4000,"ViewTranslation","Tue [abbreviated weekday]","",,"",1122,"ሰሊጝ",1
4001,"ViewTranslation","Wed [abbreviated weekday]","",,"",1122,"ለጓ",1
4002,"ViewTranslation","Thu [abbreviated weekday]","",,"",1122,"ኣምድ",1
4003,"ViewTranslation","Fri [abbreviated weekday]","",,"",1122,"ኣርብ",1
4004,"ViewTranslation","Sat [abbreviated weekday]","",,"",1122,"ሰ/ሽ",1
4005,"ViewTranslation","January [month]","",,"",1122,"ልደትሪ",1
4006,"ViewTranslation","February [month]","",,"",1122,"ካብኽብቲ",1
4007,"ViewTranslation","March [month]","",,"",1122,"ክብላ",1
4008,"ViewTranslation","April [month]","",,"",1122,"ፋጅኺሪ",1
4009,"ViewTranslation","May [month]","",,"",1122,"ክቢቅሪ",1
4010,"ViewTranslation","June [month]","",,"",1122,"ምኪኤል ትጓ̅ኒሪ",1
4011,"ViewTranslation","July [month]","",,"",1122,"ኰርኩ",1
4012,"ViewTranslation","August [month]","",,"",1122,"ማርያም ትሪ",1
4013,"ViewTranslation","September [month]","",,"",1122,"ያኸኒ መሳቅለሪ",1
4014,"ViewTranslation","October [month]","",,"",1122,"መተሉ",1
4015,"ViewTranslation","November [month]","",,"",1122,"ምኪኤል መሽወሪ",1
4016,"ViewTranslation","December [month]","",,"",1122,"ተሕሳስሪ",1
4017,"ViewTranslation","Jan [abbreviated month]","",,"",1122,"ልደት",1
4018,"ViewTranslation","Feb [abbreviated month]","",,"",1122,"ካብኽ",1
4019,"ViewTranslation","Mar [abbreviated month]","",,"",1122,"ክብላ",1
4020,"ViewTranslation","Apr [abbreviated month]","",,"",1122,"ፋጅኺ",1
4021,"ViewTranslation","May [abbreviated month]","",,"",1122,"ክቢቅ",1
4022,"ViewTranslation","Jun [abbreviated month]","",,"",1122,"ም/ት",1
4023,"ViewTranslation","Jul [abbreviated month]","",,"",1122,"ኰር",1
4024,"ViewTranslation","Aug [abbreviated month]","",,"",1122,"ማርያ",1
4025,"ViewTranslation","Sep [abbreviated month]","",,"",1122,"ያኸኒ",1
4026,"ViewTranslation","Oct [abbreviated month]","",,"",1122,"መተሉ",1
4027,"ViewTranslation","Nov [abbreviated month]","",,"",1122,"ም/ም",1
4028,"ViewTranslation","Dec [abbreviated month]","",,"",1122,"ተሕሳ",1
4029,"ViewTranslation","Sunday [weekday]","",,"",1177,"Diumenge",1
4030,"ViewTranslation","Monday [weekday]","",,"",1177,"Dilluns",1
4031,"ViewTranslation","Tuesday [weekday]","",,"",1177,"Dimarts",1
4032,"ViewTranslation","Wednesday [weekday]","",,"",1177,"Dimecres",1
4033,"ViewTranslation","Thursday [weekday]","",,"",1177,"Dijous",1
4034,"ViewTranslation","Friday [weekday]","",,"",1177,"Divendres",1
4035,"ViewTranslation","Saturday [weekday]","",,"",1177,"Dissabte",1
4036,"ViewTranslation","Sun [abbreviated weekday]","",,"",1177,"Dg",1
4037,"ViewTranslation","Mon [abbreviated weekday]","",,"",1177,"Dl",1
4038,"ViewTranslation","Tue [abbreviated weekday]","",,"",1177,"Dt",1
4039,"ViewTranslation","Wed [abbreviated weekday]","",,"",1177,"Dc",1
4040,"ViewTranslation","Thu [abbreviated weekday]","",,"",1177,"Dj",1
4041,"ViewTranslation","Fri [abbreviated weekday]","",,"",1177,"Dv",1
4042,"ViewTranslation","Sat [abbreviated weekday]","",,"",1177,"Ds",1
4043,"ViewTranslation","January [month]","",,"",1177,"Gener",1
4044,"ViewTranslation","February [month]","",,"",1177,"Febrer",1
4045,"ViewTranslation","March [month]","",,"",1177,"Març",1
4046,"ViewTranslation","April [month]","",,"",1177,"Abril",1
4047,"ViewTranslation","May [month]","",,"",1177,"Maig",1
4048,"ViewTranslation","June [month]","",,"",1177,"Juny",1
4049,"ViewTranslation","July [month]","",,"",1177,"Juliol",1
4050,"ViewTranslation","August [month]","",,"",1177,"Agost",1
4051,"ViewTranslation","September [month]","",,"",1177,"Setembre",1
4052,"ViewTranslation","October [month]","",,"",1177,"Octubre",1
4053,"ViewTranslation","November [month]","",,"",1177,"Novembre",1
4054,"ViewTranslation","December [month]","",,"",1177,"Desembre",1
4055,"ViewTranslation","Jan [abbreviated month]","",,"",1177,"Gen",1
4056,"ViewTranslation","Feb [abbreviated month]","",,"",1177,"Feb",1
4057,"ViewTranslation","Mar [abbreviated month]","",,"",1177,"Mar",1
4058,"ViewTranslation","Apr [abbreviated month]","",,"",1177,"Abr",1
4059,"ViewTranslation","May [abbreviated month]","",,"",1177,"Mai",1
4060,"ViewTranslation","Jun [abbreviated month]","",,"",1177,"Jun",1
4061,"ViewTranslation","Jul [abbreviated month]","",,"",1177,"Jul",1
4062,"ViewTranslation","Aug [abbreviated month]","",,"",1177,"Ago",1
4063,"ViewTranslation","Sep [abbreviated month]","",,"",1177,"Set",1
4064,"ViewTranslation","Oct [abbreviated month]","",,"",1177,"Oct",1
4065,"ViewTranslation","Nov [abbreviated month]","",,"",1177,"Nov",1
4066,"ViewTranslation","Dec [abbreviated month]","",,"",1177,"Des",1
4067,"ViewTranslation","Sunday [weekday]","",,"",1233,"Neděle",1
4068,"ViewTranslation","Monday [weekday]","",,"",1233,"Pondělí",1
4069,"ViewTranslation","Tuesday [weekday]","",,"",1233,"Úterý",1
4070,"ViewTranslation","Wednesday [weekday]","",,"",1233,"Středa",1
4071,"ViewTranslation","Thursday [weekday]","",,"",1233,"Čtvrtek",1
4072,"ViewTranslation","Friday [weekday]","",,"",1233,"Pátek",1
4073,"ViewTranslation","Saturday [weekday]","",,"",1233,"Sobota",1
4074,"ViewTranslation","Sun [abbreviated weekday]","",,"",1233,"Ne",1
4075,"ViewTranslation","Mon [abbreviated weekday]","",,"",1233,"Po",1
4076,"ViewTranslation","Tue [abbreviated weekday]","",,"",1233,"Út",1
4077,"ViewTranslation","Wed [abbreviated weekday]","",,"",1233,"St",1
4078,"ViewTranslation","Thu [abbreviated weekday]","",,"",1233,"Čt",1
4079,"ViewTranslation","Fri [abbreviated weekday]","",,"",1233,"Pá",1
4080,"ViewTranslation","Sat [abbreviated weekday]","",,"",1233,"So",1
4081,"ViewTranslation","January [month]","",,"",1233,"Leden",1
4082,"ViewTranslation","February [month]","",,"",1233,"Únor",1
4083,"ViewTranslation","March [month]","",,"",1233,"Březen",1
4084,"ViewTranslation","April [month]","",,"",1233,"Duben",1
4085,"ViewTranslation","May [month]","",,"",1233,"Květen",1
4086,"ViewTranslation","June [month]","",,"",1233,"Červen",1
4087,"ViewTranslation","July [month]","",,"",1233,"Červenec",1
4088,"ViewTranslation","August [month]","",,"",1233,"Srpen",1
4089,"ViewTranslation","September [month]","",,"",1233,"Září",1
4090,"ViewTranslation","October [month]","",,"",1233,"Říjen",1
4091,"ViewTranslation","November [month]","",,"",1233,"Listopad",1
4092,"ViewTranslation","December [month]","",,"",1233,"Prosinec",1
4093,"ViewTranslation","Jan [abbreviated month]","",,"",1233,"Led",1
4094,"ViewTranslation","Feb [abbreviated month]","",,"",1233,"Úno",1
4095,"ViewTranslation","Mar [abbreviated month]","",,"",1233,"Bře",1
4096,"ViewTranslation","Apr [abbreviated month]","",,"",1233,"Dub",1
4097,"ViewTranslation","May [abbreviated month]","",,"",1233,"Kvě",1
4098,"ViewTranslation","Jun [abbreviated month]","",,"",1233,"Čen",1
4099,"ViewTranslation","Jul [abbreviated month]","",,"",1233,"Čec",1
4100,"ViewTranslation","Aug [abbreviated month]","",,"",1233,"Srp",1
4101,"ViewTranslation","Sep [abbreviated month]","",,"",1233,"Zář",1
4102,"ViewTranslation","Oct [abbreviated month]","",,"",1233,"Říj",1
4103,"ViewTranslation","Nov [abbreviated month]","",,"",1233,"Lis",1
4104,"ViewTranslation","Dec [abbreviated month]","",,"",1233,"Pro",1
4105,"ViewTranslation","Sunday [weekday]","",,"",1481,"Sul",1
4106,"ViewTranslation","Monday [weekday]","",,"",1481,"Llun",1
4107,"ViewTranslation","Tuesday [weekday]","",,"",1481,"Mawrth",1
4108,"ViewTranslation","Wednesday [weekday]","",,"",1481,"Mercher",1
4109,"ViewTranslation","Thursday [weekday]","",,"",1481,"Iau",1
4110,"ViewTranslation","Friday [weekday]","",,"",1481,"Gwener",1
4111,"ViewTranslation","Saturday [weekday]","",,"",1481,"Sadwrn",1
4112,"ViewTranslation","Sun [abbreviated weekday]","",,"",1481,"Sul",1
4113,"ViewTranslation","Mon [abbreviated weekday]","",,"",1481,"Llu",1
4114,"ViewTranslation","Tue [abbreviated weekday]","",,"",1481,"Maw",1
4115,"ViewTranslation","Wed [abbreviated weekday]","",,"",1481,"Mer",1
4116,"ViewTranslation","Thu [abbreviated weekday]","",,"",1481,"Iau",1
4117,"ViewTranslation","Fri [abbreviated weekday]","",,"",1481,"Gwe",1
4118,"ViewTranslation","Sat [abbreviated weekday]","",,"",1481,"Sad",1
4119,"ViewTranslation","January [month]","",,"",1481,"Ionawr",1
4120,"ViewTranslation","February [month]","",,"",1481,"Chwefror",1
4121,"ViewTranslation","March [month]","",,"",1481,"Mawrth",1
4122,"ViewTranslation","April [month]","",,"",1481,"Ebrill",1
4123,"ViewTranslation","May [month]","",,"",1481,"Mai",1
4124,"ViewTranslation","June [month]","",,"",1481,"Mehefin",1
4125,"ViewTranslation","July [month]","",,"",1481,"Gorffennaf",1
4126,"ViewTranslation","August [month]","",,"",1481,"Awst",1
4127,"ViewTranslation","September [month]","",,"",1481,"Medi",1
4128,"ViewTranslation","October [month]","",,"",1481,"Hydref",1
4129,"ViewTranslation","November [month]","",,"",1481,"Tachwedd",1
4130,"ViewTranslation","December [month]","",,"",1481,"Rhagfyr",1
4131,"ViewTranslation","Jan [abbreviated month]","",,"",1481,"Ion",1
4132,"ViewTranslation","Feb [abbreviated month]","",,"",1481,"Chw",1
4133,"ViewTranslation","Mar [abbreviated month]","",,"",1481,"Maw",1
4134,"ViewTranslation","Apr [abbreviated month]","",,"",1481,"Ebr",1
4135,"ViewTranslation","May [abbreviated month]","",,"",1481,"Mai",1
4136,"ViewTranslation","Jun [abbreviated month]","",,"",1481,"Meh",1
4137,"ViewTranslation","Jul [abbreviated month]","",,"",1481,"Gor",1
4138,"ViewTranslation","Aug [abbreviated month]","",,"",1481,"Aws",1
4139,"ViewTranslation","Sep [abbreviated month]","",,"",1481,"Med",1
4140,"ViewTranslation","Oct [abbreviated month]","",,"",1481,"Hyd",1
4141,"ViewTranslation","Nov [abbreviated month]","",,"",1481,"Tach",1
4142,"ViewTranslation","Dec [abbreviated month]","",,"",1481,"Rha",1
4143,"ViewTranslation","Sunday [weekday]","",,"",1499,"Søndag",1
4144,"ViewTranslation","Monday [weekday]","",,"",1499,"Mandag",1
4145,"ViewTranslation","Tuesday [weekday]","",,"",1499,"Tirsdag",1
4146,"ViewTranslation","Wednesday [weekday]","",,"",1499,"Onsdag",1
4147,"ViewTranslation","Thursday [weekday]","",,"",1499,"Torsdag",1
4148,"ViewTranslation","Friday [weekday]","",,"",1499,"Fredag",1
4149,"ViewTranslation","Saturday [weekday]","",,"",1499,"Lørdag",1
4150,"ViewTranslation","Sun [abbreviated weekday]","",,"",1499,"Søn",1
4151,"ViewTranslation","Mon [abbreviated weekday]","",,"",1499,"Man",1
4152,"ViewTranslation","Tue [abbreviated weekday]","",,"",1499,"Tir",1
4153,"ViewTranslation","Wed [abbreviated weekday]","",,"",1499,"Ons",1
4154,"ViewTranslation","Thu [abbreviated weekday]","",,"",1499,"Tor",1
4155,"ViewTranslation","Fri [abbreviated weekday]","",,"",1499,"Fre",1
4156,"ViewTranslation","Sat [abbreviated weekday]","",,"",1499,"Lør",1
4157,"ViewTranslation","January [month]","",,"",1499,"Januar",1
4158,"ViewTranslation","February [month]","",,"",1499,"Februar",1
4159,"ViewTranslation","March [month]","",,"",1499,"Marts",1
4160,"ViewTranslation","April [month]","",,"",1499,"April",1
4161,"ViewTranslation","May [month]","",,"",1499,"Maj",1
4162,"ViewTranslation","June [month]","",,"",1499,"Juni",1
4163,"ViewTranslation","July [month]","",,"",1499,"Juli",1
4164,"ViewTranslation","August [month]","",,"",1499,"August",1
4165,"ViewTranslation","September [month]","",,"",1499,"September",1
4166,"ViewTranslation","October [month]","",,"",1499,"Oktober",1
4167,"ViewTranslation","November [month]","",,"",1499,"November",1
4168,"ViewTranslation","December [month]","",,"",1499,"December",1
4169,"ViewTranslation","Jan [abbreviated month]","",,"",1499,"Jan",1
4170,"ViewTranslation","Feb [abbreviated month]","",,"",1499,"Feb",1
4171,"ViewTranslation","Mar [abbreviated month]","",,"",1499,"Mar",1
4172,"ViewTranslation","Apr [abbreviated month]","",,"",1499,"Apr",1
4173,"ViewTranslation","May [abbreviated month]","",,"",1499,"Maj",1
4174,"ViewTranslation","Jun [abbreviated month]","",,"",1499,"Jun",1
4175,"ViewTranslation","Jul [abbreviated month]","",,"",1499,"Jul",1
4176,"ViewTranslation","Aug [abbreviated month]","",,"",1499,"Aug",1
4177,"ViewTranslation","Sep [abbreviated month]","",,"",1499,"Sep",1
4178,"ViewTranslation","Oct [abbreviated month]","",,"",1499,"Okt",1
4179,"ViewTranslation","Nov [abbreviated month]","",,"",1499,"Nov",1
4180,"ViewTranslation","Dec [abbreviated month]","",,"",1499,"Dec",1
4181,"ViewTranslation","Sunday [weekday]","",,"",1793,"Κυριακή",1
4182,"ViewTranslation","Monday [weekday]","",,"",1793,"Δευτέρα",1
4183,"ViewTranslation","Tuesday [weekday]","",,"",1793,"Τρίτη",1
4184,"ViewTranslation","Wednesday [weekday]","",,"",1793,"Τετάρτη",1
4185,"ViewTranslation","Thursday [weekday]","",,"",1793,"Πέμπτη",1
4186,"ViewTranslation","Friday [weekday]","",,"",1793,"Παρασκευή",1
4187,"ViewTranslation","Saturday [weekday]","",,"",1793,"Σάββατο",1
4188,"ViewTranslation","Sun [abbreviated weekday]","",,"",1793,"Κυρ",1
4189,"ViewTranslation","Mon [abbreviated weekday]","",,"",1793,"Δευ",1
4190,"ViewTranslation","Tue [abbreviated weekday]","",,"",1793,"Τρι",1
4191,"ViewTranslation","Wed [abbreviated weekday]","",,"",1793,"Τετ",1
4192,"ViewTranslation","Thu [abbreviated weekday]","",,"",1793,"Πεμ",1
4193,"ViewTranslation","Fri [abbreviated weekday]","",,"",1793,"Παρ",1
4194,"ViewTranslation","Sat [abbreviated weekday]","",,"",1793,"Σαβ",1
4195,"ViewTranslation","January [month]","",,"",1793,"Ιανουάριος",1
4196,"ViewTranslation","February [month]","",,"",1793,"Φεβρουάριος",1
4197,"ViewTranslation","March [month]","",,"",1793,"Μάρτιος",1
4198,"ViewTranslation","April [month]","",,"",1793,"Απρίλιος",1
4199,"ViewTranslation","May [month]","",,"",1793,"Μάιος",1
4200,"ViewTranslation","June [month]","",,"",1793,"Ιούνιος",1
4201,"ViewTranslation","July [month]","",,"",1793,"Ιούλιος",1
4202,"ViewTranslation","August [month]","",,"",1793,"Αύγουστος",1
4203,"ViewTranslation","September [month]","",,"",1793,"Σεπτέμβριος",1
4204,"ViewTranslation","October [month]","",,"",1793,"Οκτώβριος",1
4205,"ViewTranslation","November [month]","",,"",1793,"Νοέμβριος",1
4206,"ViewTranslation","December [month]","",,"",1793,"Δεκέμβριος",1
4207,"ViewTranslation","Jan [abbreviated month]","",,"",1793,"Ιαν",1
4208,"ViewTranslation","Feb [abbreviated month]","",,"",1793,"Φεβ",1
4209,"ViewTranslation","Mar [abbreviated month]","",,"",1793,"Μάρ",1
4210,"ViewTranslation","Apr [abbreviated month]","",,"",1793,"Απρ",1
4211,"ViewTranslation","May [abbreviated month]","",,"",1793,"Μάι",1
4212,"ViewTranslation","Jun [abbreviated month]","",,"",1793,"Ιούν",1
4213,"ViewTranslation","Jul [abbreviated month]","",,"",1793,"Ιούλ",1
4214,"ViewTranslation","Aug [abbreviated month]","",,"",1793,"Αύγ",1
4215,"ViewTranslation","Sep [abbreviated month]","",,"",1793,"Σεπ",1
4216,"ViewTranslation","Oct [abbreviated month]","",,"",1793,"Οκτ",1
4217,"ViewTranslation","Nov [abbreviated month]","",,"",1793,"Νοέ",1
4218,"ViewTranslation","Dec [abbreviated month]","",,"",1793,"Δεκ",1
4219,"ViewTranslation","Sunday [weekday]","",,"",1819,"Sunday",1
4220,"ViewTranslation","Monday [weekday]","",,"",1819,"Monday",1
4221,"ViewTranslation","Tuesday [weekday]","",,"",1819,"Tuesday",1
4222,"ViewTranslation","Wednesday [weekday]","",,"",1819,"Wednesday",1
4223,"ViewTranslation","Thursday [weekday]","",,"",1819,"Thursday",1
4224,"ViewTranslation","Friday [weekday]","",,"",1819,"Friday",1
4225,"ViewTranslation","Saturday [weekday]","",,"",1819,"Saturday",1
4226,"ViewTranslation","Sun [abbreviated weekday]","",,"",1819,"Sun",1
4227,"ViewTranslation","Mon [abbreviated weekday]","",,"",1819,"Mon",1
4228,"ViewTranslation","Tue [abbreviated weekday]","",,"",1819,"Tue",1
4229,"ViewTranslation","Wed [abbreviated weekday]","",,"",1819,"Wed",1
4230,"ViewTranslation","Thu [abbreviated weekday]","",,"",1819,"Thu",1
4231,"ViewTranslation","Fri [abbreviated weekday]","",,"",1819,"Fri",1
4232,"ViewTranslation","Sat [abbreviated weekday]","",,"",1819,"Sat",1
4233,"ViewTranslation","January [month]","",,"",1819,"January",1
4234,"ViewTranslation","February [month]","",,"",1819,"February",1
4235,"ViewTranslation","March [month]","",,"",1819,"March",1
4236,"ViewTranslation","April [month]","",,"",1819,"April",1
4237,"ViewTranslation","May [month]","",,"",1819,"May",1
4238,"ViewTranslation","June [month]","",,"",1819,"June",1
4239,"ViewTranslation","July [month]","",,"",1819,"July",1
4240,"ViewTranslation","August [month]","",,"",1819,"August",1
4241,"ViewTranslation","September [month]","",,"",1819,"September",1
4242,"ViewTranslation","October [month]","",,"",1819,"October",1
4243,"ViewTranslation","November [month]","",,"",1819,"November",1
4244,"ViewTranslation","December [month]","",,"",1819,"December",1
4245,"ViewTranslation","Jan [abbreviated month]","",,"",1819,"Jan",1
4246,"ViewTranslation","Feb [abbreviated month]","",,"",1819,"Feb",1
4247,"ViewTranslation","Mar [abbreviated month]","",,"",1819,"Mar",1
4248,"ViewTranslation","Apr [abbreviated month]","",,"",1819,"Apr",1
4249,"ViewTranslation","May [abbreviated month]","",,"",1819,"May",1
4250,"ViewTranslation","Jun [abbreviated month]","",,"",1819,"Jun",1
4251,"ViewTranslation","Jul [abbreviated month]","",,"",1819,"Jul",1
4252,"ViewTranslation","Aug [abbreviated month]","",,"",1819,"Aug",1
4253,"ViewTranslation","Sep [abbreviated month]","",,"",1819,"Sep",1
4254,"ViewTranslation","Oct [abbreviated month]","",,"",1819,"Oct",1
4255,"ViewTranslation","Nov [abbreviated month]","",,"",1819,"Nov",1
4256,"ViewTranslation","Dec [abbreviated month]","",,"",1819,"Dec",1
4257,"ViewTranslation","Sunday [weekday]","",,"",5889,"Domingo",1
4258,"ViewTranslation","Monday [weekday]","",,"",5889,"Lunes",1
4259,"ViewTranslation","Tuesday [weekday]","",,"",5889,"Martes",1
4260,"ViewTranslation","Wednesday [weekday]","",,"",5889,"Miércoles",1
4261,"ViewTranslation","Thursday [weekday]","",,"",5889,"Jueves",1
4262,"ViewTranslation","Friday [weekday]","",,"",5889,"Viernes",1
4263,"ViewTranslation","Saturday [weekday]","",,"",5889,"Sábado",1
4264,"ViewTranslation","Sun [abbreviated weekday]","",,"",5889,"Dom",1
4265,"ViewTranslation","Mon [abbreviated weekday]","",,"",5889,"Lun",1
4266,"ViewTranslation","Tue [abbreviated weekday]","",,"",5889,"Mar",1
4267,"ViewTranslation","Wed [abbreviated weekday]","",,"",5889,"Mié",1
4268,"ViewTranslation","Thu [abbreviated weekday]","",,"",5889,"Jue",1
4269,"ViewTranslation","Fri [abbreviated weekday]","",,"",5889,"Vie",1
4270,"ViewTranslation","Sat [abbreviated weekday]","",,"",5889,"Sáb",1
4271,"ViewTranslation","January [month]","",,"",5889,"Enero",1
4272,"ViewTranslation","February [month]","",,"",5889,"Febrero",1
4273,"ViewTranslation","March [month]","",,"",5889,"Marzo",1
4274,"ViewTranslation","April [month]","",,"",5889,"Abril",1
4275,"ViewTranslation","May [month]","",,"",5889,"Mayo",1
4276,"ViewTranslation","June [month]","",,"",5889,"Junio",1
4277,"ViewTranslation","July [month]","",,"",5889,"Julio",1
4278,"ViewTranslation","August [month]","",,"",5889,"Agosto",1
4279,"ViewTranslation","September [month]","",,"",5889,"Septiembre",1
4280,"ViewTranslation","October [month]","",,"",5889,"Octubre",1
4281,"ViewTranslation","November [month]","",,"",5889,"Noviembre",1
4282,"ViewTranslation","December [month]","",,"",5889,"Diciembre",1
4283,"ViewTranslation","Jan [abbreviated month]","",,"",5889,"Ene",1
4284,"ViewTranslation","Feb [abbreviated month]","",,"",5889,"Feb",1
4285,"ViewTranslation","Mar [abbreviated month]","",,"",5889,"Mar",1
4286,"ViewTranslation","Apr [abbreviated month]","",,"",5889,"Abr",1
4287,"ViewTranslation","May [abbreviated month]","",,"",5889,"May",1
4288,"ViewTranslation","Jun [abbreviated month]","",,"",5889,"Jun",1
4289,"ViewTranslation","Jul [abbreviated month]","",,"",5889,"Jul",1
4290,"ViewTranslation","Aug [abbreviated month]","",,"",5889,"Ago",1
4291,"ViewTranslation","Sep [abbreviated month]","",,"",5889,"Sep",1
4292,"ViewTranslation","Oct [abbreviated month]","",,"",5889,"Oct",1
4293,"ViewTranslation","Nov [abbreviated month]","",,"",5889,"Nov",1
4294,"ViewTranslation","Dec [abbreviated month]","",,"",5889,"Dic",1
4295,"ViewTranslation","Sunday [weekday]","",,"",1851,"Pühapäev",1
4296,"ViewTranslation","Monday [weekday]","",,"",1851,"Esmaspäev",1
4297,"ViewTranslation","Tuesday [weekday]","",,"",1851,"Teisipäev",1
4298,"ViewTranslation","Wednesday [weekday]","",,"",1851,"Kolmapäev",1
4299,"ViewTranslation","Thursday [weekday]","",,"",1851,"Neljapäev",1
4300,"ViewTranslation","Friday [weekday]","",,"",1851,"Reede",1
4301,"ViewTranslation","Saturday [weekday]","",,"",1851,"Laupäev",1
4302,"ViewTranslation","Sun [abbreviated weekday]","",,"",1851,"P",1
4303,"ViewTranslation","Mon [abbreviated weekday]","",,"",1851,"E",1
4304,"ViewTranslation","Tue [abbreviated weekday]","",,"",1851,"T",1
4305,"ViewTranslation","Wed [abbreviated weekday]","",,"",1851,"K",1
4306,"ViewTranslation","Thu [abbreviated weekday]","",,"",1851,"N",1
4307,"ViewTranslation","Fri [abbreviated weekday]","",,"",1851,"R",1
4308,"ViewTranslation","Sat [abbreviated weekday]","",,"",1851,"L",1
4309,"ViewTranslation","January [month]","",,"",1851,"Jaanuar",1
4310,"ViewTranslation","February [month]","",,"",1851,"Veebruar",1
4311,"ViewTranslation","March [month]","",,"",1851,"Märts",1
4312,"ViewTranslation","April [month]","",,"",1851,"Aprill",1
4313,"ViewTranslation","May [month]","",,"",1851,"Mai",1
4314,"ViewTranslation","June [month]","",,"",1851,"Juuni",1
4315,"ViewTranslation","July [month]","",,"",1851,"Juuli",1
4316,"ViewTranslation","August [month]","",,"",1851,"August",1
4317,"ViewTranslation","September [month]","",,"",1851,"September",1
4318,"ViewTranslation","October [month]","",,"",1851,"Oktoober",1
4319,"ViewTranslation","November [month]","",,"",1851,"November",1
4320,"ViewTranslation","December [month]","",,"",1851,"Detsember",1
4321,"ViewTranslation","Jan [abbreviated month]","",,"",1851,"Jaan ",1
4322,"ViewTranslation","Feb [abbreviated month]","",,"",1851,"Veebr",1
4323,"ViewTranslation","Mar [abbreviated month]","",,"",1851,"Märts",1
4324,"ViewTranslation","Apr [abbreviated month]","",,"",1851,"Apr ",1
4325,"ViewTranslation","May [abbreviated month]","",,"",1851,"Mai ",1
4326,"ViewTranslation","Jun [abbreviated month]","",,"",1851,"Juuni",1
4327,"ViewTranslation","Jul [abbreviated month]","",,"",1851,"Juuli",1
4328,"ViewTranslation","Aug [abbreviated month]","",,"",1851,"Aug ",1
4329,"ViewTranslation","Sep [abbreviated month]","",,"",1851,"Sept ",1
4330,"ViewTranslation","Oct [abbreviated month]","",,"",1851,"Okt ",1
4331,"ViewTranslation","Nov [abbreviated month]","",,"",1851,"Nov ",1
4332,"ViewTranslation","Dec [abbreviated month]","",,"",1851,"Dets ",1
4333,"ViewTranslation","Sunday [weekday]","",,"",1865,"Igandea",1
4334,"ViewTranslation","Monday [weekday]","",,"",1865,"Astelehena",1
4335,"ViewTranslation","Tuesday [weekday]","",,"",1865,"Asteartea",1
4336,"ViewTranslation","Wednesday [weekday]","",,"",1865,"Asteazkena",1
4337,"ViewTranslation","Thursday [weekday]","",,"",1865,"Osteguna",1
4338,"ViewTranslation","Friday [weekday]","",,"",1865,"Ostirala",1
4339,"ViewTranslation","Saturday [weekday]","",,"",1865,"Larunbata",1
4340,"ViewTranslation","Sun [abbreviated weekday]","",,"",1865,"Ig.",1
4341,"ViewTranslation","Mon [abbreviated weekday]","",,"",1865,"Al.",1
4342,"ViewTranslation","Tue [abbreviated weekday]","",,"",1865,"Ar.",1
4343,"ViewTranslation","Wed [abbreviated weekday]","",,"",1865,"Az.",1
4344,"ViewTranslation","Thu [abbreviated weekday]","",,"",1865,"Og.",1
4345,"ViewTranslation","Fri [abbreviated weekday]","",,"",1865,"Or.",1
4346,"ViewTranslation","Sat [abbreviated weekday]","",,"",1865,"Lr.",1
4347,"ViewTranslation","January [month]","",,"",1865,"Urtarrila",1
4348,"ViewTranslation","February [month]","",,"",1865,"Otsaila",1
4349,"ViewTranslation","March [month]","",,"",1865,"Martxoa",1
4350,"ViewTranslation","April [month]","",,"",1865,"Apirila",1
4351,"ViewTranslation","May [month]","",,"",1865,"Maiatza",1
4352,"ViewTranslation","June [month]","",,"",1865,"Ekaina",1
4353,"ViewTranslation","July [month]","",,"",1865,"Uztaila",1
4354,"ViewTranslation","August [month]","",,"",1865,"Abuztua",1
4355,"ViewTranslation","September [month]","",,"",1865,"Iraila",1
4356,"ViewTranslation","October [month]","",,"",1865,"Urria",1
4357,"ViewTranslation","November [month]","",,"",1865,"Azaroa",1
4358,"ViewTranslation","December [month]","",,"",1865,"Abendua",1
4359,"ViewTranslation","Jan [abbreviated month]","",,"",1865,"Urt",1
4360,"ViewTranslation","Feb [abbreviated month]","",,"",1865,"Ots",1
4361,"ViewTranslation","Mar [abbreviated month]","",,"",1865,"Mar",1
4362,"ViewTranslation","Apr [abbreviated month]","",,"",1865,"Api",1
4363,"ViewTranslation","May [abbreviated month]","",,"",1865,"Mai",1
4364,"ViewTranslation","Jun [abbreviated month]","",,"",1865,"Eka",1
4365,"ViewTranslation","Jul [abbreviated month]","",,"",1865,"Uzt",1
4366,"ViewTranslation","Aug [abbreviated month]","",,"",1865,"Abu",1
4367,"ViewTranslation","Sep [abbreviated month]","",,"",1865,"Ira",1
4368,"ViewTranslation","Oct [abbreviated month]","",,"",1865,"Urr",1
4369,"ViewTranslation","Nov [abbreviated month]","",,"",1865,"Aza",1
4370,"ViewTranslation","Dec [abbreviated month]","",,"",1865,"Abe",1
4371,"ViewTranslation","Sunday [weekday]","",,"",1889,"یک‌شنبه",1
4372,"ViewTranslation","Monday [weekday]","",,"",1889,"دوشنبه",1
4373,"ViewTranslation","Tuesday [weekday]","",,"",1889,"سه‌شنبه",1
4374,"ViewTranslation","Wednesday [weekday]","",,"",1889,"چهارشنبه",1
4375,"ViewTranslation","Thursday [weekday]","",,"",1889,"پنج‌شنبه",1
4376,"ViewTranslation","Friday [weekday]","",,"",1889,"جمعه",1
4377,"ViewTranslation","Saturday [weekday]","",,"",1889,"شنبه",1
4378,"ViewTranslation","Sun [abbreviated weekday]","",,"",1889,"ی.",1
4379,"ViewTranslation","Mon [abbreviated weekday]","",,"",1889,"د.",1
4380,"ViewTranslation","Tue [abbreviated weekday]","",,"",1889,"س.",1
4381,"ViewTranslation","Wed [abbreviated weekday]","",,"",1889,"چ.",1
4382,"ViewTranslation","Thu [abbreviated weekday]","",,"",1889,"پ.",1
4383,"ViewTranslation","Fri [abbreviated weekday]","",,"",1889,"ج.",1
4384,"ViewTranslation","Sat [abbreviated weekday]","",,"",1889,"ش.",1
4385,"ViewTranslation","January [month]","",,"",1889,"ژانویه",1
4386,"ViewTranslation","February [month]","",,"",1889,"فوریه",1
4387,"ViewTranslation","March [month]","",,"",1889,"مارس",1
4388,"ViewTranslation","April [month]","",,"",1889,"آوریل",1
4389,"ViewTranslation","May [month]","",,"",1889,"مه",1
4390,"ViewTranslation","June [month]","",,"",1889,"ژوئن",1
4391,"ViewTranslation","July [month]","",,"",1889,"ژوئیه",1
4392,"ViewTranslation","August [month]","",,"",1889,"اوت",1
4393,"ViewTranslation","September [month]","",,"",1889,"سپتامبر",1
4394,"ViewTranslation","October [month]","",,"",1889,"اكتبر",1
4395,"ViewTranslation","November [month]","",,"",1889,"نوامبر",1
4396,"ViewTranslation","December [month]","",,"",1889,"دسامبر",1
4397,"ViewTranslation","Jan [abbreviated month]","",,"",1889,"ژان",1
4398,"ViewTranslation","Feb [abbreviated month]","",,"",1889,"فور",1
4399,"ViewTranslation","Mar [abbreviated month]","",,"",1889,"مار",1
4400,"ViewTranslation","Apr [abbreviated month]","",,"",1889,"آور",1
4401,"ViewTranslation","May [abbreviated month]","",,"",1889,"مـه",1
4402,"ViewTranslation","Jun [abbreviated month]","",,"",1889,"ژون",1
4403,"ViewTranslation","Jul [abbreviated month]","",,"",1889,"ژوی",1
4404,"ViewTranslation","Aug [abbreviated month]","",,"",1889,"اوت",1
4405,"ViewTranslation","Sep [abbreviated month]","",,"",1889,"سپت",1
4406,"ViewTranslation","Oct [abbreviated month]","",,"",1889,"اكت",1
4407,"ViewTranslation","Nov [abbreviated month]","",,"",1889,"نوا",1
4408,"ViewTranslation","Dec [abbreviated month]","",,"",1889,"دسا",1
4409,"ViewTranslation","Sunday [weekday]","",,"",1903,"Sunnuntai",1
4410,"ViewTranslation","Monday [weekday]","",,"",1903,"Maanantai",1
4411,"ViewTranslation","Tuesday [weekday]","",,"",1903,"Tiistai",1
4412,"ViewTranslation","Wednesday [weekday]","",,"",1903,"Keskiviikko",1
4413,"ViewTranslation","Thursday [weekday]","",,"",1903,"Torstai",1
4414,"ViewTranslation","Friday [weekday]","",,"",1903,"Perjantai",1
4415,"ViewTranslation","Saturday [weekday]","",,"",1903,"Lauantai",1
4416,"ViewTranslation","Sun [abbreviated weekday]","",,"",1903,"Su",1
4417,"ViewTranslation","Mon [abbreviated weekday]","",,"",1903,"Ma",1
4418,"ViewTranslation","Tue [abbreviated weekday]","",,"",1903,"Ti",1
4419,"ViewTranslation","Wed [abbreviated weekday]","",,"",1903,"Ke",1
4420,"ViewTranslation","Thu [abbreviated weekday]","",,"",1903,"To",1
4421,"ViewTranslation","Fri [abbreviated weekday]","",,"",1903,"Pe",1
4422,"ViewTranslation","Sat [abbreviated weekday]","",,"",1903,"La",1
4423,"ViewTranslation","January [month]","",,"",1903,"Tammikuu",1
4424,"ViewTranslation","February [month]","",,"",1903,"Helmikuu",1
4425,"ViewTranslation","March [month]","",,"",1903,"Maaliskuu",1
4426,"ViewTranslation","April [month]","",,"",1903,"Huhtikuu",1
4427,"ViewTranslation","May [month]","",,"",1903,"Toukokuu",1
4428,"ViewTranslation","June [month]","",,"",1903,"Kesäkuu",1
4429,"ViewTranslation","July [month]","",,"",1903,"Heinäkuu",1
4430,"ViewTranslation","August [month]","",,"",1903,"Elokuu",1
4431,"ViewTranslation","September [month]","",,"",1903,"Syyskuu",1
4432,"ViewTranslation","October [month]","",,"",1903,"Lokakuu",1
4433,"ViewTranslation","November [month]","",,"",1903,"Marraskuu",1
4434,"ViewTranslation","December [month]","",,"",1903,"Joulukuu",1
4435,"ViewTranslation","Jan [abbreviated month]","",,"",1903,"Tammi ",1
4436,"ViewTranslation","Feb [abbreviated month]","",,"",1903,"Helmi ",1
4437,"ViewTranslation","Mar [abbreviated month]","",,"",1903,"Maalis",1
4438,"ViewTranslation","Apr [abbreviated month]","",,"",1903,"Huhti ",1
4439,"ViewTranslation","May [abbreviated month]","",,"",1903,"Touko ",1
4440,"ViewTranslation","Jun [abbreviated month]","",,"",1903,"Kesä  ",1
4441,"ViewTranslation","Jul [abbreviated month]","",,"",1903,"Heinä ",1
4442,"ViewTranslation","Aug [abbreviated month]","",,"",1903,"Elo   ",1
4443,"ViewTranslation","Sep [abbreviated month]","",,"",1903,"Syys  ",1
4444,"ViewTranslation","Oct [abbreviated month]","",,"",1903,"Loka  ",1
4445,"ViewTranslation","Nov [abbreviated month]","",,"",1903,"Marras",1
4446,"ViewTranslation","Dec [abbreviated month]","",,"",1903,"Joulu ",1
4447,"ViewTranslation","Sunday [weekday]","",,"",1886,"Sunnudagur",1
4448,"ViewTranslation","Monday [weekday]","",,"",1886,"Mánadagur",1
4449,"ViewTranslation","Tuesday [weekday]","",,"",1886,"Týsdagur",1
4450,"ViewTranslation","Wednesday [weekday]","",,"",1886,"Mikudagur",1
4451,"ViewTranslation","Thursday [weekday]","",,"",1886,"Hósdagur",1
4452,"ViewTranslation","Friday [weekday]","",,"",1886,"Fríggjadagur",1
4453,"ViewTranslation","Saturday [weekday]","",,"",1886,"Leygardagur",1
4454,"ViewTranslation","Sun [abbreviated weekday]","",,"",1886,"Sun",1
4455,"ViewTranslation","Mon [abbreviated weekday]","",,"",1886,"Mán",1
4456,"ViewTranslation","Tue [abbreviated weekday]","",,"",1886,"Týs",1
4457,"ViewTranslation","Wed [abbreviated weekday]","",,"",1886,"Mik",1
4458,"ViewTranslation","Thu [abbreviated weekday]","",,"",1886,"Hós",1
4459,"ViewTranslation","Fri [abbreviated weekday]","",,"",1886,"Frí",1
4460,"ViewTranslation","Sat [abbreviated weekday]","",,"",1886,"Ley",1
4461,"ViewTranslation","January [month]","",,"",1886,"Januar",1
4462,"ViewTranslation","February [month]","",,"",1886,"Februar",1
4463,"ViewTranslation","March [month]","",,"",1886,"Mars",1
4464,"ViewTranslation","April [month]","",,"",1886,"Apríl",1
4465,"ViewTranslation","May [month]","",,"",1886,"Mai",1
4466,"ViewTranslation","June [month]","",,"",1886,"Juni",1
4467,"ViewTranslation","July [month]","",,"",1886,"Juli",1
4468,"ViewTranslation","August [month]","",,"",1886,"August",1
4469,"ViewTranslation","September [month]","",,"",1886,"September",1
4470,"ViewTranslation","October [month]","",,"",1886,"Oktober",1
4471,"ViewTranslation","November [month]","",,"",1886,"November",1
4472,"ViewTranslation","December [month]","",,"",1886,"Desember",1
4473,"ViewTranslation","Jan [abbreviated month]","",,"",1886,"Jan",1
4474,"ViewTranslation","Feb [abbreviated month]","",,"",1886,"Feb",1
4475,"ViewTranslation","Mar [abbreviated month]","",,"",1886,"Mar",1
4476,"ViewTranslation","Apr [abbreviated month]","",,"",1886,"Apr",1
4477,"ViewTranslation","May [abbreviated month]","",,"",1886,"Mai",1
4478,"ViewTranslation","Jun [abbreviated month]","",,"",1886,"Jun",1
4479,"ViewTranslation","Jul [abbreviated month]","",,"",1886,"Jul",1
4480,"ViewTranslation","Aug [abbreviated month]","",,"",1886,"Aug",1
4481,"ViewTranslation","Sep [abbreviated month]","",,"",1886,"Sep",1
4482,"ViewTranslation","Oct [abbreviated month]","",,"",1886,"Okt",1
4483,"ViewTranslation","Nov [abbreviated month]","",,"",1886,"Nov",1
4484,"ViewTranslation","Dec [abbreviated month]","",,"",1886,"Des",1
4485,"ViewTranslation","Sunday [weekday]","",,"",1930,"Dimanche",1
4486,"ViewTranslation","Monday [weekday]","",,"",1930,"Lundi",1
4487,"ViewTranslation","Tuesday [weekday]","",,"",1930,"Mardi",1
4488,"ViewTranslation","Wednesday [weekday]","",,"",1930,"Mercredi",1
4489,"ViewTranslation","Thursday [weekday]","",,"",1930,"Jeudi",1
4490,"ViewTranslation","Friday [weekday]","",,"",1930,"Vendredi",1
4491,"ViewTranslation","Saturday [weekday]","",,"",1930,"Samedi",1
4492,"ViewTranslation","Sun [abbreviated weekday]","",,"",1930,"Dim",1
4493,"ViewTranslation","Mon [abbreviated weekday]","",,"",1930,"Lun",1
4494,"ViewTranslation","Tue [abbreviated weekday]","",,"",1930,"Mar",1
4495,"ViewTranslation","Wed [abbreviated weekday]","",,"",1930,"Mer",1
4496,"ViewTranslation","Thu [abbreviated weekday]","",,"",1930,"Jeu",1
4497,"ViewTranslation","Fri [abbreviated weekday]","",,"",1930,"Ven",1
4498,"ViewTranslation","Sat [abbreviated weekday]","",,"",1930,"Sam",1
4499,"ViewTranslation","January [month]","",,"",1930,"Janvier",1
4500,"ViewTranslation","February [month]","",,"",1930,"Février",1
4501,"ViewTranslation","March [month]","",,"",1930,"Mars",1
4502,"ViewTranslation","April [month]","",,"",1930,"Avril",1
4503,"ViewTranslation","May [month]","",,"",1930,"Mai",1
4504,"ViewTranslation","June [month]","",,"",1930,"Juin",1
4505,"ViewTranslation","July [month]","",,"",1930,"Juillet",1
4506,"ViewTranslation","August [month]","",,"",1930,"Août",1
4507,"ViewTranslation","September [month]","",,"",1930,"Septembre",1
4508,"ViewTranslation","October [month]","",,"",1930,"Octobre",1
4509,"ViewTranslation","November [month]","",,"",1930,"Novembre",1
4510,"ViewTranslation","December [month]","",,"",1930,"Décembre",1
4511,"ViewTranslation","Jan [abbreviated month]","",,"",1930,"Jan",1
4512,"ViewTranslation","Feb [abbreviated month]","",,"",1930,"Fév",1
4513,"ViewTranslation","Mar [abbreviated month]","",,"",1930,"Mar",1
4514,"ViewTranslation","Apr [abbreviated month]","",,"",1930,"Avr",1
4515,"ViewTranslation","May [abbreviated month]","",,"",1930,"Mai",1
4516,"ViewTranslation","Jun [abbreviated month]","",,"",1930,"Jun",1
4517,"ViewTranslation","Jul [abbreviated month]","",,"",1930,"Jui",1
4518,"ViewTranslation","Aug [abbreviated month]","",,"",1930,"Aoû",1
4519,"ViewTranslation","Sep [abbreviated month]","",,"",1930,"Sep",1
4520,"ViewTranslation","Oct [abbreviated month]","",,"",1930,"Oct",1
4521,"ViewTranslation","Nov [abbreviated month]","",,"",1930,"Nov",1
4522,"ViewTranslation","Dec [abbreviated month]","",,"",1930,"Déc",1
4523,"ViewTranslation","Sunday [weekday]","",,"",2115,"Dé domhnaigh",1
4524,"ViewTranslation","Monday [weekday]","",,"",2115,"Dé luain",1
4525,"ViewTranslation","Tuesday [weekday]","",,"",2115,"Dé máirt",1
4526,"ViewTranslation","Wednesday [weekday]","",,"",2115,"Dé céadaoin",1
4527,"ViewTranslation","Thursday [weekday]","",,"",2115,"Déardaoin",1
4528,"ViewTranslation","Friday [weekday]","",,"",2115,"Dé haoine",1
4529,"ViewTranslation","Saturday [weekday]","",,"",2115,"Dé sathairn",1
4530,"ViewTranslation","Sun [abbreviated weekday]","",,"",2115,"Domh",1
4531,"ViewTranslation","Mon [abbreviated weekday]","",,"",2115,"Luan",1
4532,"ViewTranslation","Tue [abbreviated weekday]","",,"",2115,"Máirt",1
4533,"ViewTranslation","Wed [abbreviated weekday]","",,"",2115,"Céad",1
4534,"ViewTranslation","Thu [abbreviated weekday]","",,"",2115,"Déar",1
4535,"ViewTranslation","Fri [abbreviated weekday]","",,"",2115,"Aoine",1
4536,"ViewTranslation","Sat [abbreviated weekday]","",,"",2115,"Sath",1
4537,"ViewTranslation","January [month]","",,"",2115,"Eanáir",1
4538,"ViewTranslation","February [month]","",,"",2115,"Feabhra",1
4539,"ViewTranslation","March [month]","",,"",2115,"Márta",1
4540,"ViewTranslation","April [month]","",,"",2115,"Aibreán",1
4541,"ViewTranslation","May [month]","",,"",2115,"Mí na bealtaine",1
4542,"ViewTranslation","June [month]","",,"",2115,"Meith",1
4543,"ViewTranslation","July [month]","",,"",2115,"Iúil",1
4544,"ViewTranslation","August [month]","",,"",2115,"Lúnasa",1
4545,"ViewTranslation","September [month]","",,"",2115,"Meán fómhair",1
4546,"ViewTranslation","October [month]","",,"",2115,"Deireadh fómhair",1
4547,"ViewTranslation","November [month]","",,"",2115,"Mí na samhna",1
4548,"ViewTranslation","December [month]","",,"",2115,"Mí na nollag",1
4549,"ViewTranslation","Jan [abbreviated month]","",,"",2115,"Ean",1
4550,"ViewTranslation","Feb [abbreviated month]","",,"",2115,"Feabh",1
4551,"ViewTranslation","Mar [abbreviated month]","",,"",2115,"Márta",1
4552,"ViewTranslation","Apr [abbreviated month]","",,"",2115,"Aib",1
4553,"ViewTranslation","May [abbreviated month]","",,"",2115,"Beal",1
4554,"ViewTranslation","Jun [abbreviated month]","",,"",2115,"Meith",1
4555,"ViewTranslation","Jul [abbreviated month]","",,"",2115,"Iúil",1
4556,"ViewTranslation","Aug [abbreviated month]","",,"",2115,"Lún",1
4557,"ViewTranslation","Sep [abbreviated month]","",,"",2115,"Mfómh",1
4558,"ViewTranslation","Oct [abbreviated month]","",,"",2115,"Dfómh",1
4559,"ViewTranslation","Nov [abbreviated month]","",,"",2115,"Samh",1
4560,"ViewTranslation","Dec [abbreviated month]","",,"",2115,"Noll",1
4561,"ViewTranslation","Sunday [weekday]","",,"",2112,"Didòmhnaich",1
4562,"ViewTranslation","Monday [weekday]","",,"",2112,"Diluain",1
4563,"ViewTranslation","Tuesday [weekday]","",,"",2112,"Dimàirt",1
4564,"ViewTranslation","Wednesday [weekday]","",,"",2112,"Diciadain",1
4565,"ViewTranslation","Thursday [weekday]","",,"",2112,"Diardaoin",1
4566,"ViewTranslation","Friday [weekday]","",,"",2112,"Dihaoine",1
4567,"ViewTranslation","Saturday [weekday]","",,"",2112,"Disathairne",1
4568,"ViewTranslation","Sun [abbreviated weekday]","",,"",2112,"Dido",1
4569,"ViewTranslation","Mon [abbreviated weekday]","",,"",2112,"Dilu",1
4570,"ViewTranslation","Tue [abbreviated weekday]","",,"",2112,"Dim",1
4571,"ViewTranslation","Wed [abbreviated weekday]","",,"",2112,"Dic",1
4572,"ViewTranslation","Thu [abbreviated weekday]","",,"",2112,"Diar",1
4573,"ViewTranslation","Fri [abbreviated weekday]","",,"",2112,"Diha",1
4574,"ViewTranslation","Sat [abbreviated weekday]","",,"",2112,"Disa",1
4575,"ViewTranslation","January [month]","",,"",2112,"Am faoilteach",1
4576,"ViewTranslation","February [month]","",,"",2112,"An gearran",1
4577,"ViewTranslation","March [month]","",,"",2112,"Am màrt",1
4578,"ViewTranslation","April [month]","",,"",2112,"An giblean",1
4579,"ViewTranslation","May [month]","",,"",2112,"A' mhàigh",1
4580,"ViewTranslation","June [month]","",,"",2112,"An t-mhìos",1
4581,"ViewTranslation","July [month]","",,"",2112,"An t-luchar",1
4582,"ViewTranslation","August [month]","",,"",2112,"An lùnasdal",1
4583,"ViewTranslation","September [month]","",,"",2112,"An t-sultain",1
4584,"ViewTranslation","October [month]","",,"",2112,"An damhair",1
4585,"ViewTranslation","November [month]","",,"",2112,"An t-samhain",1
4586,"ViewTranslation","December [month]","",,"",2112,"An dùbhlachd",1
4587,"ViewTranslation","Jan [abbreviated month]","",,"",2112,"Fao",1
4588,"ViewTranslation","Feb [abbreviated month]","",,"",2112,"Gea",1
4589,"ViewTranslation","Mar [abbreviated month]","",,"",2112,"Màr",1
4590,"ViewTranslation","Apr [abbreviated month]","",,"",2112,"Gib",1
4591,"ViewTranslation","May [abbreviated month]","",,"",2112,"Mhà",1
4592,"ViewTranslation","Jun [abbreviated month]","",,"",2112,"Ogm",1
4593,"ViewTranslation","Jul [abbreviated month]","",,"",2112,"Luc",1
4594,"ViewTranslation","Aug [abbreviated month]","",,"",2112,"Lùn",1
4595,"ViewTranslation","Sep [abbreviated month]","",,"",2112,"Sul",1
4596,"ViewTranslation","Oct [abbreviated month]","",,"",2112,"Dam",1
4597,"ViewTranslation","Nov [abbreviated month]","",,"",2112,"Sam",1
4598,"ViewTranslation","Dec [abbreviated month]","",,"",2112,"Dùb",1
4599,"ViewTranslation","Sunday [weekday]","",,"",2116,"Domingo",1
4600,"ViewTranslation","Monday [weekday]","",,"",2116,"Luns",1
4601,"ViewTranslation","Tuesday [weekday]","",,"",2116,"Martes",1
4602,"ViewTranslation","Wednesday [weekday]","",,"",2116,"Mércores",1
4603,"ViewTranslation","Thursday [weekday]","",,"",2116,"Xoves",1
4604,"ViewTranslation","Friday [weekday]","",,"",2116,"Venres",1
4605,"ViewTranslation","Saturday [weekday]","",,"",2116,"Sábado",1
4606,"ViewTranslation","Sun [abbreviated weekday]","",,"",2116,"Dom",1
4607,"ViewTranslation","Mon [abbreviated weekday]","",,"",2116,"Lun",1
4608,"ViewTranslation","Tue [abbreviated weekday]","",,"",2116,"Mar",1
4609,"ViewTranslation","Wed [abbreviated weekday]","",,"",2116,"Mér",1
4610,"ViewTranslation","Thu [abbreviated weekday]","",,"",2116,"Xov",1
4611,"ViewTranslation","Fri [abbreviated weekday]","",,"",2116,"Ven",1
4612,"ViewTranslation","Sat [abbreviated weekday]","",,"",2116,"Sáb",1
4613,"ViewTranslation","January [month]","",,"",2116,"Xaneiro",1
4614,"ViewTranslation","February [month]","",,"",2116,"Febreiro",1
4615,"ViewTranslation","March [month]","",,"",2116,"Marzo",1
4616,"ViewTranslation","April [month]","",,"",2116,"Abril",1
4617,"ViewTranslation","May [month]","",,"",2116,"Maio",1
4618,"ViewTranslation","June [month]","",,"",2116,"Xuño",1
4619,"ViewTranslation","July [month]","",,"",2116,"Xullo",1
4620,"ViewTranslation","August [month]","",,"",2116,"Agosto",1
4621,"ViewTranslation","September [month]","",,"",2116,"Setembro",1
4622,"ViewTranslation","October [month]","",,"",2116,"Outubro",1
4623,"ViewTranslation","November [month]","",,"",2116,"Novembro",1
4624,"ViewTranslation","December [month]","",,"",2116,"Decembro",1
4625,"ViewTranslation","Jan [abbreviated month]","",,"",2116,"Xan",1
4626,"ViewTranslation","Feb [abbreviated month]","",,"",2116,"Feb",1
4627,"ViewTranslation","Mar [abbreviated month]","",,"",2116,"Mar",1
4628,"ViewTranslation","Apr [abbreviated month]","",,"",2116,"Abr",1
4629,"ViewTranslation","May [abbreviated month]","",,"",2116,"Mai",1
4630,"ViewTranslation","Jun [abbreviated month]","",,"",2116,"Xuñ",1
4631,"ViewTranslation","Jul [abbreviated month]","",,"",2116,"Xul",1
4632,"ViewTranslation","Aug [abbreviated month]","",,"",2116,"Ago",1
4633,"ViewTranslation","Sep [abbreviated month]","",,"",2116,"Set",1
4634,"ViewTranslation","Oct [abbreviated month]","",,"",2116,"Out",1
4635,"ViewTranslation","Nov [abbreviated month]","",,"",2116,"Nov",1
4636,"ViewTranslation","Dec [abbreviated month]","",,"",2116,"Dec",1
4637,"ViewTranslation","Sunday [weekday]","",,"",2226,"રવિવાર",1
4638,"ViewTranslation","Monday [weekday]","",,"",2226,"સોમવાર",1
4639,"ViewTranslation","Tuesday [weekday]","",,"",2226,"મન્ગળવાર",1
4640,"ViewTranslation","Wednesday [weekday]","",,"",2226,"બુધવાર",1
4641,"ViewTranslation","Thursday [weekday]","",,"",2226,"ગુરુવાર",1
4642,"ViewTranslation","Friday [weekday]","",,"",2226,"શુક્રવાર",1
4643,"ViewTranslation","Saturday [weekday]","",,"",2226,"શનિવાર",1
4644,"ViewTranslation","Sun [abbreviated weekday]","",,"",2226,"રવિ",1
4645,"ViewTranslation","Mon [abbreviated weekday]","",,"",2226,"સોમ",1
4646,"ViewTranslation","Tue [abbreviated weekday]","",,"",2226,"મન્ગળ",1
4647,"ViewTranslation","Wed [abbreviated weekday]","",,"",2226,"બુધ",1
4648,"ViewTranslation","Thu [abbreviated weekday]","",,"",2226,"ગુરુ",1
4649,"ViewTranslation","Fri [abbreviated weekday]","",,"",2226,"શુક્ર",1
4650,"ViewTranslation","Sat [abbreviated weekday]","",,"",2226,"શનિ",1
4651,"ViewTranslation","January [month]","",,"",2226,"જાન્યુઆરી",1
4652,"ViewTranslation","February [month]","",,"",2226,"ફેબ્રુઆરી",1
4653,"ViewTranslation","March [month]","",,"",2226,"માર્ચ",1
4654,"ViewTranslation","April [month]","",,"",2226,"એપ્રિલ",1
4655,"ViewTranslation","May [month]","",,"",2226,"મે",1
4656,"ViewTranslation","June [month]","",,"",2226,"જુન",1
4657,"ViewTranslation","July [month]","",,"",2226,"જુલાઇ",1
4658,"ViewTranslation","August [month]","",,"",2226,"ઓગસ્ટ",1
4659,"ViewTranslation","September [month]","",,"",2226,"સેપ્ટેમ્બર",1
4660,"ViewTranslation","October [month]","",,"",2226,"ઓક્ટોબર",1
4661,"ViewTranslation","November [month]","",,"",2226,"નવેમ્બર",1
4662,"ViewTranslation","December [month]","",,"",2226,"ડિસેમ્બર",1
4663,"ViewTranslation","Jan [abbreviated month]","",,"",2226,"જાન",1
4664,"ViewTranslation","Feb [abbreviated month]","",,"",2226,"ફેબ",1
4665,"ViewTranslation","Mar [abbreviated month]","",,"",2226,"માર",1
4666,"ViewTranslation","Apr [abbreviated month]","",,"",2226,"એપ્ર",1
4667,"ViewTranslation","May [abbreviated month]","",,"",2226,"મે",1
4668,"ViewTranslation","Jun [abbreviated month]","",,"",2226,"જુન",1
4669,"ViewTranslation","Jul [abbreviated month]","",,"",2226,"જુલ",1
4670,"ViewTranslation","Aug [abbreviated month]","",,"",2226,"ઓગ",1
4671,"ViewTranslation","Sep [abbreviated month]","",,"",2226,"સેપ્ટ",1
4672,"ViewTranslation","Oct [abbreviated month]","",,"",2226,"ઓક્ટ",1
4673,"ViewTranslation","Nov [abbreviated month]","",,"",2226,"નોવ",1
4674,"ViewTranslation","Dec [abbreviated month]","",,"",2226,"ડિસ",1
4675,"ViewTranslation","Sunday [weekday]","",,"",2125,"Jedoonee",1
4676,"ViewTranslation","Monday [weekday]","",,"",2125,"Jelhein",1
4677,"ViewTranslation","Tuesday [weekday]","",,"",2125,"Jemayrt",1
4678,"ViewTranslation","Wednesday [weekday]","",,"",2125,"Jercean",1
4679,"ViewTranslation","Thursday [weekday]","",,"",2125,"Jerdein",1
4680,"ViewTranslation","Friday [weekday]","",,"",2125,"Jeheiney",1
4681,"ViewTranslation","Saturday [weekday]","",,"",2125,"Jesarn",1
4682,"ViewTranslation","Sun [abbreviated weekday]","",,"",2125,"Jed",1
4683,"ViewTranslation","Mon [abbreviated weekday]","",,"",2125,"Jel",1
4684,"ViewTranslation","Tue [abbreviated weekday]","",,"",2125,"Jem",1
4685,"ViewTranslation","Wed [abbreviated weekday]","",,"",2125,"Jerc",1
4686,"ViewTranslation","Thu [abbreviated weekday]","",,"",2125,"Jerd",1
4687,"ViewTranslation","Fri [abbreviated weekday]","",,"",2125,"Jeh",1
4688,"ViewTranslation","Sat [abbreviated weekday]","",,"",2125,"Jes",1
4689,"ViewTranslation","January [month]","",,"",2125,"Jerrey-geuree",1
4690,"ViewTranslation","February [month]","",,"",2125,"Toshiaght-arree",1
4691,"ViewTranslation","March [month]","",,"",2125,"Mayrnt",1
4692,"ViewTranslation","April [month]","",,"",2125,"Averil",1
4693,"ViewTranslation","May [month]","",,"",2125,"Boaldyn",1
4694,"ViewTranslation","June [month]","",,"",2125,"Mean-souree",1
4695,"ViewTranslation","July [month]","",,"",2125,"Jerrey-souree",1
4696,"ViewTranslation","August [month]","",,"",2125,"Luanistyn",1
4697,"ViewTranslation","September [month]","",,"",2125,"Mean-fouyir",1
4698,"ViewTranslation","October [month]","",,"",2125,"Jerrey-fouyir",1
4699,"ViewTranslation","November [month]","",,"",2125,"Mee houney",1
4700,"ViewTranslation","December [month]","",,"",2125,"Mee ny nollick",1
4701,"ViewTranslation","Jan [abbreviated month]","",,"",2125,"J-guer",1
4702,"ViewTranslation","Feb [abbreviated month]","",,"",2125,"T-arree",1
4703,"ViewTranslation","Mar [abbreviated month]","",,"",2125,"Mayrnt",1
4704,"ViewTranslation","Apr [abbreviated month]","",,"",2125,"Avrril",1
4705,"ViewTranslation","May [abbreviated month]","",,"",2125,"Boaldyn",1
4706,"ViewTranslation","Jun [abbreviated month]","",,"",2125,"M-souree",1
4707,"ViewTranslation","Jul [abbreviated month]","",,"",2125,"J-souree",1
4708,"ViewTranslation","Aug [abbreviated month]","",,"",2125,"Luanistyn",1
4709,"ViewTranslation","Sep [abbreviated month]","",,"",2125,"M-fouyir",1
4710,"ViewTranslation","Oct [abbreviated month]","",,"",2125,"J-fouyir",1
4711,"ViewTranslation","Nov [abbreviated month]","",,"",2125,"M.houney",1
4712,"ViewTranslation","Dec [abbreviated month]","",,"",2125,"M.nollick",1
4713,"ViewTranslation","Sunday [weekday]","",,"",2323,"יום ראשון",1
4714,"ViewTranslation","Monday [weekday]","",,"",2323,"יום שני",1
4715,"ViewTranslation","Tuesday [weekday]","",,"",2323,"יום שלישי",1
4716,"ViewTranslation","Wednesday [weekday]","",,"",2323,"יום רביעי",1
4717,"ViewTranslation","Thursday [weekday]","",,"",2323,"יום חמישי",1
4718,"ViewTranslation","Friday [weekday]","",,"",2323,"יום ששי",1
4719,"ViewTranslation","Saturday [weekday]","",,"",2323,"יום שבת",1
4720,"ViewTranslation","Sun [abbreviated weekday]","",,"",2323,"יום א'",1
4721,"ViewTranslation","Mon [abbreviated weekday]","",,"",2323,"יום ב'",1
4722,"ViewTranslation","Tue [abbreviated weekday]","",,"",2323,"יום ג'",1
4723,"ViewTranslation","Wed [abbreviated weekday]","",,"",2323,"יום ד'",1
4724,"ViewTranslation","Thu [abbreviated weekday]","",,"",2323,"יום ה'",1
4725,"ViewTranslation","Fri [abbreviated weekday]","",,"",2323,"יום ו'",1
4726,"ViewTranslation","Sat [abbreviated weekday]","",,"",2323,"שבת",1
4727,"ViewTranslation","January [month]","",,"",2323,"ינואר",1
4728,"ViewTranslation","February [month]","",,"",2323,"פברואר",1
4729,"ViewTranslation","March [month]","",,"",2323,"מרץ",1
4730,"ViewTranslation","April [month]","",,"",2323,"אפריל",1
4731,"ViewTranslation","May [month]","",,"",2323,"מאי",1
4732,"ViewTranslation","June [month]","",,"",2323,"יוני",1
4733,"ViewTranslation","July [month]","",,"",2323,"יולי",1
4734,"ViewTranslation","August [month]","",,"",2323,"אוגוסט",1
4735,"ViewTranslation","September [month]","",,"",2323,"ספטמבר",1
4736,"ViewTranslation","October [month]","",,"",2323,"אוקטובר",1
4737,"ViewTranslation","November [month]","",,"",2323,"נובמבר",1
4738,"ViewTranslation","December [month]","",,"",2323,"דצמבר",1
4739,"ViewTranslation","Jan [abbreviated month]","",,"",2323,"ינו",1
4740,"ViewTranslation","Feb [abbreviated month]","",,"",2323,"פבר",1
4741,"ViewTranslation","Mar [abbreviated month]","",,"",2323,"מרץ",1
4742,"ViewTranslation","Apr [abbreviated month]","",,"",2323,"אפר",1
4743,"ViewTranslation","May [abbreviated month]","",,"",2323,"מאי",1
4744,"ViewTranslation","Jun [abbreviated month]","",,"",2323,"יונ",1
4745,"ViewTranslation","Jul [abbreviated month]","",,"",2323,"יול",1
4746,"ViewTranslation","Aug [abbreviated month]","",,"",2323,"אוג",1
4747,"ViewTranslation","Sep [abbreviated month]","",,"",2323,"ספט",1
4748,"ViewTranslation","Oct [abbreviated month]","",,"",2323,"אוק",1
4749,"ViewTranslation","Nov [abbreviated month]","",,"",2323,"נוב",1
4750,"ViewTranslation","Dec [abbreviated month]","",,"",2323,"דצמ",1
4751,"ViewTranslation","Sunday [weekday]","",,"",2343,"रविवार ",1
4752,"ViewTranslation","Monday [weekday]","",,"",2343,"सोमवार ",1
4753,"ViewTranslation","Tuesday [weekday]","",,"",2343,"मंगलवार ",1
4754,"ViewTranslation","Wednesday [weekday]","",,"",2343,"बुधवार ",1
4755,"ViewTranslation","Thursday [weekday]","",,"",2343,"गुरुवार ",1
4756,"ViewTranslation","Friday [weekday]","",,"",2343,"शुक्रवार ",1
4757,"ViewTranslation","Saturday [weekday]","",,"",2343,"शनिवार ",1
4758,"ViewTranslation","Sun [abbreviated weekday]","",,"",2343,"रवि ",1
4759,"ViewTranslation","Mon [abbreviated weekday]","",,"",2343,"सोम ",1
4760,"ViewTranslation","Tue [abbreviated weekday]","",,"",2343,"मंगल ",1
4761,"ViewTranslation","Wed [abbreviated weekday]","",,"",2343,"बुध ",1
4762,"ViewTranslation","Thu [abbreviated weekday]","",,"",2343,"गुरु ",1
4763,"ViewTranslation","Fri [abbreviated weekday]","",,"",2343,"शुक्र ",1
4764,"ViewTranslation","Sat [abbreviated weekday]","",,"",2343,"शनि ",1
4765,"ViewTranslation","January [month]","",,"",2343,"जनवरी",1
4766,"ViewTranslation","February [month]","",,"",2343,"फ़रवरी",1
4767,"ViewTranslation","March [month]","",,"",2343,"मार्च",1
4768,"ViewTranslation","April [month]","",,"",2343,"अप्र ल",1
4769,"ViewTranslation","May [month]","",,"",2343,"मई",1
4770,"ViewTranslation","June [month]","",,"",2343,"जून",1
4771,"ViewTranslation","July [month]","",,"",2343,"जुलाई",1
4772,"ViewTranslation","August [month]","",,"",2343,"अगस्त",1
4773,"ViewTranslation","September [month]","",,"",2343,"सितम्बर",1
4774,"ViewTranslation","October [month]","",,"",2343,"अक्टूबर",1
4775,"ViewTranslation","November [month]","",,"",2343,"नवम्बर",1
4776,"ViewTranslation","December [month]","",,"",2343,"दिसम्बर",1
4777,"ViewTranslation","Jan [abbreviated month]","",,"",2343,"जनवरी",1
4778,"ViewTranslation","Feb [abbreviated month]","",,"",2343,"फ़रवरी",1
4779,"ViewTranslation","Mar [abbreviated month]","",,"",2343,"मार्च",1
4780,"ViewTranslation","Apr [abbreviated month]","",,"",2343,"अप्र ल",1
4781,"ViewTranslation","May [abbreviated month]","",,"",2343,"मई",1
4782,"ViewTranslation","Jun [abbreviated month]","",,"",2343,"जून",1
4783,"ViewTranslation","Jul [abbreviated month]","",,"",2343,"जुलाई",1
4784,"ViewTranslation","Aug [abbreviated month]","",,"",2343,"अगस्त",1
4785,"ViewTranslation","Sep [abbreviated month]","",,"",2343,"सितम्बर",1
4786,"ViewTranslation","Oct [abbreviated month]","",,"",2343,"अक्टूबर",1
4787,"ViewTranslation","Nov [abbreviated month]","",,"",2343,"नवम्बर",1
4788,"ViewTranslation","Dec [abbreviated month]","",,"",2343,"दिसम्बर",1
4789,"ViewTranslation","Sunday [weekday]","",,"",2418,"Nedjelja",1
4790,"ViewTranslation","Monday [weekday]","",,"",2418,"Ponedjeljak",1
4791,"ViewTranslation","Tuesday [weekday]","",,"",2418,"Utorak",1
4792,"ViewTranslation","Wednesday [weekday]","",,"",2418,"Srijeda",1
4793,"ViewTranslation","Thursday [weekday]","",,"",2418,"Četvrtak",1
4794,"ViewTranslation","Friday [weekday]","",,"",2418,"Petak",1
4795,"ViewTranslation","Saturday [weekday]","",,"",2418,"Subota",1
4796,"ViewTranslation","Sun [abbreviated weekday]","",,"",2418,"Ned",1
4797,"ViewTranslation","Mon [abbreviated weekday]","",,"",2418,"Pon",1
4798,"ViewTranslation","Tue [abbreviated weekday]","",,"",2418,"Uto",1
4799,"ViewTranslation","Wed [abbreviated weekday]","",,"",2418,"Sri",1
4800,"ViewTranslation","Thu [abbreviated weekday]","",,"",2418,"Čet",1
4801,"ViewTranslation","Fri [abbreviated weekday]","",,"",2418,"Pet",1
4802,"ViewTranslation","Sat [abbreviated weekday]","",,"",2418,"Sub",1
4803,"ViewTranslation","January [month]","",,"",2418,"Siječanj",1
4804,"ViewTranslation","February [month]","",,"",2418,"Veljača",1
4805,"ViewTranslation","March [month]","",,"",2418,"Ožujak",1
4806,"ViewTranslation","April [month]","",,"",2418,"Travanj",1
4807,"ViewTranslation","May [month]","",,"",2418,"Svibanj",1
4808,"ViewTranslation","June [month]","",,"",2418,"Lipanj",1
4809,"ViewTranslation","July [month]","",,"",2418,"Srpanj",1
4810,"ViewTranslation","August [month]","",,"",2418,"Kolovoz",1
4811,"ViewTranslation","September [month]","",,"",2418,"Rujan",1
4812,"ViewTranslation","October [month]","",,"",2418,"Listopad",1
4813,"ViewTranslation","November [month]","",,"",2418,"Studeni",1
4814,"ViewTranslation","December [month]","",,"",2418,"Prosinac",1
4815,"ViewTranslation","Jan [abbreviated month]","",,"",2418,"Sij",1
4816,"ViewTranslation","Feb [abbreviated month]","",,"",2418,"Vel",1
4817,"ViewTranslation","Mar [abbreviated month]","",,"",2418,"Ožu",1
4818,"ViewTranslation","Apr [abbreviated month]","",,"",2418,"Tra",1
4819,"ViewTranslation","May [abbreviated month]","",,"",2418,"Svi",1
4820,"ViewTranslation","Jun [abbreviated month]","",,"",2418,"Lip",1
4821,"ViewTranslation","Jul [abbreviated month]","",,"",2418,"Srp",1
4822,"ViewTranslation","Aug [abbreviated month]","",,"",2418,"Kol",1
4823,"ViewTranslation","Sep [abbreviated month]","",,"",2418,"Ruj",1
4824,"ViewTranslation","Oct [abbreviated month]","",,"",2418,"Lis",1
4825,"ViewTranslation","Nov [abbreviated month]","",,"",2418,"Stu",1
4826,"ViewTranslation","Dec [abbreviated month]","",,"",2418,"Pro",1
4827,"ViewTranslation","Sunday [weekday]","",,"",2443,"Vasárnap",1
4828,"ViewTranslation","Monday [weekday]","",,"",2443,"Hétfő",1
4829,"ViewTranslation","Tuesday [weekday]","",,"",2443,"Kedd",1
4830,"ViewTranslation","Wednesday [weekday]","",,"",2443,"Szerda",1
4831,"ViewTranslation","Thursday [weekday]","",,"",2443,"Csütörtök",1
4832,"ViewTranslation","Friday [weekday]","",,"",2443,"Péntek",1
4833,"ViewTranslation","Saturday [weekday]","",,"",2443,"Szombat",1
4834,"ViewTranslation","Sun [abbreviated weekday]","",,"",2443,"v",1
4835,"ViewTranslation","Mon [abbreviated weekday]","",,"",2443,"h",1
4836,"ViewTranslation","Tue [abbreviated weekday]","",,"",2443,"k",1
4837,"ViewTranslation","Wed [abbreviated weekday]","",,"",2443,"Sze",1
4838,"ViewTranslation","Thu [abbreviated weekday]","",,"",2443,"Cs",1
4839,"ViewTranslation","Fri [abbreviated weekday]","",,"",2443,"p",1
4840,"ViewTranslation","Sat [abbreviated weekday]","",,"",2443,"Szo",1
4841,"ViewTranslation","January [month]","",,"",2443,"Január",1
4842,"ViewTranslation","February [month]","",,"",2443,"Február",1
4843,"ViewTranslation","March [month]","",,"",2443,"Március",1
4844,"ViewTranslation","April [month]","",,"",2443,"Április",1
4845,"ViewTranslation","May [month]","",,"",2443,"Május",1
4846,"ViewTranslation","June [month]","",,"",2443,"Június",1
4847,"ViewTranslation","July [month]","",,"",2443,"Július",1
4848,"ViewTranslation","August [month]","",,"",2443,"Augusztus",1
4849,"ViewTranslation","September [month]","",,"",2443,"Szeptember",1
4850,"ViewTranslation","October [month]","",,"",2443,"Október",1
4851,"ViewTranslation","November [month]","",,"",2443,"November",1
4852,"ViewTranslation","December [month]","",,"",2443,"December",1
4853,"ViewTranslation","Jan [abbreviated month]","",,"",2443,"Jan",1
4854,"ViewTranslation","Feb [abbreviated month]","",,"",2443,"Feb",1
4855,"ViewTranslation","Mar [abbreviated month]","",,"",2443,"Már",1
4856,"ViewTranslation","Apr [abbreviated month]","",,"",2443,"Ápr",1
4857,"ViewTranslation","May [abbreviated month]","",,"",2443,"Máj",1
4858,"ViewTranslation","Jun [abbreviated month]","",,"",2443,"Jún",1
4859,"ViewTranslation","Jul [abbreviated month]","",,"",2443,"Júl",1
4860,"ViewTranslation","Aug [abbreviated month]","",,"",2443,"Aug",1
4861,"ViewTranslation","Sep [abbreviated month]","",,"",2443,"Sze",1
4862,"ViewTranslation","Oct [abbreviated month]","",,"",2443,"Okt",1
4863,"ViewTranslation","Nov [abbreviated month]","",,"",2443,"Nov",1
4864,"ViewTranslation","Dec [abbreviated month]","",,"",2443,"Dec",1
4865,"ViewTranslation","Sunday [weekday]","",,"",2558,"Minggu",1
4866,"ViewTranslation","Monday [weekday]","",,"",2558,"Senin",1
4867,"ViewTranslation","Tuesday [weekday]","",,"",2558,"Selasa",1
4868,"ViewTranslation","Wednesday [weekday]","",,"",2558,"Rabu",1
4869,"ViewTranslation","Thursday [weekday]","",,"",2558,"Kamis",1
4870,"ViewTranslation","Friday [weekday]","",,"",2558,"Jumat",1
4871,"ViewTranslation","Saturday [weekday]","",,"",2558,"Sabtu",1
4872,"ViewTranslation","Sun [abbreviated weekday]","",,"",2558,"Min",1
4873,"ViewTranslation","Mon [abbreviated weekday]","",,"",2558,"Sen",1
4874,"ViewTranslation","Tue [abbreviated weekday]","",,"",2558,"Sel",1
4875,"ViewTranslation","Wed [abbreviated weekday]","",,"",2558,"Rab",1
4876,"ViewTranslation","Thu [abbreviated weekday]","",,"",2558,"Kam",1
4877,"ViewTranslation","Fri [abbreviated weekday]","",,"",2558,"Jum",1
4878,"ViewTranslation","Sat [abbreviated weekday]","",,"",2558,"Sab",1
4879,"ViewTranslation","January [month]","",,"",2558,"Januari",1
4880,"ViewTranslation","February [month]","",,"",2558,"Pebruari",1
4881,"ViewTranslation","March [month]","",,"",2558,"Maret",1
4882,"ViewTranslation","April [month]","",,"",2558,"April",1
4883,"ViewTranslation","May [month]","",,"",2558,"Mei",1
4884,"ViewTranslation","June [month]","",,"",2558,"Juni",1
4885,"ViewTranslation","July [month]","",,"",2558,"Juli",1
4886,"ViewTranslation","August [month]","",,"",2558,"Agustus",1
4887,"ViewTranslation","September [month]","",,"",2558,"September",1
4888,"ViewTranslation","October [month]","",,"",2558,"Oktober",1
4889,"ViewTranslation","November [month]","",,"",2558,"November",1
4890,"ViewTranslation","December [month]","",,"",2558,"Desember",1
4891,"ViewTranslation","Jan [abbreviated month]","",,"",2558,"Jan",1
4892,"ViewTranslation","Feb [abbreviated month]","",,"",2558,"Peb",1
4893,"ViewTranslation","Mar [abbreviated month]","",,"",2558,"Mar",1
4894,"ViewTranslation","Apr [abbreviated month]","",,"",2558,"Apr",1
4895,"ViewTranslation","May [abbreviated month]","",,"",2558,"Mei",1
4896,"ViewTranslation","Jun [abbreviated month]","",,"",2558,"Jun",1
4897,"ViewTranslation","Jul [abbreviated month]","",,"",2558,"Jul",1
4898,"ViewTranslation","Aug [abbreviated month]","",,"",2558,"Agu",1
4899,"ViewTranslation","Sep [abbreviated month]","",,"",2558,"Sep",1
4900,"ViewTranslation","Oct [abbreviated month]","",,"",2558,"Okt",1
4901,"ViewTranslation","Nov [abbreviated month]","",,"",2558,"Nov",1
4902,"ViewTranslation","Dec [abbreviated month]","",,"",2558,"Des",1
4903,"ViewTranslation","Sunday [weekday]","",,"",2593,"Sunnudagur",1
4904,"ViewTranslation","Monday [weekday]","",,"",2593,"Mánudagur",1
4905,"ViewTranslation","Tuesday [weekday]","",,"",2593,"Þriðjudagur",1
4906,"ViewTranslation","Wednesday [weekday]","",,"",2593,"Miðvikudagur",1
4907,"ViewTranslation","Thursday [weekday]","",,"",2593,"Fimmtudagur",1
4908,"ViewTranslation","Friday [weekday]","",,"",2593,"Föstudagur",1
4909,"ViewTranslation","Saturday [weekday]","",,"",2593,"Laugardagur",1
4910,"ViewTranslation","Sun [abbreviated weekday]","",,"",2593,"Sun",1
4911,"ViewTranslation","Mon [abbreviated weekday]","",,"",2593,"Mán",1
4912,"ViewTranslation","Tue [abbreviated weekday]","",,"",2593,"Þri",1
4913,"ViewTranslation","Wed [abbreviated weekday]","",,"",2593,"Mið",1
4914,"ViewTranslation","Thu [abbreviated weekday]","",,"",2593,"Fim",1
4915,"ViewTranslation","Fri [abbreviated weekday]","",,"",2593,"Fös",1
4916,"ViewTranslation","Sat [abbreviated weekday]","",,"",2593,"Lau",1
4917,"ViewTranslation","January [month]","",,"",2593,"Janúar",1
4918,"ViewTranslation","February [month]","",,"",2593,"Febrúar",1
4919,"ViewTranslation","March [month]","",,"",2593,"Mars",1
4920,"ViewTranslation","April [month]","",,"",2593,"Apríl",1
4921,"ViewTranslation","May [month]","",,"",2593,"Maí",1
4922,"ViewTranslation","June [month]","",,"",2593,"Júní",1
4923,"ViewTranslation","July [month]","",,"",2593,"Júlí",1
4924,"ViewTranslation","August [month]","",,"",2593,"Ágúst",1
4925,"ViewTranslation","September [month]","",,"",2593,"September",1
4926,"ViewTranslation","October [month]","",,"",2593,"Október",1
4927,"ViewTranslation","November [month]","",,"",2593,"Nóvember",1
4928,"ViewTranslation","December [month]","",,"",2593,"Desember",1
4929,"ViewTranslation","Jan [abbreviated month]","",,"",2593,"Jan",1
4930,"ViewTranslation","Feb [abbreviated month]","",,"",2593,"Feb",1
4931,"ViewTranslation","Mar [abbreviated month]","",,"",2593,"Mar",1
4932,"ViewTranslation","Apr [abbreviated month]","",,"",2593,"Apr",1
4933,"ViewTranslation","May [abbreviated month]","",,"",2593,"Maí",1
4934,"ViewTranslation","Jun [abbreviated month]","",,"",2593,"Jún",1
4935,"ViewTranslation","Jul [abbreviated month]","",,"",2593,"Júl",1
4936,"ViewTranslation","Aug [abbreviated month]","",,"",2593,"Ágú",1
4937,"ViewTranslation","Sep [abbreviated month]","",,"",2593,"Sep",1
4938,"ViewTranslation","Oct [abbreviated month]","",,"",2593,"Okt",1
4939,"ViewTranslation","Nov [abbreviated month]","",,"",2593,"Nóv",1
4940,"ViewTranslation","Dec [abbreviated month]","",,"",2593,"Des",1
4941,"ViewTranslation","Sunday [weekday]","",,"",2600,"Domenica",1
4942,"ViewTranslation","Monday [weekday]","",,"",2600,"Lunedì",1
4943,"ViewTranslation","Tuesday [weekday]","",,"",2600,"Martedì",1
4944,"ViewTranslation","Wednesday [weekday]","",,"",2600,"Mercoledì",1
4945,"ViewTranslation","Thursday [weekday]","",,"",2600,"Giovedì",1
4946,"ViewTranslation","Friday [weekday]","",,"",2600,"Venerdì",1
4947,"ViewTranslation","Saturday [weekday]","",,"",2600,"Sabato",1
4948,"ViewTranslation","Sun [abbreviated weekday]","",,"",2600,"Dom",1
4949,"ViewTranslation","Mon [abbreviated weekday]","",,"",2600,"Lun",1
4950,"ViewTranslation","Tue [abbreviated weekday]","",,"",2600,"Mar",1
4951,"ViewTranslation","Wed [abbreviated weekday]","",,"",2600,"Mer",1
4952,"ViewTranslation","Thu [abbreviated weekday]","",,"",2600,"Gio",1
4953,"ViewTranslation","Fri [abbreviated weekday]","",,"",2600,"Ven",1
4954,"ViewTranslation","Sat [abbreviated weekday]","",,"",2600,"Sab",1
4955,"ViewTranslation","January [month]","",,"",2600,"Gennaio",1
4956,"ViewTranslation","February [month]","",,"",2600,"Febbraio",1
4957,"ViewTranslation","March [month]","",,"",2600,"Marzo",1
4958,"ViewTranslation","April [month]","",,"",2600,"Aprile",1
4959,"ViewTranslation","May [month]","",,"",2600,"Maggio",1
4960,"ViewTranslation","June [month]","",,"",2600,"Giugno",1
4961,"ViewTranslation","July [month]","",,"",2600,"Luglio",1
4962,"ViewTranslation","August [month]","",,"",2600,"Agosto",1
4963,"ViewTranslation","September [month]","",,"",2600,"Settembre",1
4964,"ViewTranslation","October [month]","",,"",2600,"Ottobre",1
4965,"ViewTranslation","November [month]","",,"",2600,"Novembre",1
4966,"ViewTranslation","December [month]","",,"",2600,"Dicembre",1
4967,"ViewTranslation","Jan [abbreviated month]","",,"",2600,"Gen",1
4968,"ViewTranslation","Feb [abbreviated month]","",,"",2600,"Feb",1
4969,"ViewTranslation","Mar [abbreviated month]","",,"",2600,"Mar",1
4970,"ViewTranslation","Apr [abbreviated month]","",,"",2600,"Apr",1
4971,"ViewTranslation","May [abbreviated month]","",,"",2600,"Mag",1
4972,"ViewTranslation","Jun [abbreviated month]","",,"",2600,"Giu",1
4973,"ViewTranslation","Jul [abbreviated month]","",,"",2600,"Lug",1
4974,"ViewTranslation","Aug [abbreviated month]","",,"",2600,"Ago",1
4975,"ViewTranslation","Sep [abbreviated month]","",,"",2600,"Set",1
4976,"ViewTranslation","Oct [abbreviated month]","",,"",2600,"Ott",1
4977,"ViewTranslation","Nov [abbreviated month]","",,"",2600,"Nov",1
4978,"ViewTranslation","Dec [abbreviated month]","",,"",2600,"Dic",1
4979,"ViewTranslation","Sunday [weekday]","",,"",2723,"日曜日",1
4980,"ViewTranslation","Monday [weekday]","",,"",2723,"月曜日",1
4981,"ViewTranslation","Tuesday [weekday]","",,"",2723,"火曜日",1
4982,"ViewTranslation","Wednesday [weekday]","",,"",2723,"水曜日",1
4983,"ViewTranslation","Thursday [weekday]","",,"",2723,"木曜日",1
4984,"ViewTranslation","Friday [weekday]","",,"",2723,"金曜日",1
4985,"ViewTranslation","Saturday [weekday]","",,"",2723,"土曜日",1
4986,"ViewTranslation","Sun [abbreviated weekday]","",,"",2723,"日",1
4987,"ViewTranslation","Mon [abbreviated weekday]","",,"",2723,"月",1
4988,"ViewTranslation","Tue [abbreviated weekday]","",,"",2723,"火",1
4989,"ViewTranslation","Wed [abbreviated weekday]","",,"",2723,"水",1
4990,"ViewTranslation","Thu [abbreviated weekday]","",,"",2723,"木",1
4991,"ViewTranslation","Fri [abbreviated weekday]","",,"",2723,"金",1
4992,"ViewTranslation","Sat [abbreviated weekday]","",,"",2723,"土",1
4993,"ViewTranslation","January [month]","",,"",2723,"1月",1
4994,"ViewTranslation","February [month]","",,"",2723,"2月",1
4995,"ViewTranslation","March [month]","",,"",2723,"3月",1
4996,"ViewTranslation","April [month]","",,"",2723,"4月",1
4997,"ViewTranslation","May [month]","",,"",2723,"5月",1
4998,"ViewTranslation","June [month]","",,"",2723,"6月",1
4999,"ViewTranslation","July [month]","",,"",2723,"7月",1
5000,"ViewTranslation","August [month]","",,"",2723,"8月",1
5001,"ViewTranslation","September [month]","",,"",2723,"9月",1
5002,"ViewTranslation","October [month]","",,"",2723,"10月",1
5003,"ViewTranslation","November [month]","",,"",2723,"11月",1
5004,"ViewTranslation","December [month]","",,"",2723,"12月",1
5005,"ViewTranslation","Jan [abbreviated month]","",,"",2723," 1月",1
5006,"ViewTranslation","Feb [abbreviated month]","",,"",2723," 2月",1
5007,"ViewTranslation","Mar [abbreviated month]","",,"",2723," 3月",1
5008,"ViewTranslation","Apr [abbreviated month]","",,"",2723," 4月",1
5009,"ViewTranslation","May [abbreviated month]","",,"",2723," 5月",1
5010,"ViewTranslation","Jun [abbreviated month]","",,"",2723," 6月",1
5011,"ViewTranslation","Jul [abbreviated month]","",,"",2723," 7月",1
5012,"ViewTranslation","Aug [abbreviated month]","",,"",2723," 8月",1
5013,"ViewTranslation","Sep [abbreviated month]","",,"",2723," 9月",1
5014,"ViewTranslation","Oct [abbreviated month]","",,"",2723,"10月",1
5015,"ViewTranslation","Nov [abbreviated month]","",,"",2723,"11月",1
5016,"ViewTranslation","Dec [abbreviated month]","",,"",2723,"12月",1
5017,"ViewTranslation","Sunday [weekday]","",,"",2770,"კვირა",1
5018,"ViewTranslation","Monday [weekday]","",,"",2770,"ორშაბათი",1
5019,"ViewTranslation","Tuesday [weekday]","",,"",2770,"სამშაბათი",1
5020,"ViewTranslation","Wednesday [weekday]","",,"",2770,"ოთხშაბათი",1
5021,"ViewTranslation","Thursday [weekday]","",,"",2770,"ხუთშაბათი",1
5022,"ViewTranslation","Friday [weekday]","",,"",2770,"პარასკევი",1
5023,"ViewTranslation","Saturday [weekday]","",,"",2770,"შაბათი",1
5024,"ViewTranslation","Sun [abbreviated weekday]","",,"",2770,"კვი",1
5025,"ViewTranslation","Mon [abbreviated weekday]","",,"",2770,"ორშ",1
5026,"ViewTranslation","Tue [abbreviated weekday]","",,"",2770,"სამ",1
5027,"ViewTranslation","Wed [abbreviated weekday]","",,"",2770,"ოთხ",1
5028,"ViewTranslation","Thu [abbreviated weekday]","",,"",2770,"ხუთ",1
5029,"ViewTranslation","Fri [abbreviated weekday]","",,"",2770,"პარ",1
5030,"ViewTranslation","Sat [abbreviated weekday]","",,"",2770,"შაბ",1
5031,"ViewTranslation","January [month]","",,"",2770,"იანვარი",1
5032,"ViewTranslation","February [month]","",,"",2770,"თებერვალი",1
5033,"ViewTranslation","March [month]","",,"",2770,"მარტი",1
5034,"ViewTranslation","April [month]","",,"",2770,"აპრილი",1
5035,"ViewTranslation","May [month]","",,"",2770,"მაისი",1
5036,"ViewTranslation","June [month]","",,"",2770,"ივნისი",1
5037,"ViewTranslation","July [month]","",,"",2770,"ივლისი",1
5038,"ViewTranslation","August [month]","",,"",2770,"აგვისტო",1
5039,"ViewTranslation","September [month]","",,"",2770,"სექტემბერი",1
5040,"ViewTranslation","October [month]","",,"",2770,"ოქტომბერი",1
5041,"ViewTranslation","November [month]","",,"",2770,"ნოემბერი",1
5042,"ViewTranslation","December [month]","",,"",2770,"დეკემბერი",1
5043,"ViewTranslation","Jan [abbreviated month]","",,"",2770,"იან",1
5044,"ViewTranslation","Feb [abbreviated month]","",,"",2770,"თებ",1
5045,"ViewTranslation","Mar [abbreviated month]","",,"",2770,"მარ",1
5046,"ViewTranslation","Apr [abbreviated month]","",,"",2770,"აპრ",1
5047,"ViewTranslation","May [abbreviated month]","",,"",2770,"მაი",1
5048,"ViewTranslation","Jun [abbreviated month]","",,"",2770,"ივნ",1
5049,"ViewTranslation","Jul [abbreviated month]","",,"",2770,"ივლ",1
5050,"ViewTranslation","Aug [abbreviated month]","",,"",2770,"აგვ",1
5051,"ViewTranslation","Sep [abbreviated month]","",,"",2770,"სექ",1
5052,"ViewTranslation","Oct [abbreviated month]","",,"",2770,"ოქტ",1
5053,"ViewTranslation","Nov [abbreviated month]","",,"",2770,"ნოე",1
5054,"ViewTranslation","Dec [abbreviated month]","",,"",2770,"დეკ",1
5055,"ViewTranslation","Sunday [weekday]","",,"",2763,"Sabaat",1
5056,"ViewTranslation","Monday [weekday]","",,"",2763,"Ataasinngorneq",1
5057,"ViewTranslation","Tuesday [weekday]","",,"",2763,"Marlunngorneq",1
5058,"ViewTranslation","Wednesday [weekday]","",,"",2763,"Pingasunngorneq",1
5059,"ViewTranslation","Thursday [weekday]","",,"",2763,"Sisamanngorneq",1
5060,"ViewTranslation","Friday [weekday]","",,"",2763,"Tallimanngorneq",1
5061,"ViewTranslation","Saturday [weekday]","",,"",2763,"Arfininngorneq",1
5062,"ViewTranslation","Sun [abbreviated weekday]","",,"",2763,"Sab",1
5063,"ViewTranslation","Mon [abbreviated weekday]","",,"",2763,"Ata",1
5064,"ViewTranslation","Tue [abbreviated weekday]","",,"",2763,"Mar",1
5065,"ViewTranslation","Wed [abbreviated weekday]","",,"",2763,"Pin",1
5066,"ViewTranslation","Thu [abbreviated weekday]","",,"",2763,"Sis",1
5067,"ViewTranslation","Fri [abbreviated weekday]","",,"",2763,"Tal",1
5068,"ViewTranslation","Sat [abbreviated weekday]","",,"",2763,"Arf",1
5069,"ViewTranslation","January [month]","",,"",2763,"Januari",1
5070,"ViewTranslation","February [month]","",,"",2763,"Februari",1
5071,"ViewTranslation","March [month]","",,"",2763,"Martsi",1
5072,"ViewTranslation","April [month]","",,"",2763,"Aprili",1
5073,"ViewTranslation","May [month]","",,"",2763,"Maji",1
5074,"ViewTranslation","June [month]","",,"",2763,"Juni",1
5075,"ViewTranslation","July [month]","",,"",2763,"Juli",1
5076,"ViewTranslation","August [month]","",,"",2763,"Augustusi",1
5077,"ViewTranslation","September [month]","",,"",2763,"Septemberi",1
5078,"ViewTranslation","October [month]","",,"",2763,"Oktoberi",1
5079,"ViewTranslation","November [month]","",,"",2763,"Novemberi",1
5080,"ViewTranslation","December [month]","",,"",2763,"Decemberi",1
5081,"ViewTranslation","Jan [abbreviated month]","",,"",2763,"Jan",1
5082,"ViewTranslation","Feb [abbreviated month]","",,"",2763,"Feb",1
5083,"ViewTranslation","Mar [abbreviated month]","",,"",2763,"Mar",1
5084,"ViewTranslation","Apr [abbreviated month]","",,"",2763,"Apr",1
5085,"ViewTranslation","May [abbreviated month]","",,"",2763,"Maj",1
5086,"ViewTranslation","Jun [abbreviated month]","",,"",2763,"Jun",1
5087,"ViewTranslation","Jul [abbreviated month]","",,"",2763,"Jul",1
5088,"ViewTranslation","Aug [abbreviated month]","",,"",2763,"Aug",1
5089,"ViewTranslation","Sep [abbreviated month]","",,"",2763,"Sep",1
5090,"ViewTranslation","Oct [abbreviated month]","",,"",2763,"Okt",1
5091,"ViewTranslation","Nov [abbreviated month]","",,"",2763,"Nov",1
5092,"ViewTranslation","Dec [abbreviated month]","",,"",2763,"Dec",1
5093,"ViewTranslation","Sunday [weekday]","",,"",2765,"ರವಿವಾರ",1
5094,"ViewTranslation","Monday [weekday]","",,"",2765,"ಸೋಮವಾರ",1
5095,"ViewTranslation","Tuesday [weekday]","",,"",2765,"ಮಂಗಳವಾರ",1
5096,"ViewTranslation","Wednesday [weekday]","",,"",2765,"ಬುಧವಾರ",1
5097,"ViewTranslation","Thursday [weekday]","",,"",2765,"ಗುರುವಾರ",1
5098,"ViewTranslation","Friday [weekday]","",,"",2765,"ಶುಕ್ರವಾರ",1
5099,"ViewTranslation","Saturday [weekday]","",,"",2765,"ಶನಿವಾರ",1
5100,"ViewTranslation","Sun [abbreviated weekday]","",,"",2765,"ರ",1
5101,"ViewTranslation","Mon [abbreviated weekday]","",,"",2765,"ಸೋ",1
5102,"ViewTranslation","Tue [abbreviated weekday]","",,"",2765,"ಮಂ",1
5103,"ViewTranslation","Wed [abbreviated weekday]","",,"",2765,"ಬು",1
5104,"ViewTranslation","Thu [abbreviated weekday]","",,"",2765,"ಗು",1
5105,"ViewTranslation","Fri [abbreviated weekday]","",,"",2765,"ಶು",1
5106,"ViewTranslation","Sat [abbreviated weekday]","",,"",2765,"ಶ",1
5107,"ViewTranslation","January [month]","",,"",2765,"ಜನವರಿ",1
5108,"ViewTranslation","February [month]","",,"",2765,"ಫೆಬ್ರವರಿ",1
5109,"ViewTranslation","March [month]","",,"",2765,"ಮಾರ್ಚ",1
5110,"ViewTranslation","April [month]","",,"",2765,"ಏಪ್ರಿಲ್",1
5111,"ViewTranslation","May [month]","",,"",2765,"ಮೇ",1
5112,"ViewTranslation","June [month]","",,"",2765,"ಜೂನ್",1
5113,"ViewTranslation","July [month]","",,"",2765,"ಜುಲಾಯಿ",1
5114,"ViewTranslation","August [month]","",,"",2765,"ಆಗಸ್ತು",1
5115,"ViewTranslation","September [month]","",,"",2765,"ಸೆಪ್ಟೆಂಬರ",1
5116,"ViewTranslation","October [month]","",,"",2765,"ಅಕ್ತೂಬರ",1
5117,"ViewTranslation","November [month]","",,"",2765,"ನವೆಂಬರ",1
5118,"ViewTranslation","December [month]","",,"",2765,"ದಶಂಬರ",1
5119,"ViewTranslation","Jan [abbreviated month]","",,"",2765,"ಜ",1
5120,"ViewTranslation","Feb [abbreviated month]","",,"",2765,"ಫೆ",1
5121,"ViewTranslation","Mar [abbreviated month]","",,"",2765,"ಮಾ",1
5122,"ViewTranslation","Apr [abbreviated month]","",,"",2765,"ಏ",1
5123,"ViewTranslation","May [abbreviated month]","",,"",2765,"ಮೇ",1
5124,"ViewTranslation","Jun [abbreviated month]","",,"",2765,"ಜೂ",1
5125,"ViewTranslation","Jul [abbreviated month]","",,"",2765,"ಜು",1
5126,"ViewTranslation","Aug [abbreviated month]","",,"",2765,"ಆ",1
5127,"ViewTranslation","Sep [abbreviated month]","",,"",2765,"ಸೆ",1
5128,"ViewTranslation","Oct [abbreviated month]","",,"",2765,"ಅ",1
5129,"ViewTranslation","Nov [abbreviated month]","",,"",2765,"ನ",1
5130,"ViewTranslation","Dec [abbreviated month]","",,"",2765,"ದ",1
5131,"ViewTranslation","Sunday [weekday]","",,"",3122,"일요일",1
5132,"ViewTranslation","Monday [weekday]","",,"",3122,"월요일",1
5133,"ViewTranslation","Tuesday [weekday]","",,"",3122,"화요일",1
5134,"ViewTranslation","Wednesday [weekday]","",,"",3122,"수요일",1
5135,"ViewTranslation","Thursday [weekday]","",,"",3122,"목요일",1
5136,"ViewTranslation","Friday [weekday]","",,"",3122,"금요일",1
5137,"ViewTranslation","Saturday [weekday]","",,"",3122,"토요일",1
5138,"ViewTranslation","Sun [abbreviated weekday]","",,"",3122,"일",1
5139,"ViewTranslation","Mon [abbreviated weekday]","",,"",3122,"월",1
5140,"ViewTranslation","Tue [abbreviated weekday]","",,"",3122,"화",1
5141,"ViewTranslation","Wed [abbreviated weekday]","",,"",3122,"수",1
5142,"ViewTranslation","Thu [abbreviated weekday]","",,"",3122,"목",1
5143,"ViewTranslation","Fri [abbreviated weekday]","",,"",3122,"금",1
5144,"ViewTranslation","Sat [abbreviated weekday]","",,"",3122,"토",1
5145,"ViewTranslation","January [month]","",,"",3122,"일월",1
5146,"ViewTranslation","February [month]","",,"",3122,"이월",1
5147,"ViewTranslation","March [month]","",,"",3122,"삼월",1
5148,"ViewTranslation","April [month]","",,"",3122,"사월",1
5149,"ViewTranslation","May [month]","",,"",3122,"오월",1
5150,"ViewTranslation","June [month]","",,"",3122,"유월",1
5151,"ViewTranslation","July [month]","",,"",3122,"칠월",1
5152,"ViewTranslation","August [month]","",,"",3122,"팔월",1
5153,"ViewTranslation","September [month]","",,"",3122,"구월",1
5154,"ViewTranslation","October [month]","",,"",3122,"시월",1
5155,"ViewTranslation","November [month]","",,"",3122,"십일월",1
5156,"ViewTranslation","December [month]","",,"",3122,"십이월",1
5157,"ViewTranslation","Jan [abbreviated month]","",,"",3122," 1월",1
5158,"ViewTranslation","Feb [abbreviated month]","",,"",3122," 2월",1
5159,"ViewTranslation","Mar [abbreviated month]","",,"",3122," 3월",1
5160,"ViewTranslation","Apr [abbreviated month]","",,"",3122," 4월",1
5161,"ViewTranslation","May [abbreviated month]","",,"",3122," 5월",1
5162,"ViewTranslation","Jun [abbreviated month]","",,"",3122," 6월",1
5163,"ViewTranslation","Jul [abbreviated month]","",,"",3122," 7월",1
5164,"ViewTranslation","Aug [abbreviated month]","",,"",3122," 8월",1
5165,"ViewTranslation","Sep [abbreviated month]","",,"",3122," 9월",1
5166,"ViewTranslation","Oct [abbreviated month]","",,"",3122,"10월",1
5167,"ViewTranslation","Nov [abbreviated month]","",,"",3122,"11월",1
5168,"ViewTranslation","Dec [abbreviated month]","",,"",3122,"12월",1
5169,"ViewTranslation","Sunday [weekday]","",,"",1372,"De sul",1
5170,"ViewTranslation","Monday [weekday]","",,"",1372,"De lun",1
5171,"ViewTranslation","Tuesday [weekday]","",,"",1372,"De merth",1
5172,"ViewTranslation","Wednesday [weekday]","",,"",1372,"De merher",1
5173,"ViewTranslation","Thursday [weekday]","",,"",1372,"De yow",1
5174,"ViewTranslation","Friday [weekday]","",,"",1372,"De gwener",1
5175,"ViewTranslation","Saturday [weekday]","",,"",1372,"De sadorn",1
5176,"ViewTranslation","Sun [abbreviated weekday]","",,"",1372,"Sul",1
5177,"ViewTranslation","Mon [abbreviated weekday]","",,"",1372,"Lun",1
5178,"ViewTranslation","Tue [abbreviated weekday]","",,"",1372,"Mth",1
5179,"ViewTranslation","Wed [abbreviated weekday]","",,"",1372,"Mhr",1
5180,"ViewTranslation","Thu [abbreviated weekday]","",,"",1372,"Yow",1
5181,"ViewTranslation","Fri [abbreviated weekday]","",,"",1372,"Gwe",1
5182,"ViewTranslation","Sat [abbreviated weekday]","",,"",1372,"Sad",1
5183,"ViewTranslation","January [month]","",,"",1372,"Mys genver",1
5184,"ViewTranslation","February [month]","",,"",1372,"Mys whevrel",1
5185,"ViewTranslation","March [month]","",,"",1372,"Mys merth",1
5186,"ViewTranslation","April [month]","",,"",1372,"Mys ebrel",1
5187,"ViewTranslation","May [month]","",,"",1372,"Mys me",1
5188,"ViewTranslation","June [month]","",,"",1372,"Mys evan",1
5189,"ViewTranslation","July [month]","",,"",1372,"Mys gortheren",1
5190,"ViewTranslation","August [month]","",,"",1372,"Mye est",1
5191,"ViewTranslation","September [month]","",,"",1372,"Mys gwyngala",1
5192,"ViewTranslation","October [month]","",,"",1372,"Mys hedra",1
5193,"ViewTranslation","November [month]","",,"",1372,"Mys du",1
5194,"ViewTranslation","December [month]","",,"",1372,"Mys kevardhu",1
5195,"ViewTranslation","Jan [abbreviated month]","",,"",1372,"Gen",1
5196,"ViewTranslation","Feb [abbreviated month]","",,"",1372,"Whe>",1
5197,"ViewTranslation","Mar [abbreviated month]","",,"",1372,"Mer",1
5198,"ViewTranslation","Apr [abbreviated month]","",,"",1372,"Ebr",1
5199,"ViewTranslation","May [abbreviated month]","",,"",1372,"Me",1
5200,"ViewTranslation","Jun [abbreviated month]","",,"",1372,"Evn",1
5201,"ViewTranslation","Jul [abbreviated month]","",,"",1372,"Gor",1
5202,"ViewTranslation","Aug [abbreviated month]","",,"",1372,"Est",1
5203,"ViewTranslation","Sep [abbreviated month]","",,"",1372,"Gwn",1
5204,"ViewTranslation","Oct [abbreviated month]","",,"",1372,"Hed",1
5205,"ViewTranslation","Nov [abbreviated month]","",,"",1372,"Du",1
5206,"ViewTranslation","Dec [abbreviated month]","",,"",1372,"Kev",1
5207,"ViewTranslation","Sunday [weekday]","",,"",3694,"Sabiiti",1
5208,"ViewTranslation","Monday [weekday]","",,"",3694,"Balaza",1
5209,"ViewTranslation","Tuesday [weekday]","",,"",3694,"Lwakubiri",1
5210,"ViewTranslation","Wednesday [weekday]","",,"",3694,"Lwakusatu",1
5211,"ViewTranslation","Thursday [weekday]","",,"",3694,"Lwakuna",1
5212,"ViewTranslation","Friday [weekday]","",,"",3694,"Lwakutaano",1
5213,"ViewTranslation","Saturday [weekday]","",,"",3694,"Lwamukaaga",1
5214,"ViewTranslation","Sun [abbreviated weekday]","",,"",3694,"Sab",1
5215,"ViewTranslation","Mon [abbreviated weekday]","",,"",3694,"Bal",1
5216,"ViewTranslation","Tue [abbreviated weekday]","",,"",3694,"Lw2",1
5217,"ViewTranslation","Wed [abbreviated weekday]","",,"",3694,"Lw3",1
5218,"ViewTranslation","Thu [abbreviated weekday]","",,"",3694,"Lw4",1
5219,"ViewTranslation","Fri [abbreviated weekday]","",,"",3694,"Lw5",1
5220,"ViewTranslation","Sat [abbreviated weekday]","",,"",3694,"Lw6",1
5221,"ViewTranslation","January [month]","",,"",3694,"Janwaliyo",1
5222,"ViewTranslation","February [month]","",,"",3694,"Febwaliyo",1
5223,"ViewTranslation","March [month]","",,"",3694,"Marisi",1
5224,"ViewTranslation","April [month]","",,"",3694,"Apuli",1
5225,"ViewTranslation","May [month]","",,"",3694,"Maayi",1
5226,"ViewTranslation","June [month]","",,"",3694,"Juuni",1
5227,"ViewTranslation","July [month]","",,"",3694,"Julaai",1
5228,"ViewTranslation","August [month]","",,"",3694,"Agusito",1
5229,"ViewTranslation","September [month]","",,"",3694,"Sebuttemba",1
5230,"ViewTranslation","October [month]","",,"",3694,"Okitobba",1
5231,"ViewTranslation","November [month]","",,"",3694,"Novemba",1
5232,"ViewTranslation","December [month]","",,"",3694,"Desemba",1
5233,"ViewTranslation","Jan [abbreviated month]","",,"",3694,"Jan",1
5234,"ViewTranslation","Feb [abbreviated month]","",,"",3694,"Feb",1
5235,"ViewTranslation","Mar [abbreviated month]","",,"",3694,"Mar",1
5236,"ViewTranslation","Apr [abbreviated month]","",,"",3694,"Apu",1
5237,"ViewTranslation","May [abbreviated month]","",,"",3694,"Maa",1
5238,"ViewTranslation","Jun [abbreviated month]","",,"",3694,"Jun",1
5239,"ViewTranslation","Jul [abbreviated month]","",,"",3694,"Jul",1
5240,"ViewTranslation","Aug [abbreviated month]","",,"",3694,"Agu",1
5241,"ViewTranslation","Sep [abbreviated month]","",,"",3694,"Seb",1
5242,"ViewTranslation","Oct [abbreviated month]","",,"",3694,"Oki",1
5243,"ViewTranslation","Nov [abbreviated month]","",,"",3694,"Nov",1
5244,"ViewTranslation","Dec [abbreviated month]","",,"",3694,"Des",1
5245,"ViewTranslation","Sunday [weekday]","",,"",3428,"ອາທິດ",1
5246,"ViewTranslation","Monday [weekday]","",,"",3428,"ຈັນ",1
5247,"ViewTranslation","Tuesday [weekday]","",,"",3428,"ອັງຄານ",1
5248,"ViewTranslation","Wednesday [weekday]","",,"",3428,"ພຸດ",1
5249,"ViewTranslation","Thursday [weekday]","",,"",3428,"ພະຫັດ",1
5250,"ViewTranslation","Friday [weekday]","",,"",3428,"ສຸກ",1
5251,"ViewTranslation","Saturday [weekday]","",,"",3428,"ເສົາ",1
5252,"ViewTranslation","Sun [abbreviated weekday]","",,"",3428,"ອາ.",1
5253,"ViewTranslation","Mon [abbreviated weekday]","",,"",3428,"ຈ.",1
5254,"ViewTranslation","Tue [abbreviated weekday]","",,"",3428,"ຄ.",1
5255,"ViewTranslation","Wed [abbreviated weekday]","",,"",3428,"ພ.",1
5256,"ViewTranslation","Thu [abbreviated weekday]","",,"",3428,"ພຫ.",1
5257,"ViewTranslation","Fri [abbreviated weekday]","",,"",3428,"ສ.",1
5258,"ViewTranslation","Sat [abbreviated weekday]","",,"",3428,"ສ.",1
5259,"ViewTranslation","January [month]","",,"",3428,"ມັງກອນ",1
5260,"ViewTranslation","February [month]","",,"",3428,"ກຸມຟາ",1
5261,"ViewTranslation","March [month]","",,"",3428,"ມີນາ",1
5262,"ViewTranslation","April [month]","",,"",3428,"ເມສາ",1
5263,"ViewTranslation","May [month]","",,"",3428,"ພຶດສະພາ",1
5264,"ViewTranslation","June [month]","",,"",3428,"ມິຖຸນາ",1
5265,"ViewTranslation","July [month]","",,"",3428,"ກໍລະກົດ",1
5266,"ViewTranslation","August [month]","",,"",3428,"ສິງຫາ",1
5267,"ViewTranslation","September [month]","",,"",3428,"ກັນຍາ",1
5268,"ViewTranslation","October [month]","",,"",3428,"ຕຸລາ",1
5269,"ViewTranslation","November [month]","",,"",3428,"ພະຈິກ",1
5270,"ViewTranslation","December [month]","",,"",3428,"ທັນວາ",1
5271,"ViewTranslation","Jan [abbreviated month]","",,"",3428,"ມ.ກ.",1
5272,"ViewTranslation","Feb [abbreviated month]","",,"",3428,"ກ.ພ.",1
5273,"ViewTranslation","Mar [abbreviated month]","",,"",3428,"ມ.ນ.",1
5274,"ViewTranslation","Apr [abbreviated month]","",,"",3428,"ມ.ສ.",1
5275,"ViewTranslation","May [abbreviated month]","",,"",3428,"ພ.ພ.",1
5276,"ViewTranslation","Jun [abbreviated month]","",,"",3428,"ມິ.ຖ.",1
5277,"ViewTranslation","Jul [abbreviated month]","",,"",3428,"ກ.ລ.",1
5278,"ViewTranslation","Aug [abbreviated month]","",,"",3428,"ສ.ຫ.",1
5279,"ViewTranslation","Sep [abbreviated month]","",,"",3428,"ກ.ຍ.",1
5280,"ViewTranslation","Oct [abbreviated month]","",,"",3428,"ຕ.ລ.",1
5281,"ViewTranslation","Nov [abbreviated month]","",,"",3428,"ພ.ຈ.",1
5282,"ViewTranslation","Dec [abbreviated month]","",,"",3428,"ທ.ວ.",1
5283,"ViewTranslation","Sunday [weekday]","",,"",3553,"Sekmadienis",1
5284,"ViewTranslation","Monday [weekday]","",,"",3553,"Pirmadienis",1
5285,"ViewTranslation","Tuesday [weekday]","",,"",3553,"Antradienis",1
5286,"ViewTranslation","Wednesday [weekday]","",,"",3553,"Trečiadienis",1
5287,"ViewTranslation","Thursday [weekday]","",,"",3553,"Ketvirtadienis",1
5288,"ViewTranslation","Friday [weekday]","",,"",3553,"Penktadienis",1
5289,"ViewTranslation","Saturday [weekday]","",,"",3553,"Šeštadienis",1
5290,"ViewTranslation","Sun [abbreviated weekday]","",,"",3553,"Sk",1
5291,"ViewTranslation","Mon [abbreviated weekday]","",,"",3553,"Pr",1
5292,"ViewTranslation","Tue [abbreviated weekday]","",,"",3553,"An",1
5293,"ViewTranslation","Wed [abbreviated weekday]","",,"",3553,"Tr",1
5294,"ViewTranslation","Thu [abbreviated weekday]","",,"",3553,"Kt",1
5295,"ViewTranslation","Fri [abbreviated weekday]","",,"",3553,"Pn",1
5296,"ViewTranslation","Sat [abbreviated weekday]","",,"",3553,"Št",1
5297,"ViewTranslation","January [month]","",,"",3553,"Sausio",1
5298,"ViewTranslation","February [month]","",,"",3553,"Vasario",1
5299,"ViewTranslation","March [month]","",,"",3553,"Kovo",1
5300,"ViewTranslation","April [month]","",,"",3553,"Balandžio",1
5301,"ViewTranslation","May [month]","",,"",3553,"Gegužės",1
5302,"ViewTranslation","June [month]","",,"",3553,"Birželio",1
5303,"ViewTranslation","July [month]","",,"",3553,"Liepos",1
5304,"ViewTranslation","August [month]","",,"",3553,"Rugpjūčio",1
5305,"ViewTranslation","September [month]","",,"",3553,"Rugsėjo",1
5306,"ViewTranslation","October [month]","",,"",3553,"Spalio",1
5307,"ViewTranslation","November [month]","",,"",3553,"Lapkričio",1
5308,"ViewTranslation","December [month]","",,"",3553,"Gruodžio",1
5309,"ViewTranslation","Jan [abbreviated month]","",,"",3553,"Sau",1
5310,"ViewTranslation","Feb [abbreviated month]","",,"",3553,"Vas",1
5311,"ViewTranslation","Mar [abbreviated month]","",,"",3553,"Kov",1
5312,"ViewTranslation","Apr [abbreviated month]","",,"",3553,"Bal",1
5313,"ViewTranslation","May [abbreviated month]","",,"",3553,"Geg",1
5314,"ViewTranslation","Jun [abbreviated month]","",,"",3553,"Bir",1
5315,"ViewTranslation","Jul [abbreviated month]","",,"",3553,"Lie",1
5316,"ViewTranslation","Aug [abbreviated month]","",,"",3553,"Rgp",1
5317,"ViewTranslation","Sep [abbreviated month]","",,"",3553,"Rgs",1
5318,"ViewTranslation","Oct [abbreviated month]","",,"",3553,"Spa",1
5319,"ViewTranslation","Nov [abbreviated month]","",,"",3553,"Lap",1
5320,"ViewTranslation","Dec [abbreviated month]","",,"",3553,"Grd",1
5321,"ViewTranslation","Sunday [weekday]","",,"",3435,"Svētdiena",1
5322,"ViewTranslation","Monday [weekday]","",,"",3435,"Pirmdiena",1
5323,"ViewTranslation","Tuesday [weekday]","",,"",3435,"Otrdiena",1
5324,"ViewTranslation","Wednesday [weekday]","",,"",3435,"Trešdiena",1
5325,"ViewTranslation","Thursday [weekday]","",,"",3435,"Ceturtdiena",1
5326,"ViewTranslation","Friday [weekday]","",,"",3435,"Piektdiena",1
5327,"ViewTranslation","Saturday [weekday]","",,"",3435,"Sestdiena",1
5328,"ViewTranslation","Sun [abbreviated weekday]","",,"",3435,"Sv",1
5329,"ViewTranslation","Mon [abbreviated weekday]","",,"",3435,"P ",1
5330,"ViewTranslation","Tue [abbreviated weekday]","",,"",3435,"O ",1
5331,"ViewTranslation","Wed [abbreviated weekday]","",,"",3435,"T ",1
5332,"ViewTranslation","Thu [abbreviated weekday]","",,"",3435,"C ",1
5333,"ViewTranslation","Fri [abbreviated weekday]","",,"",3435,"Pk",1
5334,"ViewTranslation","Sat [abbreviated weekday]","",,"",3435,"S ",1
5335,"ViewTranslation","January [month]","",,"",3435,"Janvāris",1
5336,"ViewTranslation","February [month]","",,"",3435,"Februāris",1
5337,"ViewTranslation","March [month]","",,"",3435,"Marts",1
5338,"ViewTranslation","April [month]","",,"",3435,"Aprīlis",1
5339,"ViewTranslation","May [month]","",,"",3435,"Maijs",1
5340,"ViewTranslation","June [month]","",,"",3435,"Jūnijs",1
5341,"ViewTranslation","July [month]","",,"",3435,"Jūlijs",1
5342,"ViewTranslation","August [month]","",,"",3435,"Augusts",1
5343,"ViewTranslation","September [month]","",,"",3435,"Septembris",1
5344,"ViewTranslation","October [month]","",,"",3435,"Oktobris",1
5345,"ViewTranslation","November [month]","",,"",3435,"Novembris",1
5346,"ViewTranslation","December [month]","",,"",3435,"Decembris",1
5347,"ViewTranslation","Jan [abbreviated month]","",,"",3435,"Jan",1
5348,"ViewTranslation","Feb [abbreviated month]","",,"",3435,"Feb",1
5349,"ViewTranslation","Mar [abbreviated month]","",,"",3435,"Mar",1
5350,"ViewTranslation","Apr [abbreviated month]","",,"",3435,"Apr",1
5351,"ViewTranslation","May [abbreviated month]","",,"",3435,"Mai",1
5352,"ViewTranslation","Jun [abbreviated month]","",,"",3435,"Jūn",1
5353,"ViewTranslation","Jul [abbreviated month]","",,"",3435,"Jūl",1
5354,"ViewTranslation","Aug [abbreviated month]","",,"",3435,"Aug",1
5355,"ViewTranslation","Sep [abbreviated month]","",,"",3435,"Sep",1
5356,"ViewTranslation","Oct [abbreviated month]","",,"",3435,"Okt",1
5357,"ViewTranslation","Nov [abbreviated month]","",,"",3435,"Nov",1
5358,"ViewTranslation","Dec [abbreviated month]","",,"",3435,"Dec",1
5359,"ViewTranslation","Sunday [weekday]","",,"",4166,"Rātapu",1
5360,"ViewTranslation","Monday [weekday]","",,"",4166,"Mane",1
5361,"ViewTranslation","Tuesday [weekday]","",,"",4166,"Tūrei",1
5362,"ViewTranslation","Wednesday [weekday]","",,"",4166,"Wenerei",1
5363,"ViewTranslation","Thursday [weekday]","",,"",4166,"Tāite",1
5364,"ViewTranslation","Friday [weekday]","",,"",4166,"Paraire",1
5365,"ViewTranslation","Saturday [weekday]","",,"",4166,"Hātarei",1
5366,"ViewTranslation","Sun [abbreviated weekday]","",,"",4166,"Ta",1
5367,"ViewTranslation","Mon [abbreviated weekday]","",,"",4166,"Ma",1
5368,"ViewTranslation","Tue [abbreviated weekday]","",,"",4166,"Tū",1
5369,"ViewTranslation","Wed [abbreviated weekday]","",,"",4166,"We",1
5370,"ViewTranslation","Thu [abbreviated weekday]","",,"",4166,"Tāi",1
5371,"ViewTranslation","Fri [abbreviated weekday]","",,"",4166,"Pa",1
5372,"ViewTranslation","Sat [abbreviated weekday]","",,"",4166,"Hā",1
5373,"ViewTranslation","January [month]","",,"",4166,"Kohi-tātea",1
5374,"ViewTranslation","February [month]","",,"",4166,"Hui-tanguru",1
5375,"ViewTranslation","March [month]","",,"",4166,"Poutū-te-rangi",1
5376,"ViewTranslation","April [month]","",,"",4166,"Paenga-whāwhā",1
5377,"ViewTranslation","May [month]","",,"",4166,"Haratua",1
5378,"ViewTranslation","June [month]","",,"",4166,"Pipiri",1
5379,"ViewTranslation","July [month]","",,"",4166,"Hōngoingoi",1
5380,"ViewTranslation","August [month]","",,"",4166,"Here-turi-kōkā",1
5381,"ViewTranslation","September [month]","",,"",4166,"Mahuru",1
5382,"ViewTranslation","October [month]","",,"",4166,"Whiringa-ā-nuku",1
5383,"ViewTranslation","November [month]","",,"",4166,"Whiringa-ā-rangi",1
5384,"ViewTranslation","December [month]","",,"",4166,"Hakihea",1
5385,"ViewTranslation","Jan [abbreviated month]","",,"",4166,"Kohi",1
5386,"ViewTranslation","Feb [abbreviated month]","",,"",4166,"Hui",1
5387,"ViewTranslation","Mar [abbreviated month]","",,"",4166,"Pou",1
5388,"ViewTranslation","Apr [abbreviated month]","",,"",4166,"Pae",1
5389,"ViewTranslation","May [abbreviated month]","",,"",4166,"Hara",1
5390,"ViewTranslation","Jun [abbreviated month]","",,"",4166,"Pipi",1
5391,"ViewTranslation","Jul [abbreviated month]","",,"",4166,"Hōngoi",1
5392,"ViewTranslation","Aug [abbreviated month]","",,"",4166,"Here",1
5393,"ViewTranslation","Sep [abbreviated month]","",,"",4166,"Mahu",1
5394,"ViewTranslation","Oct [abbreviated month]","",,"",4166,"Whi-nu",1
5395,"ViewTranslation","Nov [abbreviated month]","",,"",4166,"Whi-ra",1
5396,"ViewTranslation","Dec [abbreviated month]","",,"",4166,"Haki",1
5397,"ViewTranslation","Sunday [weekday]","",,"",3981,"Недела",1
5398,"ViewTranslation","Monday [weekday]","",,"",3981,"Понеделник",1
5399,"ViewTranslation","Tuesday [weekday]","",,"",3981,"Вторник",1
5400,"ViewTranslation","Wednesday [weekday]","",,"",3981,"Среда",1
5401,"ViewTranslation","Thursday [weekday]","",,"",3981,"Четврток",1
5402,"ViewTranslation","Friday [weekday]","",,"",3981,"Петок",1
5403,"ViewTranslation","Saturday [weekday]","",,"",3981,"Сабота",1
5404,"ViewTranslation","Sun [abbreviated weekday]","",,"",3981,"Нед",1
5405,"ViewTranslation","Mon [abbreviated weekday]","",,"",3981,"Пон",1
5406,"ViewTranslation","Tue [abbreviated weekday]","",,"",3981,"Вто",1
5407,"ViewTranslation","Wed [abbreviated weekday]","",,"",3981,"Сре",1
5408,"ViewTranslation","Thu [abbreviated weekday]","",,"",3981,"Чет",1
5409,"ViewTranslation","Fri [abbreviated weekday]","",,"",3981,"Пет",1
5410,"ViewTranslation","Sat [abbreviated weekday]","",,"",3981,"Саб",1
5411,"ViewTranslation","January [month]","",,"",3981,"Јануари",1
5412,"ViewTranslation","February [month]","",,"",3981,"Февруари",1
5413,"ViewTranslation","March [month]","",,"",3981,"Март",1
5414,"ViewTranslation","April [month]","",,"",3981,"Април",1
5415,"ViewTranslation","May [month]","",,"",3981,"Мај",1
5416,"ViewTranslation","June [month]","",,"",3981,"Јуни",1
5417,"ViewTranslation","July [month]","",,"",3981,"Јули",1
5418,"ViewTranslation","August [month]","",,"",3981,"Август",1
5419,"ViewTranslation","September [month]","",,"",3981,"Септември",1
5420,"ViewTranslation","October [month]","",,"",3981,"Октомври",1
5421,"ViewTranslation","November [month]","",,"",3981,"Ноември",1
5422,"ViewTranslation","December [month]","",,"",3981,"Декември",1
5423,"ViewTranslation","Jan [abbreviated month]","",,"",3981,"Јан",1
5424,"ViewTranslation","Feb [abbreviated month]","",,"",3981,"Фев",1
5425,"ViewTranslation","Mar [abbreviated month]","",,"",3981,"Мар",1
5426,"ViewTranslation","Apr [abbreviated month]","",,"",3981,"Апр",1
5427,"ViewTranslation","May [abbreviated month]","",,"",3981,"Мај",1
5428,"ViewTranslation","Jun [abbreviated month]","",,"",3981,"Јун",1
5429,"ViewTranslation","Jul [abbreviated month]","",,"",3981,"Јул",1
5430,"ViewTranslation","Aug [abbreviated month]","",,"",3981,"Авг",1
5431,"ViewTranslation","Sep [abbreviated month]","",,"",3981,"Сеп",1
5432,"ViewTranslation","Oct [abbreviated month]","",,"",3981,"Окт",1
5433,"ViewTranslation","Nov [abbreviated month]","",,"",3981,"Ное",1
5434,"ViewTranslation","Dec [abbreviated month]","",,"",3981,"Дек",1
5435,"ViewTranslation","Sunday [weekday]","",,"",3736,"ഞായറു്",1
5436,"ViewTranslation","Monday [weekday]","",,"",3736,"തിങ്കളു്",1
5437,"ViewTranslation","Tuesday [weekday]","",,"",3736,"ചൊവ്വ",1
5438,"ViewTranslation","Wednesday [weekday]","",,"",3736,"ബുധനു്",1
5439,"ViewTranslation","Thursday [weekday]","",,"",3736,"വ്യാഴം",1
5440,"ViewTranslation","Friday [weekday]","",,"",3736,"വെള്ളി",1
5441,"ViewTranslation","Saturday [weekday]","",,"",3736,"ശനി",1
5442,"ViewTranslation","Sun [abbreviated weekday]","",,"",3736,"ഞാ",1
5443,"ViewTranslation","Mon [abbreviated weekday]","",,"",3736,"തി",1
5444,"ViewTranslation","Tue [abbreviated weekday]","",,"",3736,"ചൊ",1
5445,"ViewTranslation","Wed [abbreviated weekday]","",,"",3736,"ബു",1
5446,"ViewTranslation","Thu [abbreviated weekday]","",,"",3736,"വ്യാ",1
5447,"ViewTranslation","Fri [abbreviated weekday]","",,"",3736,"വെ",1
5448,"ViewTranslation","Sat [abbreviated weekday]","",,"",3736,"ശ",1
5449,"ViewTranslation","January [month]","",,"",3736,"ജനുവരി",1
5450,"ViewTranslation","February [month]","",,"",3736,"ഫെബ്രുവരി",1
5451,"ViewTranslation","March [month]","",,"",3736,"മാറു്ച്ച്",1
5452,"ViewTranslation","April [month]","",,"",3736,"ഏപ്റിലു്",1
5453,"ViewTranslation","May [month]","",,"",3736,"മെയ്",1
5454,"ViewTranslation","June [month]","",,"",3736,"ജൂണു്",1
5455,"ViewTranslation","July [month]","",,"",3736,"ജൂലൈ",1
5456,"ViewTranslation","August [month]","",,"",3736,"ആഗസ്ത്",1
5457,"ViewTranslation","September [month]","",,"",3736,"സെപ്തംബറു്",1
5458,"ViewTranslation","October [month]","",,"",3736,"ഒക്ടോബറു്",1
5459,"ViewTranslation","November [month]","",,"",3736,"നവംബറു്",1
5460,"ViewTranslation","December [month]","",,"",3736,"ഡിസംബറു്",1
5461,"ViewTranslation","Jan [abbreviated month]","",,"",3736,"ജനു",1
5462,"ViewTranslation","Feb [abbreviated month]","",,"",3736,"ഫെബ്",1
5463,"ViewTranslation","Mar [abbreviated month]","",,"",3736,"മാറ്",1
5464,"ViewTranslation","Apr [abbreviated month]","",,"",3736,"ഏപ്റില്",1
5465,"ViewTranslation","May [abbreviated month]","",,"",3736,"െമയ്",1
5466,"ViewTranslation","Jun [abbreviated month]","",,"",3736,"ജൂണ്",1
5467,"ViewTranslation","Jul [abbreviated month]","",,"",3736,"ജൂൈല",1
5468,"ViewTranslation","Aug [abbreviated month]","",,"",3736,"ആഗ",1
5469,"ViewTranslation","Sep [abbreviated month]","",,"",3736,"െസപ്തം",1
5470,"ViewTranslation","Oct [abbreviated month]","",,"",3736,"ഒക്ൈട",1
5471,"ViewTranslation","Nov [abbreviated month]","",,"",3736,"നവം",1
5472,"ViewTranslation","Dec [abbreviated month]","",,"",3736,"ഡിസം",1
5473,"ViewTranslation","Sunday [weekday]","",,"",4093,"Ням",1
5474,"ViewTranslation","Monday [weekday]","",,"",4093,"Даваа",1
5475,"ViewTranslation","Tuesday [weekday]","",,"",4093,"Мягмар",1
5476,"ViewTranslation","Wednesday [weekday]","",,"",4093,"Лхагва",1
5477,"ViewTranslation","Thursday [weekday]","",,"",4093,"Пүрэв",1
5478,"ViewTranslation","Friday [weekday]","",,"",4093,"Баасан",1
5479,"ViewTranslation","Saturday [weekday]","",,"",4093,"Бямба",1
5480,"ViewTranslation","Sun [abbreviated weekday]","",,"",4093,"Ня",1
5481,"ViewTranslation","Mon [abbreviated weekday]","",,"",4093,"Да",1
5482,"ViewTranslation","Tue [abbreviated weekday]","",,"",4093,"Мя",1
5483,"ViewTranslation","Wed [abbreviated weekday]","",,"",4093,"Лх",1
5484,"ViewTranslation","Thu [abbreviated weekday]","",,"",4093,"Пү",1
5485,"ViewTranslation","Fri [abbreviated weekday]","",,"",4093,"Ба",1
5486,"ViewTranslation","Sat [abbreviated weekday]","",,"",4093,"Бя",1
5487,"ViewTranslation","January [month]","",,"",4093,"Нэгдүгээр сар",1
5488,"ViewTranslation","February [month]","",,"",4093,"Хоёрдугаар сар",1
5489,"ViewTranslation","March [month]","",,"",4093,"Гуравдугаар сар",1
5490,"ViewTranslation","April [month]","",,"",4093,"Дөрөвдүгээр сар",1
5491,"ViewTranslation","May [month]","",,"",4093,"Тавдугаар сар",1
5492,"ViewTranslation","June [month]","",,"",4093,"Зургаадугар сар",1
5493,"ViewTranslation","July [month]","",,"",4093,"Долоодугаар сар",1
5494,"ViewTranslation","August [month]","",,"",4093,"Наймдугаар сар",1
5495,"ViewTranslation","September [month]","",,"",4093,"Есдүгээр сар",1
5496,"ViewTranslation","October [month]","",,"",4093,"Аравдугаар сар",1
5497,"ViewTranslation","November [month]","",,"",4093,"Арваннэгдүгээр сар",1
5498,"ViewTranslation","December [month]","",,"",4093,"Арванхоёрдгаар сар",1
5499,"ViewTranslation","Jan [abbreviated month]","",,"",4093,"1-р",1
5500,"ViewTranslation","Feb [abbreviated month]","",,"",4093,"2-р",1
5501,"ViewTranslation","Mar [abbreviated month]","",,"",4093,"3-р",1
5502,"ViewTranslation","Apr [abbreviated month]","",,"",4093,"4-р",1
5503,"ViewTranslation","May [abbreviated month]","",,"",4093,"5-р",1
5504,"ViewTranslation","Jun [abbreviated month]","",,"",4093,"6-р",1
5505,"ViewTranslation","Jul [abbreviated month]","",,"",4093,"7-р",1
5506,"ViewTranslation","Aug [abbreviated month]","",,"",4093,"8-р",1
5507,"ViewTranslation","Sep [abbreviated month]","",,"",4093,"9-р",1
5508,"ViewTranslation","Oct [abbreviated month]","",,"",4093,"10-р",1
5509,"ViewTranslation","Nov [abbreviated month]","",,"",4093,"11-р",1
5510,"ViewTranslation","Dec [abbreviated month]","",,"",4093,"12-р",1
5511,"ViewTranslation","Sunday [weekday]","",,"",3740,"रविवार",1
5512,"ViewTranslation","Monday [weekday]","",,"",3740,"सोमवार",1
5513,"ViewTranslation","Tuesday [weekday]","",,"",3740,"मंगळवार",1
5514,"ViewTranslation","Wednesday [weekday]","",,"",3740,"मंगळवार",1
5515,"ViewTranslation","Thursday [weekday]","",,"",3740,"गुरुवार",1
5516,"ViewTranslation","Friday [weekday]","",,"",3740,"शुक्रवार",1
5517,"ViewTranslation","Saturday [weekday]","",,"",3740,"शनिवार",1
5518,"ViewTranslation","Sun [abbreviated weekday]","",,"",3740,"रवि",1
5519,"ViewTranslation","Mon [abbreviated weekday]","",,"",3740,"सोम",1
5520,"ViewTranslation","Tue [abbreviated weekday]","",,"",3740,"मंगळ",1
5521,"ViewTranslation","Wed [abbreviated weekday]","",,"",3740,"बुध",1
5522,"ViewTranslation","Thu [abbreviated weekday]","",,"",3740,"गुरु",1
5523,"ViewTranslation","Fri [abbreviated weekday]","",,"",3740,"शुक्र",1
5524,"ViewTranslation","Sat [abbreviated weekday]","",,"",3740,"शनि",1
5525,"ViewTranslation","January [month]","",,"",3740,"जानेवारी",1
5526,"ViewTranslation","February [month]","",,"",3740,"फेबृवारी",1
5527,"ViewTranslation","March [month]","",,"",3740,"मार्च",1
5528,"ViewTranslation","April [month]","",,"",3740,"एप्रिल",1
5529,"ViewTranslation","May [month]","",,"",3740,"मे",1
5530,"ViewTranslation","June [month]","",,"",3740,"जून",1
5531,"ViewTranslation","July [month]","",,"",3740,"जुलै",1
5532,"ViewTranslation","August [month]","",,"",3740,"ओगस्ट",1
5533,"ViewTranslation","September [month]","",,"",3740,"सेप्टेंबर",1
5534,"ViewTranslation","October [month]","",,"",3740,"ओक्टोबर",1
5535,"ViewTranslation","November [month]","",,"",3740,"नोव्हेंबर",1
5536,"ViewTranslation","December [month]","",,"",3740,"डिसेंबर",1
5537,"ViewTranslation","Jan [abbreviated month]","",,"",3740,"जानेवारी",1
5538,"ViewTranslation","Feb [abbreviated month]","",,"",3740,"फेबृवारी",1
5539,"ViewTranslation","Mar [abbreviated month]","",,"",3740,"मार्च",1
5540,"ViewTranslation","Apr [abbreviated month]","",,"",3740,"एप्रिल",1
5541,"ViewTranslation","May [abbreviated month]","",,"",3740,"मे",1
5542,"ViewTranslation","Jun [abbreviated month]","",,"",3740,"जून",1
5543,"ViewTranslation","Jul [abbreviated month]","",,"",3740,"जुलै",1
5544,"ViewTranslation","Aug [abbreviated month]","",,"",3740,"ओगस्ट",1
5545,"ViewTranslation","Sep [abbreviated month]","",,"",3740,"सेप्टेंबर",1
5546,"ViewTranslation","Oct [abbreviated month]","",,"",3740,"ओक्टोबर",1
5547,"ViewTranslation","Nov [abbreviated month]","",,"",3740,"नोव्हेंबर",1
5548,"ViewTranslation","Dec [abbreviated month]","",,"",3740,"डिसेंबर",1
5549,"ViewTranslation","Sunday [weekday]","",,"",4184,"Ahad",1
5550,"ViewTranslation","Monday [weekday]","",,"",4184,"Isnin",1
5551,"ViewTranslation","Tuesday [weekday]","",,"",4184,"Selasa",1
5552,"ViewTranslation","Wednesday [weekday]","",,"",4184,"Rabu",1
5553,"ViewTranslation","Thursday [weekday]","",,"",4184,"Khamis",1
5554,"ViewTranslation","Friday [weekday]","",,"",4184,"Jumaat",1
5555,"ViewTranslation","Saturday [weekday]","",,"",4184,"Sabtu",1
5556,"ViewTranslation","Sun [abbreviated weekday]","",,"",4184,"Ahd",1
5557,"ViewTranslation","Mon [abbreviated weekday]","",,"",4184,"Isn",1
5558,"ViewTranslation","Tue [abbreviated weekday]","",,"",4184,"Sel",1
5559,"ViewTranslation","Wed [abbreviated weekday]","",,"",4184,"Rab",1
5560,"ViewTranslation","Thu [abbreviated weekday]","",,"",4184,"Kha",1
5561,"ViewTranslation","Fri [abbreviated weekday]","",,"",4184,"Jum",1
5562,"ViewTranslation","Sat [abbreviated weekday]","",,"",4184,"Sab",1
5563,"ViewTranslation","January [month]","",,"",4184,"Januari",1
5564,"ViewTranslation","February [month]","",,"",4184,"Februari",1
5565,"ViewTranslation","March [month]","",,"",4184,"Mac",1
5566,"ViewTranslation","April [month]","",,"",4184,"April",1
5567,"ViewTranslation","May [month]","",,"",4184,"Mei",1
5568,"ViewTranslation","June [month]","",,"",4184,"Jun",1
5569,"ViewTranslation","July [month]","",,"",4184,"Julai",1
5570,"ViewTranslation","August [month]","",,"",4184,"Ogos",1
5571,"ViewTranslation","September [month]","",,"",4184,"September",1
5572,"ViewTranslation","October [month]","",,"",4184,"Oktober",1
5573,"ViewTranslation","November [month]","",,"",4184,"November",1
5574,"ViewTranslation","December [month]","",,"",4184,"Disember",1
5575,"ViewTranslation","Jan [abbreviated month]","",,"",4184,"Jan",1
5576,"ViewTranslation","Feb [abbreviated month]","",,"",4184,"Feb",1
5577,"ViewTranslation","Mar [abbreviated month]","",,"",4184,"Mac",1
5578,"ViewTranslation","Apr [abbreviated month]","",,"",4184,"Apr",1
5579,"ViewTranslation","May [abbreviated month]","",,"",4184,"Mei",1
5580,"ViewTranslation","Jun [abbreviated month]","",,"",4184,"Jun",1
5581,"ViewTranslation","Jul [abbreviated month]","",,"",4184,"Jul",1
5582,"ViewTranslation","Aug [abbreviated month]","",,"",4184,"Ogos",1
5583,"ViewTranslation","Sep [abbreviated month]","",,"",4184,"Sep",1
5584,"ViewTranslation","Oct [abbreviated month]","",,"",4184,"Okt",1
5585,"ViewTranslation","Nov [abbreviated month]","",,"",4184,"Nov",1
5586,"ViewTranslation","Dec [abbreviated month]","",,"",4184,"Dis",1
5587,"ViewTranslation","Sunday [weekday]","",,"",4022,"Il-ħadd",1
5588,"ViewTranslation","Monday [weekday]","",,"",4022,"It-tnejn",1
5589,"ViewTranslation","Tuesday [weekday]","",,"",4022,"It-tlieta",1
5590,"ViewTranslation","Wednesday [weekday]","",,"",4022,"L-erbgħa",1
5591,"ViewTranslation","Thursday [weekday]","",,"",4022,"Il-ħamis",1
5592,"ViewTranslation","Friday [weekday]","",,"",4022,"Il-ġimgħa",1
5593,"ViewTranslation","Saturday [weekday]","",,"",4022,"Is-sibt",1
5594,"ViewTranslation","Sun [abbreviated weekday]","",,"",4022,"Ħad",1
5595,"ViewTranslation","Mon [abbreviated weekday]","",,"",4022,"Tne",1
5596,"ViewTranslation","Tue [abbreviated weekday]","",,"",4022,"Tli",1
5597,"ViewTranslation","Wed [abbreviated weekday]","",,"",4022,"Erb",1
5598,"ViewTranslation","Thu [abbreviated weekday]","",,"",4022,"Ħam",1
5599,"ViewTranslation","Fri [abbreviated weekday]","",,"",4022,"Ġim",1
5600,"ViewTranslation","Sat [abbreviated weekday]","",,"",4022,"Sib",1
5601,"ViewTranslation","January [month]","",,"",4022,"Jannar",1
5602,"ViewTranslation","February [month]","",,"",4022,"Frar",1
5603,"ViewTranslation","March [month]","",,"",4022,"Marzu",1
5604,"ViewTranslation","April [month]","",,"",4022,"April",1
5605,"ViewTranslation","May [month]","",,"",4022,"Mejju",1
5606,"ViewTranslation","June [month]","",,"",4022,"Ġunju",1
5607,"ViewTranslation","July [month]","",,"",4022,"Lulju",1
5608,"ViewTranslation","August [month]","",,"",4022,"Awissu",1
5609,"ViewTranslation","September [month]","",,"",4022,"Settembru",1
5610,"ViewTranslation","October [month]","",,"",4022,"Ottubru",1
5611,"ViewTranslation","November [month]","",,"",4022,"Novembru",1
5612,"ViewTranslation","December [month]","",,"",4022,"Diċembru ",1
5613,"ViewTranslation","Jan [abbreviated month]","",,"",4022,"Jan",1
5614,"ViewTranslation","Feb [abbreviated month]","",,"",4022,"Fra",1
5615,"ViewTranslation","Mar [abbreviated month]","",,"",4022,"Mar",1
5616,"ViewTranslation","Apr [abbreviated month]","",,"",4022,"Apr",1
5617,"ViewTranslation","May [abbreviated month]","",,"",4022,"Mej",1
5618,"ViewTranslation","Jun [abbreviated month]","",,"",4022,"Ġun",1
5619,"ViewTranslation","Jul [abbreviated month]","",,"",4022,"Lul",1
5620,"ViewTranslation","Aug [abbreviated month]","",,"",4022,"Awi",1
5621,"ViewTranslation","Sep [abbreviated month]","",,"",4022,"Set",1
5622,"ViewTranslation","Oct [abbreviated month]","",,"",4022,"Ott",1
5623,"ViewTranslation","Nov [abbreviated month]","",,"",4022,"Nov",1
5624,"ViewTranslation","Dec [abbreviated month]","",,"",4022,"Diċ",1
5625,"ViewTranslation","Sunday [weekday]","",,"",4695,"Søndag",1
5626,"ViewTranslation","Monday [weekday]","",,"",4695,"Mandag",1
5627,"ViewTranslation","Tuesday [weekday]","",,"",4695,"Tirsdag",1
5628,"ViewTranslation","Wednesday [weekday]","",,"",4695,"Onsdag",1
5629,"ViewTranslation","Thursday [weekday]","",,"",4695,"Torsdag",1
5630,"ViewTranslation","Friday [weekday]","",,"",4695,"Fredag",1
5631,"ViewTranslation","Saturday [weekday]","",,"",4695,"Lørdag",1
5632,"ViewTranslation","Sun [abbreviated weekday]","",,"",4695,"Søn",1
5633,"ViewTranslation","Mon [abbreviated weekday]","",,"",4695,"Man",1
5634,"ViewTranslation","Tue [abbreviated weekday]","",,"",4695,"Tir",1
5635,"ViewTranslation","Wed [abbreviated weekday]","",,"",4695,"Ons",1
5636,"ViewTranslation","Thu [abbreviated weekday]","",,"",4695,"Tor",1
5637,"ViewTranslation","Fri [abbreviated weekday]","",,"",4695,"Fre",1
5638,"ViewTranslation","Sat [abbreviated weekday]","",,"",4695,"Lør",1
5639,"ViewTranslation","January [month]","",,"",4695,"Januar",1
5640,"ViewTranslation","February [month]","",,"",4695,"Februar",1
5641,"ViewTranslation","March [month]","",,"",4695,"Mars",1
5642,"ViewTranslation","April [month]","",,"",4695,"April",1
5643,"ViewTranslation","May [month]","",,"",4695,"Mai",1
5644,"ViewTranslation","June [month]","",,"",4695,"Juni",1
5645,"ViewTranslation","July [month]","",,"",4695,"Juli",1
5646,"ViewTranslation","August [month]","",,"",4695,"August",1
5647,"ViewTranslation","September [month]","",,"",4695,"September",1
5648,"ViewTranslation","October [month]","",,"",4695,"Oktober",1
5649,"ViewTranslation","November [month]","",,"",4695,"November",1
5650,"ViewTranslation","December [month]","",,"",4695,"Desember",1
5651,"ViewTranslation","Jan [abbreviated month]","",,"",4695,"Jan",1
5652,"ViewTranslation","Feb [abbreviated month]","",,"",4695,"Feb",1
5653,"ViewTranslation","Mar [abbreviated month]","",,"",4695,"Mar",1
5654,"ViewTranslation","Apr [abbreviated month]","",,"",4695,"Apr",1
5655,"ViewTranslation","May [abbreviated month]","",,"",4695,"Mai",1
5656,"ViewTranslation","Jun [abbreviated month]","",,"",4695,"Jun",1
5657,"ViewTranslation","Jul [abbreviated month]","",,"",4695,"Jul",1
5658,"ViewTranslation","Aug [abbreviated month]","",,"",4695,"Aug",1
5659,"ViewTranslation","Sep [abbreviated month]","",,"",4695,"Sep",1
5660,"ViewTranslation","Oct [abbreviated month]","",,"",4695,"Okt",1
5661,"ViewTranslation","Nov [abbreviated month]","",,"",4695,"Nov",1
5662,"ViewTranslation","Dec [abbreviated month]","",,"",4695,"Des",1
5663,"ViewTranslation","Sunday [weekday]","",,"",4499,"आइतबार ",1
5664,"ViewTranslation","Monday [weekday]","",,"",4499,"सोमबार ",1
5665,"ViewTranslation","Tuesday [weekday]","",,"",4499,"मंगलबार ",1
5666,"ViewTranslation","Wednesday [weekday]","",,"",4499,"बुधबार ",1
5667,"ViewTranslation","Thursday [weekday]","",,"",4499,"बिहिबार ",1
5668,"ViewTranslation","Friday [weekday]","",,"",4499,"शुक्रबार ",1
5669,"ViewTranslation","Saturday [weekday]","",,"",4499,"शनिबार ",1
5670,"ViewTranslation","Sun [abbreviated weekday]","",,"",4499,"आइत ",1
5671,"ViewTranslation","Mon [abbreviated weekday]","",,"",4499,"सोम ",1
5672,"ViewTranslation","Tue [abbreviated weekday]","",,"",4499,"मंगल ",1
5673,"ViewTranslation","Wed [abbreviated weekday]","",,"",4499,"बुध ",1
5674,"ViewTranslation","Thu [abbreviated weekday]","",,"",4499,"बिहि ",1
5675,"ViewTranslation","Fri [abbreviated weekday]","",,"",4499,"शुक्र ",1
5676,"ViewTranslation","Sat [abbreviated weekday]","",,"",4499,"शनि ",1
5677,"ViewTranslation","January [month]","",,"",4499,"जनवरी",1
5678,"ViewTranslation","February [month]","",,"",4499,"फ़रवरी",1
5679,"ViewTranslation","March [month]","",,"",4499,"मार्च",1
5680,"ViewTranslation","April [month]","",,"",4499,"अप्रेल",1
5681,"ViewTranslation","May [month]","",,"",4499,"मई",1
5682,"ViewTranslation","June [month]","",,"",4499,"जून",1
5683,"ViewTranslation","July [month]","",,"",4499,"जुलाई",1
5684,"ViewTranslation","August [month]","",,"",4499,"अगस्त",1
5685,"ViewTranslation","September [month]","",,"",4499,"सितम्बर",1
5686,"ViewTranslation","October [month]","",,"",4499,"अक्टूबर",1
5687,"ViewTranslation","November [month]","",,"",4499,"नवम्बर",1
5688,"ViewTranslation","December [month]","",,"",4499,"दिसम्बर",1
5689,"ViewTranslation","Jan [abbreviated month]","",,"",4499,"जनवरी",1
5690,"ViewTranslation","Feb [abbreviated month]","",,"",4499,"फ़रवरी",1
5691,"ViewTranslation","Mar [abbreviated month]","",,"",4499,"मार्च",1
5692,"ViewTranslation","Apr [abbreviated month]","",,"",4499,"अप्रेल",1
5693,"ViewTranslation","May [abbreviated month]","",,"",4499,"मई",1
5694,"ViewTranslation","Jun [abbreviated month]","",,"",4499,"जून",1
5695,"ViewTranslation","Jul [abbreviated month]","",,"",4499,"जुलाई",1
5696,"ViewTranslation","Aug [abbreviated month]","",,"",4499,"अगस्त",1
5697,"ViewTranslation","Sep [abbreviated month]","",,"",4499,"सितम्बर",1
5698,"ViewTranslation","Oct [abbreviated month]","",,"",4499,"अक्टूबर",1
5699,"ViewTranslation","Nov [abbreviated month]","",,"",4499,"नवम्बर",1
5700,"ViewTranslation","Dec [abbreviated month]","",,"",4499,"दिसम्बर",1
5701,"ViewTranslation","Sunday [weekday]","",,"",4628,"zondag",1
5702,"ViewTranslation","Monday [weekday]","",,"",4628,"maandag",1
5703,"ViewTranslation","Tuesday [weekday]","",,"",4628,"dinsdag",1
5704,"ViewTranslation","Wednesday [weekday]","",,"",4628,"woensdag",1
5705,"ViewTranslation","Thursday [weekday]","",,"",4628,"donderdag",1
5706,"ViewTranslation","Friday [weekday]","",,"",4628,"vrijdag",1
5707,"ViewTranslation","Saturday [weekday]","",,"",4628,"zaterdag",1
5708,"ViewTranslation","Sun [abbreviated weekday]","",,"",4628,"zo",1
5709,"ViewTranslation","Mon [abbreviated weekday]","",,"",4628,"ma",1
5710,"ViewTranslation","Tue [abbreviated weekday]","",,"",4628,"di",1
5711,"ViewTranslation","Wed [abbreviated weekday]","",,"",4628,"wo",1
5712,"ViewTranslation","Thu [abbreviated weekday]","",,"",4628,"do",1
5713,"ViewTranslation","Fri [abbreviated weekday]","",,"",4628,"vr",1
5714,"ViewTranslation","Sat [abbreviated weekday]","",,"",4628,"za",1
5715,"ViewTranslation","January [month]","",,"",4628,"januari",1
5716,"ViewTranslation","February [month]","",,"",4628,"februari",1
5717,"ViewTranslation","March [month]","",,"",4628,"maart",1
5718,"ViewTranslation","April [month]","",,"",4628,"april",1
5719,"ViewTranslation","May [month]","",,"",4628,"mei",1
5720,"ViewTranslation","June [month]","",,"",4628,"juni",1
5721,"ViewTranslation","July [month]","",,"",4628,"juli",1
5722,"ViewTranslation","August [month]","",,"",4628,"augustus",1
5723,"ViewTranslation","September [month]","",,"",4628,"september",1
5724,"ViewTranslation","October [month]","",,"",4628,"oktober",1
5725,"ViewTranslation","November [month]","",,"",4628,"november",1
5726,"ViewTranslation","December [month]","",,"",4628,"december",1
5727,"ViewTranslation","Jan [abbreviated month]","",,"",4628,"jan",1
5728,"ViewTranslation","Feb [abbreviated month]","",,"",4628,"feb",1
5729,"ViewTranslation","Mar [abbreviated month]","",,"",4628,"mrt",1
5730,"ViewTranslation","Apr [abbreviated month]","",,"",4628,"apr",1
5731,"ViewTranslation","May [abbreviated month]","",,"",4628,"mei",1
5732,"ViewTranslation","Jun [abbreviated month]","",,"",4628,"jun",1
5733,"ViewTranslation","Jul [abbreviated month]","",,"",4628,"jul",1
5734,"ViewTranslation","Aug [abbreviated month]","",,"",4628,"aug",1
5735,"ViewTranslation","Sep [abbreviated month]","",,"",4628,"sep",1
5736,"ViewTranslation","Oct [abbreviated month]","",,"",4628,"okt",1
5737,"ViewTranslation","Nov [abbreviated month]","",,"",4628,"nov",1
5738,"ViewTranslation","Dec [abbreviated month]","",,"",4628,"dec",1
5739,"ViewTranslation","Sunday [weekday]","",,"",4682,"Sundag ",1
5740,"ViewTranslation","Monday [weekday]","",,"",4682,"Måndag ",1
5741,"ViewTranslation","Tuesday [weekday]","",,"",4682,"Tysdag ",1
5742,"ViewTranslation","Wednesday [weekday]","",,"",4682,"Onsdag ",1
5743,"ViewTranslation","Thursday [weekday]","",,"",4682,"Torsdag ",1
5744,"ViewTranslation","Friday [weekday]","",,"",4682,"Fredag ",1
5745,"ViewTranslation","Saturday [weekday]","",,"",4682,"Laurdag ",1
5746,"ViewTranslation","Sun [abbreviated weekday]","",,"",4682,"Su ",1
5747,"ViewTranslation","Mon [abbreviated weekday]","",,"",4682,"Må ",1
5748,"ViewTranslation","Tue [abbreviated weekday]","",,"",4682,"Ty ",1
5749,"ViewTranslation","Wed [abbreviated weekday]","",,"",4682,"On ",1
5750,"ViewTranslation","Thu [abbreviated weekday]","",,"",4682,"To ",1
5751,"ViewTranslation","Fri [abbreviated weekday]","",,"",4682,"Fr ",1
5752,"ViewTranslation","Sat [abbreviated weekday]","",,"",4682,"Lau ",1
5753,"ViewTranslation","January [month]","",,"",4682,"Januar",1
5754,"ViewTranslation","February [month]","",,"",4682,"Februar",1
5755,"ViewTranslation","March [month]","",,"",4682,"Mars",1
5756,"ViewTranslation","April [month]","",,"",4682,"April",1
5757,"ViewTranslation","May [month]","",,"",4682,"Mai",1
5758,"ViewTranslation","June [month]","",,"",4682,"Juni",1
5759,"ViewTranslation","July [month]","",,"",4682,"Juli",1
5760,"ViewTranslation","August [month]","",,"",4682,"August",1
5761,"ViewTranslation","September [month]","",,"",4682,"September",1
5762,"ViewTranslation","October [month]","",,"",4682,"Oktober",1
5763,"ViewTranslation","November [month]","",,"",4682,"November",1
5764,"ViewTranslation","December [month]","",,"",4682,"Desember",1
5765,"ViewTranslation","Jan [abbreviated month]","",,"",4682,"Jan",1
5766,"ViewTranslation","Feb [abbreviated month]","",,"",4682,"Feb",1
5767,"ViewTranslation","Mar [abbreviated month]","",,"",4682,"Mar",1
5768,"ViewTranslation","Apr [abbreviated month]","",,"",4682,"Apr",1
5769,"ViewTranslation","May [abbreviated month]","",,"",4682,"Mai",1
5770,"ViewTranslation","Jun [abbreviated month]","",,"",4682,"Jun",1
5771,"ViewTranslation","Jul [abbreviated month]","",,"",4682,"Jul",1
5772,"ViewTranslation","Aug [abbreviated month]","",,"",4682,"Aug",1
5773,"ViewTranslation","Sep [abbreviated month]","",,"",4682,"Sep",1
5774,"ViewTranslation","Oct [abbreviated month]","",,"",4682,"Okt",1
5775,"ViewTranslation","Nov [abbreviated month]","",,"",4682,"Nov",1
5776,"ViewTranslation","Dec [abbreviated month]","",,"",4682,"Des",1
5777,"ViewTranslation","Sunday [weekday]","",,"",4709,"Søndag",1
5778,"ViewTranslation","Monday [weekday]","",,"",4709,"Mandag",1
5779,"ViewTranslation","Tuesday [weekday]","",,"",4709,"Tirsdag",1
5780,"ViewTranslation","Wednesday [weekday]","",,"",4709,"Onsdag",1
5781,"ViewTranslation","Thursday [weekday]","",,"",4709,"Torsdag",1
5782,"ViewTranslation","Friday [weekday]","",,"",4709,"Fredag",1
5783,"ViewTranslation","Saturday [weekday]","",,"",4709,"Lørdag",1
5784,"ViewTranslation","Sun [abbreviated weekday]","",,"",4709,"Søn",1
5785,"ViewTranslation","Mon [abbreviated weekday]","",,"",4709,"Man",1
5786,"ViewTranslation","Tue [abbreviated weekday]","",,"",4709,"Tir",1
5787,"ViewTranslation","Wed [abbreviated weekday]","",,"",4709,"Ons",1
5788,"ViewTranslation","Thu [abbreviated weekday]","",,"",4709,"Tor",1
5789,"ViewTranslation","Fri [abbreviated weekday]","",,"",4709,"Fre",1
5790,"ViewTranslation","Sat [abbreviated weekday]","",,"",4709,"Lør",1
5791,"ViewTranslation","January [month]","",,"",4709,"Januar",1
5792,"ViewTranslation","February [month]","",,"",4709,"Februar",1
5793,"ViewTranslation","March [month]","",,"",4709,"Mars",1
5794,"ViewTranslation","April [month]","",,"",4709,"April",1
5795,"ViewTranslation","May [month]","",,"",4709,"Mai",1
5796,"ViewTranslation","June [month]","",,"",4709,"Juni",1
5797,"ViewTranslation","July [month]","",,"",4709,"Juli",1
5798,"ViewTranslation","August [month]","",,"",4709,"August",1
5799,"ViewTranslation","September [month]","",,"",4709,"September",1
5800,"ViewTranslation","October [month]","",,"",4709,"Oktober",1
5801,"ViewTranslation","November [month]","",,"",4709,"November",1
5802,"ViewTranslation","December [month]","",,"",4709,"Desember",1
5803,"ViewTranslation","Jan [abbreviated month]","",,"",4709,"Jan",1
5804,"ViewTranslation","Feb [abbreviated month]","",,"",4709,"Feb",1
5805,"ViewTranslation","Mar [abbreviated month]","",,"",4709,"Mar",1
5806,"ViewTranslation","Apr [abbreviated month]","",,"",4709,"Apr",1
5807,"ViewTranslation","May [abbreviated month]","",,"",4709,"Mai",1
5808,"ViewTranslation","Jun [abbreviated month]","",,"",4709,"Jun",1
5809,"ViewTranslation","Jul [abbreviated month]","",,"",4709,"Jul",1
5810,"ViewTranslation","Aug [abbreviated month]","",,"",4709,"Aug",1
5811,"ViewTranslation","Sep [abbreviated month]","",,"",4709,"Sep",1
5812,"ViewTranslation","Oct [abbreviated month]","",,"",4709,"Okt",1
5813,"ViewTranslation","Nov [abbreviated month]","",,"",4709,"Nov",1
5814,"ViewTranslation","Dec [abbreviated month]","",,"",4709,"Des",1
5815,"ViewTranslation","Sunday [weekday]","",,"",4867,"Dimenge",1
5816,"ViewTranslation","Monday [weekday]","",,"",4867,"Diluns",1
5817,"ViewTranslation","Tuesday [weekday]","",,"",4867,"Dimars",1
5818,"ViewTranslation","Wednesday [weekday]","",,"",4867,"Dimecres",1
5819,"ViewTranslation","Thursday [weekday]","",,"",4867,"Dijóus",1
5820,"ViewTranslation","Friday [weekday]","",,"",4867,"Divendres",1
5821,"ViewTranslation","Saturday [weekday]","",,"",4867,"Disabte",1
5822,"ViewTranslation","Sun [abbreviated weekday]","",,"",4867,"Dim",1
5823,"ViewTranslation","Mon [abbreviated weekday]","",,"",4867,"Lun",1
5824,"ViewTranslation","Tue [abbreviated weekday]","",,"",4867,"Mar",1
5825,"ViewTranslation","Wed [abbreviated weekday]","",,"",4867,"Mec",1
5826,"ViewTranslation","Thu [abbreviated weekday]","",,"",4867,"Jóu",1
5827,"ViewTranslation","Fri [abbreviated weekday]","",,"",4867,"Ven",1
5828,"ViewTranslation","Sat [abbreviated weekday]","",,"",4867,"Sab",1
5829,"ViewTranslation","January [month]","",,"",4867,"Genièr",1
5830,"ViewTranslation","February [month]","",,"",4867,"Febrièr",1
5831,"ViewTranslation","March [month]","",,"",4867,"Març",1
5832,"ViewTranslation","April [month]","",,"",4867,"Abrial",1
5833,"ViewTranslation","May [month]","",,"",4867,"Mai",1
5834,"ViewTranslation","June [month]","",,"",4867,"Junh",1
5835,"ViewTranslation","July [month]","",,"",4867,"Julhet",1
5836,"ViewTranslation","August [month]","",,"",4867,"Agóst",1
5837,"ViewTranslation","September [month]","",,"",4867,"Setembre",1
5838,"ViewTranslation","October [month]","",,"",4867,"Octobre",1
5839,"ViewTranslation","November [month]","",,"",4867,"Novembre",1
5840,"ViewTranslation","December [month]","",,"",4867,"Decembre",1
5841,"ViewTranslation","Jan [abbreviated month]","",,"",4867,"Gen",1
5842,"ViewTranslation","Feb [abbreviated month]","",,"",4867,"Feb",1
5843,"ViewTranslation","Mar [abbreviated month]","",,"",4867,"Mar",1
5844,"ViewTranslation","Apr [abbreviated month]","",,"",4867,"Abr",1
5845,"ViewTranslation","May [abbreviated month]","",,"",4867,"Mai",1
5846,"ViewTranslation","Jun [abbreviated month]","",,"",4867,"Jun",1
5847,"ViewTranslation","Jul [abbreviated month]","",,"",4867,"Jul",1
5848,"ViewTranslation","Aug [abbreviated month]","",,"",4867,"Agó",1
5849,"ViewTranslation","Sep [abbreviated month]","",,"",4867,"Set",1
5850,"ViewTranslation","Oct [abbreviated month]","",,"",4867,"Oct",1
5851,"ViewTranslation","Nov [abbreviated month]","",,"",4867,"Nov",1
5852,"ViewTranslation","Dec [abbreviated month]","",,"",4867,"Dec",1
5853,"ViewTranslation","Sunday [weekday]","",,"",4967,"Dilbata",1
5854,"ViewTranslation","Monday [weekday]","",,"",4967,"Wiixata",1
5855,"ViewTranslation","Tuesday [weekday]","",,"",4967,"Qibxata",1
5856,"ViewTranslation","Wednesday [weekday]","",,"",4967,"Roobii",1
5857,"ViewTranslation","Thursday [weekday]","",,"",4967,"Kamiisa",1
5858,"ViewTranslation","Friday [weekday]","",,"",4967,"Jimaata",1
5859,"ViewTranslation","Saturday [weekday]","",,"",4967,"Sanbata",1
5860,"ViewTranslation","Sun [abbreviated weekday]","",,"",4967,"Dil",1
5861,"ViewTranslation","Mon [abbreviated weekday]","",,"",4967,"Wix",1
5862,"ViewTranslation","Tue [abbreviated weekday]","",,"",4967,"Qib",1
5863,"ViewTranslation","Wed [abbreviated weekday]","",,"",4967,"Rob",1
5864,"ViewTranslation","Thu [abbreviated weekday]","",,"",4967,"Kam",1
5865,"ViewTranslation","Fri [abbreviated weekday]","",,"",4967,"Jim",1
5866,"ViewTranslation","Sat [abbreviated weekday]","",,"",4967,"San",1
5867,"ViewTranslation","January [month]","",,"",4967,"Amajjii",1
5868,"ViewTranslation","February [month]","",,"",4967,"Guraandhala",1
5869,"ViewTranslation","March [month]","",,"",4967,"Bitooteessa",1
5870,"ViewTranslation","April [month]","",,"",4967,"Elba",1
5871,"ViewTranslation","May [month]","",,"",4967,"Caamsa",1
5872,"ViewTranslation","June [month]","",,"",4967,"Waxabajjii",1
5873,"ViewTranslation","July [month]","",,"",4967,"Adooleessa",1
5874,"ViewTranslation","August [month]","",,"",4967,"Hagayya",1
5875,"ViewTranslation","September [month]","",,"",4967,"Fuulbana",1
5876,"ViewTranslation","October [month]","",,"",4967,"Onkololeessa",1
5877,"ViewTranslation","November [month]","",,"",4967,"Sadaasa",1
5878,"ViewTranslation","December [month]","",,"",4967,"Muddee",1
5879,"ViewTranslation","Jan [abbreviated month]","",,"",4967,"Ama",1
5880,"ViewTranslation","Feb [abbreviated month]","",,"",4967,"Gur",1
5881,"ViewTranslation","Mar [abbreviated month]","",,"",4967,"Bit",1
5882,"ViewTranslation","Apr [abbreviated month]","",,"",4967,"Elb",1
5883,"ViewTranslation","May [abbreviated month]","",,"",4967,"Cam",1
5884,"ViewTranslation","Jun [abbreviated month]","",,"",4967,"Wax",1
5885,"ViewTranslation","Jul [abbreviated month]","",,"",4967,"Ado",1
5886,"ViewTranslation","Aug [abbreviated month]","",,"",4967,"Hag",1
5887,"ViewTranslation","Sep [abbreviated month]","",,"",4967,"Ful",1
5888,"ViewTranslation","Oct [abbreviated month]","",,"",4967,"Onk",1
5889,"ViewTranslation","Nov [abbreviated month]","",,"",4967,"Sad",1
5890,"ViewTranslation","Dec [abbreviated month]","",,"",4967,"Mud",1
5891,"ViewTranslation","Sunday [weekday]","",,"",5031,"ਆੈਤਵਾਰ ",1
5892,"ViewTranslation","Monday [weekday]","",,"",5031,"ਸੋਮਵਾਰ ",1
5893,"ViewTranslation","Tuesday [weekday]","",,"",5031,"ਮੰਗਲਵਾਰ ",1
5894,"ViewTranslation","Wednesday [weekday]","",,"",5031,"ਬੁੱਧਵਾਰ ",1
5895,"ViewTranslation","Thursday [weekday]","",,"",5031,"ਵੀਰਵਾਰ ",1
5896,"ViewTranslation","Friday [weekday]","",,"",5031,"ਸ਼ੁਕਰਵਾਰ ",1
5897,"ViewTranslation","Saturday [weekday]","",,"",5031,"ਸ਼ਨੀਵਾਰ ",1
5898,"ViewTranslation","Sun [abbreviated weekday]","",,"",5031,"ਆੈਤ ",1
5899,"ViewTranslation","Mon [abbreviated weekday]","",,"",5031,"ਸੋਮ ",1
5900,"ViewTranslation","Tue [abbreviated weekday]","",,"",5031,"ਮੰਗਲ ",1
5901,"ViewTranslation","Wed [abbreviated weekday]","",,"",5031,"ਬੁੱਧ ",1
5902,"ViewTranslation","Thu [abbreviated weekday]","",,"",5031,"ਵੀਰ ",1
5903,"ViewTranslation","Fri [abbreviated weekday]","",,"",5031,"ਸ਼ੁਕਰ ",1
5904,"ViewTranslation","Sat [abbreviated weekday]","",,"",5031,"ਸ਼ਨੀ ",1
5905,"ViewTranslation","January [month]","",,"",5031,"ਜਨਵਰੀ",1
5906,"ViewTranslation","February [month]","",,"",5031,"ਫ਼ਰਵਰੀ",1
5907,"ViewTranslation","March [month]","",,"",5031,"ਮਾਰਛ",1
5908,"ViewTranslation","April [month]","",,"",5031,"ਅਪ਼ੈਲ",1
5909,"ViewTranslation","May [month]","",,"",5031,"ਮੲੀ",1
5910,"ViewTranslation","June [month]","",,"",5031,"ਜੂਨ",1
5911,"ViewTranslation","July [month]","",,"",5031,"ਜੁਲਾੲੀ",1
5912,"ViewTranslation","August [month]","",,"",5031,"ਅਗਸਤ",1
5913,"ViewTranslation","September [month]","",,"",5031,"ਸਿਤੰਬਰ",1
5914,"ViewTranslation","October [month]","",,"",5031,"ਅਕਤੂਬਰ",1
5915,"ViewTranslation","November [month]","",,"",5031,"ਨਵੰਬਰ",1
5916,"ViewTranslation","December [month]","",,"",5031,"ਦਿਸੰਬਰ",1
5917,"ViewTranslation","Jan [abbreviated month]","",,"",5031,"ਜਨਵਰੀ",1
5918,"ViewTranslation","Feb [abbreviated month]","",,"",5031,"ਫ਼ਰਵਰੀ",1
5919,"ViewTranslation","Mar [abbreviated month]","",,"",5031,"ਮਾਰਛ",1
5920,"ViewTranslation","Apr [abbreviated month]","",,"",5031,"ਅਪ਼ੈਲ",1
5921,"ViewTranslation","May [abbreviated month]","",,"",5031,"ਮੲੀ",1
5922,"ViewTranslation","Jun [abbreviated month]","",,"",5031,"ਜੂਨ",1
5923,"ViewTranslation","Jul [abbreviated month]","",,"",5031,"ਜੁਲਾੲੀ",1
5924,"ViewTranslation","Aug [abbreviated month]","",,"",5031,"ਅਗਸਤ",1
5925,"ViewTranslation","Sep [abbreviated month]","",,"",5031,"ਸਿਤੰਬਰ",1
5926,"ViewTranslation","Oct [abbreviated month]","",,"",5031,"ਅਕਤੂਬਰ",1
5927,"ViewTranslation","Nov [abbreviated month]","",,"",5031,"ਨਵੰਬਰ",1
5928,"ViewTranslation","Dec [abbreviated month]","",,"",5031,"ਦਿਸੰਬਰ",1
5929,"ViewTranslation","Sunday [weekday]","",,"",5244,"Niedziela",1
5930,"ViewTranslation","Monday [weekday]","",,"",5244,"Poniedziałek",1
5931,"ViewTranslation","Tuesday [weekday]","",,"",5244,"Wtorek",1
5932,"ViewTranslation","Wednesday [weekday]","",,"",5244,"Środa",1
5933,"ViewTranslation","Thursday [weekday]","",,"",5244,"Czwartek",1
5934,"ViewTranslation","Friday [weekday]","",,"",5244,"Piątek",1
5935,"ViewTranslation","Saturday [weekday]","",,"",5244,"Sobota",1
5936,"ViewTranslation","Sun [abbreviated weekday]","",,"",5244,"Nie",1
5937,"ViewTranslation","Mon [abbreviated weekday]","",,"",5244,"Pon",1
5938,"ViewTranslation","Tue [abbreviated weekday]","",,"",5244,"Wto",1
5939,"ViewTranslation","Wed [abbreviated weekday]","",,"",5244,"Śro",1
5940,"ViewTranslation","Thu [abbreviated weekday]","",,"",5244,"Czw",1
5941,"ViewTranslation","Fri [abbreviated weekday]","",,"",5244,"Pią",1
5942,"ViewTranslation","Sat [abbreviated weekday]","",,"",5244,"Sob",1
5943,"ViewTranslation","January [month]","",,"",5244,"Styczeń",1
5944,"ViewTranslation","February [month]","",,"",5244,"Luty",1
5945,"ViewTranslation","March [month]","",,"",5244,"Marzec",1
5946,"ViewTranslation","April [month]","",,"",5244,"Kwiecień",1
5947,"ViewTranslation","May [month]","",,"",5244,"Maj",1
5948,"ViewTranslation","June [month]","",,"",5244,"Czerwiec",1
5949,"ViewTranslation","July [month]","",,"",5244,"Lipiec",1
5950,"ViewTranslation","August [month]","",,"",5244,"Sierpień",1
5951,"ViewTranslation","September [month]","",,"",5244,"Wrzesień",1
5952,"ViewTranslation","October [month]","",,"",5244,"Październik",1
5953,"ViewTranslation","November [month]","",,"",5244,"Listopad",1
5954,"ViewTranslation","December [month]","",,"",5244,"Grudzień",1
5955,"ViewTranslation","Jan [abbreviated month]","",,"",5244,"Sty",1
5956,"ViewTranslation","Feb [abbreviated month]","",,"",5244,"Lut",1
5957,"ViewTranslation","Mar [abbreviated month]","",,"",5244,"Mar",1
5958,"ViewTranslation","Apr [abbreviated month]","",,"",5244,"Kwi",1
5959,"ViewTranslation","May [abbreviated month]","",,"",5244,"Maj",1
5960,"ViewTranslation","Jun [abbreviated month]","",,"",5244,"Cze",1
5961,"ViewTranslation","Jul [abbreviated month]","",,"",5244,"Lip",1
5962,"ViewTranslation","Aug [abbreviated month]","",,"",5244,"Sie",1
5963,"ViewTranslation","Sep [abbreviated month]","",,"",5244,"Wrz",1
5964,"ViewTranslation","Oct [abbreviated month]","",,"",5244,"Paź",1
5965,"ViewTranslation","Nov [abbreviated month]","",,"",5244,"Lis",1
5966,"ViewTranslation","Dec [abbreviated month]","",,"",5244,"Gru",1
5967,"ViewTranslation","Sunday [weekday]","",,"",5250,"Domingo",1
5968,"ViewTranslation","Monday [weekday]","",,"",5250,"Segunda",1
5969,"ViewTranslation","Tuesday [weekday]","",,"",5250,"Terça",1
5970,"ViewTranslation","Wednesday [weekday]","",,"",5250,"Quarta",1
5971,"ViewTranslation","Thursday [weekday]","",,"",5250,"Quinta",1
5972,"ViewTranslation","Friday [weekday]","",,"",5250,"Sexta",1
5973,"ViewTranslation","Saturday [weekday]","",,"",5250,"Sábado",1
5974,"ViewTranslation","Sun [abbreviated weekday]","",,"",5250,"Dom",1
5975,"ViewTranslation","Mon [abbreviated weekday]","",,"",5250,"Seg",1
5976,"ViewTranslation","Tue [abbreviated weekday]","",,"",5250,"Ter",1
5977,"ViewTranslation","Wed [abbreviated weekday]","",,"",5250,"Qua",1
5978,"ViewTranslation","Thu [abbreviated weekday]","",,"",5250,"Qui",1
5979,"ViewTranslation","Fri [abbreviated weekday]","",,"",5250,"Sex",1
5980,"ViewTranslation","Sat [abbreviated weekday]","",,"",5250,"Sáb",1
5981,"ViewTranslation","January [month]","",,"",5250,"Janeiro",1
5982,"ViewTranslation","February [month]","",,"",5250,"Fevereiro",1
5983,"ViewTranslation","March [month]","",,"",5250,"Março",1
5984,"ViewTranslation","April [month]","",,"",5250,"Abril",1
5985,"ViewTranslation","May [month]","",,"",5250,"Maio",1
5986,"ViewTranslation","June [month]","",,"",5250,"Junho",1
5987,"ViewTranslation","July [month]","",,"",5250,"Julho",1
5988,"ViewTranslation","August [month]","",,"",5250,"Agosto",1
5989,"ViewTranslation","September [month]","",,"",5250,"Setembro",1
5990,"ViewTranslation","October [month]","",,"",5250,"Outubro",1
5991,"ViewTranslation","November [month]","",,"",5250,"Novembro",1
5992,"ViewTranslation","December [month]","",,"",5250,"Dezembro",1
5993,"ViewTranslation","Jan [abbreviated month]","",,"",5250,"Jan",1
5994,"ViewTranslation","Feb [abbreviated month]","",,"",5250,"Fev",1
5995,"ViewTranslation","Mar [abbreviated month]","",,"",5250,"Mar",1
5996,"ViewTranslation","Apr [abbreviated month]","",,"",5250,"Abr",1
5997,"ViewTranslation","May [abbreviated month]","",,"",5250,"Mai",1
5998,"ViewTranslation","Jun [abbreviated month]","",,"",5250,"Jun",1
5999,"ViewTranslation","Jul [abbreviated month]","",,"",5250,"Jul",1
6000,"ViewTranslation","Aug [abbreviated month]","",,"",5250,"Ago",1
6001,"ViewTranslation","Sep [abbreviated month]","",,"",5250,"Set",1
6002,"ViewTranslation","Oct [abbreviated month]","",,"",5250,"Out",1
6003,"ViewTranslation","Nov [abbreviated month]","",,"",5250,"Nov",1
6004,"ViewTranslation","Dec [abbreviated month]","",,"",5250,"Dez",1
6005,"ViewTranslation","Sunday [weekday]","",,"",5528,"Duminică",1
6006,"ViewTranslation","Monday [weekday]","",,"",5528,"Luni",1
6007,"ViewTranslation","Tuesday [weekday]","",,"",5528,"Marţi",1
6008,"ViewTranslation","Wednesday [weekday]","",,"",5528,"Miercuri",1
6009,"ViewTranslation","Thursday [weekday]","",,"",5528,"Joi",1
6010,"ViewTranslation","Friday [weekday]","",,"",5528,"Vineri",1
6011,"ViewTranslation","Saturday [weekday]","",,"",5528,"Sîmbătă",1
6012,"ViewTranslation","Sun [abbreviated weekday]","",,"",5528,"Du",1
6013,"ViewTranslation","Mon [abbreviated weekday]","",,"",5528,"Lu",1
6014,"ViewTranslation","Tue [abbreviated weekday]","",,"",5528,"Ma",1
6015,"ViewTranslation","Wed [abbreviated weekday]","",,"",5528,"Mi",1
6016,"ViewTranslation","Thu [abbreviated weekday]","",,"",5528,"Jo",1
6017,"ViewTranslation","Fri [abbreviated weekday]","",,"",5528,"Vi",1
6018,"ViewTranslation","Sat [abbreviated weekday]","",,"",5528,"Sî",1
6019,"ViewTranslation","January [month]","",,"",5528,"Ianuarie",1
6020,"ViewTranslation","February [month]","",,"",5528,"Februarie",1
6021,"ViewTranslation","March [month]","",,"",5528,"Martie",1
6022,"ViewTranslation","April [month]","",,"",5528,"Aprilie",1
6023,"ViewTranslation","May [month]","",,"",5528,"Mai",1
6024,"ViewTranslation","June [month]","",,"",5528,"Iunie",1
6025,"ViewTranslation","July [month]","",,"",5528,"Iulie",1
6026,"ViewTranslation","August [month]","",,"",5528,"August",1
6027,"ViewTranslation","September [month]","",,"",5528,"Septembrie",1
6028,"ViewTranslation","October [month]","",,"",5528,"Octombrie",1
6029,"ViewTranslation","November [month]","",,"",5528,"Noiembrie",1
6030,"ViewTranslation","December [month]","",,"",5528,"Decembrie",1
6031,"ViewTranslation","Jan [abbreviated month]","",,"",5528,"Ian",1
6032,"ViewTranslation","Feb [abbreviated month]","",,"",5528,"Feb",1
6033,"ViewTranslation","Mar [abbreviated month]","",,"",5528,"Mar",1
6034,"ViewTranslation","Apr [abbreviated month]","",,"",5528,"Apr",1
6035,"ViewTranslation","May [abbreviated month]","",,"",5528,"Mai",1
6036,"ViewTranslation","Jun [abbreviated month]","",,"",5528,"Iun",1
6037,"ViewTranslation","Jul [abbreviated month]","",,"",5528,"Iul",1
6038,"ViewTranslation","Aug [abbreviated month]","",,"",5528,"Aug",1
6039,"ViewTranslation","Sep [abbreviated month]","",,"",5528,"Sep",1
6040,"ViewTranslation","Oct [abbreviated month]","",,"",5528,"Oct",1
6041,"ViewTranslation","Nov [abbreviated month]","",,"",5528,"Nov",1
6042,"ViewTranslation","Dec [abbreviated month]","",,"",5528,"Dec",1
6043,"ViewTranslation","Sunday [weekday]","",,"",5819,"Sotnabeaivi",1
6044,"ViewTranslation","Monday [weekday]","",,"",5819,"Vuossárga",1
6045,"ViewTranslation","Tuesday [weekday]","",,"",5819,"Maŋŋebarga",1
6046,"ViewTranslation","Wednesday [weekday]","",,"",5819,"Gaskavahkku",1
6047,"ViewTranslation","Thursday [weekday]","",,"",5819,"Duorasdat",1
6048,"ViewTranslation","Friday [weekday]","",,"",5819,"Bearjadat",1
6049,"ViewTranslation","Saturday [weekday]","",,"",5819,"Lávvardat",1
6050,"ViewTranslation","Sun [abbreviated weekday]","",,"",5819,"Sotn",1
6051,"ViewTranslation","Mon [abbreviated weekday]","",,"",5819,"Vuos",1
6052,"ViewTranslation","Tue [abbreviated weekday]","",,"",5819,"Maŋ",1
6053,"ViewTranslation","Wed [abbreviated weekday]","",,"",5819,"Gask",1
6054,"ViewTranslation","Thu [abbreviated weekday]","",,"",5819,"Duor",1
6055,"ViewTranslation","Fri [abbreviated weekday]","",,"",5819,"Bear",1
6056,"ViewTranslation","Sat [abbreviated weekday]","",,"",5819,"Láv",1
6057,"ViewTranslation","January [month]","",,"",5819,"Ođđajagemánu",1
6058,"ViewTranslation","February [month]","",,"",5819,"Guovvamánu",1
6059,"ViewTranslation","March [month]","",,"",5819,"Njukčamánu",1
6060,"ViewTranslation","April [month]","",,"",5819,"Cuoŋománu",1
6061,"ViewTranslation","May [month]","",,"",5819,"Miessemánu",1
6062,"ViewTranslation","June [month]","",,"",5819,"Geassemánu",1
6063,"ViewTranslation","July [month]","",,"",5819,"Suoidnemánu",1
6064,"ViewTranslation","August [month]","",,"",5819,"Borgemánu",1
6065,"ViewTranslation","September [month]","",,"",5819,"Čakčamánu",1
6066,"ViewTranslation","October [month]","",,"",5819,"Golggotmánu",1
6067,"ViewTranslation","November [month]","",,"",5819,"Skábmamánu",1
6068,"ViewTranslation","December [month]","",,"",5819,"Juovlamánu",1
6069,"ViewTranslation","Jan [abbreviated month]","",,"",5819,"Ođđj",1
6070,"ViewTranslation","Feb [abbreviated month]","",,"",5819,"Guov",1
6071,"ViewTranslation","Mar [abbreviated month]","",,"",5819,"Njuk",1
6072,"ViewTranslation","Apr [abbreviated month]","",,"",5819,"Cuoŋ",1
6073,"ViewTranslation","May [abbreviated month]","",,"",5819,"Mies",1
6074,"ViewTranslation","Jun [abbreviated month]","",,"",5819,"Geas",1
6075,"ViewTranslation","Jul [abbreviated month]","",,"",5819,"Suoi",1
6076,"ViewTranslation","Aug [abbreviated month]","",,"",5819,"Borg",1
6077,"ViewTranslation","Sep [abbreviated month]","",,"",5819,"Čakč",1
6078,"ViewTranslation","Oct [abbreviated month]","",,"",5819,"Golg",1
6079,"ViewTranslation","Nov [abbreviated month]","",,"",5819,"Skáb",1
6080,"ViewTranslation","Dec [abbreviated month]","",,"",5819,"Juov",1
6081,"ViewTranslation","Sunday [weekday]","",,"",5728,"Sambata",1
6082,"ViewTranslation","Monday [weekday]","",,"",5728,"Sanyo",1
6083,"ViewTranslation","Tuesday [weekday]","",,"",5728,"Maakisanyo",1
6084,"ViewTranslation","Wednesday [weekday]","",,"",5728,"Roowe",1
6085,"ViewTranslation","Thursday [weekday]","",,"",5728,"Hamuse",1
6086,"ViewTranslation","Friday [weekday]","",,"",5728,"Arbe",1
6087,"ViewTranslation","Saturday [weekday]","",,"",5728,"Qidaame",1
6088,"ViewTranslation","Sun [abbreviated weekday]","",,"",5728,"Sam",1
6089,"ViewTranslation","Mon [abbreviated weekday]","",,"",5728,"San",1
6090,"ViewTranslation","Tue [abbreviated weekday]","",,"",5728,"Mak",1
6091,"ViewTranslation","Wed [abbreviated weekday]","",,"",5728,"Row",1
6092,"ViewTranslation","Thu [abbreviated weekday]","",,"",5728,"Ham",1
6093,"ViewTranslation","Fri [abbreviated weekday]","",,"",5728,"Arb",1
6094,"ViewTranslation","Sat [abbreviated weekday]","",,"",5728,"Qid",1
6095,"ViewTranslation","January [month]","",,"",5728,"January",1
6096,"ViewTranslation","February [month]","",,"",5728,"February",1
6097,"ViewTranslation","March [month]","",,"",5728,"March",1
6098,"ViewTranslation","April [month]","",,"",5728,"April",1
6099,"ViewTranslation","May [month]","",,"",5728,"May",1
6100,"ViewTranslation","June [month]","",,"",5728,"June",1
6101,"ViewTranslation","July [month]","",,"",5728,"July",1
6102,"ViewTranslation","August [month]","",,"",5728,"August",1
6103,"ViewTranslation","September [month]","",,"",5728,"September",1
6104,"ViewTranslation","October [month]","",,"",5728,"October",1
6105,"ViewTranslation","November [month]","",,"",5728,"November",1
6106,"ViewTranslation","December [month]","",,"",5728,"December",1
6107,"ViewTranslation","Jan [abbreviated month]","",,"",5728,"Jan",1
6108,"ViewTranslation","Feb [abbreviated month]","",,"",5728,"Feb",1
6109,"ViewTranslation","Mar [abbreviated month]","",,"",5728,"Mar",1
6110,"ViewTranslation","Apr [abbreviated month]","",,"",5728,"Apr",1
6111,"ViewTranslation","May [abbreviated month]","",,"",5728,"May",1
6112,"ViewTranslation","Jun [abbreviated month]","",,"",5728,"Jun",1
6113,"ViewTranslation","Jul [abbreviated month]","",,"",5728,"Jul",1
6114,"ViewTranslation","Aug [abbreviated month]","",,"",5728,"Aug",1
6115,"ViewTranslation","Sep [abbreviated month]","",,"",5728,"Sep",1
6116,"ViewTranslation","Oct [abbreviated month]","",,"",5728,"Oct",1
6117,"ViewTranslation","Nov [abbreviated month]","",,"",5728,"Nov",1
6118,"ViewTranslation","Dec [abbreviated month]","",,"",5728,"Dec",1
6119,"ViewTranslation","Sunday [weekday]","",,"",5800,"Nedeľa",1
6120,"ViewTranslation","Monday [weekday]","",,"",5800,"Pondelok",1
6121,"ViewTranslation","Tuesday [weekday]","",,"",5800,"Utorok",1
6122,"ViewTranslation","Wednesday [weekday]","",,"",5800,"Streda",1
6123,"ViewTranslation","Thursday [weekday]","",,"",5800,"Štvrtok",1
6124,"ViewTranslation","Friday [weekday]","",,"",5800,"Piatok",1
6125,"ViewTranslation","Saturday [weekday]","",,"",5800,"Sobota",1
6126,"ViewTranslation","Sun [abbreviated weekday]","",,"",5800,"Ne",1
6127,"ViewTranslation","Mon [abbreviated weekday]","",,"",5800,"Po",1
6128,"ViewTranslation","Tue [abbreviated weekday]","",,"",5800,"Ut",1
6129,"ViewTranslation","Wed [abbreviated weekday]","",,"",5800,"St",1
6130,"ViewTranslation","Thu [abbreviated weekday]","",,"",5800,"Št",1
6131,"ViewTranslation","Fri [abbreviated weekday]","",,"",5800,"Pi",1
6132,"ViewTranslation","Sat [abbreviated weekday]","",,"",5800,"So",1
6133,"ViewTranslation","January [month]","",,"",5800,"Január",1
6134,"ViewTranslation","February [month]","",,"",5800,"Február",1
6135,"ViewTranslation","March [month]","",,"",5800,"Marec",1
6136,"ViewTranslation","April [month]","",,"",5800,"Apríl",1
6137,"ViewTranslation","May [month]","",,"",5800,"Máj",1
6138,"ViewTranslation","June [month]","",,"",5800,"Jún",1
6139,"ViewTranslation","July [month]","",,"",5800,"Júl",1
6140,"ViewTranslation","August [month]","",,"",5800,"August",1
6141,"ViewTranslation","September [month]","",,"",5800,"September",1
6142,"ViewTranslation","October [month]","",,"",5800,"Október",1
6143,"ViewTranslation","November [month]","",,"",5800,"November",1
6144,"ViewTranslation","December [month]","",,"",5800,"December",1
6145,"ViewTranslation","Jan [abbreviated month]","",,"",5800,"Jan",1
6146,"ViewTranslation","Feb [abbreviated month]","",,"",5800,"Feb",1
6147,"ViewTranslation","Mar [abbreviated month]","",,"",5800,"Mar",1
6148,"ViewTranslation","Apr [abbreviated month]","",,"",5800,"Apr",1
6149,"ViewTranslation","May [abbreviated month]","",,"",5800,"Máj",1
6150,"ViewTranslation","Jun [abbreviated month]","",,"",5800,"Jún",1
6151,"ViewTranslation","Jul [abbreviated month]","",,"",5800,"Júl",1
6152,"ViewTranslation","Aug [abbreviated month]","",,"",5800,"Aug",1
6153,"ViewTranslation","Sep [abbreviated month]","",,"",5800,"Sep",1
6154,"ViewTranslation","Oct [abbreviated month]","",,"",5800,"Okt",1
6155,"ViewTranslation","Nov [abbreviated month]","",,"",5800,"Nov",1
6156,"ViewTranslation","Dec [abbreviated month]","",,"",5800,"Dec",1
6157,"ViewTranslation","Sunday [weekday]","",,"",5810,"Nedelja",1
6158,"ViewTranslation","Monday [weekday]","",,"",5810,"Ponedeljek",1
6159,"ViewTranslation","Tuesday [weekday]","",,"",5810,"Torek",1
6160,"ViewTranslation","Wednesday [weekday]","",,"",5810,"Sreda",1
6161,"ViewTranslation","Thursday [weekday]","",,"",5810,"Četrtek",1
6162,"ViewTranslation","Friday [weekday]","",,"",5810,"Petek",1
6163,"ViewTranslation","Saturday [weekday]","",,"",5810,"Sobota",1
6164,"ViewTranslation","Sun [abbreviated weekday]","",,"",5810,"Ned",1
6165,"ViewTranslation","Mon [abbreviated weekday]","",,"",5810,"Pon",1
6166,"ViewTranslation","Tue [abbreviated weekday]","",,"",5810,"Tor",1
6167,"ViewTranslation","Wed [abbreviated weekday]","",,"",5810,"Sre",1
6168,"ViewTranslation","Thu [abbreviated weekday]","",,"",5810,"Čet",1
6169,"ViewTranslation","Fri [abbreviated weekday]","",,"",5810,"Pet",1
6170,"ViewTranslation","Sat [abbreviated weekday]","",,"",5810,"Sob",1
6171,"ViewTranslation","January [month]","",,"",5810,"Januar",1
6172,"ViewTranslation","February [month]","",,"",5810,"Februar",1
6173,"ViewTranslation","March [month]","",,"",5810,"Marec",1
6174,"ViewTranslation","April [month]","",,"",5810,"April",1
6175,"ViewTranslation","May [month]","",,"",5810,"Maj",1
6176,"ViewTranslation","June [month]","",,"",5810,"Junij",1
6177,"ViewTranslation","July [month]","",,"",5810,"Julij",1
6178,"ViewTranslation","August [month]","",,"",5810,"Avgust",1
6179,"ViewTranslation","September [month]","",,"",5810,"September",1
6180,"ViewTranslation","October [month]","",,"",5810,"Oktober",1
6181,"ViewTranslation","November [month]","",,"",5810,"November",1
6182,"ViewTranslation","December [month]","",,"",5810,"December",1
6183,"ViewTranslation","Jan [abbreviated month]","",,"",5810,"Jan",1
6184,"ViewTranslation","Feb [abbreviated month]","",,"",5810,"Feb",1
6185,"ViewTranslation","Mar [abbreviated month]","",,"",5810,"Mar",1
6186,"ViewTranslation","Apr [abbreviated month]","",,"",5810,"Apr",1
6187,"ViewTranslation","May [abbreviated month]","",,"",5810,"Maj",1
6188,"ViewTranslation","Jun [abbreviated month]","",,"",5810,"Jun",1
6189,"ViewTranslation","Jul [abbreviated month]","",,"",5810,"Jul",1
6190,"ViewTranslation","Aug [abbreviated month]","",,"",5810,"Avg",1
6191,"ViewTranslation","Sep [abbreviated month]","",,"",5810,"Sep",1
6192,"ViewTranslation","Oct [abbreviated month]","",,"",5810,"Okt",1
6193,"ViewTranslation","Nov [abbreviated month]","",,"",5810,"Nov",1
6194,"ViewTranslation","Dec [abbreviated month]","",,"",5810,"Dec",1
6195,"ViewTranslation","Sunday [weekday]","",,"",5876,"Axad",1
6196,"ViewTranslation","Monday [weekday]","",,"",5876,"Isniin",1
6197,"ViewTranslation","Tuesday [weekday]","",,"",5876,"Salaaso",1
6198,"ViewTranslation","Wednesday [weekday]","",,"",5876,"Arbaco",1
6199,"ViewTranslation","Thursday [weekday]","",,"",5876,"Khamiis",1
6200,"ViewTranslation","Friday [weekday]","",,"",5876,"Jimco",1
6201,"ViewTranslation","Saturday [weekday]","",,"",5876,"Sabti",1
6202,"ViewTranslation","Sun [abbreviated weekday]","",,"",5876,"Axa",1
6203,"ViewTranslation","Mon [abbreviated weekday]","",,"",5876,"Isn",1
6204,"ViewTranslation","Tue [abbreviated weekday]","",,"",5876,"Sal",1
6205,"ViewTranslation","Wed [abbreviated weekday]","",,"",5876,"Arb",1
6206,"ViewTranslation","Thu [abbreviated weekday]","",,"",5876,"Kha",1
6207,"ViewTranslation","Fri [abbreviated weekday]","",,"",5876,"Jim",1
6208,"ViewTranslation","Sat [abbreviated weekday]","",,"",5876,"Sab",1
6209,"ViewTranslation","January [month]","",,"",5876,"Bisha koobaad",1
6210,"ViewTranslation","February [month]","",,"",5876,"Bisha labaad",1
6211,"ViewTranslation","March [month]","",,"",5876,"Bisha saddexaad",1
6212,"ViewTranslation","April [month]","",,"",5876,"Bisha afraad",1
6213,"ViewTranslation","May [month]","",,"",5876,"Bisha shanaad",1
6214,"ViewTranslation","June [month]","",,"",5876,"Bisha lixaad",1
6215,"ViewTranslation","July [month]","",,"",5876,"Bisha todobaad",1
6216,"ViewTranslation","August [month]","",,"",5876,"Bisha sideedaad",1
6217,"ViewTranslation","September [month]","",,"",5876,"Bisha sagaalaad",1
6218,"ViewTranslation","October [month]","",,"",5876,"Bisha tobnaad",1
6219,"ViewTranslation","November [month]","",,"",5876,"Bisha kow iyo tobnaad",1
6220,"ViewTranslation","December [month]","",,"",5876,"Bisha laba iyo tobnaad",1
6221,"ViewTranslation","Jan [abbreviated month]","",,"",5876,"Kob",1
6222,"ViewTranslation","Feb [abbreviated month]","",,"",5876,"Lab",1
6223,"ViewTranslation","Mar [abbreviated month]","",,"",5876,"Sad",1
6224,"ViewTranslation","Apr [abbreviated month]","",,"",5876,"Afr",1
6225,"ViewTranslation","May [abbreviated month]","",,"",5876,"Sha",1
6226,"ViewTranslation","Jun [abbreviated month]","",,"",5876,"Lix",1
6227,"ViewTranslation","Jul [abbreviated month]","",,"",5876,"Tod",1
6228,"ViewTranslation","Aug [abbreviated month]","",,"",5876,"Sid",1
6229,"ViewTranslation","Sep [abbreviated month]","",,"",5876,"Sag",1
6230,"ViewTranslation","Oct [abbreviated month]","",,"",5876,"Tob",1
6231,"ViewTranslation","Nov [abbreviated month]","",,"",5876,"Kit",1
6232,"ViewTranslation","Dec [abbreviated month]","",,"",5876,"Lit",1
6233,"ViewTranslation","Sunday [weekday]","",,"",5910,"E diel ",1
6234,"ViewTranslation","Monday [weekday]","",,"",5910,"E hënë ",1
6235,"ViewTranslation","Tuesday [weekday]","",,"",5910,"E martë ",1
6236,"ViewTranslation","Wednesday [weekday]","",,"",5910,"E mërkurë ",1
6237,"ViewTranslation","Thursday [weekday]","",,"",5910,"E enjte ",1
6238,"ViewTranslation","Friday [weekday]","",,"",5910,"E premte ",1
6239,"ViewTranslation","Saturday [weekday]","",,"",5910,"E shtunë ",1
6240,"ViewTranslation","Sun [abbreviated weekday]","",,"",5910,"Die ",1
6241,"ViewTranslation","Mon [abbreviated weekday]","",,"",5910,"Hën ",1
6242,"ViewTranslation","Tue [abbreviated weekday]","",,"",5910,"Mar ",1
6243,"ViewTranslation","Wed [abbreviated weekday]","",,"",5910,"Mër ",1
6244,"ViewTranslation","Thu [abbreviated weekday]","",,"",5910,"Enj ",1
6245,"ViewTranslation","Fri [abbreviated weekday]","",,"",5910,"Pre ",1
6246,"ViewTranslation","Sat [abbreviated weekday]","",,"",5910,"Sht ",1
6247,"ViewTranslation","January [month]","",,"",5910,"Janar",1
6248,"ViewTranslation","February [month]","",,"",5910,"Shkurt",1
6249,"ViewTranslation","March [month]","",,"",5910,"Mars",1
6250,"ViewTranslation","April [month]","",,"",5910,"Prill",1
6251,"ViewTranslation","May [month]","",,"",5910,"Maj",1
6252,"ViewTranslation","June [month]","",,"",5910,"Qershor",1
6253,"ViewTranslation","July [month]","",,"",5910,"Korrik",1
6254,"ViewTranslation","August [month]","",,"",5910,"Gusht",1
6255,"ViewTranslation","September [month]","",,"",5910,"Shtator",1
6256,"ViewTranslation","October [month]","",,"",5910,"Tetor",1
6257,"ViewTranslation","November [month]","",,"",5910,"Nëntor",1
6258,"ViewTranslation","December [month]","",,"",5910,"Dhjetor",1
6259,"ViewTranslation","Jan [abbreviated month]","",,"",5910,"Jan",1
6260,"ViewTranslation","Feb [abbreviated month]","",,"",5910,"Shk",1
6261,"ViewTranslation","Mar [abbreviated month]","",,"",5910,"Mar",1
6262,"ViewTranslation","Apr [abbreviated month]","",,"",5910,"Pri",1
6263,"ViewTranslation","May [abbreviated month]","",,"",5910,"Maj",1
6264,"ViewTranslation","Jun [abbreviated month]","",,"",5910,"Qer",1
6265,"ViewTranslation","Jul [abbreviated month]","",,"",5910,"Kor",1
6266,"ViewTranslation","Aug [abbreviated month]","",,"",5910,"Gsh",1
6267,"ViewTranslation","Sep [abbreviated month]","",,"",5910,"Sht",1
6268,"ViewTranslation","Oct [abbreviated month]","",,"",5910,"Tet",1
6269,"ViewTranslation","Nov [abbreviated month]","",,"",5910,"Nën",1
6270,"ViewTranslation","Dec [abbreviated month]","",,"",5910,"Dhj",1
6271,"ViewTranslation","Sunday [weekday]","",,"",5933,"Nedelja",1
6272,"ViewTranslation","Monday [weekday]","",,"",5933,"Ponedeljak",1
6273,"ViewTranslation","Tuesday [weekday]","",,"",5933,"Utorak",1
6274,"ViewTranslation","Wednesday [weekday]","",,"",5933,"Sreda",1
6275,"ViewTranslation","Thursday [weekday]","",,"",5933,"Četvrtak",1
6276,"ViewTranslation","Friday [weekday]","",,"",5933,"Petak",1
6277,"ViewTranslation","Saturday [weekday]","",,"",5933,"Subota",1
6278,"ViewTranslation","Sun [abbreviated weekday]","",,"",5933,"Ned",1
6279,"ViewTranslation","Mon [abbreviated weekday]","",,"",5933,"Pon",1
6280,"ViewTranslation","Tue [abbreviated weekday]","",,"",5933,"Uto",1
6281,"ViewTranslation","Wed [abbreviated weekday]","",,"",5933,"Sre",1
6282,"ViewTranslation","Thu [abbreviated weekday]","",,"",5933,"Čet",1
6283,"ViewTranslation","Fri [abbreviated weekday]","",,"",5933,"Pet",1
6284,"ViewTranslation","Sat [abbreviated weekday]","",,"",5933,"Sub",1
6285,"ViewTranslation","January [month]","",,"",5933,"Januar",1
6286,"ViewTranslation","February [month]","",,"",5933,"Februar",1
6287,"ViewTranslation","March [month]","",,"",5933,"Mart",1
6288,"ViewTranslation","April [month]","",,"",5933,"April",1
6289,"ViewTranslation","May [month]","",,"",5933,"Maj",1
6290,"ViewTranslation","June [month]","",,"",5933,"Juni",1
6291,"ViewTranslation","July [month]","",,"",5933,"Juli",1
6292,"ViewTranslation","August [month]","",,"",5933,"Avgust",1
6293,"ViewTranslation","September [month]","",,"",5933,"Septembar",1
6294,"ViewTranslation","October [month]","",,"",5933,"Oktobar",1
6295,"ViewTranslation","November [month]","",,"",5933,"Novembar",1
6296,"ViewTranslation","December [month]","",,"",5933,"Decembar",1
6297,"ViewTranslation","Jan [abbreviated month]","",,"",5933,"Jan",1
6298,"ViewTranslation","Feb [abbreviated month]","",,"",5933,"Feb",1
6299,"ViewTranslation","Mar [abbreviated month]","",,"",5933,"Mar",1
6300,"ViewTranslation","Apr [abbreviated month]","",,"",5933,"Apr",1
6301,"ViewTranslation","May [abbreviated month]","",,"",5933,"Maj",1
6302,"ViewTranslation","Jun [abbreviated month]","",,"",5933,"Jun",1
6303,"ViewTranslation","Jul [abbreviated month]","",,"",5933,"Jul",1
6304,"ViewTranslation","Aug [abbreviated month]","",,"",5933,"Avg",1
6305,"ViewTranslation","Sep [abbreviated month]","",,"",5933,"Sep",1
6306,"ViewTranslation","Oct [abbreviated month]","",,"",5933,"Okt",1
6307,"ViewTranslation","Nov [abbreviated month]","",,"",5933,"Nov",1
6308,"ViewTranslation","Dec [abbreviated month]","",,"",5933,"Dec",1
6309,"ViewTranslation","Sunday [weekday]","",,"",5882,"Sontaha",1
6310,"ViewTranslation","Monday [weekday]","",,"",5882,"Mmantaha",1
6311,"ViewTranslation","Tuesday [weekday]","",,"",5882,"Labobedi",1
6312,"ViewTranslation","Wednesday [weekday]","",,"",5882,"Laboraru",1
6313,"ViewTranslation","Thursday [weekday]","",,"",5882,"Labone",1
6314,"ViewTranslation","Friday [weekday]","",,"",5882,"Labohlane",1
6315,"ViewTranslation","Saturday [weekday]","",,"",5882,"Moqebelo",1
6316,"ViewTranslation","Sun [abbreviated weekday]","",,"",5882,"Son",1
6317,"ViewTranslation","Mon [abbreviated weekday]","",,"",5882,"Mma",1
6318,"ViewTranslation","Tue [abbreviated weekday]","",,"",5882,"Bed",1
6319,"ViewTranslation","Wed [abbreviated weekday]","",,"",5882,"Rar",1
6320,"ViewTranslation","Thu [abbreviated weekday]","",,"",5882,"Ne",1
6321,"ViewTranslation","Fri [abbreviated weekday]","",,"",5882,"Hla",1
6322,"ViewTranslation","Sat [abbreviated weekday]","",,"",5882,"Moq",1
6323,"ViewTranslation","January [month]","",,"",5882,"Phesekgong",1
6324,"ViewTranslation","February [month]","",,"",5882,"Hlakola",1
6325,"ViewTranslation","March [month]","",,"",5882,"Hlakubele",1
6326,"ViewTranslation","April [month]","",,"",5882,"Mmese",1
6327,"ViewTranslation","May [month]","",,"",5882,"Motsheanong",1
6328,"ViewTranslation","June [month]","",,"",5882,"Phupjane",1
6329,"ViewTranslation","July [month]","",,"",5882,"Phupu",1
6330,"ViewTranslation","August [month]","",,"",5882,"Phata",1
6331,"ViewTranslation","September [month]","",,"",5882,"Leotshe",1
6332,"ViewTranslation","October [month]","",,"",5882,"Mphalane",1
6333,"ViewTranslation","November [month]","",,"",5882,"Pundungwane",1
6334,"ViewTranslation","December [month]","",,"",5882,"Tshitwe",1
6335,"ViewTranslation","Jan [abbreviated month]","",,"",5882,"Phe",1
6336,"ViewTranslation","Feb [abbreviated month]","",,"",5882,"Kol",1
6337,"ViewTranslation","Mar [abbreviated month]","",,"",5882,"Ube",1
6338,"ViewTranslation","Apr [abbreviated month]","",,"",5882,"Mme",1
6339,"ViewTranslation","May [abbreviated month]","",,"",5882,"Mot",1
6340,"ViewTranslation","Jun [abbreviated month]","",,"",5882,"Jan",1
6341,"ViewTranslation","Jul [abbreviated month]","",,"",5882,"Upu",1
6342,"ViewTranslation","Aug [abbreviated month]","",,"",5882,"Pha",1
6343,"ViewTranslation","Sep [abbreviated month]","",,"",5882,"Leo",1
6344,"ViewTranslation","Oct [abbreviated month]","",,"",5882,"Mph",1
6345,"ViewTranslation","Nov [abbreviated month]","",,"",5882,"Pun",1
6346,"ViewTranslation","Dec [abbreviated month]","",,"",5882,"Tsh",1
6347,"ViewTranslation","Sunday [weekday]","",,"",6024,"Söndag",1
6348,"ViewTranslation","Monday [weekday]","",,"",6024,"Måndag",1
6349,"ViewTranslation","Tuesday [weekday]","",,"",6024,"Tisdag",1
6350,"ViewTranslation","Wednesday [weekday]","",,"",6024,"Onsdag",1
6351,"ViewTranslation","Thursday [weekday]","",,"",6024,"Torsdag",1
6352,"ViewTranslation","Friday [weekday]","",,"",6024,"Fredag",1
6353,"ViewTranslation","Saturday [weekday]","",,"",6024,"Lördag",1
6354,"ViewTranslation","Sun [abbreviated weekday]","",,"",6024,"Sön",1
6355,"ViewTranslation","Mon [abbreviated weekday]","",,"",6024,"Mån",1
6356,"ViewTranslation","Tue [abbreviated weekday]","",,"",6024,"Tis",1
6357,"ViewTranslation","Wed [abbreviated weekday]","",,"",6024,"Ons",1
6358,"ViewTranslation","Thu [abbreviated weekday]","",,"",6024,"Tor",1
6359,"ViewTranslation","Fri [abbreviated weekday]","",,"",6024,"Fre",1
6360,"ViewTranslation","Sat [abbreviated weekday]","",,"",6024,"Lör",1
6361,"ViewTranslation","January [month]","",,"",6024,"Januari",1
6362,"ViewTranslation","February [month]","",,"",6024,"Februari",1
6363,"ViewTranslation","March [month]","",,"",6024,"Mars",1
6364,"ViewTranslation","April [month]","",,"",6024,"April",1
6365,"ViewTranslation","May [month]","",,"",6024,"Maj",1
6366,"ViewTranslation","June [month]","",,"",6024,"Juni",1
6367,"ViewTranslation","July [month]","",,"",6024,"Juli",1
6368,"ViewTranslation","August [month]","",,"",6024,"Augusti",1
6369,"ViewTranslation","September [month]","",,"",6024,"September",1
6370,"ViewTranslation","October [month]","",,"",6024,"Oktober",1
6371,"ViewTranslation","November [month]","",,"",6024,"November",1
6372,"ViewTranslation","December [month]","",,"",6024,"December",1
6373,"ViewTranslation","Jan [abbreviated month]","",,"",6024,"Jan",1
6374,"ViewTranslation","Feb [abbreviated month]","",,"",6024,"Feb",1
6375,"ViewTranslation","Mar [abbreviated month]","",,"",6024,"Mar",1
6376,"ViewTranslation","Apr [abbreviated month]","",,"",6024,"Apr",1
6377,"ViewTranslation","May [abbreviated month]","",,"",6024,"Maj",1
6378,"ViewTranslation","Jun [abbreviated month]","",,"",6024,"Jun",1
6379,"ViewTranslation","Jul [abbreviated month]","",,"",6024,"Jul",1
6380,"ViewTranslation","Aug [abbreviated month]","",,"",6024,"Aug",1
6381,"ViewTranslation","Sep [abbreviated month]","",,"",6024,"Sep",1
6382,"ViewTranslation","Oct [abbreviated month]","",,"",6024,"Okt",1
6383,"ViewTranslation","Nov [abbreviated month]","",,"",6024,"Nov",1
6384,"ViewTranslation","Dec [abbreviated month]","",,"",6024,"Dec",1
6385,"ViewTranslation","Sunday [weekday]","",,"",6090,"ஞாயிறு",1
6386,"ViewTranslation","Monday [weekday]","",,"",6090,"திங்கள்",1
6387,"ViewTranslation","Tuesday [weekday]","",,"",6090,"செவ்வாய்",1
6388,"ViewTranslation","Wednesday [weekday]","",,"",6090,"புதன்",1
6389,"ViewTranslation","Thursday [weekday]","",,"",6090,"வியாழன்",1
6390,"ViewTranslation","Friday [weekday]","",,"",6090,"வெள்ளி",1
6391,"ViewTranslation","Saturday [weekday]","",,"",6090,"சனி",1
6392,"ViewTranslation","Sun [abbreviated weekday]","",,"",6090,"ஞ",1
6393,"ViewTranslation","Mon [abbreviated weekday]","",,"",6090,"த",1
6394,"ViewTranslation","Tue [abbreviated weekday]","",,"",6090,"ச",1
6395,"ViewTranslation","Wed [abbreviated weekday]","",,"",6090,"ப",1
6396,"ViewTranslation","Thu [abbreviated weekday]","",,"",6090,"வ",1
6397,"ViewTranslation","Fri [abbreviated weekday]","",,"",6090,"வ",1
6398,"ViewTranslation","Sat [abbreviated weekday]","",,"",6090,"ச",1
6399,"ViewTranslation","January [month]","",,"",6090,"ஜனவரி",1
6400,"ViewTranslation","February [month]","",,"",6090,"பெப்ரவரி",1
6401,"ViewTranslation","March [month]","",,"",6090,"மார்ச்",1
6402,"ViewTranslation","April [month]","",,"",6090,"ஏப்ரல்",1
6403,"ViewTranslation","May [month]","",,"",6090,"மே",1
6404,"ViewTranslation","June [month]","",,"",6090,"ஜூன்",1
6405,"ViewTranslation","July [month]","",,"",6090,"ஜூலை",1
6406,"ViewTranslation","August [month]","",,"",6090,"ஆகஸ்ட்",1
6407,"ViewTranslation","September [month]","",,"",6090,"செப்டம்பர்",1
6408,"ViewTranslation","October [month]","",,"",6090,"அக்டோபர்",1
6409,"ViewTranslation","November [month]","",,"",6090,"நவம்பர்",1
6410,"ViewTranslation","December [month]","",,"",6090,"டிசம்பர்r",1
6411,"ViewTranslation","Jan [abbreviated month]","",,"",6090,"ஜனவரி",1
6412,"ViewTranslation","Feb [abbreviated month]","",,"",6090,"பெப்ரவரி",1
6413,"ViewTranslation","Mar [abbreviated month]","",,"",6090,"மார்ச்",1
6414,"ViewTranslation","Apr [abbreviated month]","",,"",6090,"ஏப்ரல்",1
6415,"ViewTranslation","May [abbreviated month]","",,"",6090,"மே",1
6416,"ViewTranslation","Jun [abbreviated month]","",,"",6090,"ஜூன்",1
6417,"ViewTranslation","Jul [abbreviated month]","",,"",6090,"ஜூலை",1
6418,"ViewTranslation","Aug [abbreviated month]","",,"",6090,"ஆகஸ்ட்",1
6419,"ViewTranslation","Sep [abbreviated month]","",,"",6090,"செப்டம்பர்",1
6420,"ViewTranslation","Oct [abbreviated month]","",,"",6090,"அக்டோபர்",1
6421,"ViewTranslation","Nov [abbreviated month]","",,"",6090,"நவம்பர்",1
6422,"ViewTranslation","Dec [abbreviated month]","",,"",6090,"டிசம்பர்r",1
6423,"ViewTranslation","Sunday [weekday]","",,"",6182,"ఆదివారం",1
6424,"ViewTranslation","Monday [weekday]","",,"",6182,"సోమవారం",1
6425,"ViewTranslation","Tuesday [weekday]","",,"",6182,"మంగళవారం",1
6426,"ViewTranslation","Wednesday [weekday]","",,"",6182,"బుధవారం",1
6427,"ViewTranslation","Thursday [weekday]","",,"",6182,"గురువారం",1
6428,"ViewTranslation","Friday [weekday]","",,"",6182,"శుక్రవారం",1
6429,"ViewTranslation","Saturday [weekday]","",,"",6182,"శనివారం",1
6430,"ViewTranslation","Sun [abbreviated weekday]","",,"",6182,"ఆది",1
6431,"ViewTranslation","Mon [abbreviated weekday]","",,"",6182,"సోమ",1
6432,"ViewTranslation","Tue [abbreviated weekday]","",,"",6182,"మంగళ",1
6433,"ViewTranslation","Wed [abbreviated weekday]","",,"",6182,"బుధ",1
6434,"ViewTranslation","Thu [abbreviated weekday]","",,"",6182,"గురు",1
6435,"ViewTranslation","Fri [abbreviated weekday]","",,"",6182,"శుక్ర",1
6436,"ViewTranslation","Sat [abbreviated weekday]","",,"",6182,"శని",1
6437,"ViewTranslation","January [month]","",,"",6182,"జనవరి",1
6438,"ViewTranslation","February [month]","",,"",6182,"ఫిబ్రవరి",1
6439,"ViewTranslation","March [month]","",,"",6182,"మార్చి",1
6440,"ViewTranslation","April [month]","",,"",6182,"ఏప్రిల్",1
6441,"ViewTranslation","May [month]","",,"",6182,"మే",1
6442,"ViewTranslation","June [month]","",,"",6182,"జూన్",1
6443,"ViewTranslation","July [month]","",,"",6182,"జూలై",1
6444,"ViewTranslation","August [month]","",,"",6182,"ఆగస్టు",1
6445,"ViewTranslation","September [month]","",,"",6182,"సెప్టెంబర్",1
6446,"ViewTranslation","October [month]","",,"",6182,"అక్టోబర్",1
6447,"ViewTranslation","November [month]","",,"",6182,"నవంబర్",1
6448,"ViewTranslation","December [month]","",,"",6182,"డిసెంబర్",1
6449,"ViewTranslation","Jan [abbreviated month]","",,"",6182,"జనవరి",1
6450,"ViewTranslation","Feb [abbreviated month]","",,"",6182,"ఫిబ్రవరి",1
6451,"ViewTranslation","Mar [abbreviated month]","",,"",6182,"మార్చి",1
6452,"ViewTranslation","Apr [abbreviated month]","",,"",6182,"ఏప్రిల్",1
6453,"ViewTranslation","May [abbreviated month]","",,"",6182,"మే",1
6454,"ViewTranslation","Jun [abbreviated month]","",,"",6182,"జూన్",1
6455,"ViewTranslation","Jul [abbreviated month]","",,"",6182,"జూలై",1
6456,"ViewTranslation","Aug [abbreviated month]","",,"",6182,"ఆగస్టు",1
6457,"ViewTranslation","Sep [abbreviated month]","",,"",6182,"సెప్టెంబర్",1
6458,"ViewTranslation","Oct [abbreviated month]","",,"",6182,"అక్టోబర్",1
6459,"ViewTranslation","Nov [abbreviated month]","",,"",6182,"నవంబర్",1
6460,"ViewTranslation","Dec [abbreviated month]","",,"",6182,"డిసెంబర్",1
6461,"ViewTranslation","Sunday [weekday]","",,"",6210,"Воскресенье",1
6462,"ViewTranslation","Monday [weekday]","",,"",6210,"Понедельник",1
6463,"ViewTranslation","Tuesday [weekday]","",,"",6210,"Вторник",1
6464,"ViewTranslation","Wednesday [weekday]","",,"",6210,"Среда",1
6465,"ViewTranslation","Thursday [weekday]","",,"",6210,"Четверг",1
6466,"ViewTranslation","Friday [weekday]","",,"",6210,"Пятница",1
6467,"ViewTranslation","Saturday [weekday]","",,"",6210,"Суббота",1
6468,"ViewTranslation","Sun [abbreviated weekday]","",,"",6210,"Вск",1
6469,"ViewTranslation","Mon [abbreviated weekday]","",,"",6210,"Пнд",1
6470,"ViewTranslation","Tue [abbreviated weekday]","",,"",6210,"Втр",1
6471,"ViewTranslation","Wed [abbreviated weekday]","",,"",6210,"Срд",1
6472,"ViewTranslation","Thu [abbreviated weekday]","",,"",6210,"Чтв",1
6473,"ViewTranslation","Fri [abbreviated weekday]","",,"",6210,"Птн",1
6474,"ViewTranslation","Sat [abbreviated weekday]","",,"",6210,"Сбт",1
6475,"ViewTranslation","January [month]","",,"",6210,"Января",1
6476,"ViewTranslation","February [month]","",,"",6210,"Февраля",1
6477,"ViewTranslation","March [month]","",,"",6210,"Марта",1
6478,"ViewTranslation","April [month]","",,"",6210,"Апреля",1
6479,"ViewTranslation","May [month]","",,"",6210,"Мая",1
6480,"ViewTranslation","June [month]","",,"",6210,"Июня",1
6481,"ViewTranslation","July [month]","",,"",6210,"Июля",1
6482,"ViewTranslation","August [month]","",,"",6210,"Августа",1
6483,"ViewTranslation","September [month]","",,"",6210,"Сентября",1
6484,"ViewTranslation","October [month]","",,"",6210,"Октября",1
6485,"ViewTranslation","November [month]","",,"",6210,"Ноября",1
6486,"ViewTranslation","December [month]","",,"",6210,"Декабря",1
6487,"ViewTranslation","Jan [abbreviated month]","",,"",6210,"Янв",1
6488,"ViewTranslation","Feb [abbreviated month]","",,"",6210,"Фев",1
6489,"ViewTranslation","Mar [abbreviated month]","",,"",6210,"Мар",1
6490,"ViewTranslation","Apr [abbreviated month]","",,"",6210,"Апр",1
6491,"ViewTranslation","May [abbreviated month]","",,"",6210,"Май",1
6492,"ViewTranslation","Jun [abbreviated month]","",,"",6210,"Июн",1
6493,"ViewTranslation","Jul [abbreviated month]","",,"",6210,"Июл",1
6494,"ViewTranslation","Aug [abbreviated month]","",,"",6210,"Авг",1
6495,"ViewTranslation","Sep [abbreviated month]","",,"",6210,"Сен",1
6496,"ViewTranslation","Oct [abbreviated month]","",,"",6210,"Окт",1
6497,"ViewTranslation","Nov [abbreviated month]","",,"",6210,"Ноя",1
6498,"ViewTranslation","Dec [abbreviated month]","",,"",6210,"Дек",1
6499,"ViewTranslation","Sunday [weekday]","",,"",6223,"อาทิตย์",1
6500,"ViewTranslation","Monday [weekday]","",,"",6223,"จันทร์",1
6501,"ViewTranslation","Tuesday [weekday]","",,"",6223,"อังคาร",1
6502,"ViewTranslation","Wednesday [weekday]","",,"",6223,"พุธ",1
6503,"ViewTranslation","Thursday [weekday]","",,"",6223,"พฤหัสบดี",1
6504,"ViewTranslation","Friday [weekday]","",,"",6223,"ศุกร์",1
6505,"ViewTranslation","Saturday [weekday]","",,"",6223,"เสาร์",1
6506,"ViewTranslation","Sun [abbreviated weekday]","",,"",6223,"อา.",1
6507,"ViewTranslation","Mon [abbreviated weekday]","",,"",6223,"จ.",1
6508,"ViewTranslation","Tue [abbreviated weekday]","",,"",6223,"อ.",1
6509,"ViewTranslation","Wed [abbreviated weekday]","",,"",6223,"พ.",1
6510,"ViewTranslation","Thu [abbreviated weekday]","",,"",6223,"พฤ.",1
6511,"ViewTranslation","Fri [abbreviated weekday]","",,"",6223,"ศ.",1
6512,"ViewTranslation","Sat [abbreviated weekday]","",,"",6223,"ส.",1
6513,"ViewTranslation","January [month]","",,"",6223,"มกราคม",1
6514,"ViewTranslation","February [month]","",,"",6223,"กุมภาพันธ์",1
6515,"ViewTranslation","March [month]","",,"",6223,"มีนาคม",1
6516,"ViewTranslation","April [month]","",,"",6223,"เมษายน",1
6517,"ViewTranslation","May [month]","",,"",6223,"พฤษภาคม",1
6518,"ViewTranslation","June [month]","",,"",6223,"มิถุนายน",1
6519,"ViewTranslation","July [month]","",,"",6223,"กรกฎาคม",1
6520,"ViewTranslation","August [month]","",,"",6223,"สิงหาคม",1
6521,"ViewTranslation","September [month]","",,"",6223,"กันยายน",1
6522,"ViewTranslation","October [month]","",,"",6223,"ตุลาคม",1
6523,"ViewTranslation","November [month]","",,"",6223,"พฤศจิกายน",1
6524,"ViewTranslation","December [month]","",,"",6223,"ธันวาคม",1
6525,"ViewTranslation","Jan [abbreviated month]","",,"",6223,"ม.ค.",1
6526,"ViewTranslation","Feb [abbreviated month]","",,"",6223,"ก.พ.",1
6527,"ViewTranslation","Mar [abbreviated month]","",,"",6223,"มี.ค.",1
6528,"ViewTranslation","Apr [abbreviated month]","",,"",6223,"เม.ย.",1
6529,"ViewTranslation","May [abbreviated month]","",,"",6223,"พ.ค.",1
6530,"ViewTranslation","Jun [abbreviated month]","",,"",6223,"มิ.ย.",1
6531,"ViewTranslation","Jul [abbreviated month]","",,"",6223,"ก.ค.",1
6532,"ViewTranslation","Aug [abbreviated month]","",,"",6223,"ส.ค.",1
6533,"ViewTranslation","Sep [abbreviated month]","",,"",6223,"ก.ย.",1
6534,"ViewTranslation","Oct [abbreviated month]","",,"",6223,"ต.ค.",1
6535,"ViewTranslation","Nov [abbreviated month]","",,"",6223,"พ.ย.",1
6536,"ViewTranslation","Dec [abbreviated month]","",,"",6223,"ธ.ค.",1
6537,"ViewTranslation","Sunday [weekday]","",,"",6249,"ሰንበት ዓባይ",1
6538,"ViewTranslation","Monday [weekday]","",,"",6249,"ሰኖ",1
6539,"ViewTranslation","Tuesday [weekday]","",,"",6249,"ታላሸኖ",1
6540,"ViewTranslation","Wednesday [weekday]","",,"",6249,"ኣረርባዓ",1
6541,"ViewTranslation","Thursday [weekday]","",,"",6249,"ከሚሽ",1
6542,"ViewTranslation","Friday [weekday]","",,"",6249,"ጅምዓት",1
6543,"ViewTranslation","Saturday [weekday]","",,"",6249,"ሰንበት ንኢሽ",1
6544,"ViewTranslation","Sun [abbreviated weekday]","",,"",6249,"ሰ/ዓ",1
6545,"ViewTranslation","Mon [abbreviated weekday]","",,"",6249,"ሰኖ ",1
6546,"ViewTranslation","Tue [abbreviated weekday]","",,"",6249,"ታላሸ",1
6547,"ViewTranslation","Wed [abbreviated weekday]","",,"",6249,"ኣረር",1
6548,"ViewTranslation","Thu [abbreviated weekday]","",,"",6249,"ከሚሽ",1
6549,"ViewTranslation","Fri [abbreviated weekday]","",,"",6249,"ጅምዓ",1
6550,"ViewTranslation","Sat [abbreviated weekday]","",,"",6249,"ሰ/ን",1
6551,"ViewTranslation","January [month]","",,"",6249,"ጥሪ",1
6552,"ViewTranslation","February [month]","",,"",6249,"ለካቲት",1
6553,"ViewTranslation","March [month]","",,"",6249,"መጋቢት",1
6554,"ViewTranslation","April [month]","",,"",6249,"ሚያዝያ",1
6555,"ViewTranslation","May [month]","",,"",6249,"ግንቦት",1
6556,"ViewTranslation","June [month]","",,"",6249,"ሰነ",1
6557,"ViewTranslation","July [month]","",,"",6249,"ሓምለ",1
6558,"ViewTranslation","August [month]","",,"",6249,"ነሓሰ",1
6559,"ViewTranslation","September [month]","",,"",6249,"መስከረም",1
6560,"ViewTranslation","October [month]","",,"",6249,"ጥቅምቲ",1
6561,"ViewTranslation","November [month]","",,"",6249,"ሕዳር",1
6562,"ViewTranslation","December [month]","",,"",6249,"ታሕሳስ",1
6563,"ViewTranslation","Jan [abbreviated month]","",,"",6249,"ጥሪ ",1
6564,"ViewTranslation","Feb [abbreviated month]","",,"",6249,"ለካቲ",1
6565,"ViewTranslation","Mar [abbreviated month]","",,"",6249,"መጋቢ",1
6566,"ViewTranslation","Apr [abbreviated month]","",,"",6249,"ሚያዝ",1
6567,"ViewTranslation","May [abbreviated month]","",,"",6249,"ግንቦ",1
6568,"ViewTranslation","Jun [abbreviated month]","",,"",6249,"ሰነ ",1
6569,"ViewTranslation","Jul [abbreviated month]","",,"",6249,"ሓምለ",1
6570,"ViewTranslation","Aug [abbreviated month]","",,"",6249,"ነሓሰ",1
6571,"ViewTranslation","Sep [abbreviated month]","",,"",6249,"መስከ",1
6572,"ViewTranslation","Oct [abbreviated month]","",,"",6249,"ጥቅም",1
6573,"ViewTranslation","Nov [abbreviated month]","",,"",6249,"ሕዳር",1
6574,"ViewTranslation","Dec [abbreviated month]","",,"",6249,"ታሕሳ",1
6575,"ViewTranslation","Sunday [weekday]","",,"",6211,"Linggo",1
6576,"ViewTranslation","Monday [weekday]","",,"",6211,"Lunes",1
6577,"ViewTranslation","Tuesday [weekday]","",,"",6211,"Martes",1
6578,"ViewTranslation","Wednesday [weekday]","",,"",6211,"Miyerkoles",1
6579,"ViewTranslation","Thursday [weekday]","",,"",6211,"Huwebes",1
6580,"ViewTranslation","Friday [weekday]","",,"",6211,"Biyernes",1
6581,"ViewTranslation","Saturday [weekday]","",,"",6211,"Sabado",1
6582,"ViewTranslation","Sun [abbreviated weekday]","",,"",6211,"Lin",1
6583,"ViewTranslation","Mon [abbreviated weekday]","",,"",6211,"Lun",1
6584,"ViewTranslation","Tue [abbreviated weekday]","",,"",6211,"Mar",1
6585,"ViewTranslation","Wed [abbreviated weekday]","",,"",6211,"Miy",1
6586,"ViewTranslation","Thu [abbreviated weekday]","",,"",6211,"Huw",1
6587,"ViewTranslation","Fri [abbreviated weekday]","",,"",6211,"Biy",1
6588,"ViewTranslation","Sat [abbreviated weekday]","",,"",6211,"Sab",1
6589,"ViewTranslation","January [month]","",,"",6211,"Enero",1
6590,"ViewTranslation","February [month]","",,"",6211,"Pebrero",1
6591,"ViewTranslation","March [month]","",,"",6211,"Marso",1
6592,"ViewTranslation","April [month]","",,"",6211,"Abril",1
6593,"ViewTranslation","May [month]","",,"",6211,"Mayo",1
6594,"ViewTranslation","June [month]","",,"",6211,"Hunyo",1
6595,"ViewTranslation","July [month]","",,"",6211,"Hulyo",1
6596,"ViewTranslation","August [month]","",,"",6211,"Agosto",1
6597,"ViewTranslation","September [month]","",,"",6211,"Septiyembre",1
6598,"ViewTranslation","October [month]","",,"",6211,"Oktubre",1
6599,"ViewTranslation","November [month]","",,"",6211,"Nobiyembre",1
6600,"ViewTranslation","December [month]","",,"",6211,"Disyembre",1
6601,"ViewTranslation","Jan [abbreviated month]","",,"",6211,"Ene",1
6602,"ViewTranslation","Feb [abbreviated month]","",,"",6211,"Peb",1
6603,"ViewTranslation","Mar [abbreviated month]","",,"",6211,"Mar",1
6604,"ViewTranslation","Apr [abbreviated month]","",,"",6211,"Abr",1
6605,"ViewTranslation","May [abbreviated month]","",,"",6211,"May",1
6606,"ViewTranslation","Jun [abbreviated month]","",,"",6211,"Hun",1
6607,"ViewTranslation","Jul [abbreviated month]","",,"",6211,"Hul",1
6608,"ViewTranslation","Aug [abbreviated month]","",,"",6211,"Ago",1
6609,"ViewTranslation","Sep [abbreviated month]","",,"",6211,"Sep",1
6610,"ViewTranslation","Oct [abbreviated month]","",,"",6211,"Okt",1
6611,"ViewTranslation","Nov [abbreviated month]","",,"",6211,"Nob",1
6612,"ViewTranslation","Dec [abbreviated month]","",,"",6211,"Dis",1
6613,"ViewTranslation","Sunday [weekday]","",,"",6519,"Pazar",1
6614,"ViewTranslation","Monday [weekday]","",,"",6519,"Pazartesi",1
6615,"ViewTranslation","Tuesday [weekday]","",,"",6519,"Salı",1
6616,"ViewTranslation","Wednesday [weekday]","",,"",6519,"Çarşamba",1
6617,"ViewTranslation","Thursday [weekday]","",,"",6519,"Perşembe",1
6618,"ViewTranslation","Friday [weekday]","",,"",6519,"Cuma",1
6619,"ViewTranslation","Saturday [weekday]","",,"",6519,"Cumartesi",1
6620,"ViewTranslation","Sun [abbreviated weekday]","",,"",6519,"Paz",1
6621,"ViewTranslation","Mon [abbreviated weekday]","",,"",6519,"Pzt",1
6622,"ViewTranslation","Tue [abbreviated weekday]","",,"",6519,"Sal",1
6623,"ViewTranslation","Wed [abbreviated weekday]","",,"",6519,"Çrş",1
6624,"ViewTranslation","Thu [abbreviated weekday]","",,"",6519,"Prş",1
6625,"ViewTranslation","Fri [abbreviated weekday]","",,"",6519,"Cum",1
6626,"ViewTranslation","Sat [abbreviated weekday]","",,"",6519,"Cts",1
6627,"ViewTranslation","January [month]","",,"",6519,"Ocak",1
6628,"ViewTranslation","February [month]","",,"",6519,"Şubat",1
6629,"ViewTranslation","March [month]","",,"",6519,"Mart",1
6630,"ViewTranslation","April [month]","",,"",6519,"Nisan",1
6631,"ViewTranslation","May [month]","",,"",6519,"Mayıs",1
6632,"ViewTranslation","June [month]","",,"",6519,"Haziran",1
6633,"ViewTranslation","July [month]","",,"",6519,"Temmuz",1
6634,"ViewTranslation","August [month]","",,"",6519,"Ağustos",1
6635,"ViewTranslation","September [month]","",,"",6519,"Eylül",1
6636,"ViewTranslation","October [month]","",,"",6519,"Ekim",1
6637,"ViewTranslation","November [month]","",,"",6519,"Kasım",1
6638,"ViewTranslation","December [month]","",,"",6519,"Aralık",1
6639,"ViewTranslation","Jan [abbreviated month]","",,"",6519,"Oca",1
6640,"ViewTranslation","Feb [abbreviated month]","",,"",6519,"Şub",1
6641,"ViewTranslation","Mar [abbreviated month]","",,"",6519,"Mar",1
6642,"ViewTranslation","Apr [abbreviated month]","",,"",6519,"Nis",1
6643,"ViewTranslation","May [abbreviated month]","",,"",6519,"May",1
6644,"ViewTranslation","Jun [abbreviated month]","",,"",6519,"Haz",1
6645,"ViewTranslation","Jul [abbreviated month]","",,"",6519,"Tem",1
6646,"ViewTranslation","Aug [abbreviated month]","",,"",6519,"Ağu",1
6647,"ViewTranslation","Sep [abbreviated month]","",,"",6519,"Eyl",1
6648,"ViewTranslation","Oct [abbreviated month]","",,"",6519,"Eki",1
6649,"ViewTranslation","Nov [abbreviated month]","",,"",6519,"Kas",1
6650,"ViewTranslation","Dec [abbreviated month]","",,"",6519,"Ara",1
6651,"ViewTranslation","Sunday [weekday]","",,"",6097,"Якшәмбе",1
6652,"ViewTranslation","Monday [weekday]","",,"",6097,"Дышәмбе",1
6653,"ViewTranslation","Tuesday [weekday]","",,"",6097,"Сишәмбе",1
6654,"ViewTranslation","Wednesday [weekday]","",,"",6097,"Чәршәәмбе",1
6655,"ViewTranslation","Thursday [weekday]","",,"",6097,"Пәнҗешмбе",1
6656,"ViewTranslation","Friday [weekday]","",,"",6097,"Җомга",1
6657,"ViewTranslation","Saturday [weekday]","",,"",6097,"Шимбә",1
6658,"ViewTranslation","Sun [abbreviated weekday]","",,"",6097,"Якш",1
6659,"ViewTranslation","Mon [abbreviated weekday]","",,"",6097,"Дыш",1
6660,"ViewTranslation","Tue [abbreviated weekday]","",,"",6097,"Сиш",1
6661,"ViewTranslation","Wed [abbreviated weekday]","",,"",6097,"Чәрш",1
6662,"ViewTranslation","Thu [abbreviated weekday]","",,"",6097,"Пәнҗ",1
6663,"ViewTranslation","Fri [abbreviated weekday]","",,"",6097,"Җом",1
6664,"ViewTranslation","Sat [abbreviated weekday]","",,"",6097,"Шим",1
6665,"ViewTranslation","January [month]","",,"",6097,"Января",1
6666,"ViewTranslation","February [month]","",,"",6097,"Февраля",1
6667,"ViewTranslation","March [month]","",,"",6097,"Марта",1
6668,"ViewTranslation","April [month]","",,"",6097,"Апреля",1
6669,"ViewTranslation","May [month]","",,"",6097,"Мая",1
6670,"ViewTranslation","June [month]","",,"",6097,"Июня",1
6671,"ViewTranslation","July [month]","",,"",6097,"Июля",1
6672,"ViewTranslation","August [month]","",,"",6097,"Августа",1
6673,"ViewTranslation","September [month]","",,"",6097,"Сентября",1
6674,"ViewTranslation","October [month]","",,"",6097,"Октября",1
6675,"ViewTranslation","November [month]","",,"",6097,"Ноября",1
6676,"ViewTranslation","December [month]","",,"",6097,"Декабря",1
6677,"ViewTranslation","Jan [abbreviated month]","",,"",6097,"Янв",1
6678,"ViewTranslation","Feb [abbreviated month]","",,"",6097,"Фев",1
6679,"ViewTranslation","Mar [abbreviated month]","",,"",6097,"Мар",1
6680,"ViewTranslation","Apr [abbreviated month]","",,"",6097,"Апр",1
6681,"ViewTranslation","May [abbreviated month]","",,"",6097,"Май",1
6682,"ViewTranslation","Jun [abbreviated month]","",,"",6097,"Июн",1
6683,"ViewTranslation","Jul [abbreviated month]","",,"",6097,"Июл",1
6684,"ViewTranslation","Aug [abbreviated month]","",,"",6097,"Авг",1
6685,"ViewTranslation","Sep [abbreviated month]","",,"",6097,"Сен",1
6686,"ViewTranslation","Oct [abbreviated month]","",,"",6097,"Окт",1
6687,"ViewTranslation","Nov [abbreviated month]","",,"",6097,"Ноя",1
6688,"ViewTranslation","Dec [abbreviated month]","",,"",6097,"Дек",1
6689,"ViewTranslation","Sunday [weekday]","",,"",6640,"Неділя",1
6690,"ViewTranslation","Monday [weekday]","",,"",6640,"Понеділок",1
6691,"ViewTranslation","Tuesday [weekday]","",,"",6640,"Вівторок",1
6692,"ViewTranslation","Wednesday [weekday]","",,"",6640,"Середа",1
6693,"ViewTranslation","Thursday [weekday]","",,"",6640,"Четвер",1
6694,"ViewTranslation","Friday [weekday]","",,"",6640,"П'ятниця",1
6695,"ViewTranslation","Saturday [weekday]","",,"",6640,"Субота",1
6696,"ViewTranslation","Sun [abbreviated weekday]","",,"",6640,"Ндл",1
6697,"ViewTranslation","Mon [abbreviated weekday]","",,"",6640,"Пнд",1
6698,"ViewTranslation","Tue [abbreviated weekday]","",,"",6640,"Втр",1
6699,"ViewTranslation","Wed [abbreviated weekday]","",,"",6640,"Срд",1
6700,"ViewTranslation","Thu [abbreviated weekday]","",,"",6640,"Чтв",1
6701,"ViewTranslation","Fri [abbreviated weekday]","",,"",6640,"Птн",1
6702,"ViewTranslation","Sat [abbreviated weekday]","",,"",6640,"Сбт",1
6703,"ViewTranslation","January [month]","",,"",6640,"Січень",1
6704,"ViewTranslation","February [month]","",,"",6640,"Лютий",1
6705,"ViewTranslation","March [month]","",,"",6640,"Березень",1
6706,"ViewTranslation","April [month]","",,"",6640,"Квітень",1
6707,"ViewTranslation","May [month]","",,"",6640,"Травень",1
6708,"ViewTranslation","June [month]","",,"",6640,"Червень",1
6709,"ViewTranslation","July [month]","",,"",6640,"Липень",1
6710,"ViewTranslation","August [month]","",,"",6640,"Серпень",1
6711,"ViewTranslation","September [month]","",,"",6640,"Вересень",1
6712,"ViewTranslation","October [month]","",,"",6640,"Жовтень",1
6713,"ViewTranslation","November [month]","",,"",6640,"Листопад",1
6714,"ViewTranslation","December [month]","",,"",6640,"Грудень",1
6715,"ViewTranslation","Jan [abbreviated month]","",,"",6640,"Січ",1
6716,"ViewTranslation","Feb [abbreviated month]","",,"",6640,"Лют",1
6717,"ViewTranslation","Mar [abbreviated month]","",,"",6640,"Бер",1
6718,"ViewTranslation","Apr [abbreviated month]","",,"",6640,"Кві",1
6719,"ViewTranslation","May [abbreviated month]","",,"",6640,"Тра",1
6720,"ViewTranslation","Jun [abbreviated month]","",,"",6640,"Чер",1
6721,"ViewTranslation","Jul [abbreviated month]","",,"",6640,"Лип",1
6722,"ViewTranslation","Aug [abbreviated month]","",,"",6640,"Сер",1
6723,"ViewTranslation","Sep [abbreviated month]","",,"",6640,"Вер",1
6724,"ViewTranslation","Oct [abbreviated month]","",,"",6640,"Жов",1
6725,"ViewTranslation","Nov [abbreviated month]","",,"",6640,"Лис",1
6726,"ViewTranslation","Dec [abbreviated month]","",,"",6640,"Гру",1
6727,"ViewTranslation","Sunday [weekday]","",,"",6679,"اتوار",1
6728,"ViewTranslation","Monday [weekday]","",,"",6679,"پير",1
6729,"ViewTranslation","Tuesday [weekday]","",,"",6679,"منگل",1
6730,"ViewTranslation","Wednesday [weekday]","",,"",6679,"بدھ",1
6731,"ViewTranslation","Thursday [weekday]","",,"",6679,"جمعرات",1
6732,"ViewTranslation","Friday [weekday]","",,"",6679,"جمعه",1
6733,"ViewTranslation","Saturday [weekday]","",,"",6679,"هفته",1
6734,"ViewTranslation","Sun [abbreviated weekday]","",,"",6679,"اتوار",1
6735,"ViewTranslation","Mon [abbreviated weekday]","",,"",6679,"پير",1
6736,"ViewTranslation","Tue [abbreviated weekday]","",,"",6679,"منگل",1
6737,"ViewTranslation","Wed [abbreviated weekday]","",,"",6679,"بدھ",1
6738,"ViewTranslation","Thu [abbreviated weekday]","",,"",6679,"جمعرات",1
6739,"ViewTranslation","Fri [abbreviated weekday]","",,"",6679,"جمعه",1
6740,"ViewTranslation","Sat [abbreviated weekday]","",,"",6679,"هفته",1
6741,"ViewTranslation","January [month]","",,"",6679,"جنوري",1
6742,"ViewTranslation","February [month]","",,"",6679,"فروري",1
6743,"ViewTranslation","March [month]","",,"",6679,"مارچ",1
6744,"ViewTranslation","April [month]","",,"",6679,"اپريل",1
6745,"ViewTranslation","May [month]","",,"",6679,"مٓی",1
6746,"ViewTranslation","June [month]","",,"",6679,"جون",1
6747,"ViewTranslation","July [month]","",,"",6679,"جولاي",1
6748,"ViewTranslation","August [month]","",,"",6679,"اگست",1
6749,"ViewTranslation","September [month]","",,"",6679,"ستمبر",1
6750,"ViewTranslation","October [month]","",,"",6679,"اكتوبر",1
6751,"ViewTranslation","November [month]","",,"",6679,"نومبر",1
6752,"ViewTranslation","December [month]","",,"",6679,"دسمبر",1
6753,"ViewTranslation","Jan [abbreviated month]","",,"",6679,"جنوري",1
6754,"ViewTranslation","Feb [abbreviated month]","",,"",6679,"فروري",1
6755,"ViewTranslation","Mar [abbreviated month]","",,"",6679,"مارچ",1
6756,"ViewTranslation","Apr [abbreviated month]","",,"",6679,"اپريل",1
6757,"ViewTranslation","May [abbreviated month]","",,"",6679,"مٓی",1
6758,"ViewTranslation","Jun [abbreviated month]","",,"",6679,"جون",1
6759,"ViewTranslation","Jul [abbreviated month]","",,"",6679,"جولاي",1
6760,"ViewTranslation","Aug [abbreviated month]","",,"",6679,"اگست",1
6761,"ViewTranslation","Sep [abbreviated month]","",,"",6679,"ستمبر",1
6762,"ViewTranslation","Oct [abbreviated month]","",,"",6679,"اكتوبر",1
6763,"ViewTranslation","Nov [abbreviated month]","",,"",6679,"نومبر",1
6764,"ViewTranslation","Dec [abbreviated month]","",,"",6679,"دسمبر",1
6765,"ViewTranslation","Sunday [weekday]","",,"",6719,"Якшанба",1
6766,"ViewTranslation","Monday [weekday]","",,"",6719,"Душанба",1
6767,"ViewTranslation","Tuesday [weekday]","",,"",6719,"Сешанба",1
6768,"ViewTranslation","Wednesday [weekday]","",,"",6719,"Чоршанба",1
6769,"ViewTranslation","Thursday [weekday]","",,"",6719,"Пайшанба",1
6770,"ViewTranslation","Friday [weekday]","",,"",6719,"Жума",1
6771,"ViewTranslation","Saturday [weekday]","",,"",6719,"Шанба",1
6772,"ViewTranslation","Sun [abbreviated weekday]","",,"",6719,"Якш",1
6773,"ViewTranslation","Mon [abbreviated weekday]","",,"",6719,"Душ",1
6774,"ViewTranslation","Tue [abbreviated weekday]","",,"",6719,"Сеш",1
6775,"ViewTranslation","Wed [abbreviated weekday]","",,"",6719,"Чор",1
6776,"ViewTranslation","Thu [abbreviated weekday]","",,"",6719,"Пай",1
6777,"ViewTranslation","Fri [abbreviated weekday]","",,"",6719,"Жум",1
6778,"ViewTranslation","Sat [abbreviated weekday]","",,"",6719,"Шан",1
6779,"ViewTranslation","January [month]","",,"",6719,"Январь",1
6780,"ViewTranslation","February [month]","",,"",6719,"Февраль",1
6781,"ViewTranslation","March [month]","",,"",6719,"Март",1
6782,"ViewTranslation","April [month]","",,"",6719,"Апрель",1
6783,"ViewTranslation","May [month]","",,"",6719,"Май",1
6784,"ViewTranslation","June [month]","",,"",6719,"Июнь",1
6785,"ViewTranslation","July [month]","",,"",6719,"Июль",1
6786,"ViewTranslation","August [month]","",,"",6719,"Август",1
6787,"ViewTranslation","September [month]","",,"",6719,"Сентябрь",1
6788,"ViewTranslation","October [month]","",,"",6719,"Октябрь",1
6789,"ViewTranslation","November [month]","",,"",6719,"Ноябрь",1
6790,"ViewTranslation","December [month]","",,"",6719,"Декабрь",1
6791,"ViewTranslation","Jan [abbreviated month]","",,"",6719,"Янв",1
6792,"ViewTranslation","Feb [abbreviated month]","",,"",6719,"Фев",1
6793,"ViewTranslation","Mar [abbreviated month]","",,"",6719,"Мар",1
6794,"ViewTranslation","Apr [abbreviated month]","",,"",6719,"Апр",1
6795,"ViewTranslation","May [abbreviated month]","",,"",6719,"Май",1
6796,"ViewTranslation","Jun [abbreviated month]","",,"",6719,"Июн",1
6797,"ViewTranslation","Jul [abbreviated month]","",,"",6719,"Июл",1
6798,"ViewTranslation","Aug [abbreviated month]","",,"",6719,"Авг",1
6799,"ViewTranslation","Sep [abbreviated month]","",,"",6719,"Сен",1
6800,"ViewTranslation","Oct [abbreviated month]","",,"",6719,"Окт",1
6801,"ViewTranslation","Nov [abbreviated month]","",,"",6719,"Ноя",1
6802,"ViewTranslation","Dec [abbreviated month]","",,"",6719,"Дек",1
6803,"ViewTranslation","Sunday [weekday]","",,"",6751,"Chủ nhật ",1
6804,"ViewTranslation","Monday [weekday]","",,"",6751,"Thứ hai ",1
6805,"ViewTranslation","Tuesday [weekday]","",,"",6751,"Thứ ba ",1
6806,"ViewTranslation","Wednesday [weekday]","",,"",6751,"Thứ tư ",1
6807,"ViewTranslation","Thursday [weekday]","",,"",6751,"Thứ năm ",1
6808,"ViewTranslation","Friday [weekday]","",,"",6751,"Thứ sáu ",1
6809,"ViewTranslation","Saturday [weekday]","",,"",6751,"Thứ bảy ",1
6810,"ViewTranslation","Sun [abbreviated weekday]","",,"",6751,"Cn ",1
6811,"ViewTranslation","Mon [abbreviated weekday]","",,"",6751,"Th 2 ",1
6812,"ViewTranslation","Tue [abbreviated weekday]","",,"",6751,"Th 3 ",1
6813,"ViewTranslation","Wed [abbreviated weekday]","",,"",6751,"Th 4 ",1
6814,"ViewTranslation","Thu [abbreviated weekday]","",,"",6751,"Th 5 ",1
6815,"ViewTranslation","Fri [abbreviated weekday]","",,"",6751,"Th 6 ",1
6816,"ViewTranslation","Sat [abbreviated weekday]","",,"",6751,"Th 7 ",1
6817,"ViewTranslation","January [month]","",,"",6751,"Tháng một",1
6818,"ViewTranslation","February [month]","",,"",6751,"Tháng hai",1
6819,"ViewTranslation","March [month]","",,"",6751,"Tháng ba",1
6820,"ViewTranslation","April [month]","",,"",6751,"Tháng tư",1
6821,"ViewTranslation","May [month]","",,"",6751,"Tháng năm",1
6822,"ViewTranslation","June [month]","",,"",6751,"Tháng sáu",1
6823,"ViewTranslation","July [month]","",,"",6751,"Tháng bảy",1
6824,"ViewTranslation","August [month]","",,"",6751,"Tháng tám",1
6825,"ViewTranslation","September [month]","",,"",6751,"Tháng chín",1
6826,"ViewTranslation","October [month]","",,"",6751,"Tháng mười",1
6827,"ViewTranslation","November [month]","",,"",6751,"Tháng mười một",1
6828,"ViewTranslation","December [month]","",,"",6751,"Tháng mười hai",1
6829,"ViewTranslation","Jan [abbreviated month]","",,"",6751,"Thg 1",1
6830,"ViewTranslation","Feb [abbreviated month]","",,"",6751,"Thg 2",1
6831,"ViewTranslation","Mar [abbreviated month]","",,"",6751,"Thg 3",1
6832,"ViewTranslation","Apr [abbreviated month]","",,"",6751,"Thg 4",1
6833,"ViewTranslation","May [abbreviated month]","",,"",6751,"Thg 5",1
6834,"ViewTranslation","Jun [abbreviated month]","",,"",6751,"Thg 6",1
6835,"ViewTranslation","Jul [abbreviated month]","",,"",6751,"Thg 7",1
6836,"ViewTranslation","Aug [abbreviated month]","",,"",6751,"Thg 8",1
6837,"ViewTranslation","Sep [abbreviated month]","",,"",6751,"Thg 9",1
6838,"ViewTranslation","Oct [abbreviated month]","",,"",6751,"Thg 10",1
6839,"ViewTranslation","Nov [abbreviated month]","",,"",6751,"Thg 11",1
6840,"ViewTranslation","Dec [abbreviated month]","",,"",6751,"Thg 12",1
6841,"ViewTranslation","Sunday [weekday]","",,"",6911,"Dîmegne",1
6842,"ViewTranslation","Monday [weekday]","",,"",6911,"Londi",1
6843,"ViewTranslation","Tuesday [weekday]","",,"",6911,"Mårdi",1
6844,"ViewTranslation","Wednesday [weekday]","",,"",6911,"Merkidi",1
6845,"ViewTranslation","Thursday [weekday]","",,"",6911,"Djudi",1
6846,"ViewTranslation","Friday [weekday]","",,"",6911,"Vinrdi",1
6847,"ViewTranslation","Saturday [weekday]","",,"",6911,"Semdi",1
6848,"ViewTranslation","Sun [abbreviated weekday]","",,"",6911,"Dîm",1
6849,"ViewTranslation","Mon [abbreviated weekday]","",,"",6911,"Lon",1
6850,"ViewTranslation","Tue [abbreviated weekday]","",,"",6911,"Mår",1
6851,"ViewTranslation","Wed [abbreviated weekday]","",,"",6911,"Mer",1
6852,"ViewTranslation","Thu [abbreviated weekday]","",,"",6911,"Dju",1
6853,"ViewTranslation","Fri [abbreviated weekday]","",,"",6911,"Vin",1
6854,"ViewTranslation","Sat [abbreviated weekday]","",,"",6911,"Sem",1
6855,"ViewTranslation","January [month]","",,"",6911,"Djanvî",1
6856,"ViewTranslation","February [month]","",,"",6911,"Fevrî",1
6857,"ViewTranslation","March [month]","",,"",6911,"Måss",1
6858,"ViewTranslation","April [month]","",,"",6911,"Avri",1
6859,"ViewTranslation","May [month]","",,"",6911,"May",1
6860,"ViewTranslation","June [month]","",,"",6911,"Djun",1
6861,"ViewTranslation","July [month]","",,"",6911,"Djulete",1
6862,"ViewTranslation","August [month]","",,"",6911,"Awousse",1
6863,"ViewTranslation","September [month]","",,"",6911,"Setimbe",1
6864,"ViewTranslation","October [month]","",,"",6911,"Octôbe",1
6865,"ViewTranslation","November [month]","",,"",6911,"Nôvimbe",1
6866,"ViewTranslation","December [month]","",,"",6911,"Decimbe",1
6867,"ViewTranslation","Jan [abbreviated month]","",,"",6911,"Dja",1
6868,"ViewTranslation","Feb [abbreviated month]","",,"",6911,"Fev",1
6869,"ViewTranslation","Mar [abbreviated month]","",,"",6911,"Mås",1
6870,"ViewTranslation","Apr [abbreviated month]","",,"",6911,"Avr",1
6871,"ViewTranslation","May [abbreviated month]","",,"",6911,"May",1
6872,"ViewTranslation","Jun [abbreviated month]","",,"",6911,"Djn",1
6873,"ViewTranslation","Jul [abbreviated month]","",,"",6911,"Djl",1
6874,"ViewTranslation","Aug [abbreviated month]","",,"",6911,"Awo",1
6875,"ViewTranslation","Sep [abbreviated month]","",,"",6911,"Set",1
6876,"ViewTranslation","Oct [abbreviated month]","",,"",6911,"Oct",1
6877,"ViewTranslation","Nov [abbreviated month]","",,"",6911,"Nôv",1
6878,"ViewTranslation","Dec [abbreviated month]","",,"",6911,"Dec",1
6879,"ViewTranslation","Sunday [weekday]","",,"",7078,"Cawe",1
6880,"ViewTranslation","Monday [weekday]","",,"",7078,"Mvulo",1
6881,"ViewTranslation","Tuesday [weekday]","",,"",7078,"Lwesibini",1
6882,"ViewTranslation","Wednesday [weekday]","",,"",7078,"Lwesithathu",1
6883,"ViewTranslation","Thursday [weekday]","",,"",7078,"Lwesine",1
6884,"ViewTranslation","Friday [weekday]","",,"",7078,"Lwesihlanu",1
6885,"ViewTranslation","Saturday [weekday]","",,"",7078,"Mgqibelo",1
6886,"ViewTranslation","Sun [abbreviated weekday]","",,"",7078,"Caw",1
6887,"ViewTranslation","Mon [abbreviated weekday]","",,"",7078,"Mvu",1
6888,"ViewTranslation","Tue [abbreviated weekday]","",,"",7078,"Bin",1
6889,"ViewTranslation","Wed [abbreviated weekday]","",,"",7078,"Tha",1
6890,"ViewTranslation","Thu [abbreviated weekday]","",,"",7078,"Sin",1
6891,"ViewTranslation","Fri [abbreviated weekday]","",,"",7078,"Hla",1
6892,"ViewTranslation","Sat [abbreviated weekday]","",,"",7078,"Mgq",1
6893,"ViewTranslation","January [month]","",,"",7078,"Janyuwari",1
6894,"ViewTranslation","February [month]","",,"",7078,"Februwari",1
6895,"ViewTranslation","March [month]","",,"",7078,"Matshi",1
6896,"ViewTranslation","April [month]","",,"",7078,"Epreli",1
6897,"ViewTranslation","May [month]","",,"",7078,"Meyi",1
6898,"ViewTranslation","June [month]","",,"",7078,"Juni",1
6899,"ViewTranslation","July [month]","",,"",7078,"Julayi",1
6900,"ViewTranslation","August [month]","",,"",7078,"Agasti",1
6901,"ViewTranslation","September [month]","",,"",7078,"Septemba",1
6902,"ViewTranslation","October [month]","",,"",7078,"Okthoba",1
6903,"ViewTranslation","November [month]","",,"",7078,"Novemba",1
6904,"ViewTranslation","December [month]","",,"",7078,"Disemba",1
6905,"ViewTranslation","Jan [abbreviated month]","",,"",7078,"Jan",1
6906,"ViewTranslation","Feb [abbreviated month]","",,"",7078,"Feb",1
6907,"ViewTranslation","Mar [abbreviated month]","",,"",7078,"Mat",1
6908,"ViewTranslation","Apr [abbreviated month]","",,"",7078,"Epr",1
6909,"ViewTranslation","May [abbreviated month]","",,"",7078,"Mey",1
6910,"ViewTranslation","Jun [abbreviated month]","",,"",7078,"Jun",1
6911,"ViewTranslation","Jul [abbreviated month]","",,"",7078,"Jul",1
6912,"ViewTranslation","Aug [abbreviated month]","",,"",7078,"Aga",1
6913,"ViewTranslation","Sep [abbreviated month]","",,"",7078,"Sep",1
6914,"ViewTranslation","Oct [abbreviated month]","",,"",7078,"Okt",1
6915,"ViewTranslation","Nov [abbreviated month]","",,"",7078,"Nov",1
6916,"ViewTranslation","Dec [abbreviated month]","",,"",7078,"Dis",1
6917,"ViewTranslation","Sunday [weekday]","",,"",7324,"זונטיק",1
6918,"ViewTranslation","Monday [weekday]","",,"",7324,"מאָנטיק",1
6919,"ViewTranslation","Tuesday [weekday]","",,"",7324,"דינסטיק",1
6920,"ViewTranslation","Wednesday [weekday]","",,"",7324,"מיטװאָך",1
6921,"ViewTranslation","Thursday [weekday]","",,"",7324,"דאָנערשטיק",1
6922,"ViewTranslation","Friday [weekday]","",,"",7324,"פֿרײַטיק",1
6923,"ViewTranslation","Saturday [weekday]","",,"",7324,"שבת",1
6924,"ViewTranslation","Sun [abbreviated weekday]","",,"",7324,"זונ'",1
6925,"ViewTranslation","Mon [abbreviated weekday]","",,"",7324,"מאָנ'",1
6926,"ViewTranslation","Tue [abbreviated weekday]","",,"",7324,"דינ'",1
6927,"ViewTranslation","Wed [abbreviated weekday]","",,"",7324,"מיט'",1
6928,"ViewTranslation","Thu [abbreviated weekday]","",,"",7324,"דאָנ'",1
6929,"ViewTranslation","Fri [abbreviated weekday]","",,"",7324,"פֿרײַ'",1
6930,"ViewTranslation","Sat [abbreviated weekday]","",,"",7324,"שבת",1
6931,"ViewTranslation","January [month]","",,"",7324,"יאַנואַר",1
6932,"ViewTranslation","February [month]","",,"",7324,"פֿעברואַר",1
6933,"ViewTranslation","March [month]","",,"",7324,"מאַרץ",1
6934,"ViewTranslation","April [month]","",,"",7324,"אַפּריל",1
6935,"ViewTranslation","May [month]","",,"",7324,"מײַ",1
6936,"ViewTranslation","June [month]","",,"",7324,"יוני",1
6937,"ViewTranslation","July [month]","",,"",7324,"יולי",1
6938,"ViewTranslation","August [month]","",,"",7324,"אױגסט",1
6939,"ViewTranslation","September [month]","",,"",7324,"סעפּטעמבער",1
6940,"ViewTranslation","October [month]","",,"",7324,"אָקטאָבער",1
6941,"ViewTranslation","November [month]","",,"",7324,"נaָװעמבער",1
6942,"ViewTranslation","December [month]","",,"",7324,"דצמבר",1
6943,"ViewTranslation","Jan [abbreviated month]","",,"",7324,"יאַנ'",1
6944,"ViewTranslation","Feb [abbreviated month]","",,"",7324,"פֿעב'",1
6945,"ViewTranslation","Mar [abbreviated month]","",,"",7324,"מאַר'",1
6946,"ViewTranslation","Apr [abbreviated month]","",,"",7324,"אַפּר'",1
6947,"ViewTranslation","May [abbreviated month]","",,"",7324,"מײַ",1
6948,"ViewTranslation","Jun [abbreviated month]","",,"",7324,"יונ'",1
6949,"ViewTranslation","Jul [abbreviated month]","",,"",7324,"יול'",1
6950,"ViewTranslation","Aug [abbreviated month]","",,"",7324,"אױג'",1
6951,"ViewTranslation","Sep [abbreviated month]","",,"",7324,"סעפּ'",1
6952,"ViewTranslation","Oct [abbreviated month]","",,"",7324,"אָקט'",1
6953,"ViewTranslation","Nov [abbreviated month]","",,"",7324,"נאָװ'",1
6954,"ViewTranslation","Dec [abbreviated month]","",,"",7324,"דעצ'",1
6955,"ViewTranslation","Sunday [weekday]","",,"",7484,"星期日",1
6956,"ViewTranslation","Monday [weekday]","",,"",7484,"星期一",1
6957,"ViewTranslation","Tuesday [weekday]","",,"",7484,"星期二",1
6958,"ViewTranslation","Wednesday [weekday]","",,"",7484,"星期三",1
6959,"ViewTranslation","Thursday [weekday]","",,"",7484,"星期四",1
6960,"ViewTranslation","Friday [weekday]","",,"",7484,"星期五",1
6961,"ViewTranslation","Saturday [weekday]","",,"",7484,"星期六",1
6962,"ViewTranslation","Sun [abbreviated weekday]","",,"",7484,"日",1
6963,"ViewTranslation","Mon [abbreviated weekday]","",,"",7484,"一",1
6964,"ViewTranslation","Tue [abbreviated weekday]","",,"",7484,"二",1
6965,"ViewTranslation","Wed [abbreviated weekday]","",,"",7484,"三",1
6966,"ViewTranslation","Thu [abbreviated weekday]","",,"",7484,"四",1
6967,"ViewTranslation","Fri [abbreviated weekday]","",,"",7484,"五",1
6968,"ViewTranslation","Sat [abbreviated weekday]","",,"",7484,"六",1
6969,"ViewTranslation","January [month]","",,"",7484,"一月",1
6970,"ViewTranslation","February [month]","",,"",7484,"二月",1
6971,"ViewTranslation","March [month]","",,"",7484,"三月",1
6972,"ViewTranslation","April [month]","",,"",7484,"四月",1
6973,"ViewTranslation","May [month]","",,"",7484,"五月",1
6974,"ViewTranslation","June [month]","",,"",7484,"六月",1
6975,"ViewTranslation","July [month]","",,"",7484,"七月",1
6976,"ViewTranslation","August [month]","",,"",7484,"八月",1
6977,"ViewTranslation","September [month]","",,"",7484,"九月",1
6978,"ViewTranslation","October [month]","",,"",7484,"十月",1
6979,"ViewTranslation","November [month]","",,"",7484,"十一月",1
6980,"ViewTranslation","December [month]","",,"",7484,"十二月",1
6981,"ViewTranslation","Jan [abbreviated month]","",,"",7484," 1月",1
6982,"ViewTranslation","Feb [abbreviated month]","",,"",7484," 2月",1
6983,"ViewTranslation","Mar [abbreviated month]","",,"",7484," 3月",1
6984,"ViewTranslation","Apr [abbreviated month]","",,"",7484," 4月",1
6985,"ViewTranslation","May [abbreviated month]","",,"",7484," 5月",1
6986,"ViewTranslation","Jun [abbreviated month]","",,"",7484," 6月",1
6987,"ViewTranslation","Jul [abbreviated month]","",,"",7484," 7月",1
6988,"ViewTranslation","Aug [abbreviated month]","",,"",7484," 8月",1
6989,"ViewTranslation","Sep [abbreviated month]","",,"",7484," 9月",1
6990,"ViewTranslation","Oct [abbreviated month]","",,"",7484,"10月",1
6991,"ViewTranslation","Nov [abbreviated month]","",,"",7484,"11月",1
6992,"ViewTranslation","Dec [abbreviated month]","",,"",7484,"12月",1
6993,"ViewTranslation","Sunday [weekday]","",,"",7594,"Sonto",1
6994,"ViewTranslation","Monday [weekday]","",,"",7594,"Msombuluko",1
6995,"ViewTranslation","Tuesday [weekday]","",,"",7594,"Lwesibili",1
6996,"ViewTranslation","Wednesday [weekday]","",,"",7594,"Lwesithathu",1
6997,"ViewTranslation","Thursday [weekday]","",,"",7594,"Lwesine",1
6998,"ViewTranslation","Friday [weekday]","",,"",7594,"Lwesihlanu",1
6999,"ViewTranslation","Saturday [weekday]","",,"",7594,"Mgqibelo",1
7000,"ViewTranslation","Sun [abbreviated weekday]","",,"",7594,"Son",1
7001,"ViewTranslation","Mon [abbreviated weekday]","",,"",7594,"Mso",1
7002,"ViewTranslation","Tue [abbreviated weekday]","",,"",7594,"Bil",1
7003,"ViewTranslation","Wed [abbreviated weekday]","",,"",7594,"Tha",1
7004,"ViewTranslation","Thu [abbreviated weekday]","",,"",7594,"Sin",1
7005,"ViewTranslation","Fri [abbreviated weekday]","",,"",7594,"Hla",1
7006,"ViewTranslation","Sat [abbreviated weekday]","",,"",7594,"Mgq",1
7007,"ViewTranslation","January [month]","",,"",7594,"Januwari",1
7008,"ViewTranslation","February [month]","",,"",7594,"Februwari",1
7009,"ViewTranslation","March [month]","",,"",7594,"Mashi",1
7010,"ViewTranslation","April [month]","",,"",7594,"Apreli",1
7011,"ViewTranslation","May [month]","",,"",7594,"Meyi",1
7012,"ViewTranslation","June [month]","",,"",7594,"Juni",1
7013,"ViewTranslation","July [month]","",,"",7594,"Julayi",1
7014,"ViewTranslation","August [month]","",,"",7594,"Agasti",1
7015,"ViewTranslation","September [month]","",,"",7594,"Septemba",1
7016,"ViewTranslation","October [month]","",,"",7594,"Okthoba",1
7017,"ViewTranslation","November [month]","",,"",7594,"Novemba",1
7018,"ViewTranslation","December [month]","",,"",7594,"Disemba",1
7019,"ViewTranslation","Jan [abbreviated month]","",,"",7594,"Jan",1
7020,"ViewTranslation","Feb [abbreviated month]","",,"",7594,"Feb",1
7021,"ViewTranslation","Mar [abbreviated month]","",,"",7594,"Mas",1
7022,"ViewTranslation","Apr [abbreviated month]","",,"",7594,"Apr",1
7023,"ViewTranslation","May [abbreviated month]","",,"",7594,"Mey",1
7024,"ViewTranslation","Jun [abbreviated month]","",,"",7594,"Jun",1
7025,"ViewTranslation","Jul [abbreviated month]","",,"",7594,"Jul",1
7026,"ViewTranslation","Aug [abbreviated month]","",,"",7594,"Aga",1
7027,"ViewTranslation","Sep [abbreviated month]","",,"",7594,"Sep",1
7028,"ViewTranslation","Oct [abbreviated month]","",,"",7594,"Okt",1
7029,"ViewTranslation","Nov [abbreviated month]","",,"",7594,"Nov",1
7030,"ViewTranslation","Dec [abbreviated month]","",,"",7594,"Dis",1
END_OF_DATA
  end  
end
